#include <avr/io.h>


void ADC_Init(int canal, int div, int resol);

void ADC_Stop();

unsigned ADC_Read(int canal);

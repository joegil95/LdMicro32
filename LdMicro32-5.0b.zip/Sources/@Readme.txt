
Pour compiler les sources de Micro Ladder 4 avec Visual C++ Express 10:
(D�velopp� en C via l'API de Windows, sans MFC)

1)
Attention:
Avant de pouvoir compiler le projet, il faut g�n�rer plusieurs fichiers avec les scripts perl (.pl) fournis:
(Installer un logiciel perl comme strwberry perl)
Generation de la table des messages en diverses langues dans lang-tables.h:
	perl lang-tables.pl > lang-tables.h
Copier alors lang-tables.h dans les sources du projet

Generation de helptext.cpp:
	perl txt2c.pl > helptext.cpp
Copier alors helptext.cpp dans les sources du projet

NB: pour modifier les fichiers lang-xx.txt, qui sont truff�s d'erreurs (en tous cas le fr), les ouvrir
avec word (en mode windows) et les enregistrer sous txt en choisissant des fins de lignes de type LF seulement.


2)
Cr�er une solution (projet) VC++ de type Win 32 et y copier tous les fichiers .cpp et .h
sauf ldinterpret.c ainsi que les fichiers .rec et .ico dans les ressources

Modifier les options du projet de la fa�on suivante:

G�n�ral -> Jeu de caract�res = Non d�fini (Sauf si japonais, russe ?)
Linkeur -> Entr�e -> d�pendances suppl�mentaires: ajouter user32.lib gdi32.lib comctl32.lib comdlg32.lib advapi32.lib
C/C++ -> Pr�processeur -> d�finitions: ajouter _CRT_SECURE_NO_WARNINGS (d�sactiver warnings deprecated) 
et LDLANG_FR (langue FR pour les menus et boites) et NOMINMAX (pour un pb avec std::max)
C/C++ -> Ent�tes pr�compil�s: sans ent�tes pr�compil�

NB: mettre mcutable.h dans les sources (et non dans les ent�tes) sinon sa modification n'entra�ne pas
automatiquement la recompilation des fichiers affect�s

3)
Cr�er un autre projet (dans la m�me solution ou autre) de type Win 32 console et y placer
ldinterpret.c et intcode.h pour g�n�rer ldinterpret.exe
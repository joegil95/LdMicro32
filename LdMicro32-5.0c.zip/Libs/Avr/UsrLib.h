
#include <avr/io.h>

// standard functions to implement in C

uint16_t swap(uint16_t var);
int16_t opposite(int16_t var);


uint8_t bcd2bin(uint8_t var);
uint8_t bin2bcd(uint8_t var);



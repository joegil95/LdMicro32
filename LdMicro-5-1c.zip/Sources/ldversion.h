#ifndef __LDMICRO_VER_H__
#define __LDMICRO_VER_H__

#define LDMICRO_VER_STR           "5.1.0.c"
                              //   |     |
#define LDMICRO_VER_MAJOR (4) // <-+     |
#define LDMICRO_VER_MINOR (4) //         |
#define LDMICRO_VER_PATCH (3) //         |
#define LDMICRO_VER_TWEAK (0) // <-------+

#endif

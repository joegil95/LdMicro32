#ifndef __LANG_H_
#define __LANG_H_

const char *_(const char *in);

#endif //__LANG_H_


#include <htc.h>

unsigned UART_GetPrescaler(long fcpu, long bds);
void UART_Init(long bauds);
	 
void UART_Transmit(unsigned char data);
unsigned char UART_Receive(void);
void UART_Write(char *string);

unsigned char UART_Transmit_Ready(void);
unsigned char UART_Transmit_Busy(void);
unsigned char UART_Receive_Avail(void);

	 
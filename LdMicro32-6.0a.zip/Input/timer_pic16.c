// Timer includes		(don't modify comment)

// Init Timer			(don't modify comment)

#ifdef TIMER0
	TMR0= TIM_CNT;
	PSA= TIM_PSA;
	T0CS= 0;
	OPTION_REGbits.PS= TIM_PS;
#endif

#ifdef TIMER1
	CCPR1L= TIM_CNT & 0xFF;
	CCPR1H= TIM_CNT >> 8;
	TMR1L= 0;
	TMR1H= 0;
	T1CON= TIM_PS;
	CCP1CON= 0x0B;			// Compare mode, reset TMR1 on trigger

#if defined(LDTARGET_pic16f1512) || defined(LDTARGET_pic16f1516) || defined(LDTARGET_pic16f1527)
	TMR1GE = 1;
#endif
#endif

// Timer function		(don't modify comment)

void PlcWait()
	{
#ifndef T0IF
	#define T0IF TMR0IF
#endif

	#ifdef TIMER0
	for (long sdiv= 0 ; sdiv < TIM_SOFTDIV ; sdiv++)
		{
		while(T0IF == 0);

		TMR0= TIM_CNT;			// Reprogram TMR0 : Top= 256 - TMR0 + 1
		T0IF= 0;
		} 
	#endif

	#ifdef TIMER1
	for (long sdiv= 0 ; sdiv < TIM_SOFTDIV ; sdiv++)
		{
		while(CCP1IF == 0);

		CCP1IF= 0;
		} 
	#endif
	}
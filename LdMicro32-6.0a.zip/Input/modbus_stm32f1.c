
// Modbus Uart receive Interrupt handler
void USART%d_Handler(void)
    {
	// Check if interrupt on receive
	if (USART_GetITStatus(USART%d, USART_IT_RXNE))
        {
        // Put received data into internal buffer
		LibUartInt_InsertBuffer(USART%d, USART%d->DR);

        LibModbus_SetTicks();
		}
    }


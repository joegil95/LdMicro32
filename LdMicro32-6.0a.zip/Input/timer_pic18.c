// Timer includes		(don't modify comment)

// Init Timer			(don't modify comment)

#ifdef TIMER0
	T0CON= TIM_PS;
	TMR0H= 0;
	TMR0L= TIM_CNT;
	T08BIT= 1;
	PSA= TIM_PSA;	
	TMR0ON= 1;
#endif

#ifdef TIMER1
	T1CON= TIM_PS;
	TMR1L= 0;
	TMR1H= 0;	
	CCPR1L= TIM_CNT & 0xFF;
	CCPR1H= TIM_CNT >> 8;
	CCP1CON= 0x0B;			// Compare mode, reset TMR1 on trigger
#endif

// Timer function		(don't modify comment)

void PlcWait()
	{
#ifndef T0IF
	#define T0IF TMR0IF
#endif

	#ifdef TIMER0
	for (long sdiv= 0 ; sdiv < TIM_SOFTDIV ; sdiv++)
		{
		while(T0IF == 0);

		TMR0H= 0;
		TMR0L= TIM_CNT;
		T0IF= 0;
		} 
	#endif

	#ifdef TIMER1
	for (long sdiv= 0 ; sdiv < TIM_SOFTDIV ; sdiv++)
		{
		while(CCP1IF == 0);

		CCP1IF= 0;
		} 
	#endif
	}
// Timer includes	(don't modify comment)
#include "stm32f10x_tim.h"
#include "Lib_timer.h"

// Init Timer	(don't modify comment)

LibTimer_Init(TIM%d, 1000, %u);
LibTimer_Interrupts(TIM%d, ENABLE);
NVIC_SetPriority(TIM%d_IRQn, 0);

// Timer function		(don't modify comment)
// Cycle Timer handler
void TIM%d_Handler() 
	{
	if(TIM_GetITStatus(TIM%d, TIM_IT_Update) != RESET)		// check interrupt
		{
		Next_Cycle = 1;
		TIM_ClearITPendingBit(TIM%d, TIM_IT_Update);		// acknowledge interrupt
		}
	}

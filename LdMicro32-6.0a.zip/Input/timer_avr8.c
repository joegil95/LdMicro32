// Timer includes		(don't modify comment)

// Init Timer			(don't modify comment)

#ifdef TIMER0
	#ifdef OCR0A
		TCCR0A= (1 << WGM01);		// WGM01=1, WGM00=0 // CTC mode
		TCCR0B= TIM_CS;				// WGM02=0, CS
		OCR0A= TIM_CNT;
	#else							// By JG6
		TCCR0= (1 << WGM01);		// WGM01=1, WGM00=0 // CTC mode
		TCCR0 |= TIM_CS;			// CS
		OCR0= TIM_CNT;
	#endif
#endif

#ifdef TIMER1
	TCCR1A= 0x00;					// WGM11=0, WGM10=0
	TCCR1B= (1 << WGM12) | TIM_CS;	// WGM13=0, WGM12=1
	// The high byte must be written before the low byte in OCR1A
	OCR1AH= (TIM_CNT >> 8) & 0xFF;
	OCR1AL= TIM_CNT & 0xFF;
#endif

// Timer function		(don't modify comment)

void PlcWait()
	{
	#ifdef TIMER0
	for (long sdiv= 0 ; sdiv < TIM_SOFTDIV ; sdiv++)
		{
		#ifdef TIFR0
		while((TIFR0 & (1 << OCF0A)) == 0);
		TIFR0 |= (1 << OCF0A);
		#else
		while((TIFR & (1 << OCF0)) == 0);
		TIFR |= (1 << OCF0);
		#endif
		} 
	#endif

	#ifdef TIMER1
	for (long sdiv= 0 ; sdiv < TIM_SOFTDIV ; sdiv++)
		{
		#ifdef TIFR1
		while((TIFR1 & (1 << OCF1A)) == 0);
		TIFR1 |= (1 << OCF1A);
		#else
		while((TIFR & (1 << OCF1A)) == 0);
		TIFR |= (1 << OCF1A);
		#endif
		} 
	#endif
	}
#include <avr/io.h>

// Librairie AtMega

#include "ladder.h"
#include "UsrLib.h"

static unsigned char dummy= 0;

// port config
// port= 'A' to 'L', mask= bit selection
// mode= 1 (free input), 2 (pullup input), 3 (output)
void Gpio_conf(char port, int mask, char mode)
	{
	if (mode == 1)		// inputs without pull-ups
		{
		switch(port)
			{
			case 'A': DDRA &= ~mask; PORTA &= ~mask; break;
			case 'B': DDRB &= ~mask; PORTB &= ~mask; break;
			case 'C': DDRC &= ~mask; PORTC &= ~mask; break;
			case 'D': DDRD &= ~mask; PORTD &= ~mask; break;
			case 'E': DDRE &= ~mask; PORTE &= ~mask; break;
			case 'F': DDRF &= ~mask; PORTF &= ~mask; break;
			case 'G': DDRG &= ~mask; PORTG &= ~mask; break;
			case 'H': DDRH &= ~mask; PORTH &= ~mask; break;
			case 'I': DDRI &= ~mask; PORTI &= ~mask; break;
			case 'J': DDRJ &= ~mask; PORTJ &= ~mask; break;
			case 'K': DDRK &= ~mask; PORTK &= ~mask; break;
			case 'L': DDRL &= ~mask; PORTL &= ~mask; break;
			}
		}

	if (mode == 2)		// inputs with pull-ups
		{
		switch(port)
			{
			case 'A': DDRA &= ~mask; PORTA |= mask; break;
			case 'B': DDRB &= ~mask; PORTB |= mask; break;
			case 'C': DDRC &= ~mask; PORTC |= mask; break;
			case 'D': DDRD &= ~mask; PORTD |= mask; break;
			case 'E': DDRE &= ~mask; PORTE |= mask; break;
			case 'F': DDRF &= ~mask; PORTF |= mask; break;
			case 'G': DDRG &= ~mask; PORTG |= mask; break;
			case 'H': DDRH &= ~mask; PORTH |= mask; break;
			case 'I': DDRI &= ~mask; PORTI |= mask; break;
			case 'J': DDRJ &= ~mask; PORTJ |= mask; break;
			case 'K': DDRK &= ~mask; PORTK |= mask; break;
			case 'L': DDRL &= ~mask; PORTL |= mask; break;	
			}
		}

	if (mode == 3)		// outputs
		{
		switch(port)
			{
			case 'A': DDRA |= mask; break;
			case 'B': DDRB |= mask; break;
			case 'C': DDRC |= mask; break;
			case 'D': DDRD |= mask; break;
			case 'E': DDRE |= mask; break;
			case 'F': DDRF |= mask; break;
			case 'G': DDRG |= mask; break;
			case 'H': DDRH |= mask; break;
			case 'I': DDRI |= mask; break;
			case 'J': DDRJ |= mask; break;
			case 'K': DDRK |= mask; break;
			case 'L': DDRL |= mask; break;
			}
		}
	}

// read port input bit
// port= 'A' to 'L', mask= (1 << bit)
int Gpio_readinput(char port, int mask)
	{
	int b= 0;

	switch(port)
		{
		case 'A': b= PINA & mask; break;
		case 'B': b= PINB & mask; break;
		case 'C': b= PINC & mask; break;
		case 'D': b= PIND & mask; break;
		case 'E': b= PINE & mask; break;
		case 'F': b= PINF & mask; break;
		case 'G': b= PING & mask; break;
		case 'H': b= PINH & mask; break;
		case 'I': b= PINI & mask; break;
		case 'J': b= PINJ & mask; break;
		case 'K': b= PINK & mask; break;
		case 'L': b= PINL & mask; break;
		}

	if (b) return 1;
	return 0;;
	}

// read port output bit
// port= 'A' to 'L', mask= (1 << bit)
int Gpio_readoutput(char port, int mask)
	{
	int b= 0;

	switch(port)
		{
		case 'A': b= PORTA & mask; break;
		case 'B': b= PORTB & mask; break;
		case 'C': b= PORTC & mask; break;
		case 'D': b= PORTD & mask; break;
		case 'E': b= PORTE & mask; break;
		case 'F': b= PORTF & mask; break;
		case 'G': b= PORTG & mask; break;
		case 'H': b= PORTH & mask; break;
		case 'I': b= PORTI & mask; break;
		case 'J': b= PORTJ & mask; break;
		case 'K': b= PORTK & mask; break;
		case 'L': b= PORTL & mask; break;
		}

	if (b) return 1;
	return 0;;
	}

// set port output bits
// port= 'A' to 'L', mask= bit selection
void Gpio_setoutputs(char port, int mask)
	{
	switch(port)
		{
		case 'A': PORTA |= mask; break;
		case 'B': PORTB |= mask; break;
		case 'C': PORTC |= mask; break;
		case 'D': PORTD |= mask; break;
		case 'E': PORTE |= mask; break;
		case 'F': PORTF |= mask; break;
		case 'G': PORTG |= mask; break;
		case 'H': PORTH |= mask; break;
		case 'I': PORTI |= mask; break;
		case 'J': PORTJ |= mask; break;
		case 'K': PORTK |= mask; break;
		case 'L': PORTL |= mask; break;
		}
	}

// reset port output bits
// port= 'A' to 'L', mask= bit selection
void Gpio_resetoutputs(char port, int mask)
	{
	switch(port)
		{
		case 'A': PORTA &= ~mask; break;
		case 'B': PORTB &= ~mask; break;
		case 'C': PORTC &= ~mask; break;
		case 'D': PORTD &= ~mask; break;
		case 'E': PORTE &= ~mask; break;
		case 'F': PORTF &= ~mask; break;
		case 'G': PORTG &= ~mask; break;
		case 'H': PORTH &= ~mask; break;
		case 'I': PORTI &= ~mask; break;
		case 'J': PORTJ &= ~mask; break;
		case 'K': PORTK &= ~mask; break;
		case 'L': PORTL &= ~mask; break;
		}
	}


// Read one byte in Eeprom
unsigned char EEPROM_Read(int address)
{
    while(EECR & (1 << EEWE))
        ; // attente fin operation precedente

    EEAR = address;
    EECR |= (1 << EERE); // octet transfere de l'EEPROM dans EEDR

    return EEDR;
}

// Write one byte in Eeprom
void EEPROM_Write(int address, unsigned char byte)
{
    while(EECR & (1 << EEWE))
        ; // attente fin operation precedente

    EEAR = address;
    EEDR = byte;
    EECR |= (1 << EEMWE);
    EECR |= (1 << EEWE);
}

// swap bits from higher to lower
uint16_t swap(uint16_t var)
{
    int      i = 0;
    uint16_t res = 0;

    for(i = 0; i < 16; i++)
        if(var & (1 << i))
            res |= (1 << (15 - i));

    return res;
}

// take the opposite
int16_t opposite(int16_t var)
{
    return (-var);
}

// convert BCD to DEC
uint8_t bcd2bin(uint8_t var)
{
    uint8_t res = 10 * (var / 16) + (var % 16);

    return res;
}

// convert DEC to BCD
uint8_t bin2bcd(uint8_t var)
{
    uint8_t res = 16 * (var / 10) + (var % 10);

    return res;
}

unsigned char u__delay1;
unsigned char u__delay2;
unsigned      u__delay;
unsigned      m__delay;

//
// this function lasts 4 * (u__delay1-1) + 5 cycles ~= 4 * u__delay1 cycles
// u__delay1 must be > 0
//
void us_delay1() // no parameter because takes time to manage from stack => use global variable
{
    __asm__(
        "cli\n" // 1 cycle      // disable interrupts

        "lds r0, u__delay1\n" // 2 cycles     // r0 register is free to use in gccavr
        "loop1:"
        "nop\n"        // 1 cycle
        "dec r0\n"     // 1 cycle
        "brne loop1\n" // 2 cycles or 1 cycle at end

        "sei\n" // 1 cycle      // enable interrupts again
    );
}

//
// this function lasts about 32 * 4 * u__delay2 cycles
// u_delay2 must be > 0
//
void us_delay2() // no parameter because takes time to manage from stack => use global variable
{
    __asm__(
        "nop\n"      // 1 cycle
        "push r16\n" // 1 cycle

        "lds r0, u__delay2\n" // 2 cycles
        "ldi r16, 31\n"       // 1 cycle

        "loop2:"
        "nop\n"        // 1 cycle
        "dec r16\n"    // 1 cycle
        "brne loop2\n" // 2 cycles or 1 cycle at end   }
        "nop\n"        // 0 or 1 cycle                 } = 2 cycles

        "ldi r16, 31\n" // 1 cycle
        "dec r0\n"      // 1 cycle
        "brne loop2\n"  // 2 cycles or 1 cycle at end

        "pop r16\n" // 1 cycle
        "nop\n"     // 1 cycle
    );
}

void delay_ms(unsigned md)
{
    m__delay = md;
    /*
    while (m__delay--)          // works fine !
        {
        delay_us1(100);
        delay_us1(100);
        delay_us1(100);
        delay_us1(100);
        delay_us1(100);
        delay_us1(100);
        delay_us1(100);
        delay_us1(100);
        delay_us1(100);
        delay_us1(100);
        }
*/

    while(m__delay--) // works fine too !
    {
        delay_us2(1000);
    }
}

//-----------------------------------------------------------------------------
// Copyright 2021 Jos� GILLES
//
// This file is part of LDmicro32.
//
// LDmicro32 is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// LDmicro32 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

/* 
This code is used by Lad2C
*/

#ifdef USE_LONGS
	typedef long int integer;		// Use long variables
#else
	typedef short int integer;		// Use short variables
#endif

typedef char String[50];
typedef char Name[256];
typedef char Line[1000];

#define		NUL		0
#define		ESC		27

// Mcus
#define STM32F40X_LQFP_144			101
#define STM32F10X_LQFP_48			111

#define AT90USB647_TQFP_64			201
#define ATMEGA8_PDIP_28				202
#define ATMEGA8_TQFP_32				203
#define ATMEGA16_PDIP_40			204
#define ATMEGA16_TQFP_44			205
#define ATMEGA16U4_TQFP_44			206
#define ATMEGA32_PDIP_40			207
#define ATMEGA32_TQFP_44			208
#define ATMEGA32U4_TQFP_44			209
#define ATMEGA48_PDIP_28			210
#define ATMEGA64_TQFP_64			211
#define ATMEGA88_PDIP_28			212
#define ATMEGA128_TQFT_64			213
#define ATMEGA162_PDIP_40			214
#define ATMEGA164_PDIP_40			215
#define ATMEGA168_PDIP_28			216
#define ATMEGA324_PDIP_40			217
#define ATMEGA328_PDIP_28			218
#define ATMEGA328_TQFP_32			219
#define ATMEGA640_TQFP_100			220
#define ATMEGA644_PDIP_40			221
#define ATMEGA1280_TQFP_100			222
#define ATMEGA1284_PDIP_40			223
#define ATMEGA2560_TQFP_100			224
#define ATTINY10_SOT_6				250
#define ATTINY85_PDIP_8				251
#define ATTINY85_QFN_20				252

#define PIC16F72_PDIP_28			301
#define PIC16F88_PDIP_18			302
#define PIC16F628PDIP_18			303
#define PIC16F819PDIP_18			304
#define PIC16F876_PDIP_28			305
#define PIC16F877_PDIP_40			306
#define PIC16F886_PDIP_28			307
#define PIC16F887_PDIP_40			308
#define PIC16F887_TQFP_44			309
#define PIC16F1512_PDIP_28			310
#define PIC16F1516_PDIP_28			311
#define PIC16F1527_TQF_64			312
#define PIC16F1824_PDIP_14			313
#define PIC16F1827_PDIP_28			314

#define PIC18F458_PDIP_40			401
#define PIC18F4520_PDIP_40			402
#define PIC18F4550_PDIP_40			403


int getVarfromList(char * vname);
int getIOfromList(char * ioname);

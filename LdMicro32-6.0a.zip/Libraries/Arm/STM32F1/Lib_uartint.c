/**
 * Copyright (C) Tilen Majerle 2014, and JG 2021
 */


#include "lib_uartint.h"
#include "misc.h"

#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_usart.h"

#include "lib_gpio.h"


// Internal buffers
#define LIBUARTINT_BUFFER_SIZE 				32

uint8_t LibUsartInt1_Buffer[LIBUARTINT_BUFFER_SIZE];
uint8_t LibUsartInt2_Buffer[LIBUARTINT_BUFFER_SIZE];
uint8_t LibUsartInt3_Buffer[LIBUARTINT_BUFFER_SIZE];

LibUartInt_t LibUsartInt1 = {LibUsartInt1_Buffer, LIBUARTINT_BUFFER_SIZE, 0, 0, 0, 0};
LibUartInt_t LibUsartInt2 = {LibUsartInt2_Buffer, LIBUARTINT_BUFFER_SIZE, 0, 0, 0, 0};
LibUartInt_t LibUsartInt3 = {LibUsartInt3_Buffer, LIBUARTINT_BUFFER_SIZE, 0, 0, 0, 0};


/**
 * @brief  Initialize USART peripheral and corresponding pins
 * @param  USARTx = USART1 to USART3
 * @param  baudrate = standard baudrate value from 1200 to 115200
 * @param  datalen = USART_WordLength_8b or USART_WordLength_9b
 * @param  parity = USART_Parity_No or USART_Parity_Even or USART_Parity_Odd
 * @param  stops = USART_StopBits_1 or USART_StopBits_2
 * @retval None
 */
void LibUartInt_Init(USART_TypeDef* USARTx, uint32_t baudrate, uint16_t datalen, uint16_t parity, uint16_t stops)
    {
	USART_InitTypeDef   USART_InitStruct;
    NVIC_InitTypeDef	NVIC_InitStruct;

	USART_InitStruct.USART_BaudRate = baudrate;
    USART_InitStruct.USART_HardwareFlowControl = LibUart_HardwareFlowControl_None;  // no flow control
	USART_InitStruct.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;                    // full-duplex TX + RX
	USART_InitStruct.USART_Parity = parity;
	USART_InitStruct.USART_StopBits = stops;
	USART_InitStruct.USART_WordLength = datalen;

	if (USARTx == USART1)
        {
        // Enable clocks for USART1
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
        // Init pins
        LibGPIO_Conf(GPIOA, GPIO_PIN_9,  GPIO_Mode_AF_PP, GPIO_Speed_50MHz);            // TX
        LibGPIO_Conf(GPIOA, GPIO_PIN_10, GPIO_Mode_IN_FLOATING, GPIO_Speed_50MHz);      // RX

        NVIC_InitStruct.NVIC_IRQChannel = USART1_IRQn;      // Interrupts
        }

	if (USARTx == USART2)
        {
        // Enable clock for USART2
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
        // Init pins
        LibGPIO_Conf(GPIOA, GPIO_PIN_2,  GPIO_Mode_AF_PP, GPIO_Speed_50MHz);            // TX
        LibGPIO_Conf(GPIOA, GPIO_PIN_3, GPIO_Mode_IN_FLOATING, GPIO_Speed_50MHz);       // RX

        NVIC_InitStruct.NVIC_IRQChannel = USART2_IRQn;      // Interrupts
        }

	if (USARTx == USART3)
        {
        // Enable clock for USART3
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
        // Init pins
        LibGPIO_Conf(GPIOB, GPIO_PIN_10,  GPIO_Mode_AF_PP, GPIO_Speed_50MHz);           // TX
        LibGPIO_Conf(GPIOB, GPIO_PIN_11, GPIO_Mode_IN_FLOATING, GPIO_Speed_50MHz);      // RX

        NVIC_InitStruct.NVIC_IRQChannel = USART3_IRQn;      // Interrupts
        }

    // We are initialized
    LibUartInt_t* u = LibUartInt_GetUsart(USARTx);
    u->Initialized = 1;
	// Disable and Deinit
	USART_Cmd(USARTx, DISABLE);
	USART_DeInit(USARTx);

	// ReInit and Enable
	USART_Init(USARTx, &USART_InitStruct);
	USART_Cmd(USARTx, ENABLE);

    // Enable RX interrupt
	USART_ITConfig(USARTx, USART_IT_RXNE, ENABLE);

	// Initialize NVIC
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = LibUartInt_NVIC_PRIORITY;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = LibUartInt_GetSubPriority(USARTx);
	NVIC_Init(&NVIC_InitStruct);
    }


/**
 * @brief  Get character from UART (non blocking function)
 * @param  USARTx = USART1 to USART3
 * @retval Received character if any, or (int16_t) -1 if none
 */
int16_t LibUartInt_Getc(USART_TypeDef* USARTx)
    {
	int16_t c = -1;

	LibUartInt_t* u = LibUartInt_GetUsart(USARTx);

	// Check if we have any data in buffer
	if (u->Num > 0)
        {
		if (u->Out == u->Size)
			u->Out = 0;

		c = *(u->Buffer + u->Out);
		u->Out++;
		u->Num--;
        }
	return c;
    }


/**
 * @brief  Send character via UART
 * @param  USARTx = USART1 to USART3
 * @param  c = character to be send
 * @retval None
 */
void LibUartInt_Putc(USART_TypeDef* USARTx, volatile char c)
    {
	// Wait to be ready to send
	while (!(USARTx->SR & USART_FLAG_TXE));
	// Send data
	USARTx->DR = (uint16_t)(c & 0x01FF);
    }

/**
 * @brief  Send character via UART if possible (non blocking function)
 * @param  USARTx = USART1 to USART3
 * @param  c = character to be send
 * @retval 1 if done, 0 if not
 */
int16_t LibUartInt_Putchar(USART_TypeDef* USARTx, volatile char c)
    {
	if (USARTx->SR & USART_FLAG_TXE)        // If ready to send
        {
        USARTx->DR = (uint16_t)(c & 0x01FF);       // Send data
        return 1;
        }

    return 0;
    }

/**
 * @brief  Check if internal UART buffer is empty
 * @param  USARTx = USART1, USART2, USART3, UART4, UART5 or USART6
 * @retval false (0) if buffer not empty, true (> 0) if buffer empty
 */
uint8_t LibUartInt_BufferEmpty(USART_TypeDef* USARTx)
    {
	LibUartInt_t* u = LibUartInt_GetUsart(USARTx);
	return (u->Num == 0);
    }


/**
 * @brief  Check if internal UART buffer is full
 * @param  USARTx = USART1, USART2, USART3, UART4, UART5 or USART6
 * @retval false (0) if buffer not full, true (> 0) if fuffer full
 */
uint8_t LibUartInt_BufferFull(USART_TypeDef* USARTx)
    {
	LibUartInt_t* u = LibUartInt_GetUsart(USARTx);
	return (u->Num == u->Size);
    }


/**
 * @brief  Clear internal UART buffer
 * @param  USARTx = USART1, USART2, USART3, UART4, UART5 or USART6
 * @retval None
 */
void LibUartInt_ClearBuffer(USART_TypeDef* USARTx)
    {
	LibUartInt_t* u = LibUartInt_GetUsart(USARTx);

	u->Num = 0;
	u->In = 0;
	u->Out = 0;
    }


/**
 * Internal functions
 */
LibUartInt_t* LibUartInt_GetUsart(USART_TypeDef* USARTx)
    {
	LibUartInt_t* u;

	if (USARTx == USART1) u = &LibUsartInt1;
	if (USARTx == USART2) u = &LibUsartInt2;
	if (USARTx == USART3) u = &LibUsartInt3;

	return u;
    }

uint8_t LibUartInt_GetSubPriority(USART_TypeDef* USARTx)
    {
	uint8_t u;

	if (USARTx == USART1) u = 0;
	if (USARTx == USART2) u = 1;
	if (USARTx == USART3) u = 2;

	return u;
    }

void LibUartInt_InsertBuffer(USART_TypeDef* USARTx, uint8_t c)
    {
    LibUartInt_t* u= LibUartInt_GetUsart(USARTx);

	// Still available space in buffer
	if (u->Num < u->Size)
        {
		// Check overflow
		if (u->In == u->Size)
            {
			u->In = 0;
            }
		// Add to buffer
		u->Buffer[u->In] = c;
		u->In++;
		u->Num++;
        }
    }

/*
void USARTn_Handler(void)
    {
	// Check if interrupt on receive
	if (USART_GetITStatus(USARTn, USART_IT_RXNE))
        {
        //Put received data into internal buffer
		LibUartInt_INT_InsertBuffer(USARTn, USARTn->DR);
		}
    }
 */

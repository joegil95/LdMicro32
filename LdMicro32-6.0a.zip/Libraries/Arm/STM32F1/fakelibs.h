
#include <stdio.h>

char EEPROM_read(long address);
void EEPROM_write(long address, char data);
short EEPROM_read2(long address);
void EEPROM_write2(long address, short data);
long EEPROM_read4(long address);
void EEPROM_write4(long address, long data);

void LibModbus_Init(int uart, long speed, int timout);
int LibModbus_IntSend(unsigned char * data, int size);
int LibModbus_IntReceive(unsigned char * data);
int LibModbus_SendDone();
void LibModbus_Enable(int onoff);

/**
 * UART Library for STM32F1 with interrupts
 */

#ifndef LIBUART_H
#define LIBUART_H 250

/* C++ detection */
#ifdef __cplusplus
extern C {
#endif

/*
    U(S)ARTx    TX      RX

    USART1      PA9     PA10
    USART2      PA2     PA3
    USART3      PB10    PB11
*/

#include "stm32f10x.h"

#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_usart.h"

#include "lib_gpio.h"

// NVIC Global Priority
#define LibUartInt_NVIC_PRIORITY	0x06

typedef enum
    {
	LibUart_HardwareFlowControl_None = 0x0000,     // No flow control
	LibUart_HardwareFlowControl_RTS = 0x0100,      // RTS flow control
	LibUart_HardwareFlowControl_CTS = 0x0200,      // CTS flow control
	LibUart_HardwareFlowControl_RTS_CTS = 0x0300   // RTS and CTS flow controls
    } LibUart_HardwareFlowControl_t;


// Internal USART struct
typedef struct
    {
	uint8_t *Buffer;
	uint16_t Size;
	uint16_t Num;
	uint16_t In;
	uint16_t Out;
	uint8_t Initialized;
    } LibUartInt_t;


void LibUartInt_Init(USART_TypeDef* USARTx, uint32_t baudrate, uint16_t datalen, uint16_t parity, uint16_t stops);

void LibUartInt_Putc(USART_TypeDef* USARTx, volatile char c);
int16_t LibUartInt_Putchar(USART_TypeDef* USARTx, volatile char c);
int16_t LibUartInt_Getc(USART_TypeDef* USARTx);

uint8_t LibUartInt_BufferEmpty(USART_TypeDef* USARTx);
uint8_t LibUartInt_BufferFull(USART_TypeDef* USARTx);
void LibUartInt_ClearBuffer(USART_TypeDef* USARTx);

LibUartInt_t* LibUartInt_GetUsart(USART_TypeDef* USARTx);
uint8_t LibUartInt_GetSubPriority(USART_TypeDef* USARTx);
void LibUartInt_InsertBuffer(USART_TypeDef* USARTx, uint8_t c);

/**
 * interrupt handler on receive to be defined by user
 */
void USART1_Handler(void);
void USART2_Handler(void);
void USART3_Handler(void);

/* C++ detection */
#ifdef __cplusplus
}
#endif

#endif

/**
 * Copyright (C) JG 2019
 */

#include "Lib_usr.h"
#include "Lib_gpio.h"


// port config
// port= 'A' to 'C', mask= bit selection
// mode= 1 (free input), 2 (pullup input), 3 (output)
void Gpio_conf(char port, int mask, char mode)
	{
	if (mode == 1)		// inputs without pull-ups
		{
		switch(port)
			{
			case 'A': LibGPIO_Conf(GPIOA, mask, GPIO_Mode_IN_FLOATING, GPIO_Speed_2MHz); break;
			case 'B': LibGPIO_Conf(GPIOB, mask, GPIO_Mode_IN_FLOATING, GPIO_Speed_2MHz); break;
			case 'C': LibGPIO_Conf(GPIOC, mask, GPIO_Mode_IN_FLOATING, GPIO_Speed_2MHz); break;
			}
		}

	if (mode == 2)		// inputs with pull-ups
		{
		switch(port)
			{
			case 'A': LibGPIO_Conf(GPIOA, mask, GPIO_Mode_IPU, GPIO_Speed_2MHz); break;
			case 'B': LibGPIO_Conf(GPIOB, mask, GPIO_Mode_IPU, GPIO_Speed_2MHz); break;
			case 'C': LibGPIO_Conf(GPIOC, mask, GPIO_Mode_IPU, GPIO_Speed_2MHz); break;
			}
		}

	if (mode == 3)		// outputs
		{
		switch(port)
			{
			case 'A': LibGPIO_Conf(GPIOA, mask, GPIO_Mode_Out_PP, GPIO_Speed_2MHz); break;
			case 'B': LibGPIO_Conf(GPIOB, mask, GPIO_Mode_Out_PP, GPIO_Speed_2MHz); break;
			case 'C': LibGPIO_Conf(GPIOC, mask, GPIO_Mode_Out_PP, GPIO_Speed_2MHz); break;
			}
		}
	}

// read port input bit
// port= 'A' to 'C', mask= (1 << bit)
int Gpio_readinput(char port, int mask)
	{
	int b= 0;

	switch(port)
		{
		case 'A': b= GPIO_ReadInputDataBit(GPIOA, mask); break;
		case 'B': b= GPIO_ReadInputDataBit(GPIOB, mask); break;
		case 'C': b= GPIO_ReadInputDataBit(GPIOC, mask); break;
		}

	return b;
	}

// read port output bit
// port= 'A' to 'C', mask= (1 << bit)
int Gpio_readoutput(char port, int mask)
	{
	int b= 0;

	switch(port)
		{
		case 'A': b= GPIO_ReadOutputDataBit(GPIOA, mask); break;
		case 'B': b= GPIO_ReadOutputDataBit(GPIOB, mask); break;
		case 'C': b= GPIO_ReadOutputDataBit(GPIOC, mask); break;
		}

	return b;
	}

// set port output bits
// port= 'A' to 'C', mask= bit selection
void Gpio_setoutputs(char port, int mask)
	{
	switch(port)
		{
		case 'A': GPIO_SetBits(GPIOA, mask); break;
		case 'B': GPIO_SetBits(GPIOB, mask); break;
		case 'C': GPIO_SetBits(GPIOC, mask); break;
		}
	}

// reset port output bits
// port= 'A' to 'C', mask= bit selection
void Gpio_resetoutputs(char port, int mask)
	{
	switch(port)
		{
		case 'A': GPIO_ResetBits(GPIOA, mask); break;
		case 'B': GPIO_ResetBits(GPIOB, mask); break;
		case 'C': GPIO_ResetBits(GPIOC, mask); break;
		}
	}



// swap bits from higher to lower
uint16_t swap(uint16_t var)
{
    int      i = 0;
    uint16_t res = 0;

    for(i = 0; i < 16; i++)
        if(var & (1 << i))
            res |= (1 << (15 - i));

    return res;
}

// take the opposite
int16_t opposite(int16_t var)
{
    return (-var);
}

// convert BCD to DEC
uint8_t bcd2bin(uint8_t var)
{
    uint8_t res = 10 * (var / 16) + (var % 16);

    return res;
}

// convert DEC to BCD
uint8_t bin2bcd(uint8_t var)
{
    uint8_t res = 16 * (var / 10) + (var % 10);

    return res;
}

// delays in +/- �s
void delay_us(uint16_t us)
{
    uint32_t d = 7 * us / 2;

    for(; d > 0; d--)
        ;
}

// delays in +/- ms
void delay_ms(uint16_t ms)
{
    uint32_t d = 4000 * ms;

    for(; d > 0; d--)
        ;
}

/**
 * Copyright (C) JG 2021
 */

#include "stm32f10x.h"
#include "lib_modbus.h"

static char mdb_init= 0;
static char mdb_on= 0;
static char mdb_recvready= 0;
static int mdb_recvtimout= 10000;
static char mdb_sendready= 0;
static int mdb_sendcount= 0;
static unsigned long mdb_ticks= 0;
static unsigned long mdb_lasticks= 0;
static unsigned char * mdb_nextchar= 0;

static USART_TypeDef* USARTx= USART3;


/// NB:
/// Provide UARTx_Handler() for interrupt reception
///


// uart= USART number (1, 2, 3, 6)
// speed= USART speed (9600, 19200, ...)
// mode= write (1) or read (0)
// timout= receive timout (0 to use default value)
void LibModbus_Init(int uart, long speed, int timout)
    {
    if (mdb_init) return;

    if (timout != 0) mdb_recvtimout= timout;

    if (uart == 1) USARTx= USART1;
    if (uart == 2) USARTx= USART2;
    if (uart == 3) USARTx= USART3;

    /// Initialize USART at <speed> bauds, 8+1, E, 1
    LibUartInt_Init(USARTx, speed, USART_WordLength_9b, USART_Parity_Even, USART_StopBits_1);

    /// Initialize Timer 2 with interrupts
    LibTimer_Init(TIM2, 36, 10);            // Timer freq= 100 Khz if F = 72 MHz
    LibTimer_Interrupts(TIM2, ENABLE);

    mdb_init= 1;
    mdb_on= 1;
    }

// onoff= 1 to enable or 0 to disable Modbus sending and receiving
void LibModbus_Enable(int onoff)
    {
    if (! mdb_init) return;

    if (onoff)
        {
        LibTimer_Interrupts(TIM2, ENABLE);
        mdb_on= 1;
        }
    else
        {
        LibTimer_Interrupts(TIM2, DISABLE);
        mdb_on= 0;
        }

    LibUartInt_ClearBuffer(USARTx);
    }

// Check if send / receive is done
int LibModbus_SendDone()
    {
    if (! mdb_sendready) return 1;
    else return 0;
    }

// Generator= 0x1_A001= X^16+X^15+X^13+1
unsigned short LibModbus_Crc16(unsigned char *data, int len )
    {
	unsigned short crc = 0xFFFF;
	int i = 0;
	char j = 0;

	for(i= 0 ; i < len ; i++)
        {
		crc ^= data[i];

		for(j= 0 ; j < 8 ; j++ )
            {
			if(crc & 0x0001)
                {
				crc >>= 1;
				crc ^= 0xA001;
                }
			else
                {
				crc >>= 1;
                }
            }
        }

	return crc;
    }


// internal function
void LibModbus_SetTicks()
    {
    mdb_lasticks= mdb_ticks;
    }


// data= frame to send (must be global or static because sent under interrupt)
// size= number of bytes in frame (without CRC)
// CRC is added at the end of data[]
// returns > 0 if done or 0 if not
int LibModbus_IntSend(unsigned char * data, int size)
    {
    unsigned short crc;

    if (! mdb_on) return 0;         // Disabled
    if (mdb_sendready) return 0;        // Busy

    crc= LibModbus_Crc16(data, size);
    data[size]= (crc & 0xFF);
    data[size+1]= (crc >> 8) & 0xFF;        // No answer if bad CRC !

    mdb_sendcount= size+2;
    mdb_nextchar= data;
    mdb_sendready= 1;

    return mdb_sendcount;
    }


// data= receive buffer
// returns number of byte read (with CRC)
// returns 0 as long as no complete frame received
int LibModbus_IntReceive(unsigned char * data)
    {
    unsigned short crc;
    int16_t dat;
    int n= 0;

    if (! mdb_on) return 0;         // Disabled
    if (! mdb_recvready) return 0;      // No frame or not complete

    do
        {
        dat= LibUartInt_Getc(USARTx);       // get char from receive buffer
        if (dat != (int16_t) -1)
            {
            data[n]= dat & 0xFF;
            n++;
            }
        }
    while(dat != (int16_t) -1);

    if (n > 0)
        {
        crc= LibModbus_Crc16(data, n);
        if (crc != 0) n= 0;                 // Bad CRC => frame discarded
        }

    mdb_recvready= 0;

    return n;
    }


// Timer 2 Interrupt handler
void TIM2_Handler()
{
    static int cnt= 0;

    if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
    {
        mdb_ticks++;            // 1 ms = 100 ticks

        if (mdb_ticks < mdb_lasticks) mdb_lasticks= 0;           // If ticks Overflow
        if (mdb_ticks-mdb_lasticks > mdb_recvtimout)
            mdb_recvready= 1;                               // End of frame (dt > X ms)

        if (mdb_sendready)      // Data must be sent
            {
            if (LibUartInt_Putchar(USARTx, *mdb_nextchar))       // Try to send
                {
                mdb_nextchar++;
                cnt++;
                }

            if (cnt >= mdb_sendcount)
                {
                cnt= 0;
                mdb_sendcount= 0;
                mdb_sendready= 0;
                }
            }

        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);     // Acknowledge interrupt
    }
}

/*
// UART receive Interrupt handler
void USARTn_Handler(void)
    {
	// Check if interrupt on receive
	if (USART_GetITStatus(USARTn, USART_IT_RXNE))
        {
        // Put received data into internal buffer
		LibUartInt_InsertBuffer(USARTn, USARTn->DR);

        LibModbus_SetTicks();
		}
    }
*/

//-----------------------------------------------------------------------------
// Copyright 2021 Jos� GILLES
//
// This file is part of LDmicro32.
//
// LDmicro32 is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// LDmicro32 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

/* 
This code is used by Lad2C
*/

#include <stdio.h>

#include "common.h"


// Comment
typedef struct Comment
	{
	Name comment;					// Comment text
	}
Comment;


// Internal or external In/Out Relay
typedef struct Relay
	{
	char output;				// Last output value
	char mode;					// NF= 'F' or NO= 'O'
	char type;					// Internal variable= 'R', external input pin= 'X' or external output pin= 'Y'
	short pin;					// Associated pin if External (0 if Internal)
	char * bitptr;				// Current value (0 / 1)
	}
Relay;


// Internal or external Coil
typedef struct Coil
	{
	char output;				// Last output value
	char oldin;				// Previous input value
	char mode;					// Normal= 'N', Inverted= 'I', Set= 'S', Reset= 'R' or Trigger= 'T'
	char type;					// Internal variable= 'R' or external pin= 'Y'
	short pin;					// Associated pin if External (0 if Internal)
	char * bitptr;				// Current value (0 / 1)
	}
Coil;


// Rising Temporization
typedef struct Ton
	{
	char output;			// Last output value
	char oldin;				// Previous input value
	char running;
	integer limit;				// Temporization value
	integer * valptr;			// Current value
	}
Ton;


// Falling Temporization
typedef struct Tof
	{
	char output;			// Last output value
	char oldin;				// Previous input value
	char running;
	integer limit;				// Temporization value
	integer * valptr;			// Current value
	}
Tof;


typedef struct OneShot
	{
	char output;			// Last output value
	char oldin;				// Previous input value
	char type;				// Rising= 'R', Falling= 'F', Low= 'L'
	}
OneShot;


typedef struct Oscillator
	{
	char output;			// Last output value
	}
Oscillator;


// Counter
typedef struct Count
	{
	char output;			// Last output value
	char oldin;				// Previous input value
	char type;				// Up= 'U', Down= 'D', Cyclic= 'C', Cyclic reverse= 'R'
	char mode;				// Front '/', '\', '-', 'o' 	
	integer * begptr;			// Initial value
	integer * limptr;			// Limit value
	integer * valptr;			// Current value
	}
Count;


// Timer
typedef struct Timer
	{
	char output;			// Last output value
	char oldin;				// Previous input value
	char type;				// High= 'H', Low= 'L', Retentive High= 'U', Retentive Low= 'D', Cyclic= 'C'
	char running;
	integer * limptr;			// Limit value
	integer * valptr;			// Current value
	}
Timer;


// Res
// No structure : look at Timer / Count / Pwm Reset functions


// Quad-Encoder
typedef struct QuadEncoder
	{
	char output;			// Last output value
	char mode;				// Front '/', '\', '-', 'o' for Z input
	char oldB;				// Previous input B value
	char oldZ;				// Previous input Z value
	char * Aptr;			// Input A value
	char * Bptr;			// Input B value
	char * Zptr;			// Input Z value (Null if unused)
	integer revol;				// Count per revolution value
	integer * valptr;			// Current value of counter
	Coil * colptr;			// Ouput Coil (R / Y) or NULL if unused
	}
QuadEncoder;


// Pulser
typedef struct Pulser
	{
	char output;			// Last output value
	short pin;				// Output pin
	char stat;				// Current state 0 or 1
	integer repeat;			// Current repeat value
	integer duration;			// Current 1 / 0 duration
	integer * d1ptr;			// Duration of 1 pulses
	integer * d0ptr;			// Duration of 0 pulses
	integer * mulptr;			// Durations multiplier (> 0)
	integer * limptr;			// Limit repeat value (> 0)
	char * bitptr;			// Current value (0 / 1)
	}
Pulser;


// Formatted String
typedef struct FormatString
	{
	char output;			// Last output value
	char oldin;				// Previous input value
	integer index;				// Current index in string
	char * sptr;			// Source format string (like printf)
	char * dptr;			// Destination string
	integer * vptr;			// Variable usable in format string
	char * cptr;			// Variable to receive the next char in string
	}
FormatString;


// Shift register
typedef struct ShiftRegister
	{
	char output;			// Last output value
	char oldin;				// Previous input value
	integer size;				// Register size
	integer ** regptr;			// Register array
	}
ShiftRegister;


// Piecewise Linear Table
typedef struct PiecewiseLinear
	{
	char output;			// Last output value
	integer size;				// Table size
	integer * srceptr;			// Source variable (x)
	integer * destptr;			// Destination variable (y)
	integer * txptr;			// X values table
	integer * typtr;			// Y values table
	}
PiecewiseLinear;


// Look Up Table
typedef struct LookUp
	{
	char output;			// Last output value
	char type;				// Long values = 'L', char String= 'C'
	integer size;				// Table size
	integer * indptr;			// Index in table
	void * destptr;			// Destination variable
	void * tvptr;			// Values table or String
	}
LookUp;


// Persist (EEprom)
typedef struct Persist
	{
	char output;			// Last output value
	integer * varptr;			// Associated variable
	integer address;			// Eeprom address
	integer oldvar;			// Previouly saved value
	}
Persist;


// Modbus
typedef struct Modbus
	{
	char output;			// Last output value
	char oldin;				// Previous input value
	char init;				// 1 if initialze yet, 0 if not
	char running;
	}
Modbus;


// functions
char Master_Relay(char mast, char in);					// No structure

void Relay_Init(Relay * r, char nfno, char mod, short pin, char * bptr);
char Relay_Transfer(Relay * r, char mod, char in);

void Coil_Init(Coil * c, char typ, char mod, short pin, char * bptr);
char Coil_Transfer(Coil * c, char mod, char in);

void Ton_Init(Ton * t, integer * vptr, integer lim);			// passer lim en ptr (depuis v 4.4) Cf Thi
char Ton_Transfer(Ton * t, char in);

void Tof_Init(Tof * t, integer * vptr, integer lim);			// passer lim en ptr (depuis v 4.4) Cf Tlo
char Tof_Transfer(Tof * t, char in);

void OneShot_Init(OneShot * s, char typ);
char OneShot_Transfer(OneShot * s, char in);

void Oscillator_Init(Oscillator * s);
char Oscillator_Transfer(Oscillator * s, char in);

void Count_Init(Count * c, char typ, char mod, integer * bptr, integer * lptr, integer * vptr);
char Count_Transfer(Count * c, char in);
char Count_Reset(Count * c, char in);

void Timer_Init(Timer * c, char typ, integer * lptr, integer * vptr);		// limit is variable since v 4.4)
char Timer_Transfer(Timer * c, char in);
char Timer_Reset(Timer * c, char in);

void QuadEncoder_Init(QuadEncoder * c, char * aptr, char * bptr, char * zptr, char mod, integer rev, integer * vptr, Coil * cptr);
char QuadEncoder_Transfer(QuadEncoder * c, char in);

void Pulser_Init(Pulser * p, integer * d1ptr, integer * d0ptr, integer * mptr, integer * lptr, char * bptr);
char Pulser_Transfer(Pulser * p, char in);

void FormatString_Init(FormatString * s, char * sptr, char * dptr, integer * vptr, char * cptr);
char FormatString_Transfer(FormatString * s, char in);

void ShiftRegister_Init(ShiftRegister * s, integer siz, integer ** rptr);
char ShiftRegister_Transfer(ShiftRegister * s, char in);

void PiecewiseLinear_Init(PiecewiseLinear * p, integer siz, integer * dptr, integer * sptr, integer * xptr, integer * yptr);
char PiecewiseLinear_Transfer(PiecewiseLinear * p, char in);

void LookUp_Init(LookUp * l, char typ, int siz, void * dptr, integer * iptr, void * vptr);
char LookUp_Transfer(LookUp * l, char in);

void Persist_Init(Persist * p, integer * vptr, integer addr);
char Persist_Transfer(Persist * p, char in);

void Modbus_Init(Modbus * m, int uart, long speed, int timout);
char Modbus_Transfer(Modbus * m, LookUp * l, char mode, unsigned char * dataptr, integer * sizeptr, char in);


char Seg7_Convert(char * ptab, integer * pdest, integer index, char type, char out);
char Seg9_Convert(short * ptab, integer * pdest, integer index, char type, char out);
char Seg14_Convert(short * ptab, integer * pdest, integer index, char type, char out);
char Seg16_Convert(integer * ptab, integer * pdest, integer index, char type, char out);

// Arithmetic operations(No structure)
#define ShortCircuit(in) in

#define Move(dest, srce) dest= srce
#define Nega(dest, srce) dest= -srce
#define Not(dest, srce) dest= ~srce

#define Add(op1, op2) (op1 + op2)
#define Sub(op1, op2) (op1 - op2)
#define Mul(op1, op2) (op1 * op2)
#define Div(op1, op2) (op1 / op2)
#define Mod(op1, op2) (op1 % op2)

#define And(op1, op2) (op1 & op2)
#define Or(op1, op2) (op1 | op2)
#define Xor(op1, op2) (op1 ^ op2)
#define Shl(op1, k) (op1 << k)
#define Shr(op1, k) (op1 >> k)

integer Ssr(integer op1, int k, int n);
integer Rol(integer op1, int k, int n);
integer Ror(integer op1, int k, int n);
integer RevBits(integer op1, int n);
integer SwapBits(integer op1, int n);
integer Bin2Bcd(integer op1);
integer Bcd2Bin(integer op1);
integer BusTracer(integer op1, integer swap);

#define SetBit(op1, k) op1 |= (1 << k)
#define ClrBit(op1, k) op1 &= ~(1 << k)




////////// A COMPLETER



/**
 * AMD-AM2864BE EEPROM Library for STM32F4xx devices
 */

#define PAGESIZE 32	// nb d'octets par page


// Signaux de commande (4 bits)
#define		Pin_OE      GPIO_Pin_4	    // Output enable (sortie �C)
#define		Pin_CE		GPIO_Pin_5	    // Chip enable (sortie �C)
#define		Pin_WE		GPIO_Pin_6      // Write Enable (sortie �C)
#define		Pin_RB		GPIO_Pin_7      // Ready-Busy (entree �C)


// Fonctions de l'EEPROM
void LibEeprom_Init(GPIO_TypeDef * GPIOx, SPI_TypeDef * SPIx);

uint8_t LibEeprom_Read(uint16_t addr);
void LibEeprom_Write(uint16_t addr, uint8_t data);

void LibEeprom_PageWrite(uint8_t page, uint8_t *tabdata);
void LibEeprom_PageRead(uint8_t page, uint8_t *tabdata);




/**
 * Copyright (C) JG 2020
 */

#include <stdio.h>

#include "stm32f4xx.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_gpio.h"

#include "Lib_gpio.h"
#include "Lib_spi.h"
#include "Lib_eeprom.h"

GPIO_TypeDef * GPIO_Dat= NULL;      /// Port de donnees (8 bits poids fort)
GPIO_TypeDef * GPIO_Cmd= NULL;      /// Port de commande (4 bits)
SPI_TypeDef * SPI_Adr= NULL;        /// SPI d'adressage (8 bits)

/**
  * @brief  Configure Eeprom data and command Ports
  * @retval None
  */
void LibEeprom_Init(GPIO_TypeDef * GPIOx, SPI_TypeDef * SPIx)
	{
	GPIO_Dat= GPIOx;
	GPIO_Cmd= GPIOx;
	SPI_Adr= SPIx;

	/// configuration Port DATA 8 sorties
	LibGPIO_Conf(GPIOx, GPIO_Pin_Hig, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

    /// configuration Port CMD 3 sorties
    LibGPIO_Conf(GPIOx, Pin_OE | Pin_CE | Pin_WE, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);

    /// configuration Port CMD 1 entr�e
    LibGPIO_Conf(GPIOx, Pin_RB, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_2MHz);

    GPIO_SetBits(GPIOx, Pin_OE | Pin_CE | Pin_WE);  // sorties �tat haut

    /// configuration SPI
    LibSPI_Init(SPIx, LibSPI_DataSize_8b, SPI_BaudRatePrescaler_256);
	}


/**
  * @brief  Read data at some address in Eeprom
  * @param  Eeprom address 13 bits (0 to 8191)
  * @retval Read data (8 bits)
  */
uint8_t LibEeprom_Read(uint16_t addr)
	{
	uint16_t data = 0;

    if ((GPIO_Cmd == NULL) || (GPIO_Dat == NULL) || (SPI_Adr == NULL))  return 0;

	while (! GPIO_ReadInputDataBit(GPIO_Cmd, Pin_RB));      // attente ready

    LibSPI_Send(SPI_Adr, addr >> 5);	    // envoi 8 bits de poids fort = page addr
	LibSPI_Send(SPI_Adr, addr & 0x1F);	    // envoi 5 bits restants = offset addr
	Lib_delay(10000);	  		        // Lib_delay indispensable pour stabiliser l'adresse

    /// configuration Port DATA 8 entrees
    LibGPIO_Conf(GPIO_Dat, GPIO_Pin_Hig, GPIO_Mode_IN, GPIO_PuPd_NOPULL, GPIO_Speed_2MHz);

    GPIO_SetBits(GPIO_Cmd, Pin_CE);            // v�rification CE + OE + WE
    GPIO_SetBits(GPIO_Cmd, Pin_OE);
    GPIO_SetBits(GPIO_Cmd, Pin_WE);
    Lib_delay(50);

    GPIO_ResetBits(GPIO_Cmd, Pin_CE);          // desactivation CE + OE
	Lib_delay(50);
	GPIO_ResetBits(GPIO_Cmd, Pin_OE);
	Lib_delay(1000);

	data= GPIO_ReadInputData(GPIO_Dat);        // lecture data

    GPIO_SetBits(GPIO_Cmd, Pin_OE);            // reactivation OE + CE => fin
	Lib_delay(50);
	GPIO_SetBits(GPIO_Cmd, Pin_CE);
	Lib_delay(100);

	return (uint8_t) (data >> 8);
	}


/**
  * @brief  Write data at some address in Eeprom
  * @param  Eeprom address 13 bits (0 to 8191)
  * @param  Data to write (8 bits)
  * @retval None
  */
void LibEeprom_Write(uint16_t addr, uint8_t data)
	{
	if ((GPIO_Cmd == NULL) || (GPIO_Dat == NULL) || (SPI_Adr == NULL))  return;

    while (!GPIO_ReadInputDataBit(GPIO_Cmd, Pin_RB));      // attente ready

	LibSPI_Send(SPI_Adr, addr >> 5);        // envoi 8 bits de poids fort = page addr
	LibSPI_Send(SPI_Adr, addr & 0x1F);	    // envoi 5 bits restants = offset addr
	Lib_delay(10000);  			            // tempo indispensable pour stabiliser l'adresse

    LibGPIO_Conf(GPIO_Dat, GPIO_Pin_Hig, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz);
    GPIO_WriteHigh(GPIO_Dat, data);            // presentation data

    GPIO_SetBits(GPIO_Cmd, Pin_CE);            // v�rification CE + OE + WE
    GPIO_SetBits(GPIO_Cmd, Pin_OE);
    GPIO_SetBits(GPIO_Cmd, Pin_WE);
    Lib_delay(50);

    GPIO_ResetBits(GPIO_Cmd, Pin_CE);          // desactivation CE + WE
	Lib_delay(50);
	GPIO_ResetBits(GPIO_Cmd, Pin_WE);
	Lib_delay(100);

    GPIO_SetBits(GPIO_Cmd, Pin_WE); 	        // reactivation WE => ecriture data
	Lib_delay(100);

    GPIO_SetBits(GPIO_Cmd, Pin_CE);		    // reactivation CE => fin

    while (GPIO_ReadInputDataBit(GPIO_Cmd, Pin_RB));	    // attente validation ecriture RB = 0
	while (! GPIO_ReadInputDataBit(GPIO_Cmd, Pin_RB));	    // attente fin d'ecriture
	}


/**
  * @brief  Write some page of data (32 bytes) in Eeprom
  * @param  Eeprom page address 8 bits (0 to 255)
  * @param  Address of buffer containning data to write
  * @retval None
  */
void LibEeprom_PageWrite(uint8_t page, uint8_t *tabdata)
	{
	int i;

	for(i= 0 ; i < PAGESIZE ; i++)
	 	{
		LibEeprom_Write((page << 5) + i, tabdata[i]);
		}
	}


/**
  * @brief  Read some page of data (32 bytes) in Eeprom
  * @param  Eeprom page address 8 bits (0 to 255)
  * @param  Address of buffer to receive read data
  * @retval None
  */
void LibEeprom_PageRead(uint8_t page, uint8_t *tabdata)
	{
	int i;

	for(i= 0 ; i < PAGESIZE ; i++)
	 	{
		tabdata[i]= LibEeprom_Read((page << 5) + i);
		}
	}

/**
 * MODBUS Library for STM32F4 with interrupts
 */

#include "stm32f4xx.h"
#include "stm32f4xx_usart.h"
#include "stm32f4xx_tim.h"

#include "Lib_Uartint.h"
#include "Lib_Timer.h"

#include "misc.h"

// Public functions
void LibModbus_Init(int uart, long speed, int timout);
int LibModbus_IntSend(unsigned char * data, int size);
int LibModbus_IntReceive(unsigned char * data);
int LibModbus_SendDone();
void LibModbus_Enable(int onoff);

// Internal functions
unsigned short LibModbus_Crc16(unsigned char *data, int len );
void LibModbus_SetTicks();



/* MODBUS main Functions:

0x01    Read output Coils      Read 1 to 2000 bits of Coil status
        P1:     First Coil (2 bytes) starting at 0
        P2:     Nb of Coils (2 bytes)

        Answer:     0x01    1 byte= N   N or N+1 Bytes (to be even)
        Error:      0x81    1 Byte= 0x01 (Exception, function not supported)
                                    0x02 (Bad P1 or P1+P2)
                                    0x03 (Bad P2)
                                    0x04 (Internal read error)

0x02    Read bit Inputs        Read 1 to 2000 bits of Inputs
        P1:     First Input (2 bytes) starting at 0
        P2:     Nb of Inputs (2 bytes)

        Answer:     0x02    1 byte= N   N or N+1 Bytes (to be even)
        Error:      0x82    1 Byte= 0x01 (Exception, function not supported)
                                    0x02 (Bad P1 or P1+P2)
                                    0x03 (Bad P2)
                                    0x04 (Internal read error)

0x05    Write output Coil      Write 1 Coil On / Off
        P1:     Coil address (2 bytes) starting at 0
        P2:     Output value (2 bytes)  Off= 0x0000 / On= 0xFF00 (Others ignored)

        Answer:     0x05    2 bytes= address    2 bytes= value   (Echo of the request)
        Error:      0x85    1 Byte= 0x01 (Exception, function not supported)
                                    0x02 (Bad P1)
                                    0x03 (Bad P2)
                                    0x04 (Internal write error)

0x0F    Write output multiple Coils     Write multiple Coils On / Off
        P1:     Coil first address (2 bytes) starting at 0
        P2:     Nb of Coils (2 bytes) max= 1968
        P3:     Nb of following bytes containing ouput values (1 bit per Coil)
        P4:     Output values (N bytes)  Off= 0 / On= 1

        Answer:     0x0F    2 bytes= address    2 bytes= Nb
        Error:      0x85    1 Byte= 0x01 (Exception, function not supported)
                                    0x02 (Bad P3)
                                    0x03 (Bad P2)
                                    0x04 (Internal write error)

NB:     Errors codes always start with high bit at 1 (0x8X or 0xAX for instance)
*/

#include <htc.h>

#include "ladder.h"
#include "UsrLib.h"

unsigned char dummy= 0;


#ifndef USING_PORTA
	#define TRISA	dummy
	#define PORTA	dummy
#endif
#ifndef USING_PORTB
	#define TRISB	dummy
	#define PORTB	dummy
#endif
#ifndef USING_PORTC
	#define TRISC	dummy
	#define PORTC	dummy
#endif
#ifndef USING_PORTD
	#define TRISD	dummy
	#define PORTD	dummy
#endif
#ifndef USING_PORTE
	#define TRISE	dummy
	#define PORTE	dummy
#endif


// port config
// port= 'A' to 'E', mask= bit selection
// mode= 1 (free input), 2 (pullup input), 3 (output)
void Gpio_conf(char port, int mask, char mode)
	{
	if (mode == 1)		// inputs
		{
		switch(port)
			{
			case 'A': TRISA |= mask; break;
			case 'B': TRISB |= mask; break;
			case 'C': TRISC |= mask; break;
			case 'D': TRISD |= mask; break;
			case 'E': TRISE |= mask; break;
			}
		}

	if (mode == 2)		// inputs with pull-ups
		{
		if (port == 'B')
			{
			 nRBPU= 0;			// all pull-ups activated on port B
			}
		}

	if (mode == 3)		// outputs
		{
		switch(port)
			{
			case 'A': TRISA &= ~mask; PORTA &= ~mask; break;
			case 'B': TRISB &= ~mask; PORTB &= ~mask; break;
			case 'C': TRISC &= ~mask; PORTC &= ~mask; break;
			case 'D': TRISD &= ~mask; PORTD &= ~mask; break;
			case 'E': TRISE &= ~mask; PORTE &= ~mask; break;
			}
		}
	}

// read port input bit
// port= 'A' to 'L', mask= (1 << bit)
int Gpio_readinput(char port, int mask)
	{
	int b= 0;

	switch(port)
		{
		case 'A': b= PORTA & mask; break;
		case 'B': b= PORTB & mask; break;
		case 'C': b= PORTC & mask; break;
		case 'D': b= PORTD & mask; break;
		case 'E': b= PORTE & mask; break;
		}

	if (b) return 1;
	return 0;;
	}

// read port output bit
// port= 'A' to 'L', mask= (1 << bit)
int Gpio_readoutput(char port, int mask)
	{
	int b= 0;

	switch(port)
		{
		case 'A': b= PORTA & mask; break;
		case 'B': b= PORTB & mask; break;
		case 'C': b= PORTC & mask; break;
		case 'D': b= PORTD & mask; break;
		case 'E': b= PORTE & mask; break;
		}

	if (b) return 1;
	return 0;;
	}

// set port output bits
// port= 'A' to 'L', mask= bit selection
void Gpio_setoutputs(char port, int mask)
	{
	switch(port)
		{
		case 'A': PORTA |= mask; break;
		case 'B': PORTB |= mask; break;
		case 'C': PORTC |= mask; break;
		case 'D': PORTD |= mask; break;
		case 'E': PORTE |= mask; break;
		}
	}

// reset port output bits
// port= 'A' to 'L', mask= bit selection
void Gpio_resetoutputs(char port, int mask)
	{
	switch(port)
		{
		case 'A': PORTA &= ~mask; break;
		case 'B': PORTB &= ~mask; break;
		case 'C': PORTC &= ~mask; break;
		case 'D': PORTD &= ~mask; break;
		case 'E': PORTE &= ~mask; break;
		}
	}


#ifndef USING_PORTA
	#undef TRISA
	#undef PORTA
#endif
#ifndef USING_PORTB
	#undef TRISB
	#undef PORTB
#endif
#ifndef USING_PORTC
	#undef TRISC
	#undef PORTC
#endif
#ifndef USING_PORTD
	#undef TRISD
	#undef PORTD
#endif
#ifndef USING_PORTE
	#undef TRISE
	#undef PORTE
#endif


// swap bits from higher to lower
unsigned swap(unsigned var)
{
    int      i = 0;
    unsigned res = 0;

    for(i = 0; i < 16; i++)
        if(var & (1 << i))
            res |= (1 << (15 - i));

    return res;
}

// take the opposite
int opposite(int var)
{
    return (-var);
}

// convert BCD to DEC
unsigned char bcd2bin(unsigned char var)
{
    unsigned char res = 10 * (var / 16) + (var % 16);

    return res;
}

// convert DEC to BCD
unsigned char bin2bcd(unsigned char var)
{
    unsigned char res = 16 * (var / 10) + (var % 10);

    return res;
}

// set PORTA as digital IO instead of analogical by default
void setPortsBehaviour()
{
#if defined(LDTARGET_pic18f4520)
    // The GPIOs that can also be A/D inputs default to being A/D
    // inputs, so turn that around
    ADCON1 = (1 << 7) | // right-justify A/D result
             (0x0F << 0);  // all digital inputs
#endif
}

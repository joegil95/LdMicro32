
#include <htc.h>

#include "ladder.h"
#include "UartLib.h"

// Compute baud rate prescaler
unsigned UART_GetPrescaler(long fcpu, long bds)
	{
#if defined(LDTARGET_pic18f4XX0)
	long p=  (fcpu / 4) / bds;
#endif

#if defined(LDTARGET_pic18f458)
	long p=  (fcpu / 16) / bds;
#endif

    return (p-1);
    }

// Init UART : 8 bits, 1 stop, no parity
void UART_Init(long bauds)
	{
	unsigned prescal= UART_GetPrescaler(_XTAL_FREQ, bauds); 

	TRISC6= 1;		// Enable TX ; will be configured as I/ O by Uart
	TRISC7= 1;		// Enable RX ; will be configured as I/ O by Uart

#if defined(LDTARGET_pic18f458)
	SPBRG= prescal & 0xFF;	// Bds= Fosc / ( 16 * SPBRG+1) in high rate mode
#endif

#if defined(LDTARGET_pic18f4XX0)
	BAUDCON= 0;		// Reset BAUDCON register
	BRG16= 1;		// High rate mode
	SPBRGH= prescal >> 8;	// Set baud rate :
	SPBRG= prescal & 0xFF;	// Bds= Fosc / ( 4 * (SPBRGH:SPBRG+1)) in high rate mode
#endif

#if defined(LDTARGET_pic18f4550)
	RXDTP= 0;
#endif

	RCSTA= 0;		// Reset RCSTA register
	CREN= 1;		// Enable receiver
	SPEN= 1;		// Enable Uart

	TXSTA= 0;		// Reset TXTA register
	BRGH= 1;		// High rate mode
	TXEN= 1;		// Enable transmitter	
	}
	
	
void UART_Transmit(unsigned char data)
	{
    // Wait for empty transmit buffer
    while(TXIF == 0);
    // Send data
    TXREG= data;
	}

unsigned char UART_Receive(void)
	{
    // Wait for data to be received
    while(RCIF == 0);
    // Get and return received data
    return RCREG;
	}

unsigned char UART_Transmit_Ready(void)
	{
    return TXIF;
	}

unsigned char UART_Transmit_Busy(void)
	{
    return !TXIF;
	}

unsigned char UART_Receive_Avail(void)
	{
    return RCIF;
	}

void UART_Write(char *string)
	{
    int i= 0;

    while(string[i] != 0) 
		{
        UART_Transmit(string[i]);
        i++;
		}
	}
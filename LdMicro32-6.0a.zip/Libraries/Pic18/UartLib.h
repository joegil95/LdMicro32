
#include <htc.h>

#if (defined LDTARGET_pic18f4520) 
	#define LDTARGET_pic18f4XX0			// For PIC18F4520 or PIC18F4550
#endif

#if (defined LDTARGET_pic18f4550) 
	#define LDTARGET_pic18f4XX0			// For PIC18F4520 or PIC18F4550
#endif


unsigned UART_GetPrescaler(long fcpu, long bds);
void UART_Init(long bauds);
	 
void UART_Transmit(unsigned char data);
unsigned char UART_Receive(void);
void UART_Write(char *string);

unsigned char UART_Transmit_Ready(void);
unsigned char UART_Transmit_Busy(void);
unsigned char UART_Receive_Avail(void);

	 
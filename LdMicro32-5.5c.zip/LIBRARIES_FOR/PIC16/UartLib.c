#include "ladder.h"

#include "UartLib.h"

// Compute baud rate prescaler
unsigned UART_GetPrescaler(long fcpu, long bds)
	{
	long p=  (fcpu / 16) / bds;

    return (p-1);
    }

void UART_Init(long bauds)
{
	unsigned prescal= UART_GetPrescaler(_XTAL_FREQ, bauds); 

	// Truncate to 8 bit value
    SPBRG = prescal;	// Bds= Fosc / ( 16 * (SPBRG+1)) in high rate mode

    BRGH= 1;			// High rate mode
    TXEN= 1;			// Enable transmitter
    CREN= 1;			// Enable continuous receive
    SPEN= 1;			// Enable serial port
}

void UART_Transmit(unsigned char data)
{
    // Wait for empty transmit buffer
    while(!TRMT);
	// Send data
    TXREG = data;
}

unsigned char UART_Receive(void)
{
    // Wait for data to be received
    while(!RCIF); 
	// Get and return received data
    return RCREG;
}

unsigned char UART_Transmit_Ready(void)
{
    return TRMT;
}

unsigned char UART_Transmit_Busy(void)
{
    return !TRMT;
}

unsigned char UART_Receive_Avail(void)
{
    return RCIF;
}

void UART_Write(char *string)
{
    int i= 0;

    while(string[i] != 0) 
		{
        UART_Transmit(string[i]);
        i++;
		}
}


// Librairie STM32F4 pour EEPROM (factice)

#include "Lib_rom.h"


char Eeprom[4096];


// Fonction de lecture d'un octet
char EEPROM_read(long address)
	{
	char data= 0;

	if (address < 4096) data= Eeprom[address];
	return data;
	}

// Fonction d'�criture d'un octet
void EEPROM_write(long address, char data)
	{
	if (address < 4096) Eeprom[address]= data;
	}

// Fonction de lecture d'un mot
short EEPROM_read2(long address)
    {
    short data= 0;

    if (address < 4096)
        data= *((short *) address);
    return data;
    }

// Fonction d'�criture d'un double mot
void EEPROM_write2(long address, short data)
    {
    if (address < 4096)
        *((short *) address)= data;
    }

// Fonction de lecture d'un double mot
long EEPROM_read4(long address)
    {
    long data= 0;

    if (address < 4096)
        data= *((long *) address);
    return data;
    }

// Fonction d'�criture d'un double mot
void EEPROM_write4(long address, long data)
    {
    if (address < 4096)
        *((long *) address)= data;
    }
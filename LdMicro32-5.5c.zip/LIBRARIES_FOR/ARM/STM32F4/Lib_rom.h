
// Librairie STM32F4 pour EEPROM (factice)


// Fonction de lecture d'un octet
char EEPROM_read(long address);

// Fonction d'�criture d'un octet
void EEPROM_write(long address, char data);

// Fonction de lecture d'un mot
short EEPROM_read2(long address);

// Fonction d'�criture d'un double mot
void EEPROM_write2(long address, short data);

// Fonction de lecture d'un double mot
long EEPROM_read4(long address);

// Fonction d'�criture d'un double mot
void EEPROM_write4(long address, long data);

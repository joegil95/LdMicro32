/**
 * Copyright (C) JG 2018
 */


#include "Lib_usr.h"
#include "Lib_gpio.h"


// port config
// port= 'A' to 'H', mask= bit selection
// mode= 1 (free input), 2 (pullup input), 3 (output)
void Gpio_conf(char port, int mask, char mode)
	{
	if (mode == 1)		// inputs without pull-ups
		{
		switch(port)
			{
			case 'A': LibGPIO_Conf(GPIOA, mask, GPIO_Mode_IN, GPIO_PuPd_NOPULL, GPIO_Speed_2MHz); break;
			case 'B': LibGPIO_Conf(GPIOB, mask, GPIO_Mode_IN, GPIO_PuPd_NOPULL, GPIO_Speed_2MHz); break;
			case 'C': LibGPIO_Conf(GPIOC, mask, GPIO_Mode_IN, GPIO_PuPd_NOPULL, GPIO_Speed_2MHz); break;
			case 'D': LibGPIO_Conf(GPIOD, mask, GPIO_Mode_IN, GPIO_PuPd_NOPULL, GPIO_Speed_2MHz); break;
			case 'E': LibGPIO_Conf(GPIOE, mask, GPIO_Mode_IN, GPIO_PuPd_NOPULL, GPIO_Speed_2MHz); break;
			case 'F': LibGPIO_Conf(GPIOF, mask, GPIO_Mode_IN, GPIO_PuPd_NOPULL, GPIO_Speed_2MHz); break;
			case 'G': LibGPIO_Conf(GPIOG, mask, GPIO_Mode_IN, GPIO_PuPd_NOPULL, GPIO_Speed_2MHz); break;
			case 'H': LibGPIO_Conf(GPIOH, mask, GPIO_Mode_IN, GPIO_PuPd_NOPULL, GPIO_Speed_2MHz); break;
			}
		}

	if (mode == 2)		// inputs with pull-ups
		{
		switch(port)
			{
			case 'A': LibGPIO_Conf(GPIOA, mask, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_2MHz); break;
			case 'B': LibGPIO_Conf(GPIOB, mask, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_2MHz); break;
			case 'C': LibGPIO_Conf(GPIOC, mask, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_2MHz); break;
			case 'D': LibGPIO_Conf(GPIOD, mask, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_2MHz); break;
			case 'E': LibGPIO_Conf(GPIOE, mask, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_2MHz); break;
			case 'F': LibGPIO_Conf(GPIOF, mask, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_2MHz); break;
			case 'G': LibGPIO_Conf(GPIOG, mask, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_2MHz); break;
			case 'H': LibGPIO_Conf(GPIOH, mask, GPIO_Mode_IN, GPIO_PuPd_UP, GPIO_Speed_2MHz); break;
			}
		}

	if (mode == 3)		// outputs
		{
		switch(port)
			{
			case 'A': LibGPIO_Conf(GPIOA, mask, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz); break;
			case 'B': LibGPIO_Conf(GPIOB, mask, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz); break;
			case 'C': LibGPIO_Conf(GPIOC, mask, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz); break;
			case 'D': LibGPIO_Conf(GPIOD, mask, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz); break;
			case 'E': LibGPIO_Conf(GPIOE, mask, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz); break;
			case 'F': LibGPIO_Conf(GPIOF, mask, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz); break;
			case 'G': LibGPIO_Conf(GPIOG, mask, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz); break;
			case 'H': LibGPIO_Conf(GPIOH, mask, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_Speed_2MHz); break;
			}
		}
	}

// read port input bit
// port= 'A' to 'H', mask= (1 << bit)
int Gpio_readinput(char port, int mask)
	{
	int b= 0;

	switch(port)
		{
		case 'A': b= GPIO_ReadInputDataBit(GPIOA, mask); break;
		case 'B': b= GPIO_ReadInputDataBit(GPIOB, mask); break;
		case 'C': b= GPIO_ReadInputDataBit(GPIOC, mask); break;
		case 'D': b= GPIO_ReadInputDataBit(GPIOD, mask); break;
		case 'E': b= GPIO_ReadInputDataBit(GPIOE, mask); break;
		case 'F': b= GPIO_ReadInputDataBit(GPIOF, mask); break;
		case 'G': b= GPIO_ReadInputDataBit(GPIOG, mask); break;
		case 'H': b= GPIO_ReadInputDataBit(GPIOH, mask); break;
		}

	return b;
	}

// read port output bit
// port= 'A' to 'H', mask= (1 << bit)
int Gpio_readoutput(char port, int mask)
	{
	int b= 0;

	switch(port)
		{
		case 'A': b= GPIO_ReadOutputDataBit(GPIOA, mask); break;
		case 'B': b= GPIO_ReadOutputDataBit(GPIOB, mask); break;
		case 'C': b= GPIO_ReadOutputDataBit(GPIOC, mask); break;
		case 'D': b= GPIO_ReadOutputDataBit(GPIOD, mask); break;
		case 'E': b= GPIO_ReadOutputDataBit(GPIOE, mask); break;
		case 'F': b= GPIO_ReadOutputDataBit(GPIOF, mask); break;
		case 'G': b= GPIO_ReadOutputDataBit(GPIOG, mask); break;
		case 'H': b= GPIO_ReadOutputDataBit(GPIOH, mask); break;
		}

	return b;
	}

// set port output bits
// port= 'A' to 'H', mask= bit selection
void Gpio_setoutputs(char port, int mask)
	{
	switch(port)
		{
		case 'A': GPIO_SetBits(GPIOA, mask); break;
		case 'B': GPIO_SetBits(GPIOB, mask); break;
		case 'C': GPIO_SetBits(GPIOC, mask); break;
		case 'D': GPIO_SetBits(GPIOD, mask); break;
		case 'E': GPIO_SetBits(GPIOE, mask); break;
		case 'F': GPIO_SetBits(GPIOF, mask); break;
		case 'G': GPIO_SetBits(GPIOG, mask); break;
		case 'H': GPIO_SetBits(GPIOH, mask); break;
		}
	}

// reset port output bits
// port= 'A' to 'H', mask= bit selection
void Gpio_resetoutputs(char port, int mask)
	{
	switch(port)
		{
		case 'A': GPIO_ResetBits(GPIOA, mask); break;
		case 'B': GPIO_ResetBits(GPIOB, mask); break;
		case 'C': GPIO_ResetBits(GPIOC, mask); break;
		case 'D': GPIO_ResetBits(GPIOD, mask); break;
		case 'E': GPIO_ResetBits(GPIOE, mask); break;
		case 'F': GPIO_ResetBits(GPIOF, mask); break;
		case 'G': GPIO_ResetBits(GPIOG, mask); break;
		case 'H': GPIO_ResetBits(GPIOH, mask); break;
		}
	}


// swap bits from higher to lower
uint16_t swap(uint16_t var)
	{
    int i= 0;
    uint16_t res= 0;

    for (i= 0 ; i < 16 ; i++)
    	if (var & (1 << i)) res |= (1 << (15-i));

    return res;
    }

// take the opposite
int16_t opposite(int16_t var)
	{
    return (-var);
    }

// convert BCD to DEC
uint8_t bcd2bin(uint8_t var)
	{
    uint8_t res= 10*(var/16)+(var%16);

    return res;
    }

// convert DEC to BCD    
uint8_t bin2bcd(uint8_t var)
	{
    uint8_t res= 16*(var/10)+(var%10);

    return res;
    }

// delays in +/- �s
void delay_us(uint16_t us)
	 {
	 uint32_t d= 10 *us/2;

	 for ( ; d > 0 ; d--);
	 }

// delays in +/- ms
void delay_ms(uint16_t ms)
	 {
	 uint32_t d= 6000*ms;

	 for ( ; d > 0 ; d--);
	 }

#include <avr/io.h>

int  SPI_GetPrescaler(long fcpu, long fspi);
void SPI_Init(char division);
char SPI_Send(char tx);

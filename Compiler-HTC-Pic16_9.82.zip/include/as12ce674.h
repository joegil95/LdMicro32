#ifndef _ASPIC_H_
#warning Header file as12ce674.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS12CE674_H_
#define _AS12CE674_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define IRP                            BANKMASK(STATUS), 7
#define RP0                            BANKMASK(STATUS), 5
#define RP1                            BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
GPIO                                   equ 0005h
#define GP0                            BANKMASK(GPIO), 0
#define GP1                            BANKMASK(GPIO), 1
#define GP2                            BANKMASK(GPIO), 2
#define GP3                            BANKMASK(GPIO), 3
#define GP4                            BANKMASK(GPIO), 4
#define GP5                            BANKMASK(GPIO), 5
#define SDA                            BANKMASK(GPIO), 6
#define SCL                            BANKMASK(GPIO), 7
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define GPIF                           BANKMASK(INTCON), 0
#define INTF                           BANKMASK(INTCON), 1
#define T0IF                           BANKMASK(INTCON), 2
#define GPIE                           BANKMASK(INTCON), 3
#define INTE                           BANKMASK(INTCON), 4
#define T0IE                           BANKMASK(INTCON), 5
#define PEIE                           BANKMASK(INTCON), 6
#define GIE                            BANKMASK(INTCON), 7
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define ADIF                           BANKMASK(PIR1), 6
#ifndef _LIB_BUILD
#endif
ADRES                                  equ 001Eh
ADCON0                                 equ 001Fh
#define ADON                           BANKMASK(ADCON0), 0
#define GO_nDONE                       BANKMASK(ADCON0), 2
#define GO_DONE                        BANKMASK(ADCON0), 2
#define CHS0                           BANKMASK(ADCON0), 3
#define CHS1                           BANKMASK(ADCON0), 4
#define ADCS0                          BANKMASK(ADCON0), 6
#define ADCS1                          BANKMASK(ADCON0), 7
#define nDONE                          BANKMASK(ADCON0), 2
#define GO                             BANKMASK(ADCON0), 2
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA                            BANKMASK(OPTION_REG), 3
#define T0SE                           BANKMASK(OPTION_REG), 4
#define T0CS                           BANKMASK(OPTION_REG), 5
#define INTEDG                         BANKMASK(OPTION_REG), 6
#define nGPPU                          BANKMASK(OPTION_REG), 7
#define PS0                            BANKMASK(OPTION_REG), 0
#define PS1                            BANKMASK(OPTION_REG), 1
#define PS2                            BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRIS_REG                               equ 0085h
TRISIO                                 equ 0085h
#define TRIS0                          BANKMASK(TRIS), 0
#define TRIS1                          BANKMASK(TRIS), 1
#define TRIS2                          BANKMASK(TRIS), 2
#define TRIS3                          BANKMASK(TRIS), 3
#define TRIS4                          BANKMASK(TRIS), 4
#define TRIS5                          BANKMASK(TRIS), 5
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define ADIE                           BANKMASK(PIE1), 6
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nPOR                           BANKMASK(PCON), 1
#ifndef _LIB_BUILD
#endif
OSCCAL                                 equ 008Fh
#define CALSLW                         BANKMASK(OSCCAL), 2
#define CALFST                         BANKMASK(OSCCAL), 3
#define CAL0                           BANKMASK(OSCCAL), 4
#define CAL1                           BANKMASK(OSCCAL), 5
#define CAL2                           BANKMASK(OSCCAL), 6
#define CAL3                           BANKMASK(OSCCAL), 7
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 009Fh
#define PCFG0                          BANKMASK(ADCON1), 0
#define PCFG1                          BANKMASK(ADCON1), 1
#define PCFG2                          BANKMASK(ADCON1), 2
#ifndef _LIB_BUILD
#endif

#endif
#endif

#ifndef _CASPIC_H_
#warning Header file cas10f200.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS10F200_H_
#define _CAS10F200_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define GPWUF_bit                      BANKMASK(STATUS), 7
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
OSCCAL                                 equ 0005h
#define FOSC4_bit                      BANKMASK(OSCCAL), 0
#define CAL0_bit                       BANKMASK(OSCCAL), 1
#define CAL1_bit                       BANKMASK(OSCCAL), 2
#define CAL2_bit                       BANKMASK(OSCCAL), 3
#define CAL3_bit                       BANKMASK(OSCCAL), 4
#define CAL4_bit                       BANKMASK(OSCCAL), 5
#define CAL5_bit                       BANKMASK(OSCCAL), 6
#define CAL6_bit                       BANKMASK(OSCCAL), 7
#ifndef _LIB_BUILD
#endif
GPIO                                   equ 0006h
#define GP0_bit                        BANKMASK(GPIO), 0
#define GP1_bit                        BANKMASK(GPIO), 1
#define GP2_bit                        BANKMASK(GPIO), 2
#define GP3_bit                        BANKMASK(GPIO), 3
#ifndef _LIB_BUILD
#endif

#endif
#endif

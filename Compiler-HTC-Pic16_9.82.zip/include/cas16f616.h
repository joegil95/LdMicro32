#ifndef _CASPIC_H_
#warning Header file cas16f616.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS16F616_H_
#define _CAS16F616_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define IRP_bit                        BANKMASK(STATUS), 7
#define RP0_bit                        BANKMASK(STATUS), 5
#define RP1_bit                        BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define RA0_bit                        BANKMASK(PORTA), 0
#define RA1_bit                        BANKMASK(PORTA), 1
#define RA2_bit                        BANKMASK(PORTA), 2
#define RA3_bit                        BANKMASK(PORTA), 3
#define RA4_bit                        BANKMASK(PORTA), 4
#define RA5_bit                        BANKMASK(PORTA), 5
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 0007h
#define RC0_bit                        BANKMASK(PORTC), 0
#define RC1_bit                        BANKMASK(PORTC), 1
#define RC2_bit                        BANKMASK(PORTC), 2
#define RC3_bit                        BANKMASK(PORTC), 3
#define RC4_bit                        BANKMASK(PORTC), 4
#define RC5_bit                        BANKMASK(PORTC), 5
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define RAIF_bit                       BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define TMR0IF_bit                     BANKMASK(INTCON), 2
#define RAIE_bit                       BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define TMR0IE_bit                     BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#define T0IF_bit                       BANKMASK(INTCON), 2
#define T0IE_bit                       BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF_bit                     BANKMASK(PIR1), 0
#define TMR2IF_bit                     BANKMASK(PIR1), 1
#define C1IF_bit                       BANKMASK(PIR1), 3
#define C2IF_bit                       BANKMASK(PIR1), 4
#define ECCPIF_bit                     BANKMASK(PIR1), 5
#define ADIF_bit                       BANKMASK(PIR1), 6
#define T1IF_bit                       BANKMASK(PIR1), 0
#define T2IF_bit                       BANKMASK(PIR1), 1
#define CCP1IF_bit                     BANKMASK(PIR1), 5
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Eh
TMR1H                                  equ 000Fh
T1CON                                  equ 0010h
#define TMR1ON_bit                     BANKMASK(T1CON), 0
#define TMR1CS_bit                     BANKMASK(T1CON), 1
#define nT1SYNC_bit                    BANKMASK(T1CON), 2
#define T1OSCEN_bit                    BANKMASK(T1CON), 3
#define TMR1GE_bit                     BANKMASK(T1CON), 6
#define T1GINV_bit                     BANKMASK(T1CON), 7
#define T1CKPS0_bit                    BANKMASK(T1CON), 4
#define T1CKPS1_bit                    BANKMASK(T1CON), 5
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 0011h
T2CON                                  equ 0012h
#define TMR2ON_bit                     BANKMASK(T2CON), 2
#define T2CKPS0_bit                    BANKMASK(T2CON), 0
#define T2CKPS1_bit                    BANKMASK(T2CON), 1
#define TOUTPS0_bit                    BANKMASK(T2CON), 3
#define TOUTPS1_bit                    BANKMASK(T2CON), 4
#define TOUTPS2_bit                    BANKMASK(T2CON), 5
#define TOUTPS3_bit                    BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0013h
CCPR1H                                 equ 0014h
CCP1CON                                equ 0015h
#define CCP1M0_bit                     BANKMASK(CCP1CON), 0
#define CCP1M1_bit                     BANKMASK(CCP1CON), 1
#define CCP1M2_bit                     BANKMASK(CCP1CON), 2
#define CCP1M3_bit                     BANKMASK(CCP1CON), 3
#define DC1B0_bit                      BANKMASK(CCP1CON), 4
#define DC1B1_bit                      BANKMASK(CCP1CON), 5
#define P1M0_bit                       BANKMASK(CCP1CON), 6
#define P1M1_bit                       BANKMASK(CCP1CON), 7
#ifndef _LIB_BUILD
#endif
PWM1CON                                equ 0016h
#define PRSEN_bit                      BANKMASK(PWM1CON), 7
#define PDC0_bit                       BANKMASK(PWM1CON), 0
#define PDC1_bit                       BANKMASK(PWM1CON), 1
#define PDC2_bit                       BANKMASK(PWM1CON), 2
#define PDC3_bit                       BANKMASK(PWM1CON), 3
#define PDC4_bit                       BANKMASK(PWM1CON), 4
#define PDC5_bit                       BANKMASK(PWM1CON), 5
#define PDC6_bit                       BANKMASK(PWM1CON), 6
#ifndef _LIB_BUILD
#endif
ECCPAS                                 equ 0017h
#define ECCPASE_bit                    BANKMASK(ECCPAS), 7
#define PSSBD0_bit                     BANKMASK(ECCPAS), 0
#define PSSBD1_bit                     BANKMASK(ECCPAS), 1
#define PSSAC0_bit                     BANKMASK(ECCPAS), 2
#define PSSAC1_bit                     BANKMASK(ECCPAS), 3
#define ECCPAS0_bit                    BANKMASK(ECCPAS), 4
#define ECCPAS1_bit                    BANKMASK(ECCPAS), 5
#define ECCPAS2_bit                    BANKMASK(ECCPAS), 6
#ifndef _LIB_BUILD
#endif
VRCON                                  equ 0019h
#define VP6EN_bit                      BANKMASK(VRCON), 4
#define VRR_bit                        BANKMASK(VRCON), 5
#define C2VREN_bit                     BANKMASK(VRCON), 6
#define C1VREN_bit                     BANKMASK(VRCON), 7
#define VR0_bit                        BANKMASK(VRCON), 0
#define VR1_bit                        BANKMASK(VRCON), 1
#define VR2_bit                        BANKMASK(VRCON), 2
#define VR3_bit                        BANKMASK(VRCON), 3
#define FVREN_bit                      BANKMASK(VRCON), 4
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 001Ah
#define C1R_bit                        BANKMASK(CM1CON0), 2
#define C1POL_bit                      BANKMASK(CM1CON0), 4
#define C1OE_bit                       BANKMASK(CM1CON0), 5
#define C1OUT_bit                      BANKMASK(CM1CON0), 6
#define C1ON_bit                       BANKMASK(CM1CON0), 7
#define C1CH0_bit                      BANKMASK(CM1CON0), 0
#define C1CH1_bit                      BANKMASK(CM1CON0), 1
#ifndef _LIB_BUILD
#endif
CM2CON0                                equ 001Bh
#define C2R_bit                        BANKMASK(CM2CON0), 2
#define C2POL_bit                      BANKMASK(CM2CON0), 4
#define C2OE_bit                       BANKMASK(CM2CON0), 5
#define C2OUT_bit                      BANKMASK(CM2CON0), 6
#define C2ON_bit                       BANKMASK(CM2CON0), 7
#define C2CH0_bit                      BANKMASK(CM2CON0), 0
#define C2CH1_bit                      BANKMASK(CM2CON0), 1
#ifndef _LIB_BUILD
#endif
CM2CON1                                equ 001Ch
#define C2SYNC_bit                     BANKMASK(CM2CON1), 0
#define T1GSS_bit                      BANKMASK(CM2CON1), 1
#define C2HYS_bit                      BANKMASK(CM2CON1), 2
#define C1HYS_bit                      BANKMASK(CM2CON1), 3
#define T1ACS_bit                      BANKMASK(CM2CON1), 4
#define MC2OUT_bit                     BANKMASK(CM2CON1), 6
#define MC1ON_bit                      BANKMASK(CM2CON1), 7
#define MC1OUT_bit                     BANKMASK(CM2CON1), 7
#ifndef _LIB_BUILD
#endif
ADRESH                                 equ 001Eh
ADCON0                                 equ 001Fh
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 1
#define VCFG_bit                       BANKMASK(ADCON0), 6
#define ADFM_bit                       BANKMASK(ADCON0), 7
#define GO_bit                         BANKMASK(ADCON0), 1
#define CHS0_bit                       BANKMASK(ADCON0), 2
#define CHS1_bit                       BANKMASK(ADCON0), 3
#define CHS2_bit                       BANKMASK(ADCON0), 4
#define CHS3_bit                       BANKMASK(ADCON0), 5
#define nDONE_bit                      BANKMASK(ADCON0), 1
#define GO_DONE_bit                    BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nRAPU_bit                      BANKMASK(OPTION_REG), 7
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 0085h
#define TRISA0_bit                     BANKMASK(TRISA), 0
#define TRISA1_bit                     BANKMASK(TRISA), 1
#define TRISA2_bit                     BANKMASK(TRISA), 2
#define TRISA3_bit                     BANKMASK(TRISA), 3
#define TRISA4_bit                     BANKMASK(TRISA), 4
#define TRISA5_bit                     BANKMASK(TRISA), 5
#ifndef _LIB_BUILD
#endif
TRISC                                  equ 0087h
#define TRISC0_bit                     BANKMASK(TRISC), 0
#define TRISC1_bit                     BANKMASK(TRISC), 1
#define TRISC2_bit                     BANKMASK(TRISC), 2
#define TRISC3_bit                     BANKMASK(TRISC), 3
#define TRISC4_bit                     BANKMASK(TRISC), 4
#define TRISC5_bit                     BANKMASK(TRISC), 5
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE_bit                     BANKMASK(PIE1), 0
#define TMR2IE_bit                     BANKMASK(PIE1), 1
#define C1IE_bit                       BANKMASK(PIE1), 3
#define C2IE_bit                       BANKMASK(PIE1), 4
#define ECCPIE_bit                     BANKMASK(PIE1), 5
#define ADIE_bit                       BANKMASK(PIE1), 6
#define T1IE_bit                       BANKMASK(PIE1), 0
#define T2IE_bit                       BANKMASK(PIE1), 1
#define CCP1IE_bit                     BANKMASK(PIE1), 5
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOR_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#define nBOD_bit                       BANKMASK(PCON), 0
#ifndef _LIB_BUILD
#endif
OSCTUNE                                equ 0090h
#define TUN0_bit                       BANKMASK(OSCTUNE), 0
#define TUN1_bit                       BANKMASK(OSCTUNE), 1
#define TUN2_bit                       BANKMASK(OSCTUNE), 2
#define TUN3_bit                       BANKMASK(OSCTUNE), 3
#define TUN4_bit                       BANKMASK(OSCTUNE), 4
#ifndef _LIB_BUILD
#endif
ANSEL                                  equ 0091h
#define ANS0_bit                       BANKMASK(ANSEL), 0
#define ANS1_bit                       BANKMASK(ANSEL), 1
#define ANS2_bit                       BANKMASK(ANSEL), 2
#define ANS3_bit                       BANKMASK(ANSEL), 3
#define ANS4_bit                       BANKMASK(ANSEL), 4
#define ANS5_bit                       BANKMASK(ANSEL), 5
#define ANS6_bit                       BANKMASK(ANSEL), 6
#define ANS7_bit                       BANKMASK(ANSEL), 7
#ifndef _LIB_BUILD
#endif
PR2                                    equ 0092h
WPUA                                   equ 0095h
WPU                                    equ 0095h
#define WPUA0_bit                      BANKMASK(WPUA), 0
#define WPUA1_bit                      BANKMASK(WPUA), 1
#define WPUA2_bit                      BANKMASK(WPUA), 2
#define WPUA4_bit                      BANKMASK(WPUA), 4
#define WPUA5_bit                      BANKMASK(WPUA), 5
#define WPU0_bit                       BANKMASK(WPUA), 0
#define WPU1_bit                       BANKMASK(WPUA), 1
#define WPU2_bit                       BANKMASK(WPUA), 2
#define WPU4_bit                       BANKMASK(WPUA), 4
#define WPU5_bit                       BANKMASK(WPUA), 5
#ifndef _LIB_BUILD
#endif
IOCA                                   equ 0096h
IOC                                    equ 0096h
#define IOCA0_bit                      BANKMASK(IOCA), 0
#define IOCA1_bit                      BANKMASK(IOCA), 1
#define IOCA2_bit                      BANKMASK(IOCA), 2
#define IOCA3_bit                      BANKMASK(IOCA), 3
#define IOCA4_bit                      BANKMASK(IOCA), 4
#define IOCA5_bit                      BANKMASK(IOCA), 5
#define IOC0_bit                       BANKMASK(IOCA), 0
#define IOC1_bit                       BANKMASK(IOCA), 1
#define IOC2_bit                       BANKMASK(IOCA), 2
#define IOC3_bit                       BANKMASK(IOCA), 3
#define IOC4_bit                       BANKMASK(IOCA), 4
#define IOC5_bit                       BANKMASK(IOCA), 5
#ifndef _LIB_BUILD
#endif
SRCON0                                 equ 0099h
SRCON                                  equ 0099h
#define SRCLKEN_bit                    BANKMASK(SRCON0), 0
#define PULSR_bit                      BANKMASK(SRCON0), 2
#define PULSS_bit                      BANKMASK(SRCON0), 3
#define C2REN_bit                      BANKMASK(SRCON0), 4
#define C1SEN_bit                      BANKMASK(SRCON0), 5
#define SR0_bit                        BANKMASK(SRCON0), 6
#define SR1_bit                        BANKMASK(SRCON0), 7
#ifndef _LIB_BUILD
#endif
SRCON1                                 equ 009Ah
#define SRCS0_bit                      BANKMASK(SRCON1), 6
#define SRCS1_bit                      BANKMASK(SRCON1), 7
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 009Eh
ADCON1                                 equ 009Fh
#define ADCS0_bit                      BANKMASK(ADCON1), 4
#define ADCS1_bit                      BANKMASK(ADCON1), 5
#define ADCS2_bit                      BANKMASK(ADCON1), 6
#ifndef _LIB_BUILD
#endif

#endif
#endif

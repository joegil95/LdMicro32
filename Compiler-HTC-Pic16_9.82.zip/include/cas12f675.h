#ifndef _CASPIC_H_
#warning Header file cas12f675.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS12F675_H_
#define _CAS12F675_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define IRP_bit                        BANKMASK(STATUS), 7
#define RP0_bit                        BANKMASK(STATUS), 5
#define RP1_bit                        BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
GPIO                                   equ 0005h
#define GP0_bit                        BANKMASK(GPIO), 0
#define GP1_bit                        BANKMASK(GPIO), 1
#define GP2_bit                        BANKMASK(GPIO), 2
#define GP3_bit                        BANKMASK(GPIO), 3
#define GP4_bit                        BANKMASK(GPIO), 4
#define GP5_bit                        BANKMASK(GPIO), 5
#define GPIO0_bit                      BANKMASK(GPIO), 0
#define GPIO1_bit                      BANKMASK(GPIO), 1
#define GPIO2_bit                      BANKMASK(GPIO), 2
#define GPIO3_bit                      BANKMASK(GPIO), 3
#define GPIO4_bit                      BANKMASK(GPIO), 4
#define GPIO5_bit                      BANKMASK(GPIO), 5
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define GPIF_bit                       BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define T0IF_bit                       BANKMASK(INTCON), 2
#define GPIE_bit                       BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define T0IE_bit                       BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#define TMR0IF_bit                     BANKMASK(INTCON), 2
#define TMR0IE_bit                     BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF_bit                     BANKMASK(PIR1), 0
#define CMIF_bit                       BANKMASK(PIR1), 3
#define ADIF_bit                       BANKMASK(PIR1), 6
#define EEIF_bit                       BANKMASK(PIR1), 7
#define T1IF_bit                       BANKMASK(PIR1), 0
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Eh
TMR1H                                  equ 000Fh
T1CON                                  equ 0010h
#define TMR1ON_bit                     BANKMASK(T1CON), 0
#define TMR1CS_bit                     BANKMASK(T1CON), 1
#define nT1SYNC_bit                    BANKMASK(T1CON), 2
#define T1OSCEN_bit                    BANKMASK(T1CON), 3
#define TMR1GE_bit                     BANKMASK(T1CON), 6
#define T1CKPS0_bit                    BANKMASK(T1CON), 4
#define T1CKPS1_bit                    BANKMASK(T1CON), 5
#ifndef _LIB_BUILD
#endif
CMCON                                  equ 0019h
#define CIS_bit                        BANKMASK(CMCON), 3
#define CINV_bit                       BANKMASK(CMCON), 4
#define COUT_bit                       BANKMASK(CMCON), 6
#define CM0_bit                        BANKMASK(CMCON), 0
#define CM1_bit                        BANKMASK(CMCON), 1
#define CM2_bit                        BANKMASK(CMCON), 2
#ifndef _LIB_BUILD
#endif
ADRESH                                 equ 001Eh
ADCON0                                 equ 001Fh
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 1
#define VCFG_bit                       BANKMASK(ADCON0), 6
#define ADFM_bit                       BANKMASK(ADCON0), 7
#define GO_DONE_bit                    BANKMASK(ADCON0), 1
#define CHS0_bit                       BANKMASK(ADCON0), 2
#define CHS1_bit                       BANKMASK(ADCON0), 3
#define nDONE_bit                      BANKMASK(ADCON0), 1
#define GO_bit                         BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nGPPU_bit                      BANKMASK(OPTION_REG), 7
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISIO                                 equ 0085h
#define TRISIO0_bit                    BANKMASK(TRISIO), 0
#define TRISIO1_bit                    BANKMASK(TRISIO), 1
#define TRISIO2_bit                    BANKMASK(TRISIO), 2
#define TRISIO3_bit                    BANKMASK(TRISIO), 3
#define TRISIO4_bit                    BANKMASK(TRISIO), 4
#define TRISIO5_bit                    BANKMASK(TRISIO), 5
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE_bit                     BANKMASK(PIE1), 0
#define CMIE_bit                       BANKMASK(PIE1), 3
#define ADIE_bit                       BANKMASK(PIE1), 6
#define EEIE_bit                       BANKMASK(PIE1), 7
#define T1IE_bit                       BANKMASK(PIE1), 0
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOR_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#define nBOD_bit                       BANKMASK(PCON), 0
#ifndef _LIB_BUILD
#endif
OSCCAL                                 equ 0090h
#define CAL0_bit                       BANKMASK(OSCCAL), 2
#define CAL1_bit                       BANKMASK(OSCCAL), 3
#define CAL2_bit                       BANKMASK(OSCCAL), 4
#define CAL3_bit                       BANKMASK(OSCCAL), 5
#define CAL4_bit                       BANKMASK(OSCCAL), 6
#define CAL5_bit                       BANKMASK(OSCCAL), 7
#ifndef _LIB_BUILD
#endif
WPU                                    equ 0095h
#define WPU0_bit                       BANKMASK(WPU), 0
#define WPU1_bit                       BANKMASK(WPU), 1
#define WPU2_bit                       BANKMASK(WPU), 2
#define WPU4_bit                       BANKMASK(WPU), 4
#define WPU5_bit                       BANKMASK(WPU), 5
#ifndef _LIB_BUILD
#endif
IOC                                    equ 0096h
IOCB                                   equ 0096h
#define IOC0_bit                       BANKMASK(IOC), 0
#define IOC1_bit                       BANKMASK(IOC), 1
#define IOC2_bit                       BANKMASK(IOC), 2
#define IOC3_bit                       BANKMASK(IOC), 3
#define IOC4_bit                       BANKMASK(IOC), 4
#define IOC5_bit                       BANKMASK(IOC), 5
#define IOCB0_bit                      BANKMASK(IOC), 0
#define IOCB1_bit                      BANKMASK(IOC), 1
#define IOCB2_bit                      BANKMASK(IOC), 2
#define IOCB3_bit                      BANKMASK(IOC), 3
#define IOCB4_bit                      BANKMASK(IOC), 4
#define IOCB5_bit                      BANKMASK(IOC), 5
#ifndef _LIB_BUILD
#endif
VRCON                                  equ 0099h
#define VRR_bit                        BANKMASK(VRCON), 5
#define VREN_bit                       BANKMASK(VRCON), 7
#define VR0_bit                        BANKMASK(VRCON), 0
#define VR1_bit                        BANKMASK(VRCON), 1
#define VR2_bit                        BANKMASK(VRCON), 2
#define VR3_bit                        BANKMASK(VRCON), 3
#ifndef _LIB_BUILD
#endif
EEDATA                                 equ 009Ah
EEDAT                                  equ 009Ah
EEADR                                  equ 009Bh
#ifndef _LIB_BUILD
#endif
EECON1                                 equ 009Ch
#define RD_bit                         BANKMASK(EECON1), 0
#define WR_bit                         BANKMASK(EECON1), 1
#define WREN_bit                       BANKMASK(EECON1), 2
#define WRERR_bit                      BANKMASK(EECON1), 3
#ifndef _LIB_BUILD
#endif
EECON2                                 equ 009Dh
ADRESL                                 equ 009Eh
ANSEL                                  equ 009Fh
#define ANS0_bit                       BANKMASK(ANSEL), 0
#define ANS1_bit                       BANKMASK(ANSEL), 1
#define ANS2_bit                       BANKMASK(ANSEL), 2
#define ANS3_bit                       BANKMASK(ANSEL), 3
#define ADCS0_bit                      BANKMASK(ANSEL), 4
#define ADCS1_bit                      BANKMASK(ANSEL), 5
#define ADCS2_bit                      BANKMASK(ANSEL), 6
#ifndef _LIB_BUILD
#endif

#endif
#endif

#ifndef _ASPIC_H_
#warning Header file asmcv08a.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _ASMCV08A_H_
#define _ASMCV08A_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define PA0                            BANKMASK(STATUS), 5
#define CWUF                           BANKMASK(STATUS), 6
#define GPWUF                          BANKMASK(STATUS), 7
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
OSCCAL                                 equ 0005h
#define CAL0                           BANKMASK(OSCCAL), 1
#define CAL1                           BANKMASK(OSCCAL), 2
#define CAL2                           BANKMASK(OSCCAL), 3
#define CAL3                           BANKMASK(OSCCAL), 4
#define CAL4                           BANKMASK(OSCCAL), 5
#define CAL5                           BANKMASK(OSCCAL), 6
#define CAL6                           BANKMASK(OSCCAL), 7
#ifndef _LIB_BUILD
#endif
GPIO                                   equ 0006h
#define GP0                            BANKMASK(GPIO), 0
#define GP1                            BANKMASK(GPIO), 1
#define GP2                            BANKMASK(GPIO), 2
#define GP3                            BANKMASK(GPIO), 3
#define GP4                            BANKMASK(GPIO), 4
#define GP5                            BANKMASK(GPIO), 5
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 0007h
#define nC1WU                          BANKMASK(CM1CON0), 0
#define C1PREF                         BANKMASK(CM1CON0), 1
#define C1NREF                         BANKMASK(CM1CON0), 2
#define C1ON                           BANKMASK(CM1CON0), 3
#define nC1T0CS                        BANKMASK(CM1CON0), 4
#define C1POL                          BANKMASK(CM1CON0), 5
#define nC1OUTEN                       BANKMASK(CM1CON0), 6
#define C1OUT                          BANKMASK(CM1CON0), 7
#ifndef _LIB_BUILD
#endif
ADCON0                                 equ 0008h
#define ADON                           BANKMASK(ADCON0), 0
#define GO_nDONE                       BANKMASK(ADCON0), 1
#define GO                             BANKMASK(ADCON0), 1
#define CHS0                           BANKMASK(ADCON0), 2
#define CHS1                           BANKMASK(ADCON0), 3
#define ADCS0                          BANKMASK(ADCON0), 4
#define ADCS1                          BANKMASK(ADCON0), 5
#define ANS0                           BANKMASK(ADCON0), 6
#define ANS1                           BANKMASK(ADCON0), 7
#define nDONE                          BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
ADRES                                  equ 0009h

#endif
#endif

#ifndef _ASPIC_H_
#warning Header file as12f635.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS12F635_H_
#define _AS12F635_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define IRP                            BANKMASK(STATUS), 7
#define RP0                            BANKMASK(STATUS), 5
#define RP1                            BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
GPIO                                   equ 0005h
PORTA                                  equ 0005h
#define GP0                            BANKMASK(GPIO), 0
#define GP1                            BANKMASK(GPIO), 1
#define GP2                            BANKMASK(GPIO), 2
#define GP3                            BANKMASK(GPIO), 3
#define GP4                            BANKMASK(GPIO), 4
#define GP5                            BANKMASK(GPIO), 5
#define RA0                            BANKMASK(GPIO), 0
#define RA1                            BANKMASK(GPIO), 1
#define RA2                            BANKMASK(GPIO), 2
#define RA3                            BANKMASK(GPIO), 3
#define RA4                            BANKMASK(GPIO), 4
#define RA5                            BANKMASK(GPIO), 5
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define RAIF                           BANKMASK(INTCON), 0
#define INTF                           BANKMASK(INTCON), 1
#define T0IF                           BANKMASK(INTCON), 2
#define RAIE                           BANKMASK(INTCON), 3
#define INTE                           BANKMASK(INTCON), 4
#define T0IE                           BANKMASK(INTCON), 5
#define PEIE                           BANKMASK(INTCON), 6
#define GIE                            BANKMASK(INTCON), 7
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF                         BANKMASK(PIR1), 0
#define OSFIF                          BANKMASK(PIR1), 2
#define C1IF                           BANKMASK(PIR1), 3
#define CRIF                           BANKMASK(PIR1), 5
#define LVDIF                          BANKMASK(PIR1), 6
#define EEIF                           BANKMASK(PIR1), 7
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Eh
TMR1H                                  equ 000Fh
T1CON                                  equ 0010h
#define TMR1ON                         BANKMASK(T1CON), 0
#define TMR1CS                         BANKMASK(T1CON), 1
#define nT1SYNC                        BANKMASK(T1CON), 2
#define T1OSCEN                        BANKMASK(T1CON), 3
#define TMR1GE                         BANKMASK(T1CON), 6
#define T1GINV                         BANKMASK(T1CON), 7
#define T1CKPS0                        BANKMASK(T1CON), 4
#define T1CKPS1                        BANKMASK(T1CON), 5
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0018h
#define SWDTEN                         BANKMASK(WDTCON), 0
#define WDTPS0                         BANKMASK(WDTCON), 1
#define WDTPS1                         BANKMASK(WDTCON), 2
#define WDTPS2                         BANKMASK(WDTCON), 3
#define WDTPS3                         BANKMASK(WDTCON), 4
#ifndef _LIB_BUILD
#endif
CMCON0                                 equ 0019h
#define CIS                            BANKMASK(CMCON0), 3
#define CINV                           BANKMASK(CMCON0), 4
#define COUT                           BANKMASK(CMCON0), 6
#define CM0                            BANKMASK(CMCON0), 0
#define CM1                            BANKMASK(CMCON0), 1
#define CM2                            BANKMASK(CMCON0), 2
#define C1OUT                          BANKMASK(CMCON0), 6
#define C1INV                          BANKMASK(CMCON0), 4
#ifndef _LIB_BUILD
#endif
CMCON1                                 equ 001Ah
#define CMSYNC                         BANKMASK(CMCON1), 0
#define T1GSS                          BANKMASK(CMCON1), 1
#define C1SYNC                         BANKMASK(CMCON1), 0
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA                            BANKMASK(OPTION_REG), 3
#define T0SE                           BANKMASK(OPTION_REG), 4
#define T0CS                           BANKMASK(OPTION_REG), 5
#define INTEDG                         BANKMASK(OPTION_REG), 6
#define nRAPU                          BANKMASK(OPTION_REG), 7
#define PS0                            BANKMASK(OPTION_REG), 0
#define PS1                            BANKMASK(OPTION_REG), 1
#define PS2                            BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISIO                                 equ 0085h
TRISA                                  equ 0085h
#define TRISIO0                        BANKMASK(TRISIO), 0
#define TRISIO1                        BANKMASK(TRISIO), 1
#define TRISIO2                        BANKMASK(TRISIO), 2
#define TRISIO3                        BANKMASK(TRISIO), 3
#define TRISIO4                        BANKMASK(TRISIO), 4
#define TRISIO5                        BANKMASK(TRISIO), 5
#define TRISA0                         BANKMASK(TRISIO), 0
#define TRISA1                         BANKMASK(TRISIO), 1
#define TRISA2                         BANKMASK(TRISIO), 2
#define TRISA3                         BANKMASK(TRISIO), 3
#define TRISA4                         BANKMASK(TRISIO), 4
#define TRISA5                         BANKMASK(TRISIO), 5
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE                         BANKMASK(PIE1), 0
#define OSFIE                          BANKMASK(PIE1), 2
#define C1IE                           BANKMASK(PIE1), 3
#define CRIE                           BANKMASK(PIE1), 5
#define LVDIE                          BANKMASK(PIE1), 6
#define EEIE                           BANKMASK(PIE1), 7
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOR                           BANKMASK(PCON), 0
#define nPOR                           BANKMASK(PCON), 1
#define nWUR                           BANKMASK(PCON), 3
#define SBOREN                         BANKMASK(PCON), 4
#define ULPWUE                         BANKMASK(PCON), 5
#define nBOD                           BANKMASK(PCON), 0
#define SBODEN                         BANKMASK(PCON), 4
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 008Fh
#define SCS                            BANKMASK(OSCCON), 0
#define LTS                            BANKMASK(OSCCON), 1
#define HTS                            BANKMASK(OSCCON), 2
#define OSTS                           BANKMASK(OSCCON), 3
#define IRCF0                          BANKMASK(OSCCON), 4
#define IRCF1                          BANKMASK(OSCCON), 5
#define IRCF2                          BANKMASK(OSCCON), 6
#ifndef _LIB_BUILD
#endif
OSCTUNE                                equ 0090h
#define TUN0                           BANKMASK(OSCTUNE), 0
#define TUN1                           BANKMASK(OSCTUNE), 1
#define TUN2                           BANKMASK(OSCTUNE), 2
#define TUN3                           BANKMASK(OSCTUNE), 3
#define TUN4                           BANKMASK(OSCTUNE), 4
#ifndef _LIB_BUILD
#endif
LVDCON                                 equ 0094h
#define LVDEN                          BANKMASK(LVDCON), 4
#define IRVST                          BANKMASK(LVDCON), 5
#define LVDL0                          BANKMASK(LVDCON), 0
#define LVDL1                          BANKMASK(LVDCON), 1
#define LVDL2                          BANKMASK(LVDCON), 2
#define PLVDEN                         BANKMASK(LVDCON), 4
#ifndef _LIB_BUILD
#endif
WPUDA                                  equ 0095h
#define WPUDA0                         BANKMASK(WPUDA), 0
#define WPUDA1                         BANKMASK(WPUDA), 1
#define WPUDA2                         BANKMASK(WPUDA), 2
#define WPUDA4                         BANKMASK(WPUDA), 4
#define WPUDA5                         BANKMASK(WPUDA), 5
#ifndef _LIB_BUILD
#endif
IOCA                                   equ 0096h
#define IOCA0                          BANKMASK(IOCA), 0
#define IOCA1                          BANKMASK(IOCA), 1
#define IOCA2                          BANKMASK(IOCA), 2
#define IOCA3                          BANKMASK(IOCA), 3
#define IOCA4                          BANKMASK(IOCA), 4
#define IOCA5                          BANKMASK(IOCA), 5
#ifndef _LIB_BUILD
#endif
WDA                                    equ 0097h
#define WDA0                           BANKMASK(WDA), 0
#define WDA1                           BANKMASK(WDA), 1
#define WDA2                           BANKMASK(WDA), 2
#define WDA4                           BANKMASK(WDA), 4
#define WDA5                           BANKMASK(WDA), 5
#ifndef _LIB_BUILD
#endif
VRCON                                  equ 0099h
#define VRR                            BANKMASK(VRCON), 5
#define VREN                           BANKMASK(VRCON), 7
#define VR0                            BANKMASK(VRCON), 0
#define VR1                            BANKMASK(VRCON), 1
#define VR2                            BANKMASK(VRCON), 2
#define VR3                            BANKMASK(VRCON), 3
#ifndef _LIB_BUILD
#endif
EEDAT                                  equ 009Ah
EEDATA                                 equ 009Ah
EEADR                                  equ 009Bh
EECON1                                 equ 009Ch
#define RD                             BANKMASK(EECON1), 0
#define WR                             BANKMASK(EECON1), 1
#define WREN                           BANKMASK(EECON1), 2
#define WRERR                          BANKMASK(EECON1), 3
#ifndef _LIB_BUILD
#endif
EECON2                                 equ 009Dh
CRCON                                  equ 0110h
#define ENC_nDEC                       BANKMASK(CRCON), 6
#define GO_nDONE                       BANKMASK(CRCON), 7
#define CRREG0                         BANKMASK(CRCON), 0
#define CRREG1                         BANKMASK(CRCON), 1
#define ENC_DEC                        BANKMASK(CRCON), 6
#define GO                             BANKMASK(CRCON), 7
#ifndef _LIB_BUILD
#endif
CRDAT0                                 equ 0111h
CRDAT1                                 equ 0112h
CRDAT2                                 equ 0113h
CRDAT3                                 equ 0114h

#endif
#endif

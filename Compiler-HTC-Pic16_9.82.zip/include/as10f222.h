#ifndef _ASPIC_H_
#warning Header file as10f222.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS10F222_H_
#define _AS10F222_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define GPWUF                          BANKMASK(STATUS), 7
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
OSCCAL                                 equ 0005h
#define FOSC4                          BANKMASK(OSCCAL), 0
#define CAL0                           BANKMASK(OSCCAL), 1
#define CAL1                           BANKMASK(OSCCAL), 2
#define CAL2                           BANKMASK(OSCCAL), 3
#define CAL3                           BANKMASK(OSCCAL), 4
#define CAL4                           BANKMASK(OSCCAL), 5
#define CAL5                           BANKMASK(OSCCAL), 6
#define CAL6                           BANKMASK(OSCCAL), 7
#ifndef _LIB_BUILD
#endif
GPIO                                   equ 0006h
#define GP0                            BANKMASK(GPIO), 0
#define GP1                            BANKMASK(GPIO), 1
#define GP2                            BANKMASK(GPIO), 2
#define GP3                            BANKMASK(GPIO), 3
#ifndef _LIB_BUILD
#endif
ADCON0                                 equ 0007h
#define ADON                           BANKMASK(ADCON0), 0
#define GO_nDONE                       BANKMASK(ADCON0), 1
#define GO                             BANKMASK(ADCON0), 1
#define CHS0                           BANKMASK(ADCON0), 2
#define CHS1                           BANKMASK(ADCON0), 3
#define ANS0                           BANKMASK(ADCON0), 6
#define ANS1                           BANKMASK(ADCON0), 7
#define nDONE                          BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
ADRES                                  equ 0008h
#define ADRES0                         BANKMASK(ADRES), 0
#define ADRES1                         BANKMASK(ADRES), 1
#define ADRES2                         BANKMASK(ADRES), 2
#define ADRES3                         BANKMASK(ADRES), 3
#define ADRES4                         BANKMASK(ADRES), 4
#define ADRES5                         BANKMASK(ADRES), 5
#define ADRES6                         BANKMASK(ADRES), 6
#define ADRES7                         BANKMASK(ADRES), 7
#ifndef _LIB_BUILD
#endif

#endif
#endif

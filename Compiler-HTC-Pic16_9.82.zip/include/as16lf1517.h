#ifndef _ASPIC_H_
#warning Header file as16lf1517.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS16LF1517_H_
#define _AS16LF1517_H_

INDF0                                  equ 0000h
INDF1                                  equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#ifndef _LIB_BUILD
#endif
FSR0L                                  equ 0004h
FSR0H                                  equ 0005h
FSR1L                                  equ 0006h
FSR1H                                  equ 0007h
BSR                                    equ 0008h
#define BSR0                           BANKMASK(BSR), 0
#define BSR1                           BANKMASK(BSR), 1
#define BSR2                           BANKMASK(BSR), 2
#define BSR3                           BANKMASK(BSR), 3
#define BSR4                           BANKMASK(BSR), 4
#ifndef _LIB_BUILD
#endif
WREG                                   equ 0009h
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define IOCIF                          BANKMASK(INTCON), 0
#define INTF                           BANKMASK(INTCON), 1
#define TMR0IF                         BANKMASK(INTCON), 2
#define IOCIE                          BANKMASK(INTCON), 3
#define INTE                           BANKMASK(INTCON), 4
#define TMR0IE                         BANKMASK(INTCON), 5
#define PEIE                           BANKMASK(INTCON), 6
#define GIE                            BANKMASK(INTCON), 7
#define T0IF                           BANKMASK(INTCON), 2
#define T0IE                           BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PORTA                                  equ 000Ch
#define RA0                            BANKMASK(PORTA), 0
#define RA1                            BANKMASK(PORTA), 1
#define RA2                            BANKMASK(PORTA), 2
#define RA3                            BANKMASK(PORTA), 3
#define RA4                            BANKMASK(PORTA), 4
#define RA5                            BANKMASK(PORTA), 5
#define RA6                            BANKMASK(PORTA), 6
#define RA7                            BANKMASK(PORTA), 7
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 000Dh
#define RB0                            BANKMASK(PORTB), 0
#define RB1                            BANKMASK(PORTB), 1
#define RB2                            BANKMASK(PORTB), 2
#define RB3                            BANKMASK(PORTB), 3
#define RB4                            BANKMASK(PORTB), 4
#define RB5                            BANKMASK(PORTB), 5
#define RB6                            BANKMASK(PORTB), 6
#define RB7                            BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 000Eh
#define RC0                            BANKMASK(PORTC), 0
#define RC1                            BANKMASK(PORTC), 1
#define RC2                            BANKMASK(PORTC), 2
#define RC3                            BANKMASK(PORTC), 3
#define RC4                            BANKMASK(PORTC), 4
#define RC5                            BANKMASK(PORTC), 5
#define RC6                            BANKMASK(PORTC), 6
#define RC7                            BANKMASK(PORTC), 7
#ifndef _LIB_BUILD
#endif
PORTD                                  equ 000Fh
#define RD0                            BANKMASK(PORTD), 0
#define RD1                            BANKMASK(PORTD), 1
#define RD2                            BANKMASK(PORTD), 2
#define RD3                            BANKMASK(PORTD), 3
#define RD4                            BANKMASK(PORTD), 4
#define RD5                            BANKMASK(PORTD), 5
#define RD6                            BANKMASK(PORTD), 6
#define RD7                            BANKMASK(PORTD), 7
#ifndef _LIB_BUILD
#endif
PORTE                                  equ 0010h
#define RE0                            BANKMASK(PORTE), 0
#define RE1                            BANKMASK(PORTE), 1
#define RE2                            BANKMASK(PORTE), 2
#define RE3                            BANKMASK(PORTE), 3
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 0011h
#define TMR1IF                         BANKMASK(PIR1), 0
#define TMR2IF                         BANKMASK(PIR1), 1
#define CCP1IF                         BANKMASK(PIR1), 2
#define SSPIF                          BANKMASK(PIR1), 3
#define TXIF                           BANKMASK(PIR1), 4
#define RCIF                           BANKMASK(PIR1), 5
#define ADIF                           BANKMASK(PIR1), 6
#define TMR1GIF                        BANKMASK(PIR1), 7
#ifndef _LIB_BUILD
#endif
PIR2                                   equ 0012h
#define CCP2IF                         BANKMASK(PIR2), 0
#define BCLIF                          BANKMASK(PIR2), 3
#define OSFIF                          BANKMASK(PIR2), 7
#ifndef _LIB_BUILD
#endif
TMR0                                   equ 0015h
TMR1L                                  equ 0016h
TMR1H                                  equ 0017h
T1CON                                  equ 0018h
#define TMR1ON                         BANKMASK(T1CON), 0
#define nT1SYNC                        BANKMASK(T1CON), 2
#define T1OSCEN                        BANKMASK(T1CON), 3
#define T1CKPS0                        BANKMASK(T1CON), 4
#define T1CKPS1                        BANKMASK(T1CON), 5
#define TMR1CS0                        BANKMASK(T1CON), 6
#define TMR1CS1                        BANKMASK(T1CON), 7
#ifndef _LIB_BUILD
#endif
T1GCON                                 equ 0019h
#define T1GVAL                         BANKMASK(T1GCON), 2
#define T1GGO_nDONE                    BANKMASK(T1GCON), 3
#define T1GSPM                         BANKMASK(T1GCON), 4
#define T1GTM                          BANKMASK(T1GCON), 5
#define T1GPOL                         BANKMASK(T1GCON), 6
#define TMR1GE                         BANKMASK(T1GCON), 7
#define T1GSS0                         BANKMASK(T1GCON), 0
#define T1GSS1                         BANKMASK(T1GCON), 1
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 001Ah
PR2                                    equ 001Bh
T2CON                                  equ 001Ch
#define TMR2ON                         BANKMASK(T2CON), 2
#define T2CKPS0                        BANKMASK(T2CON), 0
#define T2CKPS1                        BANKMASK(T2CON), 1
#define T2OUTPS0                       BANKMASK(T2CON), 3
#define T2OUTPS1                       BANKMASK(T2CON), 4
#define T2OUTPS2                       BANKMASK(T2CON), 5
#define T2OUTPS3                       BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 008Ch
#define TRISA0                         BANKMASK(TRISA), 0
#define TRISA1                         BANKMASK(TRISA), 1
#define TRISA2                         BANKMASK(TRISA), 2
#define TRISA3                         BANKMASK(TRISA), 3
#define TRISA4                         BANKMASK(TRISA), 4
#define TRISA5                         BANKMASK(TRISA), 5
#define TRISA6                         BANKMASK(TRISA), 6
#define TRISA7                         BANKMASK(TRISA), 7
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 008Dh
#define TRISB0                         BANKMASK(TRISB), 0
#define TRISB1                         BANKMASK(TRISB), 1
#define TRISB2                         BANKMASK(TRISB), 2
#define TRISB3                         BANKMASK(TRISB), 3
#define TRISB4                         BANKMASK(TRISB), 4
#define TRISB5                         BANKMASK(TRISB), 5
#define TRISB6                         BANKMASK(TRISB), 6
#define TRISB7                         BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
TRISC                                  equ 008Eh
#define TRISC0                         BANKMASK(TRISC), 0
#define TRISC1                         BANKMASK(TRISC), 1
#define TRISC2                         BANKMASK(TRISC), 2
#define TRISC3                         BANKMASK(TRISC), 3
#define TRISC4                         BANKMASK(TRISC), 4
#define TRISC5                         BANKMASK(TRISC), 5
#define TRISC6                         BANKMASK(TRISC), 6
#define TRISC7                         BANKMASK(TRISC), 7
#ifndef _LIB_BUILD
#endif
TRISD                                  equ 008Fh
#define TRISD0                         BANKMASK(TRISD), 0
#define TRISD1                         BANKMASK(TRISD), 1
#define TRISD2                         BANKMASK(TRISD), 2
#define TRISD3                         BANKMASK(TRISD), 3
#define TRISD4                         BANKMASK(TRISD), 4
#define TRISD5                         BANKMASK(TRISD), 5
#define TRISD6                         BANKMASK(TRISD), 6
#define TRISD7                         BANKMASK(TRISD), 7
#ifndef _LIB_BUILD
#endif
TRISE                                  equ 0090h
#define TRISE0                         BANKMASK(TRISE), 0
#define TRISE1                         BANKMASK(TRISE), 1
#define TRISE2                         BANKMASK(TRISE), 2
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 0091h
#define TMR1IE                         BANKMASK(PIE1), 0
#define TMR2IE                         BANKMASK(PIE1), 1
#define CCP1IE                         BANKMASK(PIE1), 2
#define SSPIE                          BANKMASK(PIE1), 3
#define TXIE                           BANKMASK(PIE1), 4
#define RCIE                           BANKMASK(PIE1), 5
#define ADIE                           BANKMASK(PIE1), 6
#define TMR1GIE                        BANKMASK(PIE1), 7
#ifndef _LIB_BUILD
#endif
PIE2                                   equ 0092h
#define CCP2IE                         BANKMASK(PIE2), 0
#define BCLIE                          BANKMASK(PIE2), 3
#define OSFIE                          BANKMASK(PIE2), 7
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0095h
#define PSA                            BANKMASK(OPTION_REG), 3
#define TMR0SE                         BANKMASK(OPTION_REG), 4
#define TMR0CS                         BANKMASK(OPTION_REG), 5
#define INTEDG                         BANKMASK(OPTION_REG), 6
#define nWPUEN                         BANKMASK(OPTION_REG), 7
#define PS0                            BANKMASK(OPTION_REG), 0
#define PS1                            BANKMASK(OPTION_REG), 1
#define PS2                            BANKMASK(OPTION_REG), 2
#define T0SE                           BANKMASK(OPTION_REG), 4
#define T0CS                           BANKMASK(OPTION_REG), 5
#ifndef _LIB_BUILD
#endif
PCON                                   equ 0096h
#define nBOR                           BANKMASK(PCON), 0
#define nPOR                           BANKMASK(PCON), 1
#define nRI                            BANKMASK(PCON), 2
#define nRMCLR                         BANKMASK(PCON), 3
#define nRWDT                          BANKMASK(PCON), 4
#define STKUNF                         BANKMASK(PCON), 6
#define STKOVF                         BANKMASK(PCON), 7
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0097h
#define SWDTEN                         BANKMASK(WDTCON), 0
#define WDTPS0                         BANKMASK(WDTCON), 1
#define WDTPS1                         BANKMASK(WDTCON), 2
#define WDTPS2                         BANKMASK(WDTCON), 3
#define WDTPS3                         BANKMASK(WDTCON), 4
#define WDTPS4                         BANKMASK(WDTCON), 5
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 0099h
#define SCS0                           BANKMASK(OSCCON), 0
#define SCS1                           BANKMASK(OSCCON), 1
#define IRCF0                          BANKMASK(OSCCON), 3
#define IRCF1                          BANKMASK(OSCCON), 4
#define IRCF2                          BANKMASK(OSCCON), 5
#define IRCF3                          BANKMASK(OSCCON), 6
#ifndef _LIB_BUILD
#endif
OSCSTAT                                equ 009Ah
#define HFIOFS                         BANKMASK(OSCSTAT), 0
#define LFIOFR                         BANKMASK(OSCSTAT), 1
#define HFIOFR                         BANKMASK(OSCSTAT), 4
#define OSTS                           BANKMASK(OSCSTAT), 5
#define SOSCR                          BANKMASK(OSCSTAT), 7
#define T1OSCR                         BANKMASK(OSCSTAT), 7
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 009Bh
ADRESH                                 equ 009Ch
ADCON0                                 equ 009Dh
#define ADON                           BANKMASK(ADCON0), 0
#define GO_nDONE                       BANKMASK(ADCON0), 1
#define ADGO                           BANKMASK(ADCON0), 1
#define CHS0                           BANKMASK(ADCON0), 2
#define CHS1                           BANKMASK(ADCON0), 3
#define CHS2                           BANKMASK(ADCON0), 4
#define CHS3                           BANKMASK(ADCON0), 5
#define CHS4                           BANKMASK(ADCON0), 6
#define GO                             BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 009Eh
#define ADFM                           BANKMASK(ADCON1), 7
#define ADPREF0                        BANKMASK(ADCON1), 0
#define ADPREF1                        BANKMASK(ADCON1), 1
#define ADCS0                          BANKMASK(ADCON1), 4
#define ADCS1                          BANKMASK(ADCON1), 5
#define ADCS2                          BANKMASK(ADCON1), 6
#ifndef _LIB_BUILD
#endif
LATA                                   equ 010Ch
#define LATA0                          BANKMASK(LATA), 0
#define LATA1                          BANKMASK(LATA), 1
#define LATA2                          BANKMASK(LATA), 2
#define LATA3                          BANKMASK(LATA), 3
#define LATA4                          BANKMASK(LATA), 4
#define LATA5                          BANKMASK(LATA), 5
#define LATA6                          BANKMASK(LATA), 6
#define LATA7                          BANKMASK(LATA), 7
#ifndef _LIB_BUILD
#endif
LATB                                   equ 010Dh
#define LATB0                          BANKMASK(LATB), 0
#define LATB1                          BANKMASK(LATB), 1
#define LATB2                          BANKMASK(LATB), 2
#define LATB3                          BANKMASK(LATB), 3
#define LATB4                          BANKMASK(LATB), 4
#define LATB5                          BANKMASK(LATB), 5
#define LATB6                          BANKMASK(LATB), 6
#define LATB7                          BANKMASK(LATB), 7
#ifndef _LIB_BUILD
#endif
LATC                                   equ 010Eh
#define LATC0                          BANKMASK(LATC), 0
#define LATC1                          BANKMASK(LATC), 1
#define LATC2                          BANKMASK(LATC), 2
#define LATC3                          BANKMASK(LATC), 3
#define LATC4                          BANKMASK(LATC), 4
#define LATC5                          BANKMASK(LATC), 5
#define LATC6                          BANKMASK(LATC), 6
#define LATC7                          BANKMASK(LATC), 7
#ifndef _LIB_BUILD
#endif
LATD                                   equ 010Fh
#define LATD0                          BANKMASK(LATD), 0
#define LATD1                          BANKMASK(LATD), 1
#define LATD2                          BANKMASK(LATD), 2
#define LATD3                          BANKMASK(LATD), 3
#define LATD4                          BANKMASK(LATD), 4
#define LATD5                          BANKMASK(LATD), 5
#define LATD6                          BANKMASK(LATD), 6
#define LATD7                          BANKMASK(LATD), 7
#ifndef _LIB_BUILD
#endif
LATE                                   equ 0110h
#define LATE0                          BANKMASK(LATE), 0
#define LATE1                          BANKMASK(LATE), 1
#define LATE2                          BANKMASK(LATE), 2
#ifndef _LIB_BUILD
#endif
BORCON                                 equ 0116h
#define BORRDY                         BANKMASK(BORCON), 0
#define BORFS                          BANKMASK(BORCON), 6
#define SBOREN                         BANKMASK(BORCON), 7
#ifndef _LIB_BUILD
#endif
FVRCON                                 equ 0117h
#define TSRNG                          BANKMASK(FVRCON), 4
#define TSEN                           BANKMASK(FVRCON), 5
#define FVRRDY                         BANKMASK(FVRCON), 6
#define FVREN                          BANKMASK(FVRCON), 7
#define ADFVR0                         BANKMASK(FVRCON), 0
#define ADFVR1                         BANKMASK(FVRCON), 1
#ifndef _LIB_BUILD
#endif
APFCON                                 equ 011Dh
#define CCP2SEL                        BANKMASK(APFCON), 0
#define SSSEL                          BANKMASK(APFCON), 1
#ifndef _LIB_BUILD
#endif
ANSELA                                 equ 018Ch
#define ANSA0                          BANKMASK(ANSELA), 0
#define ANSA1                          BANKMASK(ANSELA), 1
#define ANSA2                          BANKMASK(ANSELA), 2
#define ANSA3                          BANKMASK(ANSELA), 3
#define ANSA5                          BANKMASK(ANSELA), 5
#ifndef _LIB_BUILD
#endif
ANSELB                                 equ 018Dh
#define ANSB0                          BANKMASK(ANSELB), 0
#define ANSB1                          BANKMASK(ANSELB), 1
#define ANSB2                          BANKMASK(ANSELB), 2
#define ANSB3                          BANKMASK(ANSELB), 3
#define ANSB4                          BANKMASK(ANSELB), 4
#define ANSB5                          BANKMASK(ANSELB), 5
#ifndef _LIB_BUILD
#endif
ANSELC                                 equ 018Eh
#define ANSC0                          BANKMASK(ANSELC), 0
#define ANSC1                          BANKMASK(ANSELC), 1
#define ANSC2                          BANKMASK(ANSELC), 2
#define ANSC3                          BANKMASK(ANSELC), 3
#define ANSC4                          BANKMASK(ANSELC), 4
#define ANSC5                          BANKMASK(ANSELC), 5
#define ANSC6                          BANKMASK(ANSELC), 6
#define ANSC7                          BANKMASK(ANSELC), 7
#ifndef _LIB_BUILD
#endif
ANSELD                                 equ 018Fh
#define ANSD0                          BANKMASK(ANSELD), 0
#define ANSD1                          BANKMASK(ANSELD), 1
#define ANSD2                          BANKMASK(ANSELD), 2
#define ANSD3                          BANKMASK(ANSELD), 3
#define ANSD4                          BANKMASK(ANSELD), 4
#define ANSD5                          BANKMASK(ANSELD), 5
#define ANSD6                          BANKMASK(ANSELD), 6
#define ANSD7                          BANKMASK(ANSELD), 7
#ifndef _LIB_BUILD
#endif
ANSELE                                 equ 0190h
#define ANSE0                          BANKMASK(ANSELE), 0
#define ANSE1                          BANKMASK(ANSELE), 1
#define ANSE2                          BANKMASK(ANSELE), 2
#ifndef _LIB_BUILD
#endif
PMADRL                                 equ 0191h
PMADRH                                 equ 0192h
#ifndef _LIB_BUILD
#endif
PMDATL                                 equ 0193h
PMDATH                                 equ 0194h
#ifndef _LIB_BUILD
#endif
PMCON1                                 equ 0195h
#define RD                             BANKMASK(PMCON1), 0
#define WR                             BANKMASK(PMCON1), 1
#define WREN                           BANKMASK(PMCON1), 2
#define WRERR                          BANKMASK(PMCON1), 3
#define FREE                           BANKMASK(PMCON1), 4
#define LWLO                           BANKMASK(PMCON1), 5
#define CFGS                           BANKMASK(PMCON1), 6
#ifndef _LIB_BUILD
#endif
PMCON2                                 equ 0196h
RCREG                                  equ 0199h
TXREG                                  equ 019Ah
SPBRGL                                 equ 019Bh
SPBRG                                  equ 019Bh
SPBRGH                                 equ 019Ch
RCSTA                                  equ 019Dh
#define RX9D                           BANKMASK(RCSTA), 0
#define OERR                           BANKMASK(RCSTA), 1
#define FERR                           BANKMASK(RCSTA), 2
#define ADDEN                          BANKMASK(RCSTA), 3
#define CREN                           BANKMASK(RCSTA), 4
#define SREN                           BANKMASK(RCSTA), 5
#define RX9                            BANKMASK(RCSTA), 6
#define SPEN                           BANKMASK(RCSTA), 7
#ifndef _LIB_BUILD
#endif
TXSTA                                  equ 019Eh
#define TX9D                           BANKMASK(TXSTA), 0
#define TRMT                           BANKMASK(TXSTA), 1
#define BRGH                           BANKMASK(TXSTA), 2
#define SENDB                          BANKMASK(TXSTA), 3
#define SYNC                           BANKMASK(TXSTA), 4
#define TXEN                           BANKMASK(TXSTA), 5
#define TX9                            BANKMASK(TXSTA), 6
#define CSRC                           BANKMASK(TXSTA), 7
#ifndef _LIB_BUILD
#endif
BAUDCON                                equ 019Fh
#define ABDEN                          BANKMASK(BAUDCON), 0
#define WUE                            BANKMASK(BAUDCON), 1
#define BRG16                          BANKMASK(BAUDCON), 3
#define SCKP                           BANKMASK(BAUDCON), 4
#define RCIDL                          BANKMASK(BAUDCON), 6
#define ABDOVF                         BANKMASK(BAUDCON), 7
#ifndef _LIB_BUILD
#endif
WPUB                                   equ 020Dh
#define WPUB0                          BANKMASK(WPUB), 0
#define WPUB1                          BANKMASK(WPUB), 1
#define WPUB2                          BANKMASK(WPUB), 2
#define WPUB3                          BANKMASK(WPUB), 3
#define WPUB4                          BANKMASK(WPUB), 4
#define WPUB5                          BANKMASK(WPUB), 5
#define WPUB6                          BANKMASK(WPUB), 6
#define WPUB7                          BANKMASK(WPUB), 7
#ifndef _LIB_BUILD
#endif
WPUE                                   equ 0210h
#define WPUE3                          BANKMASK(WPUE), 3
#ifndef _LIB_BUILD
#endif
SSPBUF                                 equ 0211h
SSP1BUF                                equ 0211h
SSPADD                                 equ 0212h
SSP1ADD                                equ 0212h
SSPMSK                                 equ 0213h
SSP1MSK                                equ 0213h
SSPSTAT                                equ 0214h
SSP1STAT                               equ 0214h
#define BF                             BANKMASK(SSPSTAT), 0
#define UA                             BANKMASK(SSPSTAT), 1
#define R_nW                           BANKMASK(SSPSTAT), 2
#define S                              BANKMASK(SSPSTAT), 3
#define P                              BANKMASK(SSPSTAT), 4
#define D_nA                           BANKMASK(SSPSTAT), 5
#define CKE                            BANKMASK(SSPSTAT), 6
#define SMP                            BANKMASK(SSPSTAT), 7
#ifndef _LIB_BUILD
#endif
SSPCON1                                equ 0215h
SSPCON                                 equ 0215h
SSP1CON1                               equ 0215h
#define CKP                            BANKMASK(SSPCON1), 4
#define SSPEN                          BANKMASK(SSPCON1), 5
#define SSPOV                          BANKMASK(SSPCON1), 6
#define WCOL                           BANKMASK(SSPCON1), 7
#define SSPM0                          BANKMASK(SSPCON1), 0
#define SSPM1                          BANKMASK(SSPCON1), 1
#define SSPM2                          BANKMASK(SSPCON1), 2
#define SSPM3                          BANKMASK(SSPCON1), 3
#ifndef _LIB_BUILD
#endif
SSPCON2                                equ 0216h
SSP1CON2                               equ 0216h
#define SEN                            BANKMASK(SSPCON2), 0
#define RSEN                           BANKMASK(SSPCON2), 1
#define PEN                            BANKMASK(SSPCON2), 2
#define RCEN                           BANKMASK(SSPCON2), 3
#define ACKEN                          BANKMASK(SSPCON2), 4
#define ACKDT                          BANKMASK(SSPCON2), 5
#define ACKSTAT                        BANKMASK(SSPCON2), 6
#define GCEN                           BANKMASK(SSPCON2), 7
#ifndef _LIB_BUILD
#endif
SSPCON3                                equ 0217h
SSP1CON3                               equ 0217h
#define DHEN                           BANKMASK(SSPCON3), 0
#define AHEN                           BANKMASK(SSPCON3), 1
#define SBCDE                          BANKMASK(SSPCON3), 2
#define SDAHT                          BANKMASK(SSPCON3), 3
#define BOEN                           BANKMASK(SSPCON3), 4
#define SCIE                           BANKMASK(SSPCON3), 5
#define PCIE                           BANKMASK(SSPCON3), 6
#define ACKTIM                         BANKMASK(SSPCON3), 7
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0291h
CCPR1H                                 equ 0292h
CCP1CON                                equ 0293h
#define CCP1M0                         BANKMASK(CCP1CON), 0
#define CCP1M1                         BANKMASK(CCP1CON), 1
#define CCP1M2                         BANKMASK(CCP1CON), 2
#define CCP1M3                         BANKMASK(CCP1CON), 3
#define DC1B0                          BANKMASK(CCP1CON), 4
#define DC1B1                          BANKMASK(CCP1CON), 5
#ifndef _LIB_BUILD
#endif
CCPR2L                                 equ 0298h
CCPR2H                                 equ 0299h
CCP2CON                                equ 029Ah
#define CCP2M0                         BANKMASK(CCP2CON), 0
#define CCP2M1                         BANKMASK(CCP2CON), 1
#define CCP2M2                         BANKMASK(CCP2CON), 2
#define CCP2M3                         BANKMASK(CCP2CON), 3
#define DC2B0                          BANKMASK(CCP2CON), 4
#define DC2B1                          BANKMASK(CCP2CON), 5
#ifndef _LIB_BUILD
#endif
IOCBP                                  equ 0394h
#define IOCBP0                         BANKMASK(IOCBP), 0
#define IOCBP1                         BANKMASK(IOCBP), 1
#define IOCBP2                         BANKMASK(IOCBP), 2
#define IOCBP3                         BANKMASK(IOCBP), 3
#define IOCBP4                         BANKMASK(IOCBP), 4
#define IOCBP5                         BANKMASK(IOCBP), 5
#define IOCBP6                         BANKMASK(IOCBP), 6
#define IOCBP7                         BANKMASK(IOCBP), 7
#ifndef _LIB_BUILD
#endif
IOCBN                                  equ 0395h
#define IOCBN0                         BANKMASK(IOCBN), 0
#define IOCBN1                         BANKMASK(IOCBN), 1
#define IOCBN2                         BANKMASK(IOCBN), 2
#define IOCBN3                         BANKMASK(IOCBN), 3
#define IOCBN4                         BANKMASK(IOCBN), 4
#define IOCBN5                         BANKMASK(IOCBN), 5
#define IOCBN6                         BANKMASK(IOCBN), 6
#define IOCBN7                         BANKMASK(IOCBN), 7
#ifndef _LIB_BUILD
#endif
IOCBF                                  equ 0396h
#define IOCBF0                         BANKMASK(IOCBF), 0
#define IOCBF1                         BANKMASK(IOCBF), 1
#define IOCBF2                         BANKMASK(IOCBF), 2
#define IOCBF3                         BANKMASK(IOCBF), 3
#define IOCBF4                         BANKMASK(IOCBF), 4
#define IOCBF5                         BANKMASK(IOCBF), 5
#define IOCBF6                         BANKMASK(IOCBF), 6
#define IOCBF7                         BANKMASK(IOCBF), 7
#ifndef _LIB_BUILD
#endif
STATUS_SHAD                            equ 0FE4h
#define C_SHAD                         BANKMASK(STATUS_SHAD), 0
#define DC_SHAD                        BANKMASK(STATUS_SHAD), 1
#define Z_SHAD                         BANKMASK(STATUS_SHAD), 2
#ifndef _LIB_BUILD
#endif
WREG_SHAD                              equ 0FE5h
BSR_SHAD                               equ 0FE6h
#ifndef _LIB_BUILD
#endif
PCLATH_SHAD                            equ 0FE7h
#ifndef _LIB_BUILD
#endif
FSR0L_SHAD                             equ 0FE8h
FSR0H_SHAD                             equ 0FE9h
FSR1L_SHAD                             equ 0FEAh
FSR1H_SHAD                             equ 0FEBh
STKPTR                                 equ 0FEDh
#ifndef _LIB_BUILD
#endif
TOSL                                   equ 0FEEh
TOSH                                   equ 0FEFh
#ifndef _LIB_BUILD
#endif

#endif
#endif

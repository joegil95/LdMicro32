#ifndef _ASPIC_H_
#warning Header file as10f206.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS10F206_H_
#define _AS10F206_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define CWUF                           BANKMASK(STATUS), 6
#define GPWUF                          BANKMASK(STATUS), 7
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
OSCCAL                                 equ 0005h
#define FOSC4                          BANKMASK(OSCCAL), 0
#define CAL0                           BANKMASK(OSCCAL), 1
#define CAL1                           BANKMASK(OSCCAL), 2
#define CAL2                           BANKMASK(OSCCAL), 3
#define CAL3                           BANKMASK(OSCCAL), 4
#define CAL4                           BANKMASK(OSCCAL), 5
#define CAL5                           BANKMASK(OSCCAL), 6
#define CAL6                           BANKMASK(OSCCAL), 7
#ifndef _LIB_BUILD
#endif
GPIO                                   equ 0006h
#define GP0                            BANKMASK(GPIO), 0
#define GP1                            BANKMASK(GPIO), 1
#define GP2                            BANKMASK(GPIO), 2
#define GP3                            BANKMASK(GPIO), 3
#ifndef _LIB_BUILD
#endif
CMCON0                                 equ 0007h
#define nCWU                           BANKMASK(CMCON0), 0
#define CPREF                          BANKMASK(CMCON0), 1
#define CNREF                          BANKMASK(CMCON0), 2
#define CMPON                          BANKMASK(CMCON0), 3
#define nCMPT0CS                       BANKMASK(CMCON0), 4
#define POL                            BANKMASK(CMCON0), 5
#define nCOUTEN                        BANKMASK(CMCON0), 6
#define CMPOUT                         BANKMASK(CMCON0), 7
#ifndef _LIB_BUILD
#endif

#endif
#endif

#ifndef _ASPIC_H_
#warning Header file as16f1826.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS16F1826_H_
#define _AS16F1826_H_

INDF0                                  equ 0000h
INDF1                                  equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#ifndef _LIB_BUILD
#endif
FSR0L                                  equ 0004h
FSR0H                                  equ 0005h
FSR1L                                  equ 0006h
FSR1H                                  equ 0007h
BSR                                    equ 0008h
#define BSR0                           BANKMASK(BSR), 0
#define BSR1                           BANKMASK(BSR), 1
#define BSR2                           BANKMASK(BSR), 2
#define BSR3                           BANKMASK(BSR), 3
#define BSR4                           BANKMASK(BSR), 4
#ifndef _LIB_BUILD
#endif
WREG                                   equ 0009h
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define IOCIF                          BANKMASK(INTCON), 0
#define INTF                           BANKMASK(INTCON), 1
#define TMR0IF                         BANKMASK(INTCON), 2
#define IOCIE                          BANKMASK(INTCON), 3
#define INTE                           BANKMASK(INTCON), 4
#define TMR0IE                         BANKMASK(INTCON), 5
#define PEIE                           BANKMASK(INTCON), 6
#define GIE                            BANKMASK(INTCON), 7
#define T0IF                           BANKMASK(INTCON), 2
#define T0IE                           BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PORTA                                  equ 000Ch
#define RA0                            BANKMASK(PORTA), 0
#define RA1                            BANKMASK(PORTA), 1
#define RA2                            BANKMASK(PORTA), 2
#define RA3                            BANKMASK(PORTA), 3
#define RA4                            BANKMASK(PORTA), 4
#define RA5                            BANKMASK(PORTA), 5
#define RA6                            BANKMASK(PORTA), 6
#define RA7                            BANKMASK(PORTA), 7
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 000Dh
#define RB0                            BANKMASK(PORTB), 0
#define RB1                            BANKMASK(PORTB), 1
#define RB2                            BANKMASK(PORTB), 2
#define RB3                            BANKMASK(PORTB), 3
#define RB4                            BANKMASK(PORTB), 4
#define RB5                            BANKMASK(PORTB), 5
#define RB6                            BANKMASK(PORTB), 6
#define RB7                            BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 0011h
#define TMR1IF                         BANKMASK(PIR1), 0
#define TMR2IF                         BANKMASK(PIR1), 1
#define CCP1IF                         BANKMASK(PIR1), 2
#define SSP1IF                         BANKMASK(PIR1), 3
#define TXIF                           BANKMASK(PIR1), 4
#define RCIF                           BANKMASK(PIR1), 5
#define ADIF                           BANKMASK(PIR1), 6
#define TMR1GIF                        BANKMASK(PIR1), 7
#ifndef _LIB_BUILD
#endif
PIR2                                   equ 0012h
#define BCL1IF                         BANKMASK(PIR2), 3
#define EEIF                           BANKMASK(PIR2), 4
#define C1IF                           BANKMASK(PIR2), 5
#define C2IF                           BANKMASK(PIR2), 6
#define OSFIF                          BANKMASK(PIR2), 7
#ifndef _LIB_BUILD
#endif
TMR0                                   equ 0015h
TMR1L                                  equ 0016h
TMR1H                                  equ 0017h
T1CON                                  equ 0018h
#define TMR1ON                         BANKMASK(T1CON), 0
#define nT1SYNC                        BANKMASK(T1CON), 2
#define T1OSCEN                        BANKMASK(T1CON), 3
#define T1CKPS0                        BANKMASK(T1CON), 4
#define T1CKPS1                        BANKMASK(T1CON), 5
#define TMR1CS0                        BANKMASK(T1CON), 6
#define TMR1CS1                        BANKMASK(T1CON), 7
#ifndef _LIB_BUILD
#endif
T1GCON                                 equ 0019h
#define T1GSS0                         BANKMASK(T1GCON), 0
#define T1GSS1                         BANKMASK(T1GCON), 1
#define T1GVAL                         BANKMASK(T1GCON), 2
#define T1GGO                          BANKMASK(T1GCON), 3
#define T1GSPM                         BANKMASK(T1GCON), 4
#define T1GTM                          BANKMASK(T1GCON), 5
#define T1GPOL                         BANKMASK(T1GCON), 6
#define TMR1GE                         BANKMASK(T1GCON), 7
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 001Ah
PR2                                    equ 001Bh
T2CON                                  equ 001Ch
#define T2CKPS0                        BANKMASK(T2CON), 0
#define T2CKPS1                        BANKMASK(T2CON), 1
#define TMR2ON                         BANKMASK(T2CON), 2
#define T2OUTPS0                       BANKMASK(T2CON), 3
#define T2OUTPS1                       BANKMASK(T2CON), 4
#define T2OUTPS2                       BANKMASK(T2CON), 5
#define T2OUTPS3                       BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
CPSCON0                                equ 001Eh
#define T0XCS                          BANKMASK(CPSCON0), 0
#define CPSOUT                         BANKMASK(CPSCON0), 1
#define CPSRNG0                        BANKMASK(CPSCON0), 2
#define CPSRNG1                        BANKMASK(CPSCON0), 3
#define CPSON                          BANKMASK(CPSCON0), 7
#ifndef _LIB_BUILD
#endif
CPSCON1                                equ 001Fh
#define CPSCH0                         BANKMASK(CPSCON1), 0
#define CPSCH1                         BANKMASK(CPSCON1), 1
#define CPSCH2                         BANKMASK(CPSCON1), 2
#define CPSCH3                         BANKMASK(CPSCON1), 3
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 008Ch
#define TRISA0                         BANKMASK(TRISA), 0
#define TRISA1                         BANKMASK(TRISA), 1
#define TRISA2                         BANKMASK(TRISA), 2
#define TRISA3                         BANKMASK(TRISA), 3
#define TRISA4                         BANKMASK(TRISA), 4
#define TRISA5                         BANKMASK(TRISA), 5
#define TRISA6                         BANKMASK(TRISA), 6
#define TRISA7                         BANKMASK(TRISA), 7
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 008Dh
#define TRISB0                         BANKMASK(TRISB), 0
#define TRISB1                         BANKMASK(TRISB), 1
#define TRISB2                         BANKMASK(TRISB), 2
#define TRISB3                         BANKMASK(TRISB), 3
#define TRISB4                         BANKMASK(TRISB), 4
#define TRISB5                         BANKMASK(TRISB), 5
#define TRISB6                         BANKMASK(TRISB), 6
#define TRISB7                         BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 0091h
#define TMR1IE                         BANKMASK(PIE1), 0
#define TMR2IE                         BANKMASK(PIE1), 1
#define CCP1IE                         BANKMASK(PIE1), 2
#define SSP1IE                         BANKMASK(PIE1), 3
#define TXIE                           BANKMASK(PIE1), 4
#define RCIE                           BANKMASK(PIE1), 5
#define ADIE                           BANKMASK(PIE1), 6
#define TMR1GIE                        BANKMASK(PIE1), 7
#ifndef _LIB_BUILD
#endif
PIE2                                   equ 0092h
#define BCL1IE                         BANKMASK(PIE2), 3
#define EEIE                           BANKMASK(PIE2), 4
#define C1IE                           BANKMASK(PIE2), 5
#define C2IE                           BANKMASK(PIE2), 6
#define OSFIE                          BANKMASK(PIE2), 7
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0095h
#define PS0                            BANKMASK(OPTION_REG), 0
#define PS1                            BANKMASK(OPTION_REG), 1
#define PS2                            BANKMASK(OPTION_REG), 2
#define PSA                            BANKMASK(OPTION_REG), 3
#define TMR0SE                         BANKMASK(OPTION_REG), 4
#define TMR0CS                         BANKMASK(OPTION_REG), 5
#define INTEDG                         BANKMASK(OPTION_REG), 6
#define nWPUEN                         BANKMASK(OPTION_REG), 7
#define T0SE                           BANKMASK(OPTION_REG), 4
#define T0CS                           BANKMASK(OPTION_REG), 5
#ifndef _LIB_BUILD
#endif
PCON                                   equ 0096h
#define nBOR                           BANKMASK(PCON), 0
#define nPOR                           BANKMASK(PCON), 1
#define nRI                            BANKMASK(PCON), 2
#define nRMCLR                         BANKMASK(PCON), 3
#define STKUNF                         BANKMASK(PCON), 6
#define STKOVF                         BANKMASK(PCON), 7
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0097h
#define SWDTEN                         BANKMASK(WDTCON), 0
#define WDTPS0                         BANKMASK(WDTCON), 1
#define WDTPS1                         BANKMASK(WDTCON), 2
#define WDTPS2                         BANKMASK(WDTCON), 3
#define WDTPS3                         BANKMASK(WDTCON), 4
#define WDTPS4                         BANKMASK(WDTCON), 5
#ifndef _LIB_BUILD
#endif
OSCTUNE                                equ 0098h
#define TUN0                           BANKMASK(OSCTUNE), 0
#define TUN1                           BANKMASK(OSCTUNE), 1
#define TUN2                           BANKMASK(OSCTUNE), 2
#define TUN3                           BANKMASK(OSCTUNE), 3
#define TUN4                           BANKMASK(OSCTUNE), 4
#define TUN5                           BANKMASK(OSCTUNE), 5
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 0099h
#define SCS0                           BANKMASK(OSCCON), 0
#define SCS1                           BANKMASK(OSCCON), 1
#define IRCF0                          BANKMASK(OSCCON), 3
#define IRCF1                          BANKMASK(OSCCON), 4
#define IRCF2                          BANKMASK(OSCCON), 5
#define IRCF3                          BANKMASK(OSCCON), 6
#define SPLLEN                         BANKMASK(OSCCON), 7
#ifndef _LIB_BUILD
#endif
OSCSTAT                                equ 009Ah
#define HFIOFS                         BANKMASK(OSCSTAT), 0
#define LFIOFR                         BANKMASK(OSCSTAT), 1
#define MFIOFR                         BANKMASK(OSCSTAT), 2
#define HFIOFL                         BANKMASK(OSCSTAT), 3
#define HFIOFR                         BANKMASK(OSCSTAT), 4
#define OSTS                           BANKMASK(OSCSTAT), 5
#define PLLR                           BANKMASK(OSCSTAT), 6
#define T1OSCR                         BANKMASK(OSCSTAT), 7
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 009Bh
ADRESH                                 equ 009Ch
ADCON0                                 equ 009Dh
#define ADON                           BANKMASK(ADCON0), 0
#define GO_nDONE                       BANKMASK(ADCON0), 1
#define CHS0                           BANKMASK(ADCON0), 2
#define CHS1                           BANKMASK(ADCON0), 3
#define CHS2                           BANKMASK(ADCON0), 4
#define CHS3                           BANKMASK(ADCON0), 5
#define CHS4                           BANKMASK(ADCON0), 6
#define ADGO                           BANKMASK(ADCON0), 1
#define GO                             BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 009Eh
#define ADPREF0                        BANKMASK(ADCON1), 0
#define ADPREF1                        BANKMASK(ADCON1), 1
#define ADNREF                         BANKMASK(ADCON1), 2
#define ADCS0                          BANKMASK(ADCON1), 4
#define ADCS1                          BANKMASK(ADCON1), 5
#define ADCS2                          BANKMASK(ADCON1), 6
#define ADFM                           BANKMASK(ADCON1), 7
#ifndef _LIB_BUILD
#endif
LATA                                   equ 010Ch
#define LATA0                          BANKMASK(LATA), 0
#define LATA1                          BANKMASK(LATA), 1
#define LATA2                          BANKMASK(LATA), 2
#define LATA3                          BANKMASK(LATA), 3
#define LATA4                          BANKMASK(LATA), 4
#define LATA6                          BANKMASK(LATA), 6
#define LATA7                          BANKMASK(LATA), 7
#ifndef _LIB_BUILD
#endif
LATB                                   equ 010Dh
#define LATB0                          BANKMASK(LATB), 0
#define LATB1                          BANKMASK(LATB), 1
#define LATB2                          BANKMASK(LATB), 2
#define LATB3                          BANKMASK(LATB), 3
#define LATB4                          BANKMASK(LATB), 4
#define LATB5                          BANKMASK(LATB), 5
#define LATB6                          BANKMASK(LATB), 6
#define LATB7                          BANKMASK(LATB), 7
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 0111h
#define C1SYNC                         BANKMASK(CM1CON0), 0
#define C1HYS                          BANKMASK(CM1CON0), 1
#define C1SP                           BANKMASK(CM1CON0), 2
#define C1POL                          BANKMASK(CM1CON0), 4
#define C1OE                           BANKMASK(CM1CON0), 5
#define C1OUT                          BANKMASK(CM1CON0), 6
#define C1ON                           BANKMASK(CM1CON0), 7
#ifndef _LIB_BUILD
#endif
CM1CON1                                equ 0112h
#define C1NCH0                         BANKMASK(CM1CON1), 0
#define C1NCH1                         BANKMASK(CM1CON1), 1
#define C1PCH0                         BANKMASK(CM1CON1), 4
#define C1PCH1                         BANKMASK(CM1CON1), 5
#define C1INTN                         BANKMASK(CM1CON1), 6
#define C1INTP                         BANKMASK(CM1CON1), 7
#ifndef _LIB_BUILD
#endif
CM2CON0                                equ 0113h
#define C2SYNC                         BANKMASK(CM2CON0), 0
#define C2HYS                          BANKMASK(CM2CON0), 1
#define C2SP                           BANKMASK(CM2CON0), 2
#define C2POL                          BANKMASK(CM2CON0), 4
#define C2OE                           BANKMASK(CM2CON0), 5
#define C2OUT                          BANKMASK(CM2CON0), 6
#define C2ON                           BANKMASK(CM2CON0), 7
#ifndef _LIB_BUILD
#endif
CM2CON1                                equ 0114h
#define C2NCH0                         BANKMASK(CM2CON1), 0
#define C2NCH1                         BANKMASK(CM2CON1), 1
#define C2PCH0                         BANKMASK(CM2CON1), 4
#define C2PCH1                         BANKMASK(CM2CON1), 5
#define C2INTN                         BANKMASK(CM2CON1), 6
#define C2INTP                         BANKMASK(CM2CON1), 7
#ifndef _LIB_BUILD
#endif
CMOUT                                  equ 0115h
#define MC1OUT                         BANKMASK(CMOUT), 0
#define MC2OUT                         BANKMASK(CMOUT), 1
#ifndef _LIB_BUILD
#endif
BORCON                                 equ 0116h
#define BORRDY                         BANKMASK(BORCON), 0
#define SBOREN                         BANKMASK(BORCON), 7
#ifndef _LIB_BUILD
#endif
FVRCON                                 equ 0117h
#define ADFVR0                         BANKMASK(FVRCON), 0
#define ADFVR1                         BANKMASK(FVRCON), 1
#define CDAFVR0                        BANKMASK(FVRCON), 2
#define CDAFVR1                        BANKMASK(FVRCON), 3
#define TSRNG                          BANKMASK(FVRCON), 4
#define TSEN                           BANKMASK(FVRCON), 5
#define FVRRDY                         BANKMASK(FVRCON), 6
#define FVREN                          BANKMASK(FVRCON), 7
#ifndef _LIB_BUILD
#endif
DACCON0                                equ 0118h
#define DACNSS                         BANKMASK(DACCON0), 0
#define DACPSS0                        BANKMASK(DACCON0), 2
#define DACPSS1                        BANKMASK(DACCON0), 3
#define DACOE                          BANKMASK(DACCON0), 5
#define DACLPS                         BANKMASK(DACCON0), 6
#define DACEN                          BANKMASK(DACCON0), 7
#ifndef _LIB_BUILD
#endif
DACCON1                                equ 0119h
#define DACR0                          BANKMASK(DACCON1), 0
#define DACR1                          BANKMASK(DACCON1), 1
#define DACR2                          BANKMASK(DACCON1), 2
#define DACR3                          BANKMASK(DACCON1), 3
#define DACR4                          BANKMASK(DACCON1), 4
#ifndef _LIB_BUILD
#endif
SRCON0                                 equ 011Ah
#define SRPR                           BANKMASK(SRCON0), 0
#define SRPS                           BANKMASK(SRCON0), 1
#define SRNQEN                         BANKMASK(SRCON0), 2
#define SRQEN                          BANKMASK(SRCON0), 3
#define SRCLK0                         BANKMASK(SRCON0), 4
#define SRCLK1                         BANKMASK(SRCON0), 5
#define SRCLK2                         BANKMASK(SRCON0), 6
#define SRLEN                          BANKMASK(SRCON0), 7
#ifndef _LIB_BUILD
#endif
SRCON1                                 equ 011Bh
#define SRRC1E                         BANKMASK(SRCON1), 0
#define SRRC2E                         BANKMASK(SRCON1), 1
#define SRRCKE                         BANKMASK(SRCON1), 2
#define SRRPE                          BANKMASK(SRCON1), 3
#define SRSC1E                         BANKMASK(SRCON1), 4
#define SRSC2E                         BANKMASK(SRCON1), 5
#define SRSCKE                         BANKMASK(SRCON1), 6
#define SRSPE                          BANKMASK(SRCON1), 7
#ifndef _LIB_BUILD
#endif
APFCON0                                equ 011Dh
#define CCP1SEL                        BANKMASK(APFCON0), 0
#define P1CSEL                         BANKMASK(APFCON0), 1
#define P1DSEL                         BANKMASK(APFCON0), 2
#define SS1SEL                         BANKMASK(APFCON0), 5
#define SDO1SEL                        BANKMASK(APFCON0), 6
#define RXDTSEL                        BANKMASK(APFCON0), 7
#ifndef _LIB_BUILD
#endif
APFCON1                                equ 011Eh
#define TXCKSEL                        BANKMASK(APFCON1), 0
#ifndef _LIB_BUILD
#endif
ANSELA                                 equ 018Ch
#define ANSA0                          BANKMASK(ANSELA), 0
#define ANSA1                          BANKMASK(ANSELA), 1
#define ANSA2                          BANKMASK(ANSELA), 2
#define ANSA3                          BANKMASK(ANSELA), 3
#define ANSA4                          BANKMASK(ANSELA), 4
#ifndef _LIB_BUILD
#endif
ANSELB                                 equ 018Dh
#define ANSB1                          BANKMASK(ANSELB), 1
#define ANSB2                          BANKMASK(ANSELB), 2
#define ANSB3                          BANKMASK(ANSELB), 3
#define ANSB4                          BANKMASK(ANSELB), 4
#define ANSB5                          BANKMASK(ANSELB), 5
#define ANSB6                          BANKMASK(ANSELB), 6
#define ANSB7                          BANKMASK(ANSELB), 7
#ifndef _LIB_BUILD
#endif
EEADRL                                 equ 0191h
EEADRH                                 equ 0192h
#ifndef _LIB_BUILD
#endif
EEDATL                                 equ 0193h
EEDATA                                 equ 0193h
EEDATH                                 equ 0194h
#ifndef _LIB_BUILD
#endif
EECON1                                 equ 0195h
#define RD                             BANKMASK(EECON1), 0
#define WR                             BANKMASK(EECON1), 1
#define WREN                           BANKMASK(EECON1), 2
#define WRERR                          BANKMASK(EECON1), 3
#define FREE                           BANKMASK(EECON1), 4
#define LWLO                           BANKMASK(EECON1), 5
#define CFGS                           BANKMASK(EECON1), 6
#define EEPGD                          BANKMASK(EECON1), 7
#ifndef _LIB_BUILD
#endif
EECON2                                 equ 0196h
RCREG                                  equ 0199h
TXREG                                  equ 019Ah
SPBRGL                                 equ 019Bh
SPBRG                                  equ 019Bh
SPBRGH                                 equ 019Ch
RCSTA                                  equ 019Dh
#define RX9D                           BANKMASK(RCSTA), 0
#define OERR                           BANKMASK(RCSTA), 1
#define FERR                           BANKMASK(RCSTA), 2
#define ADDEN                          BANKMASK(RCSTA), 3
#define CREN                           BANKMASK(RCSTA), 4
#define SREN                           BANKMASK(RCSTA), 5
#define RX9                            BANKMASK(RCSTA), 6
#define SPEN                           BANKMASK(RCSTA), 7
#ifndef _LIB_BUILD
#endif
TXSTA                                  equ 019Eh
#define TX9D                           BANKMASK(TXSTA), 0
#define TRMT                           BANKMASK(TXSTA), 1
#define BRGH                           BANKMASK(TXSTA), 2
#define SENDB                          BANKMASK(TXSTA), 3
#define SYNC                           BANKMASK(TXSTA), 4
#define TXEN                           BANKMASK(TXSTA), 5
#define TX9                            BANKMASK(TXSTA), 6
#define CSRC                           BANKMASK(TXSTA), 7
#ifndef _LIB_BUILD
#endif
BAUDCON                                equ 019Fh
#define ABDEN                          BANKMASK(BAUDCON), 0
#define WUE                            BANKMASK(BAUDCON), 1
#define BRG16                          BANKMASK(BAUDCON), 3
#define SCKP                           BANKMASK(BAUDCON), 4
#define RCIDL                          BANKMASK(BAUDCON), 6
#define ABDOVF                         BANKMASK(BAUDCON), 7
#ifndef _LIB_BUILD
#endif
WPUA                                   equ 020Ch
#define WPUA5                          BANKMASK(WPUA), 5
#ifndef _LIB_BUILD
#endif
WPUB                                   equ 020Dh
#define WPUB0                          BANKMASK(WPUB), 0
#define WPUB1                          BANKMASK(WPUB), 1
#define WPUB2                          BANKMASK(WPUB), 2
#define WPUB3                          BANKMASK(WPUB), 3
#define WPUB4                          BANKMASK(WPUB), 4
#define WPUB5                          BANKMASK(WPUB), 5
#define WPUB6                          BANKMASK(WPUB), 6
#define WPUB7                          BANKMASK(WPUB), 7
#ifndef _LIB_BUILD
#endif
SSP1BUF                                equ 0211h
SSPBUF                                 equ 0211h
SSP1ADD                                equ 0212h
SSPADD                                 equ 0212h
SSP1MSK                                equ 0213h
SSPMSK                                 equ 0213h
SSP1STAT                               equ 0214h
SSPSTAT                                equ 0214h
#define BF                             BANKMASK(SSP1STAT), 0
#define UA                             BANKMASK(SSP1STAT), 1
#define R_nW                           BANKMASK(SSP1STAT), 2
#define S                              BANKMASK(SSP1STAT), 3
#define P                              BANKMASK(SSP1STAT), 4
#define D_nA                           BANKMASK(SSP1STAT), 5
#define CKE                            BANKMASK(SSP1STAT), 6
#define SMP                            BANKMASK(SSP1STAT), 7
#ifndef _LIB_BUILD
#endif
SSP1CON1                               equ 0215h
SSPCON1                                equ 0215h
SSPCON                                 equ 0215h
#define SSPM0                          BANKMASK(SSP1CON1), 0
#define SSPM1                          BANKMASK(SSP1CON1), 1
#define SSPM2                          BANKMASK(SSP1CON1), 2
#define SSPM3                          BANKMASK(SSP1CON1), 3
#define CKP                            BANKMASK(SSP1CON1), 4
#define SSPEN                          BANKMASK(SSP1CON1), 5
#define SSPOV                          BANKMASK(SSP1CON1), 6
#define WCOL                           BANKMASK(SSP1CON1), 7
#ifndef _LIB_BUILD
#endif
SSP1CON2                               equ 0216h
SSPCON2                                equ 0216h
#define SEN                            BANKMASK(SSP1CON2), 0
#define RSEN                           BANKMASK(SSP1CON2), 1
#define PEN                            BANKMASK(SSP1CON2), 2
#define RCEN                           BANKMASK(SSP1CON2), 3
#define ACKEN                          BANKMASK(SSP1CON2), 4
#define ACKDT                          BANKMASK(SSP1CON2), 5
#define ACKSTAT                        BANKMASK(SSP1CON2), 6
#define GCEN                           BANKMASK(SSP1CON2), 7
#ifndef _LIB_BUILD
#endif
SSP1CON3                               equ 0217h
SSPCON3                                equ 0217h
#define DHEN                           BANKMASK(SSP1CON3), 0
#define AHEN                           BANKMASK(SSP1CON3), 1
#define SBCDE                          BANKMASK(SSP1CON3), 2
#define SDAHT                          BANKMASK(SSP1CON3), 3
#define BOEN                           BANKMASK(SSP1CON3), 4
#define SCIE                           BANKMASK(SSP1CON3), 5
#define PCIE                           BANKMASK(SSP1CON3), 6
#define ACKTIM                         BANKMASK(SSP1CON3), 7
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0291h
CCPR1H                                 equ 0292h
CCP1CON                                equ 0293h
#define CCP1M0                         BANKMASK(CCP1CON), 0
#define CCP1M1                         BANKMASK(CCP1CON), 1
#define CCP1M2                         BANKMASK(CCP1CON), 2
#define CCP1M3                         BANKMASK(CCP1CON), 3
#define DC1B0                          BANKMASK(CCP1CON), 4
#define DC1B1                          BANKMASK(CCP1CON), 5
#define P1M0                           BANKMASK(CCP1CON), 6
#define P1M1                           BANKMASK(CCP1CON), 7
#ifndef _LIB_BUILD
#endif
PWM1CON                                equ 0294h
#define P1DC0                          BANKMASK(PWM1CON), 0
#define P1DC1                          BANKMASK(PWM1CON), 1
#define P1DC2                          BANKMASK(PWM1CON), 2
#define P1DC3                          BANKMASK(PWM1CON), 3
#define P1DC4                          BANKMASK(PWM1CON), 4
#define P1DC5                          BANKMASK(PWM1CON), 5
#define P1DC6                          BANKMASK(PWM1CON), 6
#define P1RSEN                         BANKMASK(PWM1CON), 7
#ifndef _LIB_BUILD
#endif
CCP1AS                                 equ 0295h
ECCP1AS                                equ 0295h
#define PSS1BD0                        BANKMASK(CCP1AS), 0
#define PSS1BD1                        BANKMASK(CCP1AS), 1
#define PSS1AC0                        BANKMASK(CCP1AS), 2
#define PSS1AC1                        BANKMASK(CCP1AS), 3
#define CCP1AS0                        BANKMASK(CCP1AS), 4
#define CCP1AS1                        BANKMASK(CCP1AS), 5
#define CCP1AS2                        BANKMASK(CCP1AS), 6
#define CCP1ASE                        BANKMASK(CCP1AS), 7
#ifndef _LIB_BUILD
#endif
PSTR1CON                               equ 0296h
#define STR1A                          BANKMASK(PSTR1CON), 0
#define STR1B                          BANKMASK(PSTR1CON), 1
#define STR1C                          BANKMASK(PSTR1CON), 2
#define STR1D                          BANKMASK(PSTR1CON), 3
#define STR1SYNC                       BANKMASK(PSTR1CON), 4
#ifndef _LIB_BUILD
#endif
IOCBP                                  equ 0394h
#define IOCBP0                         BANKMASK(IOCBP), 0
#define IOCBP1                         BANKMASK(IOCBP), 1
#define IOCBP2                         BANKMASK(IOCBP), 2
#define IOCBP3                         BANKMASK(IOCBP), 3
#define IOCBP4                         BANKMASK(IOCBP), 4
#define IOCBP5                         BANKMASK(IOCBP), 5
#define IOCBP6                         BANKMASK(IOCBP), 6
#define IOCBP7                         BANKMASK(IOCBP), 7
#ifndef _LIB_BUILD
#endif
IOCBN                                  equ 0395h
#define IOCBN0                         BANKMASK(IOCBN), 0
#define IOCBN1                         BANKMASK(IOCBN), 1
#define IOCBN2                         BANKMASK(IOCBN), 2
#define IOCBN3                         BANKMASK(IOCBN), 3
#define IOCBN4                         BANKMASK(IOCBN), 4
#define IOCBN5                         BANKMASK(IOCBN), 5
#define IOCBN6                         BANKMASK(IOCBN), 6
#define IOCBN7                         BANKMASK(IOCBN), 7
#ifndef _LIB_BUILD
#endif
IOCBF                                  equ 0396h
#define IOCBF0                         BANKMASK(IOCBF), 0
#define IOCBF1                         BANKMASK(IOCBF), 1
#define IOCBF2                         BANKMASK(IOCBF), 2
#define IOCBF3                         BANKMASK(IOCBF), 3
#define IOCBF4                         BANKMASK(IOCBF), 4
#define IOCBF5                         BANKMASK(IOCBF), 5
#define IOCBF6                         BANKMASK(IOCBF), 6
#define IOCBF7                         BANKMASK(IOCBF), 7
#ifndef _LIB_BUILD
#endif
CLKRCON                                equ 039Ah
#define CLKRDIV0                       BANKMASK(CLKRCON), 0
#define CLKRDIV1                       BANKMASK(CLKRCON), 1
#define CLKRDIV2                       BANKMASK(CLKRCON), 2
#define CLKRDC0                        BANKMASK(CLKRCON), 3
#define CLKRDC1                        BANKMASK(CLKRCON), 4
#define CLKRSLR                        BANKMASK(CLKRCON), 5
#define CLKROE                         BANKMASK(CLKRCON), 6
#define CLKREN                         BANKMASK(CLKRCON), 7
#ifndef _LIB_BUILD
#endif
MDCON                                  equ 039Ch
#define MDBIT                          BANKMASK(MDCON), 0
#define MDOUT                          BANKMASK(MDCON), 3
#define MDOPOL                         BANKMASK(MDCON), 4
#define MDSLR                          BANKMASK(MDCON), 5
#define MDOE                           BANKMASK(MDCON), 6
#define MDEN                           BANKMASK(MDCON), 7
#ifndef _LIB_BUILD
#endif
MDSRC                                  equ 039Dh
#define MDMS0                          BANKMASK(MDSRC), 0
#define MDMS1                          BANKMASK(MDSRC), 1
#define MDMS2                          BANKMASK(MDSRC), 2
#define MDMS3                          BANKMASK(MDSRC), 3
#define MDMSODIS                       BANKMASK(MDSRC), 7
#ifndef _LIB_BUILD
#endif
MDCARL                                 equ 039Eh
#define MDCL0                          BANKMASK(MDCARL), 0
#define MDCL1                          BANKMASK(MDCARL), 1
#define MDCL2                          BANKMASK(MDCARL), 2
#define MDCL3                          BANKMASK(MDCARL), 3
#define MDCLSYNC                       BANKMASK(MDCARL), 5
#define MDCLPOL                        BANKMASK(MDCARL), 6
#define MDCLODIS                       BANKMASK(MDCARL), 7
#ifndef _LIB_BUILD
#endif
MDCARH                                 equ 039Fh
#define MDCH0                          BANKMASK(MDCARH), 0
#define MDCH1                          BANKMASK(MDCARH), 1
#define MDCH2                          BANKMASK(MDCARH), 2
#define MDCH3                          BANKMASK(MDCARH), 3
#define MDCHSYNC                       BANKMASK(MDCARH), 5
#define MDCHPOL                        BANKMASK(MDCARH), 6
#define MDCHODIS                       BANKMASK(MDCARH), 7
#ifndef _LIB_BUILD
#endif
STATUS_SHAD                            equ 0FE4h
#define C_SHAD                         BANKMASK(STATUS_SHAD), 0
#define DC_SHAD                        BANKMASK(STATUS_SHAD), 1
#define Z_SHAD                         BANKMASK(STATUS_SHAD), 2
#ifndef _LIB_BUILD
#endif
WREG_SHAD                              equ 0FE5h
BSR_SHAD                               equ 0FE6h
#ifndef _LIB_BUILD
#endif
PCLATH_SHAD                            equ 0FE7h
#ifndef _LIB_BUILD
#endif
FSR0L_SHAD                             equ 0FE8h
FSR0H_SHAD                             equ 0FE9h
FSR1L_SHAD                             equ 0FEAh
FSR1H_SHAD                             equ 0FEBh
STKPTR                                 equ 0FEDh
#ifndef _LIB_BUILD
#endif
TOSL                                   equ 0FEEh
TOSH                                   equ 0FEFh
#ifndef _LIB_BUILD
#endif

#endif
#endif

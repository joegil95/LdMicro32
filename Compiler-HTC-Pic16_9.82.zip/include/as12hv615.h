#ifndef _ASPIC_H_
#warning Header file as12hv615.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS12HV615_H_
#define _AS12HV615_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define IRP                            BANKMASK(STATUS), 7
#define RP0                            BANKMASK(STATUS), 5
#define RP1                            BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
GPIO                                   equ 0005h
PORTA                                  equ 0005h
#define GP0                            BANKMASK(GPIO), 0
#define GP1                            BANKMASK(GPIO), 1
#define GP2                            BANKMASK(GPIO), 2
#define GP3                            BANKMASK(GPIO), 3
#define GP4                            BANKMASK(GPIO), 4
#define GP5                            BANKMASK(GPIO), 5
#define GPIO0                          BANKMASK(GPIO), 0
#define GPIO1                          BANKMASK(GPIO), 1
#define GPIO2                          BANKMASK(GPIO), 2
#define GPIO3                          BANKMASK(GPIO), 3
#define GPIO4                          BANKMASK(GPIO), 4
#define GPIO5                          BANKMASK(GPIO), 5
#define RA0                            BANKMASK(GPIO), 0
#define RA1                            BANKMASK(GPIO), 1
#define RA2                            BANKMASK(GPIO), 2
#define RA3                            BANKMASK(GPIO), 3
#define RA4                            BANKMASK(GPIO), 4
#define RA5                            BANKMASK(GPIO), 5
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define GPIF                           BANKMASK(INTCON), 0
#define INTF                           BANKMASK(INTCON), 1
#define TMR0IF                         BANKMASK(INTCON), 2
#define GPIE                           BANKMASK(INTCON), 3
#define INTE                           BANKMASK(INTCON), 4
#define TMR0IE                         BANKMASK(INTCON), 5
#define PEIE                           BANKMASK(INTCON), 6
#define GIE                            BANKMASK(INTCON), 7
#define T0IF                           BANKMASK(INTCON), 2
#define T0IE                           BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF                         BANKMASK(PIR1), 0
#define TMR2IF                         BANKMASK(PIR1), 1
#define C1IF                           BANKMASK(PIR1), 3
#define ECCPIF                         BANKMASK(PIR1), 5
#define ADIF                           BANKMASK(PIR1), 6
#define T1IF                           BANKMASK(PIR1), 0
#define T2IF                           BANKMASK(PIR1), 1
#define CMIF                           BANKMASK(PIR1), 3
#define CCP1IF                         BANKMASK(PIR1), 5
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Eh
TMR1H                                  equ 000Fh
T1CON                                  equ 0010h
#define TMR1ON                         BANKMASK(T1CON), 0
#define TMR1CS                         BANKMASK(T1CON), 1
#define nT1SYNC                        BANKMASK(T1CON), 2
#define T1OSCEN                        BANKMASK(T1CON), 3
#define TMR1GE                         BANKMASK(T1CON), 6
#define T1GINV                         BANKMASK(T1CON), 7
#define T1CKPS0                        BANKMASK(T1CON), 4
#define T1CKPS1                        BANKMASK(T1CON), 5
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 0011h
T2CON                                  equ 0012h
#define TMR2ON                         BANKMASK(T2CON), 2
#define T2CKPS0                        BANKMASK(T2CON), 0
#define T2CKPS1                        BANKMASK(T2CON), 1
#define T2ON                           BANKMASK(T2CON), 2
#define TOUTPS0                        BANKMASK(T2CON), 3
#define TOUTPS1                        BANKMASK(T2CON), 4
#define TOUTPS2                        BANKMASK(T2CON), 5
#define TOUTPS3                        BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0013h
CCPR1H                                 equ 0014h
CCP1CON                                equ 0015h
#define P1M                            BANKMASK(CCP1CON), 7
#define CCP1M0                         BANKMASK(CCP1CON), 0
#define CCP1M1                         BANKMASK(CCP1CON), 1
#define CCP1M2                         BANKMASK(CCP1CON), 2
#define CCP1M3                         BANKMASK(CCP1CON), 3
#define DC1B0                          BANKMASK(CCP1CON), 4
#define DC1B1                          BANKMASK(CCP1CON), 5
#ifndef _LIB_BUILD
#endif
PWM1CON                                equ 0016h
#define PRSEN                          BANKMASK(PWM1CON), 7
#define PDC0                           BANKMASK(PWM1CON), 0
#define PDC1                           BANKMASK(PWM1CON), 1
#define PDC2                           BANKMASK(PWM1CON), 2
#define PDC3                           BANKMASK(PWM1CON), 3
#define PDC4                           BANKMASK(PWM1CON), 4
#define PDC5                           BANKMASK(PWM1CON), 5
#define PDC6                           BANKMASK(PWM1CON), 6
#ifndef _LIB_BUILD
#endif
ECCPAS                                 equ 0017h
#define ECCPASE                        BANKMASK(ECCPAS), 7
#define PSSBD0                         BANKMASK(ECCPAS), 0
#define PSSBD1                         BANKMASK(ECCPAS), 1
#define PSSAC0                         BANKMASK(ECCPAS), 2
#define PSSAC1                         BANKMASK(ECCPAS), 3
#define ECCPAS0                        BANKMASK(ECCPAS), 4
#define ECCPAS1                        BANKMASK(ECCPAS), 5
#define ECCPAS2                        BANKMASK(ECCPAS), 6
#ifndef _LIB_BUILD
#endif
VRCON                                  equ 0019h
#define FBREN                          BANKMASK(VRCON), 4
#define VRR                            BANKMASK(VRCON), 5
#define C1VREN                         BANKMASK(VRCON), 7
#define VR0                            BANKMASK(VRCON), 0
#define VR1                            BANKMASK(VRCON), 1
#define VR2                            BANKMASK(VRCON), 2
#define VR3                            BANKMASK(VRCON), 3
#define VP6EN                          BANKMASK(VRCON), 4
#define CMVREN                         BANKMASK(VRCON), 7
#define FVREN                          BANKMASK(VRCON), 4
#ifndef _LIB_BUILD
#endif
CMCON0                                 equ 001Ah
#define C1CH                           BANKMASK(CMCON0), 0
#define C1R                            BANKMASK(CMCON0), 2
#define C1POL                          BANKMASK(CMCON0), 4
#define C1OE                           BANKMASK(CMCON0), 5
#define C1OUT                          BANKMASK(CMCON0), 6
#define C1ON                           BANKMASK(CMCON0), 7
#define C1CH0                          BANKMASK(CMCON0), 0
#define CMR                            BANKMASK(CMCON0), 2
#define CMPOL                          BANKMASK(CMCON0), 4
#define CMOE                           BANKMASK(CMCON0), 5
#define COUT                           BANKMASK(CMCON0), 6
#define CMON                           BANKMASK(CMCON0), 7
#define CMCH                           BANKMASK(CMCON0), 0
#ifndef _LIB_BUILD
#endif
CMCON1                                 equ 001Ch
#define C1SYNC                         BANKMASK(CMCON1), 0
#define T1GSS                          BANKMASK(CMCON1), 1
#define C1HYS                          BANKMASK(CMCON1), 3
#define T1ACS                          BANKMASK(CMCON1), 4
#define CMSYNC                         BANKMASK(CMCON1), 0
#define CMHYS                          BANKMASK(CMCON1), 3
#ifndef _LIB_BUILD
#endif
ADRESH                                 equ 001Eh
ADCON0                                 equ 001Fh
#define ADON                           BANKMASK(ADCON0), 0
#define GO_nDONE                       BANKMASK(ADCON0), 1
#define VCFG                           BANKMASK(ADCON0), 6
#define ADFM                           BANKMASK(ADCON0), 7
#define GO                             BANKMASK(ADCON0), 1
#define CHS0                           BANKMASK(ADCON0), 2
#define CHS1                           BANKMASK(ADCON0), 3
#define CHS2                           BANKMASK(ADCON0), 4
#define nDONE                          BANKMASK(ADCON0), 1
#define GO_DONE                        BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA                            BANKMASK(OPTION_REG), 3
#define T0SE                           BANKMASK(OPTION_REG), 4
#define T0CS                           BANKMASK(OPTION_REG), 5
#define INTEDG                         BANKMASK(OPTION_REG), 6
#define nGPPU                          BANKMASK(OPTION_REG), 7
#define PS0                            BANKMASK(OPTION_REG), 0
#define PS1                            BANKMASK(OPTION_REG), 1
#define PS2                            BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISIO                                 equ 0085h
TRISA                                  equ 0085h
#define TRISIO0                        BANKMASK(TRISIO), 0
#define TRISIO1                        BANKMASK(TRISIO), 1
#define TRISIO2                        BANKMASK(TRISIO), 2
#define TRISIO3                        BANKMASK(TRISIO), 3
#define TRISIO4                        BANKMASK(TRISIO), 4
#define TRISIO5                        BANKMASK(TRISIO), 5
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE                         BANKMASK(PIE1), 0
#define TMR2IE                         BANKMASK(PIE1), 1
#define C1IE                           BANKMASK(PIE1), 3
#define ECCPIE                         BANKMASK(PIE1), 5
#define ADIE                           BANKMASK(PIE1), 6
#define T1IE                           BANKMASK(PIE1), 0
#define T2IE                           BANKMASK(PIE1), 1
#define CMIE                           BANKMASK(PIE1), 3
#define CCP1IE                         BANKMASK(PIE1), 5
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOR                           BANKMASK(PCON), 0
#define nPOR                           BANKMASK(PCON), 1
#define nBOD                           BANKMASK(PCON), 0
#ifndef _LIB_BUILD
#endif
OSCTUNE                                equ 0090h
#define TUN0                           BANKMASK(OSCTUNE), 0
#define TUN1                           BANKMASK(OSCTUNE), 1
#define TUN2                           BANKMASK(OSCTUNE), 2
#define TUN3                           BANKMASK(OSCTUNE), 3
#define TUN4                           BANKMASK(OSCTUNE), 4
#ifndef _LIB_BUILD
#endif
PR2                                    equ 0092h
APFCON                                 equ 0093h
#define P1ASEL                         BANKMASK(APFCON), 0
#define P1BSEL                         BANKMASK(APFCON), 1
#define T1GSEL                         BANKMASK(APFCON), 4
#ifndef _LIB_BUILD
#endif
WPU                                    equ 0095h
WPUA                                   equ 0095h
#define WPUA0                          BANKMASK(WPU), 0
#define WPUA1                          BANKMASK(WPU), 1
#define WPUA2                          BANKMASK(WPU), 2
#define WPUA4                          BANKMASK(WPU), 4
#define WPUA5                          BANKMASK(WPU), 5
#define WPU0                           BANKMASK(WPU), 0
#define WPU1                           BANKMASK(WPU), 1
#define WPU2                           BANKMASK(WPU), 2
#define WPU4                           BANKMASK(WPU), 4
#define WPU5                           BANKMASK(WPU), 5
#ifndef _LIB_BUILD
#endif
IOC                                    equ 0096h
IOCA                                   equ 0096h
#define IOC0                           BANKMASK(IOC), 0
#define IOC1                           BANKMASK(IOC), 1
#define IOC2                           BANKMASK(IOC), 2
#define IOC3                           BANKMASK(IOC), 3
#define IOC4                           BANKMASK(IOC), 4
#define IOC5                           BANKMASK(IOC), 5
#define IOCA0                          BANKMASK(IOC), 0
#define IOCA1                          BANKMASK(IOC), 1
#define IOCA2                          BANKMASK(IOC), 2
#define IOCA3                          BANKMASK(IOC), 3
#define IOCA4                          BANKMASK(IOC), 4
#define IOCA5                          BANKMASK(IOC), 5
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 009Eh
ANSEL                                  equ 009Fh
#define AN0                            BANKMASK(ANSEL), 0
#define AN1                            BANKMASK(ANSEL), 1
#define AN2                            BANKMASK(ANSEL), 2
#define AN3                            BANKMASK(ANSEL), 3
#define ADCS0                          BANKMASK(ANSEL), 4
#define ADCS1                          BANKMASK(ANSEL), 5
#define ADCS2                          BANKMASK(ANSEL), 6
#ifndef _LIB_BUILD
#endif

#endif
#endif

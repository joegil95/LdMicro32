#ifndef _CASPIC_H_
#warning Header file cas12f752.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS12F752_H_
#define _CAS12F752_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define RP0_bit                        BANKMASK(STATUS), 5
#define RP1_bit                        BANKMASK(STATUS), 6
#define IRP_bit                        BANKMASK(STATUS), 7
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define RA0_bit                        BANKMASK(PORTA), 0
#define RA1_bit                        BANKMASK(PORTA), 1
#define RA2_bit                        BANKMASK(PORTA), 2
#define RA3_bit                        BANKMASK(PORTA), 3
#define RA4_bit                        BANKMASK(PORTA), 4
#define RA5_bit                        BANKMASK(PORTA), 5
#ifndef _LIB_BUILD
#endif
IOCAF                                  equ 0008h
#define IOCAF0_bit                     BANKMASK(IOCAF), 0
#define IOCAF1_bit                     BANKMASK(IOCAF), 1
#define IOCAF2_bit                     BANKMASK(IOCAF), 2
#define IOCAF3_bit                     BANKMASK(IOCAF), 3
#define IOCAF4_bit                     BANKMASK(IOCAF), 4
#define IOCAF5_bit                     BANKMASK(IOCAF), 5
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define IOCIF_bit                      BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define T0IF_bit                       BANKMASK(INTCON), 2
#define IOCIE_bit                      BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define T0IE_bit                       BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF_bit                     BANKMASK(PIR1), 0
#define TMR2IF_bit                     BANKMASK(PIR1), 1
#define HLTMR1IF_bit                   BANKMASK(PIR1), 2
#define ADIF_bit                       BANKMASK(PIR1), 6
#define TMR1GIF_bit                    BANKMASK(PIR1), 7
#ifndef _LIB_BUILD
#endif
PIR2                                   equ 000Dh
#define CCP1IF_bit                     BANKMASK(PIR2), 0
#define COG1IF_bit                     BANKMASK(PIR2), 2
#define C1IF_bit                       BANKMASK(PIR2), 4
#define C2IF_bit                       BANKMASK(PIR2), 5
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Fh
TMR1H                                  equ 0010h
T1CON                                  equ 0011h
#define TMR1ON_bit                     BANKMASK(T1CON), 0
#define nT1SYNC_bit                    BANKMASK(T1CON), 2
#define T1CKPS0_bit                    BANKMASK(T1CON), 4
#define T1CKPS1_bit                    BANKMASK(T1CON), 5
#define TMR1CS0_bit                    BANKMASK(T1CON), 6
#define TMR1CS1_bit                    BANKMASK(T1CON), 7
#ifndef _LIB_BUILD
#endif
T1GCON                                 equ 0012h
#define T1GVAL_bit                     BANKMASK(T1GCON), 2
#define T1GGO_nDONE_bit                BANKMASK(T1GCON), 3
#define T1GSPM_bit                     BANKMASK(T1GCON), 4
#define T1GTM_bit                      BANKMASK(T1GCON), 5
#define T1GPOL_bit                     BANKMASK(T1GCON), 6
#define TMR1GE_bit                     BANKMASK(T1GCON), 7
#define T1GSS0_bit                     BANKMASK(T1GCON), 0
#define T1GSS1_bit                     BANKMASK(T1GCON), 1
#define T1GGO_bit                      BANKMASK(T1GCON), 3
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0013h
CCPR1H                                 equ 0014h
CCP1CON                                equ 0015h
#define CCP1M0_bit                     BANKMASK(CCP1CON), 0
#define CCP1M1_bit                     BANKMASK(CCP1CON), 1
#define CCP1M2_bit                     BANKMASK(CCP1CON), 2
#define CCP1M3_bit                     BANKMASK(CCP1CON), 3
#define DC1B0_bit                      BANKMASK(CCP1CON), 4
#define DC1B1_bit                      BANKMASK(CCP1CON), 5
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 001Ch
ADRESH                                 equ 001Dh
ADCON0                                 equ 001Eh
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 1
#define VCFG_bit                       BANKMASK(ADCON0), 6
#define ADFM_bit                       BANKMASK(ADCON0), 7
#define CHS0_bit                       BANKMASK(ADCON0), 2
#define CHS1_bit                       BANKMASK(ADCON0), 3
#define CHS2_bit                       BANKMASK(ADCON0), 4
#define CHS3_bit                       BANKMASK(ADCON0), 5
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 001Fh
#define ADCS0_bit                      BANKMASK(ADCON1), 4
#define ADCS1_bit                      BANKMASK(ADCON1), 5
#define ADCS2_bit                      BANKMASK(ADCON1), 6
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nRAPU_bit                      BANKMASK(OPTION_REG), 7
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 0085h
#define TRISA0_bit                     BANKMASK(TRISA), 0
#define TRISA1_bit                     BANKMASK(TRISA), 1
#define TRISA2_bit                     BANKMASK(TRISA), 2
#define TRISA3_bit                     BANKMASK(TRISA), 3
#define TRISA4_bit                     BANKMASK(TRISA), 4
#define TRISA5_bit                     BANKMASK(TRISA), 5
#ifndef _LIB_BUILD
#endif
IOCAP                                  equ 0088h
#define IOCAP0_bit                     BANKMASK(IOCAP), 0
#define IOCAP1_bit                     BANKMASK(IOCAP), 1
#define IOCAP2_bit                     BANKMASK(IOCAP), 2
#define IOCAP3_bit                     BANKMASK(IOCAP), 3
#define IOCAP4_bit                     BANKMASK(IOCAP), 4
#define IOCAP5_bit                     BANKMASK(IOCAP), 5
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE_bit                     BANKMASK(PIE1), 0
#define TMR2IE_bit                     BANKMASK(PIE1), 1
#define HLTMR1IE_bit                   BANKMASK(PIE1), 2
#define ADIE_bit                       BANKMASK(PIE1), 6
#define TMR1GIE_bit                    BANKMASK(PIE1), 7
#ifndef _LIB_BUILD
#endif
PIE2                                   equ 008Dh
#define CCP1IE_bit                     BANKMASK(PIE2), 0
#define COG1IE_bit                     BANKMASK(PIE2), 2
#define C1IE_bit                       BANKMASK(PIE2), 4
#define C2IE_bit                       BANKMASK(PIE2), 5
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 008Fh
#define LTS_bit                        BANKMASK(OSCCON), 1
#define HTS_bit                        BANKMASK(OSCCON), 2
#define IRCF0_bit                      BANKMASK(OSCCON), 4
#define IRCF1_bit                      BANKMASK(OSCCON), 5
#ifndef _LIB_BUILD
#endif
FVRCON                                 equ 0090h
#define FVRBUFSS_bit                   BANKMASK(FVRCON), 4
#define FVRBUFEN_bit                   BANKMASK(FVRCON), 5
#define FVRRDY_bit                     BANKMASK(FVRCON), 6
#define FVREN_bit                      BANKMASK(FVRCON), 7
#ifndef _LIB_BUILD
#endif
DACCON0                                equ 0091h
#define DACPSS0_bit                    BANKMASK(DACCON0), 2
#define DACOE_bit                      BANKMASK(DACCON0), 5
#define DACRNG_bit                     BANKMASK(DACCON0), 6
#define DACEN_bit                      BANKMASK(DACCON0), 7
#ifndef _LIB_BUILD
#endif
DACCON1                                equ 0092h
#define DACR0_bit                      BANKMASK(DACCON1), 0
#define DACR1_bit                      BANKMASK(DACCON1), 1
#define DACR2_bit                      BANKMASK(DACCON1), 2
#define DACR3_bit                      BANKMASK(DACCON1), 3
#define DACR4_bit                      BANKMASK(DACCON1), 4
#ifndef _LIB_BUILD
#endif
CM2CON0                                equ 009Bh
C2CON0                                 equ 009Bh
#define C2SYNC_bit                     BANKMASK(CM2CON0), 0
#define C2HYS_bit                      BANKMASK(CM2CON0), 1
#define C2SP_bit                       BANKMASK(CM2CON0), 2
#define C2POL_bit                      BANKMASK(CM2CON0), 4
#define C2OE_bit                       BANKMASK(CM2CON0), 5
#define C2OUT_bit                      BANKMASK(CM2CON0), 6
#define C2ON_bit                       BANKMASK(CM2CON0), 7
#ifndef _LIB_BUILD
#endif
CM2CON1                                equ 009Ch
C2CON1                                 equ 009Ch
#define C2NCH0_bit                     BANKMASK(CM2CON1), 0
#define C2INTN_bit                     BANKMASK(CM2CON1), 6
#define C2INTP_bit                     BANKMASK(CM2CON1), 7
#define C2PCH0_bit                     BANKMASK(CM2CON1), 4
#define C2PCH1_bit                     BANKMASK(CM2CON1), 5
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 009Dh
C1CON0                                 equ 009Dh
#define C1SYNC_bit                     BANKMASK(CM1CON0), 0
#define C1HYS_bit                      BANKMASK(CM1CON0), 1
#define C1SP_bit                       BANKMASK(CM1CON0), 2
#define C1POL_bit                      BANKMASK(CM1CON0), 4
#define C1OE_bit                       BANKMASK(CM1CON0), 5
#define C1OUT_bit                      BANKMASK(CM1CON0), 6
#define C1ON_bit                       BANKMASK(CM1CON0), 7
#ifndef _LIB_BUILD
#endif
CM1CON1                                equ 009Eh
C1CON1                                 equ 009Eh
#define C1NCH0_bit                     BANKMASK(CM1CON1), 0
#define C1INTN_bit                     BANKMASK(CM1CON1), 6
#define C1INTP_bit                     BANKMASK(CM1CON1), 7
#define C1PCH0_bit                     BANKMASK(CM1CON1), 4
#define C1PCH1_bit                     BANKMASK(CM1CON1), 5
#ifndef _LIB_BUILD
#endif
CMOUT                                  equ 009Fh
MCOUT                                  equ 009Fh
#define MCOUT1_bit                     BANKMASK(CMOUT), 0
#define MCOUT2_bit                     BANKMASK(CMOUT), 1
#ifndef _LIB_BUILD
#endif
LATA                                   equ 0105h
#define LATA0_bit                      BANKMASK(LATA), 0
#define LATA1_bit                      BANKMASK(LATA), 1
#define LATA2_bit                      BANKMASK(LATA), 2
#define LATA4_bit                      BANKMASK(LATA), 4
#define LATA5_bit                      BANKMASK(LATA), 5
#ifndef _LIB_BUILD
#endif
IOCAN                                  equ 0108h
#define IOCAN0_bit                     BANKMASK(IOCAN), 0
#define IOCAN1_bit                     BANKMASK(IOCAN), 1
#define IOCAN2_bit                     BANKMASK(IOCAN), 2
#define IOCAN3_bit                     BANKMASK(IOCAN), 3
#define IOCAN4_bit                     BANKMASK(IOCAN), 4
#define IOCAN5_bit                     BANKMASK(IOCAN), 5
#ifndef _LIB_BUILD
#endif
WPUA                                   equ 010Ch
#define WPUA0_bit                      BANKMASK(WPUA), 0
#define WPUA1_bit                      BANKMASK(WPUA), 1
#define WPUA2_bit                      BANKMASK(WPUA), 2
#define WPUA3_bit                      BANKMASK(WPUA), 3
#define WPUA4_bit                      BANKMASK(WPUA), 4
#define WPUA5_bit                      BANKMASK(WPUA), 5
#ifndef _LIB_BUILD
#endif
PCON                                   equ 010Fh
#define nBOR_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 0110h
PR2                                    equ 0111h
T2CON                                  equ 0112h
#define TMR2ON_bit                     BANKMASK(T2CON), 2
#define T2CKPS0_bit                    BANKMASK(T2CON), 0
#define T2CKPS1_bit                    BANKMASK(T2CON), 1
#define T2OUTPS0_bit                   BANKMASK(T2CON), 3
#define T2OUTPS1_bit                   BANKMASK(T2CON), 4
#define T2OUTPS2_bit                   BANKMASK(T2CON), 5
#define T2OUTPS3_bit                   BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
HLTMR1                                 equ 0113h
HLTPR1                                 equ 0114h
HLT1CON0                               equ 0115h
#define H1ON_bit                       BANKMASK(HLT1CON0), 2
#define H1CKPS0_bit                    BANKMASK(HLT1CON0), 0
#define H1CKPS1_bit                    BANKMASK(HLT1CON0), 1
#define H1OUTPS0_bit                   BANKMASK(HLT1CON0), 3
#define H1OUTPS1_bit                   BANKMASK(HLT1CON0), 4
#define H1OUTPS2_bit                   BANKMASK(HLT1CON0), 5
#define H1OUTPS3_bit                   BANKMASK(HLT1CON0), 6
#ifndef _LIB_BUILD
#endif
HLT1CON1                               equ 0116h
#define H1REREN_bit                    BANKMASK(HLT1CON1), 0
#define H1FEREN_bit                    BANKMASK(HLT1CON1), 1
#define H1ERS0_bit                     BANKMASK(HLT1CON1), 2
#define H1ERS1_bit                     BANKMASK(HLT1CON1), 3
#define H1ERS2_bit                     BANKMASK(HLT1CON1), 4
#ifndef _LIB_BUILD
#endif
ANSELA                                 equ 0185h
#define ANSA0_bit                      BANKMASK(ANSELA), 0
#define ANSA1_bit                      BANKMASK(ANSELA), 1
#define ANSA2_bit                      BANKMASK(ANSELA), 2
#define ANSA4_bit                      BANKMASK(ANSELA), 4
#define ANSA5_bit                      BANKMASK(ANSELA), 5
#ifndef _LIB_BUILD
#endif
APFCON                                 equ 0188h
#define COG1O0SEL_bit                  BANKMASK(APFCON), 0
#define COG1O1SEL_bit                  BANKMASK(APFCON), 1
#define COG1FSEL_bit                   BANKMASK(APFCON), 2
#define T1GSEL_bit                     BANKMASK(APFCON), 4
#ifndef _LIB_BUILD
#endif
OSCTUNE                                equ 0189h
#define TUN0_bit                       BANKMASK(OSCTUNE), 0
#define TUN1_bit                       BANKMASK(OSCTUNE), 1
#define TUN2_bit                       BANKMASK(OSCTUNE), 2
#define TUN3_bit                       BANKMASK(OSCTUNE), 3
#define TUN4_bit                       BANKMASK(OSCTUNE), 4
#ifndef _LIB_BUILD
#endif
PMCON1                                 equ 018Ch
#define RD_bit                         BANKMASK(PMCON1), 0
#define WR_bit                         BANKMASK(PMCON1), 1
#define WREN_bit                       BANKMASK(PMCON1), 2
#ifndef _LIB_BUILD
#endif
PMCON2                                 equ 018Dh
PMADRL                                 equ 018Eh
PMADRH                                 equ 018Fh
#ifndef _LIB_BUILD
#endif
PMDATL                                 equ 0190h
PMDATH                                 equ 0191h
#ifndef _LIB_BUILD
#endif
COG1PH                                 equ 0192h
#define G1PH0_bit                      BANKMASK(COG1PH), 0
#define G1PH1_bit                      BANKMASK(COG1PH), 1
#define G1PH2_bit                      BANKMASK(COG1PH), 2
#define G1PH3_bit                      BANKMASK(COG1PH), 3
#ifndef _LIB_BUILD
#endif
COG1BLK                                equ 0193h
#define G1BLKF0_bit                    BANKMASK(COG1BLK), 0
#define G1BLKF1_bit                    BANKMASK(COG1BLK), 1
#define G1BLKF2_bit                    BANKMASK(COG1BLK), 2
#define G1BLKF3_bit                    BANKMASK(COG1BLK), 3
#define G1BLKR0_bit                    BANKMASK(COG1BLK), 4
#define G1BLKR1_bit                    BANKMASK(COG1BLK), 5
#define G1BLKR2_bit                    BANKMASK(COG1BLK), 6
#define G1BLKR3_bit                    BANKMASK(COG1BLK), 7
#ifndef _LIB_BUILD
#endif
COG1DB                                 equ 0194h
#define G1DBF0_bit                     BANKMASK(COG1DB), 0
#define G1DBF1_bit                     BANKMASK(COG1DB), 1
#define G1DBF2_bit                     BANKMASK(COG1DB), 2
#define G1DBF3_bit                     BANKMASK(COG1DB), 3
#define G1BDR0_bit                     BANKMASK(COG1DB), 4
#define G1BDR1_bit                     BANKMASK(COG1DB), 5
#define G1BDR2_bit                     BANKMASK(COG1DB), 6
#define G1BDR3_bit                     BANKMASK(COG1DB), 7
#ifndef _LIB_BUILD
#endif
COG1CON0                               equ 0195h
#define G1LD_bit                       BANKMASK(COG1CON0), 2
#define G1POL0_bit                     BANKMASK(COG1CON0), 3
#define G1POL1_bit                     BANKMASK(COG1CON0), 4
#define G1OE0_bit                      BANKMASK(COG1CON0), 5
#define G1OE1_bit                      BANKMASK(COG1CON0), 6
#define G1EN_bit                       BANKMASK(COG1CON0), 7
#define G1CS0_bit                      BANKMASK(COG1CON0), 0
#define G1CS1_bit                      BANKMASK(COG1CON0), 1
#ifndef _LIB_BUILD
#endif
COG1CON1                               equ 0196h
#define G1RS0_bit                      BANKMASK(COG1CON1), 0
#define G1RS1_bit                      BANKMASK(COG1CON1), 1
#define G1RS2_bit                      BANKMASK(COG1CON1), 2
#define G1FS0_bit                      BANKMASK(COG1CON1), 3
#define G1FS1_bit                      BANKMASK(COG1CON1), 4
#define G1FS2_bit                      BANKMASK(COG1CON1), 5
#ifndef _LIB_BUILD
#endif
COG1ASD                                equ 0197h
#define G1ASDSFLT_bit                  BANKMASK(COG1ASD), 0
#define G1ASDSC1_bit                   BANKMASK(COG1ASD), 1
#define G1ASDSC2_bit                   BANKMASK(COG1ASD), 2
#define G1ASDSHLT_bit                  BANKMASK(COG1ASD), 3
#define G1ASDL0_bit                    BANKMASK(COG1ASD), 4
#define G1ASDL1_bit                    BANKMASK(COG1ASD), 5
#define G1ARSEN_bit                    BANKMASK(COG1ASD), 6
#define G1ASDE_bit                     BANKMASK(COG1ASD), 7
#ifndef _LIB_BUILD
#endif

#endif
#endif

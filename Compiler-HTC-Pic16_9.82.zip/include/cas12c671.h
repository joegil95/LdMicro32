#ifndef _CASPIC_H_
#warning Header file cas12c671.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS12C671_H_
#define _CAS12C671_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define IRP_bit                        BANKMASK(STATUS), 7
#define RP0_bit                        BANKMASK(STATUS), 5
#define RP1_bit                        BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
GPIO                                   equ 0005h
#define GP0_bit                        BANKMASK(GPIO), 0
#define GP1_bit                        BANKMASK(GPIO), 1
#define GP2_bit                        BANKMASK(GPIO), 2
#define GP3_bit                        BANKMASK(GPIO), 3
#define GP4_bit                        BANKMASK(GPIO), 4
#define GP5_bit                        BANKMASK(GPIO), 5
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define GPIF_bit                       BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define T0IF_bit                       BANKMASK(INTCON), 2
#define GPIE_bit                       BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define T0IE_bit                       BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define ADIF_bit                       BANKMASK(PIR1), 6
#ifndef _LIB_BUILD
#endif
ADRES                                  equ 001Eh
ADCON0                                 equ 001Fh
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 2
#define GO_DONE_bit                    BANKMASK(ADCON0), 2
#define CHS0_bit                       BANKMASK(ADCON0), 3
#define CHS1_bit                       BANKMASK(ADCON0), 4
#define ADCS0_bit                      BANKMASK(ADCON0), 6
#define ADCS1_bit                      BANKMASK(ADCON0), 7
#define nDONE_bit                      BANKMASK(ADCON0), 2
#define GO_bit                         BANKMASK(ADCON0), 2
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nGPPU_bit                      BANKMASK(OPTION_REG), 7
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRIS_REG                               equ 0085h
TRISIO                                 equ 0085h
#define TRIS0_bit                      BANKMASK(TRIS), 0
#define TRIS1_bit                      BANKMASK(TRIS), 1
#define TRIS2_bit                      BANKMASK(TRIS), 2
#define TRIS3_bit                      BANKMASK(TRIS), 3
#define TRIS4_bit                      BANKMASK(TRIS), 4
#define TRIS5_bit                      BANKMASK(TRIS), 5
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define ADIE_bit                       BANKMASK(PIE1), 6
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nPOR_bit                       BANKMASK(PCON), 1
#ifndef _LIB_BUILD
#endif
OSCCAL                                 equ 008Fh
#define CALSLW_bit                     BANKMASK(OSCCAL), 2
#define CALFST_bit                     BANKMASK(OSCCAL), 3
#define CAL0_bit                       BANKMASK(OSCCAL), 4
#define CAL1_bit                       BANKMASK(OSCCAL), 5
#define CAL2_bit                       BANKMASK(OSCCAL), 6
#define CAL3_bit                       BANKMASK(OSCCAL), 7
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 009Fh
#define PCFG0_bit                      BANKMASK(ADCON1), 0
#define PCFG1_bit                      BANKMASK(ADCON1), 1
#define PCFG2_bit                      BANKMASK(ADCON1), 2
#ifndef _LIB_BUILD
#endif

#endif
#endif

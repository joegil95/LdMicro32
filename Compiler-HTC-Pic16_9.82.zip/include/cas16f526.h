#ifndef _CASPIC_H_
#warning Header file cas16f526.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS16F526_H_
#define _CAS16F526_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define PA0_bit                        BANKMASK(STATUS), 5
#define CWUF_bit                       BANKMASK(STATUS), 6
#define RBWUF_bit                      BANKMASK(STATUS), 7
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
OSCCAL                                 equ 0005h
#define CAL0_bit                       BANKMASK(OSCCAL), 1
#define CAL1_bit                       BANKMASK(OSCCAL), 2
#define CAL2_bit                       BANKMASK(OSCCAL), 3
#define CAL3_bit                       BANKMASK(OSCCAL), 4
#define CAL4_bit                       BANKMASK(OSCCAL), 5
#define CAL5_bit                       BANKMASK(OSCCAL), 6
#define CAL6_bit                       BANKMASK(OSCCAL), 7
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 0006h
#define RB0_bit                        BANKMASK(PORTB), 0
#define RB1_bit                        BANKMASK(PORTB), 1
#define RB2_bit                        BANKMASK(PORTB), 2
#define RB3_bit                        BANKMASK(PORTB), 3
#define RB4_bit                        BANKMASK(PORTB), 4
#define RB5_bit                        BANKMASK(PORTB), 5
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 0007h
#define RC0_bit                        BANKMASK(PORTC), 0
#define RC1_bit                        BANKMASK(PORTC), 1
#define RC2_bit                        BANKMASK(PORTC), 2
#define RC3_bit                        BANKMASK(PORTC), 3
#define RC4_bit                        BANKMASK(PORTC), 4
#define RC5_bit                        BANKMASK(PORTC), 5
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 0008h
#define nC1WU_bit                      BANKMASK(CM1CON0), 0
#define C1PREF_bit                     BANKMASK(CM1CON0), 1
#define C1NREF_bit                     BANKMASK(CM1CON0), 2
#define C1ON_bit                       BANKMASK(CM1CON0), 3
#define nC1T0CS_bit                    BANKMASK(CM1CON0), 4
#define C1POL_bit                      BANKMASK(CM1CON0), 5
#define nC1OUTEN_bit                   BANKMASK(CM1CON0), 6
#define C1OUT_bit                      BANKMASK(CM1CON0), 7
#ifndef _LIB_BUILD
#endif
ADCON0                                 equ 0009h
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 1
#define GO_bit                         BANKMASK(ADCON0), 1
#define CHS0_bit                       BANKMASK(ADCON0), 2
#define CHS1_bit                       BANKMASK(ADCON0), 3
#define ADCS0_bit                      BANKMASK(ADCON0), 4
#define ADCS1_bit                      BANKMASK(ADCON0), 5
#define ANS0_bit                       BANKMASK(ADCON0), 6
#define ANS1_bit                       BANKMASK(ADCON0), 7
#define NOT_DONE_bit                   BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
ADRES                                  equ 000Ah
#define ADRES0_bit                     BANKMASK(ADRES), 0
#define ADRES1_bit                     BANKMASK(ADRES), 1
#define ADRES2_bit                     BANKMASK(ADRES), 2
#define ADRES3_bit                     BANKMASK(ADRES), 3
#define ADRES4_bit                     BANKMASK(ADRES), 4
#define ADRES5_bit                     BANKMASK(ADRES), 5
#define ADRES6_bit                     BANKMASK(ADRES), 6
#define ADRES7_bit                     BANKMASK(ADRES), 7
#ifndef _LIB_BUILD
#endif
CM2CON0                                equ 000Bh
#define nC2WU_bit                      BANKMASK(CM2CON0), 0
#define C2PREF1_bit                    BANKMASK(CM2CON0), 1
#define C2NREF_bit                     BANKMASK(CM2CON0), 2
#define C2ON_bit                       BANKMASK(CM2CON0), 3
#define C2PREF2_bit                    BANKMASK(CM2CON0), 4
#define C2POL_bit                      BANKMASK(CM2CON0), 5
#define nC2OUTEN_bit                   BANKMASK(CM2CON0), 6
#define C2OUT_bit                      BANKMASK(CM2CON0), 7
#ifndef _LIB_BUILD
#endif
VRCON                                  equ 000Ch
#define VRR_bit                        BANKMASK(VRCON), 5
#define VROE_bit                       BANKMASK(VRCON), 6
#define VREN_bit                       BANKMASK(VRCON), 7
#define VR0_bit                        BANKMASK(VRCON), 0
#define VR1_bit                        BANKMASK(VRCON), 1
#define VR2_bit                        BANKMASK(VRCON), 2
#define VR3_bit                        BANKMASK(VRCON), 3
#ifndef _LIB_BUILD
#endif
EECON                                  equ 0021h
#define RD_bit                         BANKMASK(EECON), 0
#define WR_bit                         BANKMASK(EECON), 1
#define WREN_bit                       BANKMASK(EECON), 2
#define WRERR_bit                      BANKMASK(EECON), 3
#define FREE_bit                       BANKMASK(EECON), 4
#ifndef _LIB_BUILD
#endif
EEDATA                                 equ 0025h
EEADR                                  equ 0026h

#endif
#endif

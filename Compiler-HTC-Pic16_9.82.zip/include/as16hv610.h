#ifndef _ASPIC_H_
#warning Header file as16hv610.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS16HV610_H_
#define _AS16HV610_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define IRP                            BANKMASK(STATUS), 7
#define RP0                            BANKMASK(STATUS), 5
#define RP1                            BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define RA0                            BANKMASK(PORTA), 0
#define RA1                            BANKMASK(PORTA), 1
#define RA2                            BANKMASK(PORTA), 2
#define RA3                            BANKMASK(PORTA), 3
#define RA4                            BANKMASK(PORTA), 4
#define RA5                            BANKMASK(PORTA), 5
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 0007h
#define RC0                            BANKMASK(PORTC), 0
#define RC1                            BANKMASK(PORTC), 1
#define RC2                            BANKMASK(PORTC), 2
#define RC3                            BANKMASK(PORTC), 3
#define RC4                            BANKMASK(PORTC), 4
#define RC5                            BANKMASK(PORTC), 5
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define RAIF                           BANKMASK(INTCON), 0
#define INTF                           BANKMASK(INTCON), 1
#define TMR0IF                         BANKMASK(INTCON), 2
#define RAIE                           BANKMASK(INTCON), 3
#define INTE                           BANKMASK(INTCON), 4
#define TMR0IE                         BANKMASK(INTCON), 5
#define PEIE                           BANKMASK(INTCON), 6
#define GIE                            BANKMASK(INTCON), 7
#define T0IF                           BANKMASK(INTCON), 2
#define T0IE                           BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF                         BANKMASK(PIR1), 0
#define C1IF                           BANKMASK(PIR1), 3
#define C2IF                           BANKMASK(PIR1), 4
#define T1IF                           BANKMASK(PIR1), 0
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Eh
TMR1H                                  equ 000Fh
T1CON                                  equ 0010h
#define TMR1ON                         BANKMASK(T1CON), 0
#define TMR1CS                         BANKMASK(T1CON), 1
#define nT1SYNC                        BANKMASK(T1CON), 2
#define T1OSCEN                        BANKMASK(T1CON), 3
#define TMR1GE                         BANKMASK(T1CON), 6
#define T1GINV                         BANKMASK(T1CON), 7
#define T1CKPS0                        BANKMASK(T1CON), 4
#define T1CKPS1                        BANKMASK(T1CON), 5
#ifndef _LIB_BUILD
#endif
VRCON                                  equ 0019h
#define VP6EN                          BANKMASK(VRCON), 4
#define VRR                            BANKMASK(VRCON), 5
#define C2VREN                         BANKMASK(VRCON), 6
#define C1VREN                         BANKMASK(VRCON), 7
#define VR0                            BANKMASK(VRCON), 0
#define VR1                            BANKMASK(VRCON), 1
#define VR2                            BANKMASK(VRCON), 2
#define VR3                            BANKMASK(VRCON), 3
#define FVREN                          BANKMASK(VRCON), 4
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 001Ah
#define C1R                            BANKMASK(CM1CON0), 2
#define C1POL                          BANKMASK(CM1CON0), 4
#define C1OE                           BANKMASK(CM1CON0), 5
#define C1OUT                          BANKMASK(CM1CON0), 6
#define C1ON                           BANKMASK(CM1CON0), 7
#define C1CH0                          BANKMASK(CM1CON0), 0
#define C1CH1                          BANKMASK(CM1CON0), 1
#ifndef _LIB_BUILD
#endif
CM2CON0                                equ 001Bh
#define C2R                            BANKMASK(CM2CON0), 2
#define C2POL                          BANKMASK(CM2CON0), 4
#define C2OE                           BANKMASK(CM2CON0), 5
#define C2OUT                          BANKMASK(CM2CON0), 6
#define C2ON                           BANKMASK(CM2CON0), 7
#define C2CH0                          BANKMASK(CM2CON0), 0
#define C2CH1                          BANKMASK(CM2CON0), 1
#ifndef _LIB_BUILD
#endif
CM2CON1                                equ 001Ch
#define C2SYNC                         BANKMASK(CM2CON1), 0
#define T1GSS                          BANKMASK(CM2CON1), 1
#define C2HYS                          BANKMASK(CM2CON1), 2
#define C1HYS                          BANKMASK(CM2CON1), 3
#define T1ACS                          BANKMASK(CM2CON1), 4
#define MC2OUT                         BANKMASK(CM2CON1), 6
#define MC1ON                          BANKMASK(CM2CON1), 7
#define MC1OUT                         BANKMASK(CM2CON1), 7
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA                            BANKMASK(OPTION_REG), 3
#define T0SE                           BANKMASK(OPTION_REG), 4
#define T0CS                           BANKMASK(OPTION_REG), 5
#define INTEDG                         BANKMASK(OPTION_REG), 6
#define nRAPU                          BANKMASK(OPTION_REG), 7
#define PS0                            BANKMASK(OPTION_REG), 0
#define PS1                            BANKMASK(OPTION_REG), 1
#define PS2                            BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 0085h
#define TRISA0                         BANKMASK(TRISA), 0
#define TRISA1                         BANKMASK(TRISA), 1
#define TRISA2                         BANKMASK(TRISA), 2
#define TRISA3                         BANKMASK(TRISA), 3
#define TRISA4                         BANKMASK(TRISA), 4
#define TRISA5                         BANKMASK(TRISA), 5
#ifndef _LIB_BUILD
#endif
TRISC                                  equ 0087h
#define TRISC0                         BANKMASK(TRISC), 0
#define TRISC1                         BANKMASK(TRISC), 1
#define TRISC2                         BANKMASK(TRISC), 2
#define TRISC3                         BANKMASK(TRISC), 3
#define TRISC4                         BANKMASK(TRISC), 4
#define TRISC5                         BANKMASK(TRISC), 5
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE                         BANKMASK(PIE1), 0
#define C1IE                           BANKMASK(PIE1), 3
#define C2IE                           BANKMASK(PIE1), 4
#define T1IE                           BANKMASK(PIE1), 0
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOR                           BANKMASK(PCON), 0
#define nPOR                           BANKMASK(PCON), 1
#define nBOD                           BANKMASK(PCON), 0
#ifndef _LIB_BUILD
#endif
OSCTUNE                                equ 0090h
#define TUN0                           BANKMASK(OSCTUNE), 0
#define TUN1                           BANKMASK(OSCTUNE), 1
#define TUN2                           BANKMASK(OSCTUNE), 2
#define TUN3                           BANKMASK(OSCTUNE), 3
#define TUN4                           BANKMASK(OSCTUNE), 4
#ifndef _LIB_BUILD
#endif
ANSEL                                  equ 0091h
#define ANS0                           BANKMASK(ANSEL), 0
#define ANS1                           BANKMASK(ANSEL), 1
#define ANS4                           BANKMASK(ANSEL), 4
#define ANS5                           BANKMASK(ANSEL), 5
#define ANS6                           BANKMASK(ANSEL), 6
#define ANS7                           BANKMASK(ANSEL), 7
#ifndef _LIB_BUILD
#endif
WPUA                                   equ 0095h
WPU                                    equ 0095h
#define WPUA0                          BANKMASK(WPUA), 0
#define WPUA1                          BANKMASK(WPUA), 1
#define WPUA2                          BANKMASK(WPUA), 2
#define WPUA4                          BANKMASK(WPUA), 4
#define WPUA5                          BANKMASK(WPUA), 5
#define WPU0                           BANKMASK(WPUA), 0
#define WPU1                           BANKMASK(WPUA), 1
#define WPU2                           BANKMASK(WPUA), 2
#define WPU4                           BANKMASK(WPUA), 4
#define WPU5                           BANKMASK(WPUA), 5
#ifndef _LIB_BUILD
#endif
IOCA                                   equ 0096h
IOC                                    equ 0096h
#define IOCA0                          BANKMASK(IOCA), 0
#define IOCA1                          BANKMASK(IOCA), 1
#define IOCA2                          BANKMASK(IOCA), 2
#define IOCA3                          BANKMASK(IOCA), 3
#define IOCA4                          BANKMASK(IOCA), 4
#define IOCA5                          BANKMASK(IOCA), 5
#define IOC0                           BANKMASK(IOCA), 0
#define IOC1                           BANKMASK(IOCA), 1
#define IOC2                           BANKMASK(IOCA), 2
#define IOC3                           BANKMASK(IOCA), 3
#define IOC4                           BANKMASK(IOCA), 4
#define IOC5                           BANKMASK(IOCA), 5
#ifndef _LIB_BUILD
#endif
SRCON0                                 equ 0099h
#define SRCLKEN                        BANKMASK(SRCON0), 0
#define PULSR                          BANKMASK(SRCON0), 2
#define PULSS                          BANKMASK(SRCON0), 3
#define C2REN                          BANKMASK(SRCON0), 4
#define C1SEN                          BANKMASK(SRCON0), 5
#define SR0                            BANKMASK(SRCON0), 6
#define SR1                            BANKMASK(SRCON0), 7
#ifndef _LIB_BUILD
#endif
SRCON1                                 equ 009Ah
#define SRCS0                          BANKMASK(SRCON1), 6
#define SRCS1                          BANKMASK(SRCON1), 7
#ifndef _LIB_BUILD
#endif

#endif
#endif

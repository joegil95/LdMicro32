#ifndef _CASPIC_H_
#warning Header file cas10lf320.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS10LF320_H_
#define _CAS10LF320_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define RP0_bit                        BANKMASK(STATUS), 5
#define RP1_bit                        BANKMASK(STATUS), 6
#define IRP_bit                        BANKMASK(STATUS), 7
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define PORTA0_bit                     BANKMASK(PORTA), 0
#define PORTA1_bit                     BANKMASK(PORTA), 1
#define PORTA2_bit                     BANKMASK(PORTA), 2
#define PORTA3_bit                     BANKMASK(PORTA), 3
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 0006h
#ifndef _LIB_BUILD
#endif
LATA                                   equ 0007h
#define LATA0_bit                      BANKMASK(LATA), 0
#define LATA1_bit                      BANKMASK(LATA), 1
#define LATA2_bit                      BANKMASK(LATA), 2
#ifndef _LIB_BUILD
#endif
ANSELA                                 equ 0008h
#define ANSA0_bit                      BANKMASK(ANSELA), 0
#define ANSA1_bit                      BANKMASK(ANSELA), 1
#define ANSA2_bit                      BANKMASK(ANSELA), 2
#ifndef _LIB_BUILD
#endif
WPUA                                   equ 0009h
#define WPUA0_bit                      BANKMASK(WPUA), 0
#define WPUA1_bit                      BANKMASK(WPUA), 1
#define WPUA2_bit                      BANKMASK(WPUA), 2
#define WPUA3_bit                      BANKMASK(WPUA), 3
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#define PCLH0_bit                      BANKMASK(PCLATH), 0
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define IOCIF_bit                      BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define TMR0IF_bit                     BANKMASK(INTCON), 2
#define IOCIE_bit                      BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define TMR0IE_bit                     BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR2IF_bit                     BANKMASK(PIR1), 1
#define CLC1IF_bit                     BANKMASK(PIR1), 3
#define NCO1IF_bit                     BANKMASK(PIR1), 4
#define ADIF_bit                       BANKMASK(PIR1), 6
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 000Dh
#define TMR2IE_bit                     BANKMASK(PIE1), 1
#define CLC1IE_bit                     BANKMASK(PIE1), 3
#define NCO1IE_bit                     BANKMASK(PIE1), 4
#define ADIE_bit                       BANKMASK(PIE1), 6
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 000Eh
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nWPUEN_bit                     BANKMASK(OPTION_REG), 7
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
PCON                                   equ 000Fh
#define nBOR_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 0010h
#define HFIOFS_bit                     BANKMASK(OSCCON), 0
#define LFIOFR_bit                     BANKMASK(OSCCON), 1
#define HFIOFR_bit                     BANKMASK(OSCCON), 3
#define IRCF0_bit                      BANKMASK(OSCCON), 4
#define IRCF1_bit                      BANKMASK(OSCCON), 5
#define IRCF2_bit                      BANKMASK(OSCCON), 6
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 0011h
PR2                                    equ 0012h
T2CON                                  equ 0013h
#define TMR2ON_bit                     BANKMASK(T2CON), 2
#define T2CKPS0_bit                    BANKMASK(T2CON), 0
#define T2CKPS1_bit                    BANKMASK(T2CON), 1
#define TOUTPS0_bit                    BANKMASK(T2CON), 3
#define TOUTPS1_bit                    BANKMASK(T2CON), 4
#define TOUTPS2_bit                    BANKMASK(T2CON), 5
#define TOUTPS3_bit                    BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
IOCAP                                  equ 0014h
#define IOCAP0_bit                     BANKMASK(IOCAP), 0
#define IOCAP1_bit                     BANKMASK(IOCAP), 1
#define IOCAP2_bit                     BANKMASK(IOCAP), 2
#define IOCAP3_bit                     BANKMASK(IOCAP), 3
#ifndef _LIB_BUILD
#endif
IOCAN                                  equ 0015h
#define IOCAN0_bit                     BANKMASK(IOCAN), 0
#define IOCAN1_bit                     BANKMASK(IOCAN), 1
#define IOCAN2_bit                     BANKMASK(IOCAN), 2
#define IOCAN3_bit                     BANKMASK(IOCAN), 3
#ifndef _LIB_BUILD
#endif
IOCAF                                  equ 0016h
#define IOCAF0_bit                     BANKMASK(IOCAF), 0
#define IOCAF1_bit                     BANKMASK(IOCAF), 1
#define IOCAF2_bit                     BANKMASK(IOCAF), 2
#define IOCAF3_bit                     BANKMASK(IOCAF), 3
#ifndef _LIB_BUILD
#endif
FVRCON                                 equ 0017h
#define ADFVR0_bit                     BANKMASK(FVRCON), 0
#define ADFVR1_bit                     BANKMASK(FVRCON), 1
#define TSRNG_bit                      BANKMASK(FVRCON), 4
#define TSEN_bit                       BANKMASK(FVRCON), 5
#define FVRRDY_bit                     BANKMASK(FVRCON), 6
#define FVREN_bit                      BANKMASK(FVRCON), 7
#ifndef _LIB_BUILD
#endif
ADRES                                  equ 0018h
ADCON                                  equ 0019h
#define ADON_bit                       BANKMASK(ADCON), 0
#define GO_nDONE_bit                   BANKMASK(ADCON), 1
#define CHS0_bit                       BANKMASK(ADCON), 2
#define CHS1_bit                       BANKMASK(ADCON), 3
#define CHS2_bit                       BANKMASK(ADCON), 4
#define ADCS0_bit                      BANKMASK(ADCON), 5
#define ADCS1_bit                      BANKMASK(ADCON), 6
#define ADCS2_bit                      BANKMASK(ADCON), 7
#ifndef _LIB_BUILD
#endif
PMADRL                                 equ 001Ah
PMADRH                                 equ 001Bh
#define PMADR8_bit                     BANKMASK(PMADRH), 0
#ifndef _LIB_BUILD
#endif
PMDATL                                 equ 001Ch
PMDATH                                 equ 001Dh
#ifndef _LIB_BUILD
#endif
PMCON1                                 equ 001Eh
#define RD_bit                         BANKMASK(PMCON1), 0
#define WR_bit                         BANKMASK(PMCON1), 1
#define WREN_bit                       BANKMASK(PMCON1), 2
#define WRERR_bit                      BANKMASK(PMCON1), 3
#define FREE_bit                       BANKMASK(PMCON1), 4
#define LWLO_bit                       BANKMASK(PMCON1), 5
#define CFGS_bit                       BANKMASK(PMCON1), 6
#ifndef _LIB_BUILD
#endif
PMCON2                                 equ 001Fh
CLKRCON                                equ 0020h
#define CLKROE_bit                     BANKMASK(CLKRCON), 6
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0022h
#define SWDTEN_bit                     BANKMASK(WDTCON), 0
#define WDTPS0_bit                     BANKMASK(WDTCON), 1
#define WDTPS1_bit                     BANKMASK(WDTCON), 2
#define WDTPS2_bit                     BANKMASK(WDTCON), 3
#define WDTPS3_bit                     BANKMASK(WDTCON), 4
#define WDTPS4_bit                     BANKMASK(WDTCON), 5
#ifndef _LIB_BUILD
#endif
VREGCON                                equ 0023h
#define VREGPM0_bit                    BANKMASK(VREGCON), 0
#define VREGPM1_bit                    BANKMASK(VREGCON), 1
#ifndef _LIB_BUILD
#endif
BORCON                                 equ 0024h
#define BORRDY_bit                     BANKMASK(BORCON), 0
#define BORFS_bit                      BANKMASK(BORCON), 6
#define SBOREN_bit                     BANKMASK(BORCON), 7
#ifndef _LIB_BUILD
#endif

#endif
#endif

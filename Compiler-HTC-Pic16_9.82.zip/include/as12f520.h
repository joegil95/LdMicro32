#ifndef _ASPIC_H_
#warning Header file as12f520.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS12F520_H_
#define _AS12F520_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define PA0                            BANKMASK(STATUS), 5
#define PA1                            BANKMASK(STATUS), 6
#define RBWUF                          BANKMASK(STATUS), 7
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
OSCCAL                                 equ 0005h
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 0006h
#define RB0                            BANKMASK(PORTB), 0
#define RB1                            BANKMASK(PORTB), 1
#define RB2                            BANKMASK(PORTB), 2
#define RB3                            BANKMASK(PORTB), 3
#define RB4                            BANKMASK(PORTB), 4
#define RB5                            BANKMASK(PORTB), 5
#ifndef _LIB_BUILD
#endif
EECON                                  equ 0021h
#define RD                             BANKMASK(EECON), 0
#define WR                             BANKMASK(EECON), 1
#define WREN                           BANKMASK(EECON), 2
#define WRERR                          BANKMASK(EECON), 3
#define FREE                           BANKMASK(EECON), 4
#ifndef _LIB_BUILD
#endif
EEDATA                                 equ 0025h
EEADR                                  equ 0026h

#endif
#endif

#ifndef _ASPIC_H_
#warning Header file asrf675k.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _ASRF675K_H_
#define _ASRF675K_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define IRP                            BANKMASK(STATUS), 7
#define RP0                            BANKMASK(STATUS), 5
#define RP1                            BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
GPIO                                   equ 0005h
#define GP0                            BANKMASK(GPIO), 0
#define GP1                            BANKMASK(GPIO), 1
#define GP2                            BANKMASK(GPIO), 2
#define GP3                            BANKMASK(GPIO), 3
#define GP4                            BANKMASK(GPIO), 4
#define GP5                            BANKMASK(GPIO), 5
#define GPIO0                          BANKMASK(GPIO), 0
#define GPIO1                          BANKMASK(GPIO), 1
#define GPIO2                          BANKMASK(GPIO), 2
#define GPIO3                          BANKMASK(GPIO), 3
#define GPIO4                          BANKMASK(GPIO), 4
#define GPIO5                          BANKMASK(GPIO), 5
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define GPIF                           BANKMASK(INTCON), 0
#define INTF                           BANKMASK(INTCON), 1
#define T0IF                           BANKMASK(INTCON), 2
#define GPIE                           BANKMASK(INTCON), 3
#define INTE                           BANKMASK(INTCON), 4
#define T0IE                           BANKMASK(INTCON), 5
#define PEIE                           BANKMASK(INTCON), 6
#define GIE                            BANKMASK(INTCON), 7
#define TMR0IF                         BANKMASK(INTCON), 2
#define TMR0IE                         BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF                         BANKMASK(PIR1), 0
#define CMIF                           BANKMASK(PIR1), 3
#define ADIF                           BANKMASK(PIR1), 6
#define EEIF                           BANKMASK(PIR1), 7
#define T1IF                           BANKMASK(PIR1), 0
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Eh
TMR1H                                  equ 000Fh
T1CON                                  equ 0010h
#define TMR1ON                         BANKMASK(T1CON), 0
#define TMR1CS                         BANKMASK(T1CON), 1
#define nT1SYNC                        BANKMASK(T1CON), 2
#define T1OSCEN                        BANKMASK(T1CON), 3
#define TMR1GE                         BANKMASK(T1CON), 6
#define T1CKPS0                        BANKMASK(T1CON), 4
#define T1CKPS1                        BANKMASK(T1CON), 5
#ifndef _LIB_BUILD
#endif
CMCON                                  equ 0019h
#define CIS                            BANKMASK(CMCON), 3
#define CINV                           BANKMASK(CMCON), 4
#define COUT                           BANKMASK(CMCON), 6
#define CM0                            BANKMASK(CMCON), 0
#define CM1                            BANKMASK(CMCON), 1
#define CM2                            BANKMASK(CMCON), 2
#ifndef _LIB_BUILD
#endif
ADRESH                                 equ 001Eh
ADCON0                                 equ 001Fh
#define ADON                           BANKMASK(ADCON0), 0
#define GO_nDONE                       BANKMASK(ADCON0), 1
#define VCFG                           BANKMASK(ADCON0), 6
#define ADFM                           BANKMASK(ADCON0), 7
#define GO_DONE                        BANKMASK(ADCON0), 1
#define CHS0                           BANKMASK(ADCON0), 2
#define CHS1                           BANKMASK(ADCON0), 3
#define nDONE                          BANKMASK(ADCON0), 1
#define GO                             BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA                            BANKMASK(OPTION_REG), 3
#define T0SE                           BANKMASK(OPTION_REG), 4
#define T0CS                           BANKMASK(OPTION_REG), 5
#define INTEDG                         BANKMASK(OPTION_REG), 6
#define nGPPU                          BANKMASK(OPTION_REG), 7
#define PS0                            BANKMASK(OPTION_REG), 0
#define PS1                            BANKMASK(OPTION_REG), 1
#define PS2                            BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISIO                                 equ 0085h
#define TRISIO0                        BANKMASK(TRISIO), 0
#define TRISIO1                        BANKMASK(TRISIO), 1
#define TRISIO2                        BANKMASK(TRISIO), 2
#define TRISIO3                        BANKMASK(TRISIO), 3
#define TRISIO4                        BANKMASK(TRISIO), 4
#define TRISIO5                        BANKMASK(TRISIO), 5
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE                         BANKMASK(PIE1), 0
#define CMIE                           BANKMASK(PIE1), 3
#define ADIE                           BANKMASK(PIE1), 6
#define EEIE                           BANKMASK(PIE1), 7
#define T1IE                           BANKMASK(PIE1), 0
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOR                           BANKMASK(PCON), 0
#define nPOR                           BANKMASK(PCON), 1
#define nBOD                           BANKMASK(PCON), 0
#ifndef _LIB_BUILD
#endif
OSCCAL                                 equ 0090h
#define CAL0                           BANKMASK(OSCCAL), 2
#define CAL1                           BANKMASK(OSCCAL), 3
#define CAL2                           BANKMASK(OSCCAL), 4
#define CAL3                           BANKMASK(OSCCAL), 5
#define CAL4                           BANKMASK(OSCCAL), 6
#define CAL5                           BANKMASK(OSCCAL), 7
#ifndef _LIB_BUILD
#endif
WPU                                    equ 0095h
#define WPU0                           BANKMASK(WPU), 0
#define WPU1                           BANKMASK(WPU), 1
#define WPU2                           BANKMASK(WPU), 2
#define WPU4                           BANKMASK(WPU), 4
#define WPU5                           BANKMASK(WPU), 5
#ifndef _LIB_BUILD
#endif
IOC                                    equ 0096h
IOCB                                   equ 0096h
#define IOC0                           BANKMASK(IOC), 0
#define IOC1                           BANKMASK(IOC), 1
#define IOC2                           BANKMASK(IOC), 2
#define IOC3                           BANKMASK(IOC), 3
#define IOC4                           BANKMASK(IOC), 4
#define IOC5                           BANKMASK(IOC), 5
#define IOCB0                          BANKMASK(IOC), 0
#define IOCB1                          BANKMASK(IOC), 1
#define IOCB2                          BANKMASK(IOC), 2
#define IOCB3                          BANKMASK(IOC), 3
#define IOCB4                          BANKMASK(IOC), 4
#define IOCB5                          BANKMASK(IOC), 5
#ifndef _LIB_BUILD
#endif
VRCON                                  equ 0099h
#define VRR                            BANKMASK(VRCON), 5
#define VREN                           BANKMASK(VRCON), 7
#define VR0                            BANKMASK(VRCON), 0
#define VR1                            BANKMASK(VRCON), 1
#define VR2                            BANKMASK(VRCON), 2
#define VR3                            BANKMASK(VRCON), 3
#ifndef _LIB_BUILD
#endif
EEDATA                                 equ 009Ah
EEDAT                                  equ 009Ah
EEADR                                  equ 009Bh
#ifndef _LIB_BUILD
#endif
EECON1                                 equ 009Ch
#define RD                             BANKMASK(EECON1), 0
#define WR                             BANKMASK(EECON1), 1
#define WREN                           BANKMASK(EECON1), 2
#define WRERR                          BANKMASK(EECON1), 3
#ifndef _LIB_BUILD
#endif
EECON2                                 equ 009Dh
ADRESL                                 equ 009Eh
ANSEL                                  equ 009Fh
#define ANS0                           BANKMASK(ANSEL), 0
#define ANS1                           BANKMASK(ANSEL), 1
#define ANS2                           BANKMASK(ANSEL), 2
#define ANS3                           BANKMASK(ANSEL), 3
#define ADCS0                          BANKMASK(ANSEL), 4
#define ADCS1                          BANKMASK(ANSEL), 5
#define ADCS2                          BANKMASK(ANSEL), 6
#ifndef _LIB_BUILD
#endif

#endif
#endif

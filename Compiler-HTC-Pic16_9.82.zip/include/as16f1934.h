#ifndef _ASPIC_H_
#warning Header file as16f1934.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS16F1934_H_
#define _AS16F1934_H_

INDF0                                  equ 0000h
INDF1                                  equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#ifndef _LIB_BUILD
#endif
FSR0L                                  equ 0004h
FSR0H                                  equ 0005h
FSR1L                                  equ 0006h
FSR1H                                  equ 0007h
BSR                                    equ 0008h
#define BSR0                           BANKMASK(BSR), 0
#define BSR1                           BANKMASK(BSR), 1
#define BSR2                           BANKMASK(BSR), 2
#define BSR3                           BANKMASK(BSR), 3
#define BSR4                           BANKMASK(BSR), 4
#ifndef _LIB_BUILD
#endif
WREG                                   equ 0009h
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define IOCIF                          BANKMASK(INTCON), 0
#define INTF                           BANKMASK(INTCON), 1
#define TMR0IF                         BANKMASK(INTCON), 2
#define IOCIE                          BANKMASK(INTCON), 3
#define INTE                           BANKMASK(INTCON), 4
#define TMR0IE                         BANKMASK(INTCON), 5
#define PEIE                           BANKMASK(INTCON), 6
#define GIE                            BANKMASK(INTCON), 7
#define T0IF                           BANKMASK(INTCON), 2
#define T0IE                           BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PORTA                                  equ 000Ch
#define RA0                            BANKMASK(PORTA), 0
#define RA1                            BANKMASK(PORTA), 1
#define RA2                            BANKMASK(PORTA), 2
#define RA3                            BANKMASK(PORTA), 3
#define RA4                            BANKMASK(PORTA), 4
#define RA5                            BANKMASK(PORTA), 5
#define RA6                            BANKMASK(PORTA), 6
#define RA7                            BANKMASK(PORTA), 7
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 000Dh
#define RB0                            BANKMASK(PORTB), 0
#define RB1                            BANKMASK(PORTB), 1
#define RB2                            BANKMASK(PORTB), 2
#define RB3                            BANKMASK(PORTB), 3
#define RB4                            BANKMASK(PORTB), 4
#define RB5                            BANKMASK(PORTB), 5
#define RB6                            BANKMASK(PORTB), 6
#define RB7                            BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 000Eh
#define RC0                            BANKMASK(PORTC), 0
#define RC1                            BANKMASK(PORTC), 1
#define RC2                            BANKMASK(PORTC), 2
#define RC3                            BANKMASK(PORTC), 3
#define RC4                            BANKMASK(PORTC), 4
#define RC5                            BANKMASK(PORTC), 5
#define RC6                            BANKMASK(PORTC), 6
#define RC7                            BANKMASK(PORTC), 7
#ifndef _LIB_BUILD
#endif
PORTD                                  equ 000Fh
#define RD0                            BANKMASK(PORTD), 0
#define RD1                            BANKMASK(PORTD), 1
#define RD2                            BANKMASK(PORTD), 2
#define RD3                            BANKMASK(PORTD), 3
#define RD4                            BANKMASK(PORTD), 4
#define RD5                            BANKMASK(PORTD), 5
#define RD6                            BANKMASK(PORTD), 6
#define RD7                            BANKMASK(PORTD), 7
#ifndef _LIB_BUILD
#endif
PORTE                                  equ 0010h
#define RE0                            BANKMASK(PORTE), 0
#define RE1                            BANKMASK(PORTE), 1
#define RE2                            BANKMASK(PORTE), 2
#define RE3                            BANKMASK(PORTE), 3
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 0011h
#define TMR1IF                         BANKMASK(PIR1), 0
#define TMR2IF                         BANKMASK(PIR1), 1
#define CCP1IF                         BANKMASK(PIR1), 2
#define SSPIF                          BANKMASK(PIR1), 3
#define TXIF                           BANKMASK(PIR1), 4
#define RCIF                           BANKMASK(PIR1), 5
#define ADIF                           BANKMASK(PIR1), 6
#define TMR1GIF                        BANKMASK(PIR1), 7
#ifndef _LIB_BUILD
#endif
PIR2                                   equ 0012h
#define CCP2IF                         BANKMASK(PIR2), 0
#define LCDIF                          BANKMASK(PIR2), 2
#define BCLIF                          BANKMASK(PIR2), 3
#define EEIF                           BANKMASK(PIR2), 4
#define C1IF                           BANKMASK(PIR2), 5
#define C2IF                           BANKMASK(PIR2), 6
#define OSFIF                          BANKMASK(PIR2), 7
#ifndef _LIB_BUILD
#endif
PIR3                                   equ 0013h
#define TMR4IF                         BANKMASK(PIR3), 1
#define TMR6IF                         BANKMASK(PIR3), 3
#define CCP3IF                         BANKMASK(PIR3), 4
#define CCP4IF                         BANKMASK(PIR3), 5
#define CCP5IF                         BANKMASK(PIR3), 6
#ifndef _LIB_BUILD
#endif
TMR0                                   equ 0015h
TMR1L                                  equ 0016h
TMR1H                                  equ 0017h
T1CON                                  equ 0018h
#define TMR1ON                         BANKMASK(T1CON), 0
#define nT1SYNC                        BANKMASK(T1CON), 2
#define T1OSCEN                        BANKMASK(T1CON), 3
#define T1CKPS0                        BANKMASK(T1CON), 4
#define T1CKPS1                        BANKMASK(T1CON), 5
#define TMR1CS0                        BANKMASK(T1CON), 6
#define TMR1CS1                        BANKMASK(T1CON), 7
#ifndef _LIB_BUILD
#endif
T1GCON                                 equ 0019h
#define T1GSS0                         BANKMASK(T1GCON), 0
#define T1GSS1                         BANKMASK(T1GCON), 1
#define T1GVAL                         BANKMASK(T1GCON), 2
#define T1GGO_nDONE                    BANKMASK(T1GCON), 3
#define T1GSPM                         BANKMASK(T1GCON), 4
#define T1GTM                          BANKMASK(T1GCON), 5
#define T1GPOL                         BANKMASK(T1GCON), 6
#define TMR1GE                         BANKMASK(T1GCON), 7
#define T1GGO                          BANKMASK(T1GCON), 3
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 001Ah
PR2                                    equ 001Bh
T2CON                                  equ 001Ch
#define T2CKPS0                        BANKMASK(T2CON), 0
#define T2CKPS1                        BANKMASK(T2CON), 1
#define TMR2ON                         BANKMASK(T2CON), 2
#define T2OUTPS0                       BANKMASK(T2CON), 3
#define T2OUTPS1                       BANKMASK(T2CON), 4
#define T2OUTPS2                       BANKMASK(T2CON), 5
#define T2OUTPS3                       BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
CPSCON0                                equ 001Eh
#define T0XCS                          BANKMASK(CPSCON0), 0
#define CPSOUT                         BANKMASK(CPSCON0), 1
#define CPSRNG0                        BANKMASK(CPSCON0), 2
#define CPSRNG1                        BANKMASK(CPSCON0), 3
#define CPSON                          BANKMASK(CPSCON0), 7
#ifndef _LIB_BUILD
#endif
CPSCON1                                equ 001Fh
#define CPSCH0                         BANKMASK(CPSCON1), 0
#define CPSCH1                         BANKMASK(CPSCON1), 1
#define CPSCH2                         BANKMASK(CPSCON1), 2
#define CPSCH3                         BANKMASK(CPSCON1), 3
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 008Ch
#define TRISA0                         BANKMASK(TRISA), 0
#define TRISA1                         BANKMASK(TRISA), 1
#define TRISA2                         BANKMASK(TRISA), 2
#define TRISA3                         BANKMASK(TRISA), 3
#define TRISA4                         BANKMASK(TRISA), 4
#define TRISA5                         BANKMASK(TRISA), 5
#define TRISA6                         BANKMASK(TRISA), 6
#define TRISA7                         BANKMASK(TRISA), 7
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 008Dh
#define TRISB0                         BANKMASK(TRISB), 0
#define TRISB1                         BANKMASK(TRISB), 1
#define TRISB2                         BANKMASK(TRISB), 2
#define TRISB3                         BANKMASK(TRISB), 3
#define TRISB4                         BANKMASK(TRISB), 4
#define TRISB5                         BANKMASK(TRISB), 5
#define TRISB6                         BANKMASK(TRISB), 6
#define TRISB7                         BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
TRISC                                  equ 008Eh
#define TRISC0                         BANKMASK(TRISC), 0
#define TRISC1                         BANKMASK(TRISC), 1
#define TRISC2                         BANKMASK(TRISC), 2
#define TRISC3                         BANKMASK(TRISC), 3
#define TRISC4                         BANKMASK(TRISC), 4
#define TRISC5                         BANKMASK(TRISC), 5
#define TRISC6                         BANKMASK(TRISC), 6
#define TRISC7                         BANKMASK(TRISC), 7
#ifndef _LIB_BUILD
#endif
TRISD                                  equ 008Fh
#define TRISD0                         BANKMASK(TRISD), 0
#define TRISD1                         BANKMASK(TRISD), 1
#define TRISD2                         BANKMASK(TRISD), 2
#define TRISD3                         BANKMASK(TRISD), 3
#define TRISD4                         BANKMASK(TRISD), 4
#define TRISD5                         BANKMASK(TRISD), 5
#define TRISD6                         BANKMASK(TRISD), 6
#define TRISD7                         BANKMASK(TRISD), 7
#ifndef _LIB_BUILD
#endif
TRISE                                  equ 0090h
#define TRISE0                         BANKMASK(TRISE), 0
#define TRISE1                         BANKMASK(TRISE), 1
#define TRISE2                         BANKMASK(TRISE), 2
#define TRISE3                         BANKMASK(TRISE), 3
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 0091h
#define TMR1IE                         BANKMASK(PIE1), 0
#define TMR2IE                         BANKMASK(PIE1), 1
#define CCP1IE                         BANKMASK(PIE1), 2
#define SSPIE                          BANKMASK(PIE1), 3
#define TXIE                           BANKMASK(PIE1), 4
#define RCIE                           BANKMASK(PIE1), 5
#define ADIE                           BANKMASK(PIE1), 6
#define TMR1GIE                        BANKMASK(PIE1), 7
#ifndef _LIB_BUILD
#endif
PIE2                                   equ 0092h
#define CCP2IE                         BANKMASK(PIE2), 0
#define LCDIE                          BANKMASK(PIE2), 2
#define BCLIE                          BANKMASK(PIE2), 3
#define EEIE                           BANKMASK(PIE2), 4
#define C1IE                           BANKMASK(PIE2), 5
#define C2IE                           BANKMASK(PIE2), 6
#define OSFIE                          BANKMASK(PIE2), 7
#ifndef _LIB_BUILD
#endif
PIE3                                   equ 0093h
#define TMR4IE                         BANKMASK(PIE3), 1
#define TMR6IE                         BANKMASK(PIE3), 3
#define CCP3IE                         BANKMASK(PIE3), 4
#define CCP4IE                         BANKMASK(PIE3), 5
#define CCP5IE                         BANKMASK(PIE3), 6
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0095h
#define PS0                            BANKMASK(OPTION_REG), 0
#define PS1                            BANKMASK(OPTION_REG), 1
#define PS2                            BANKMASK(OPTION_REG), 2
#define PSA                            BANKMASK(OPTION_REG), 3
#define TMR0SE                         BANKMASK(OPTION_REG), 4
#define TMR0CS                         BANKMASK(OPTION_REG), 5
#define INTEDG                         BANKMASK(OPTION_REG), 6
#define nWPUEN                         BANKMASK(OPTION_REG), 7
#define T0SE                           BANKMASK(OPTION_REG), 4
#define T0CS                           BANKMASK(OPTION_REG), 5
#ifndef _LIB_BUILD
#endif
PCON                                   equ 0096h
#define nBOR                           BANKMASK(PCON), 0
#define nPOR                           BANKMASK(PCON), 1
#define nRI                            BANKMASK(PCON), 2
#define nRMCLR                         BANKMASK(PCON), 3
#define STKUNF                         BANKMASK(PCON), 6
#define STKOVF                         BANKMASK(PCON), 7
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0097h
#define SWDTEN                         BANKMASK(WDTCON), 0
#define WDTPS0                         BANKMASK(WDTCON), 1
#define WDTPS1                         BANKMASK(WDTCON), 2
#define WDTPS2                         BANKMASK(WDTCON), 3
#define WDTPS3                         BANKMASK(WDTCON), 4
#define WDTPS4                         BANKMASK(WDTCON), 5
#ifndef _LIB_BUILD
#endif
OSCTUNE                                equ 0098h
#define TUN0                           BANKMASK(OSCTUNE), 0
#define TUN1                           BANKMASK(OSCTUNE), 1
#define TUN2                           BANKMASK(OSCTUNE), 2
#define TUN3                           BANKMASK(OSCTUNE), 3
#define TUN4                           BANKMASK(OSCTUNE), 4
#define TUN5                           BANKMASK(OSCTUNE), 5
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 0099h
#define SCS0                           BANKMASK(OSCCON), 0
#define SCS1                           BANKMASK(OSCCON), 1
#define IRCF0                          BANKMASK(OSCCON), 3
#define IRCF1                          BANKMASK(OSCCON), 4
#define IRCF2                          BANKMASK(OSCCON), 5
#define IRCF3                          BANKMASK(OSCCON), 6
#define SPLLEN                         BANKMASK(OSCCON), 7
#ifndef _LIB_BUILD
#endif
OSCSTAT                                equ 009Ah
#define HFIOFS                         BANKMASK(OSCSTAT), 0
#define LFIOFR                         BANKMASK(OSCSTAT), 1
#define MFIOFR                         BANKMASK(OSCSTAT), 2
#define HFIOFL                         BANKMASK(OSCSTAT), 3
#define HFIOFR                         BANKMASK(OSCSTAT), 4
#define OSTS                           BANKMASK(OSCSTAT), 5
#define PLLR                           BANKMASK(OSCSTAT), 6
#define T1OSCR                         BANKMASK(OSCSTAT), 7
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 009Bh
ADRESH                                 equ 009Ch
ADCON0                                 equ 009Dh
#define ADON                           BANKMASK(ADCON0), 0
#define GO_nDONE                       BANKMASK(ADCON0), 1
#define CHS0                           BANKMASK(ADCON0), 2
#define CHS1                           BANKMASK(ADCON0), 3
#define CHS2                           BANKMASK(ADCON0), 4
#define CHS3                           BANKMASK(ADCON0), 5
#define CHS4                           BANKMASK(ADCON0), 6
#define ADGO                           BANKMASK(ADCON0), 1
#define GO                             BANKMASK(ADCON0), 1
#define nDONE                          BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 009Eh
#define ADPREF0                        BANKMASK(ADCON1), 0
#define ADPREF1                        BANKMASK(ADCON1), 1
#define ADNREF                         BANKMASK(ADCON1), 2
#define ADCS0                          BANKMASK(ADCON1), 4
#define ADCS1                          BANKMASK(ADCON1), 5
#define ADCS2                          BANKMASK(ADCON1), 6
#define ADFM                           BANKMASK(ADCON1), 7
#ifndef _LIB_BUILD
#endif
LATA                                   equ 010Ch
#define LATA0                          BANKMASK(LATA), 0
#define LATA1                          BANKMASK(LATA), 1
#define LATA2                          BANKMASK(LATA), 2
#define LATA3                          BANKMASK(LATA), 3
#define LATA4                          BANKMASK(LATA), 4
#define LATA5                          BANKMASK(LATA), 5
#define LATA6                          BANKMASK(LATA), 6
#define LATA7                          BANKMASK(LATA), 7
#ifndef _LIB_BUILD
#endif
LATB                                   equ 010Dh
#define LATB0                          BANKMASK(LATB), 0
#define LATB1                          BANKMASK(LATB), 1
#define LATB2                          BANKMASK(LATB), 2
#define LATB3                          BANKMASK(LATB), 3
#define LATB4                          BANKMASK(LATB), 4
#define LATB5                          BANKMASK(LATB), 5
#define LATB6                          BANKMASK(LATB), 6
#define LATB7                          BANKMASK(LATB), 7
#ifndef _LIB_BUILD
#endif
LATC                                   equ 010Eh
#define LATC0                          BANKMASK(LATC), 0
#define LATC1                          BANKMASK(LATC), 1
#define LATC2                          BANKMASK(LATC), 2
#define LATC3                          BANKMASK(LATC), 3
#define LATC4                          BANKMASK(LATC), 4
#define LATC5                          BANKMASK(LATC), 5
#define LATC6                          BANKMASK(LATC), 6
#define LATC7                          BANKMASK(LATC), 7
#ifndef _LIB_BUILD
#endif
LATD                                   equ 010Fh
#define LATD0                          BANKMASK(LATD), 0
#define LATD1                          BANKMASK(LATD), 1
#define LATD2                          BANKMASK(LATD), 2
#define LATD3                          BANKMASK(LATD), 3
#define LATD4                          BANKMASK(LATD), 4
#define LATD5                          BANKMASK(LATD), 5
#define LATD6                          BANKMASK(LATD), 6
#define LATD7                          BANKMASK(LATD), 7
#ifndef _LIB_BUILD
#endif
LATE                                   equ 0110h
#define LATE0                          BANKMASK(LATE), 0
#define LATE1                          BANKMASK(LATE), 1
#define LATE2                          BANKMASK(LATE), 2
#define LATE3                          BANKMASK(LATE), 3
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 0111h
#define C1SYNC                         BANKMASK(CM1CON0), 0
#define C1HYS                          BANKMASK(CM1CON0), 1
#define C1SP                           BANKMASK(CM1CON0), 2
#define C1POL                          BANKMASK(CM1CON0), 4
#define C1OE                           BANKMASK(CM1CON0), 5
#define C1OUT                          BANKMASK(CM1CON0), 6
#define C1ON                           BANKMASK(CM1CON0), 7
#ifndef _LIB_BUILD
#endif
CM1CON1                                equ 0112h
#define C1NCH0                         BANKMASK(CM1CON1), 0
#define C1NCH1                         BANKMASK(CM1CON1), 1
#define C1PCH0                         BANKMASK(CM1CON1), 4
#define C1PCH1                         BANKMASK(CM1CON1), 5
#define C1INTN                         BANKMASK(CM1CON1), 6
#define C1INTP                         BANKMASK(CM1CON1), 7
#ifndef _LIB_BUILD
#endif
CM2CON0                                equ 0113h
#define C2SYNC                         BANKMASK(CM2CON0), 0
#define C2HYS                          BANKMASK(CM2CON0), 1
#define C2SP                           BANKMASK(CM2CON0), 2
#define C2POL                          BANKMASK(CM2CON0), 4
#define C2OE                           BANKMASK(CM2CON0), 5
#define C2OUT                          BANKMASK(CM2CON0), 6
#define C2ON                           BANKMASK(CM2CON0), 7
#ifndef _LIB_BUILD
#endif
CM2CON1                                equ 0114h
#define C2NCH0                         BANKMASK(CM2CON1), 0
#define C2NCH1                         BANKMASK(CM2CON1), 1
#define C2PCH0                         BANKMASK(CM2CON1), 4
#define C2PCH1                         BANKMASK(CM2CON1), 5
#define C2INTN                         BANKMASK(CM2CON1), 6
#define C2INTP                         BANKMASK(CM2CON1), 7
#ifndef _LIB_BUILD
#endif
CMOUT                                  equ 0115h
#define MC1OUT                         BANKMASK(CMOUT), 0
#define MC2OUT                         BANKMASK(CMOUT), 1
#ifndef _LIB_BUILD
#endif
BORCON                                 equ 0116h
#define BORRDY                         BANKMASK(BORCON), 0
#define SBOREN                         BANKMASK(BORCON), 7
#ifndef _LIB_BUILD
#endif
FVRCON                                 equ 0117h
#define ADFVR0                         BANKMASK(FVRCON), 0
#define ADFVR1                         BANKMASK(FVRCON), 1
#define CDAFVR0                        BANKMASK(FVRCON), 2
#define CDAFVR1                        BANKMASK(FVRCON), 3
#define TSRNG                          BANKMASK(FVRCON), 4
#define TSEN                           BANKMASK(FVRCON), 5
#define FVRRDY                         BANKMASK(FVRCON), 6
#define FVREN                          BANKMASK(FVRCON), 7
#ifndef _LIB_BUILD
#endif
DACCON0                                equ 0118h
#define DACNSS                         BANKMASK(DACCON0), 0
#define DACPSS0                        BANKMASK(DACCON0), 2
#define DACPSS1                        BANKMASK(DACCON0), 3
#define DACOE                          BANKMASK(DACCON0), 5
#define DACLPS                         BANKMASK(DACCON0), 6
#define DACEN                          BANKMASK(DACCON0), 7
#ifndef _LIB_BUILD
#endif
DACCON1                                equ 0119h
#define DACR0                          BANKMASK(DACCON1), 0
#define DACR1                          BANKMASK(DACCON1), 1
#define DACR2                          BANKMASK(DACCON1), 2
#define DACR3                          BANKMASK(DACCON1), 3
#define DACR4                          BANKMASK(DACCON1), 4
#ifndef _LIB_BUILD
#endif
SRCON0                                 equ 011Ah
#define SRPR                           BANKMASK(SRCON0), 0
#define SRPS                           BANKMASK(SRCON0), 1
#define SRNQEN                         BANKMASK(SRCON0), 2
#define SRQEN                          BANKMASK(SRCON0), 3
#define SRCLK0                         BANKMASK(SRCON0), 4
#define SRCLK1                         BANKMASK(SRCON0), 5
#define SRCLK2                         BANKMASK(SRCON0), 6
#define SRLEN                          BANKMASK(SRCON0), 7
#ifndef _LIB_BUILD
#endif
SRCON1                                 equ 011Bh
#define SRRC1E                         BANKMASK(SRCON1), 0
#define SRRC2E                         BANKMASK(SRCON1), 1
#define SRRCKE                         BANKMASK(SRCON1), 2
#define SRRPE                          BANKMASK(SRCON1), 3
#define SRSC1E                         BANKMASK(SRCON1), 4
#define SRSC2E                         BANKMASK(SRCON1), 5
#define SRSCKE                         BANKMASK(SRCON1), 6
#define SRSPE                          BANKMASK(SRCON1), 7
#ifndef _LIB_BUILD
#endif
APFCON                                 equ 011Dh
#define CCP2SEL                        BANKMASK(APFCON), 0
#define SSSEL                          BANKMASK(APFCON), 1
#define C2OUTSEL                       BANKMASK(APFCON), 2
#define SRNQSEL                        BANKMASK(APFCON), 3
#define P2BSEL                         BANKMASK(APFCON), 4
#define T1GSEL                         BANKMASK(APFCON), 5
#define CCP3SEL                        BANKMASK(APFCON), 6
#ifndef _LIB_BUILD
#endif
ANSELA                                 equ 018Ch
#define ANSA0                          BANKMASK(ANSELA), 0
#define ANSA1                          BANKMASK(ANSELA), 1
#define ANSA2                          BANKMASK(ANSELA), 2
#define ANSA3                          BANKMASK(ANSELA), 3
#define ANSA4                          BANKMASK(ANSELA), 4
#define ANSA5                          BANKMASK(ANSELA), 5
#ifndef _LIB_BUILD
#endif
ANSELB                                 equ 018Dh
#define ANSB0                          BANKMASK(ANSELB), 0
#define ANSB1                          BANKMASK(ANSELB), 1
#define ANSB2                          BANKMASK(ANSELB), 2
#define ANSB3                          BANKMASK(ANSELB), 3
#define ANSB4                          BANKMASK(ANSELB), 4
#define ANSB5                          BANKMASK(ANSELB), 5
#ifndef _LIB_BUILD
#endif
ANSELD                                 equ 018Fh
#define ANSD0                          BANKMASK(ANSELD), 0
#define ANSD1                          BANKMASK(ANSELD), 1
#define ANSD2                          BANKMASK(ANSELD), 2
#define ANSD3                          BANKMASK(ANSELD), 3
#define ANSD4                          BANKMASK(ANSELD), 4
#define ANSD5                          BANKMASK(ANSELD), 5
#define ANSD6                          BANKMASK(ANSELD), 6
#define ANSD7                          BANKMASK(ANSELD), 7
#ifndef _LIB_BUILD
#endif
ANSELE                                 equ 0190h
#define ANSE0                          BANKMASK(ANSELE), 0
#define ANSE1                          BANKMASK(ANSELE), 1
#define ANSE2                          BANKMASK(ANSELE), 2
#ifndef _LIB_BUILD
#endif
EEADRL                                 equ 0191h
EEADRH                                 equ 0192h
#ifndef _LIB_BUILD
#endif
EEDATL                                 equ 0193h
EEDATA                                 equ 0193h
EEDATH                                 equ 0194h
#ifndef _LIB_BUILD
#endif
EECON1                                 equ 0195h
#define RD                             BANKMASK(EECON1), 0
#define WR                             BANKMASK(EECON1), 1
#define WREN                           BANKMASK(EECON1), 2
#define WRERR                          BANKMASK(EECON1), 3
#define FREE                           BANKMASK(EECON1), 4
#define LWLO                           BANKMASK(EECON1), 5
#define CFGS                           BANKMASK(EECON1), 6
#define EEPGD                          BANKMASK(EECON1), 7
#ifndef _LIB_BUILD
#endif
EECON2                                 equ 0196h
RCREG                                  equ 0199h
TXREG                                  equ 019Ah
SPBRGL                                 equ 019Bh
SPBRG                                  equ 019Bh
SPBRGH                                 equ 019Ch
RCSTA                                  equ 019Dh
#define RX9D                           BANKMASK(RCSTA), 0
#define OERR                           BANKMASK(RCSTA), 1
#define FERR                           BANKMASK(RCSTA), 2
#define ADDEN                          BANKMASK(RCSTA), 3
#define CREN                           BANKMASK(RCSTA), 4
#define SREN                           BANKMASK(RCSTA), 5
#define RX9                            BANKMASK(RCSTA), 6
#define SPEN                           BANKMASK(RCSTA), 7
#ifndef _LIB_BUILD
#endif
TXSTA                                  equ 019Eh
#define TX9D                           BANKMASK(TXSTA), 0
#define TRMT                           BANKMASK(TXSTA), 1
#define BRGH                           BANKMASK(TXSTA), 2
#define SENDB                          BANKMASK(TXSTA), 3
#define SYNC                           BANKMASK(TXSTA), 4
#define TXEN                           BANKMASK(TXSTA), 5
#define TX9                            BANKMASK(TXSTA), 6
#define CSRC                           BANKMASK(TXSTA), 7
#ifndef _LIB_BUILD
#endif
BAUDCON                                equ 019Fh
#define ABDEN                          BANKMASK(BAUDCON), 0
#define WUE                            BANKMASK(BAUDCON), 1
#define BRG16                          BANKMASK(BAUDCON), 3
#define SCKP                           BANKMASK(BAUDCON), 4
#define RCIDL                          BANKMASK(BAUDCON), 6
#define ABDOVF                         BANKMASK(BAUDCON), 7
#ifndef _LIB_BUILD
#endif
WPUB                                   equ 020Dh
#define WPUB0                          BANKMASK(WPUB), 0
#define WPUB1                          BANKMASK(WPUB), 1
#define WPUB2                          BANKMASK(WPUB), 2
#define WPUB3                          BANKMASK(WPUB), 3
#define WPUB4                          BANKMASK(WPUB), 4
#define WPUB5                          BANKMASK(WPUB), 5
#define WPUB6                          BANKMASK(WPUB), 6
#define WPUB7                          BANKMASK(WPUB), 7
#ifndef _LIB_BUILD
#endif
WPUE                                   equ 0210h
#define WPUE3                          BANKMASK(WPUE), 3
#ifndef _LIB_BUILD
#endif
SSPBUF                                 equ 0211h
SSPADD                                 equ 0212h
SSPMSK                                 equ 0213h
SSPSTAT                                equ 0214h
#define BF                             BANKMASK(SSPSTAT), 0
#define UA                             BANKMASK(SSPSTAT), 1
#define R_nW                           BANKMASK(SSPSTAT), 2
#define S                              BANKMASK(SSPSTAT), 3
#define P                              BANKMASK(SSPSTAT), 4
#define D_nA                           BANKMASK(SSPSTAT), 5
#define CKE                            BANKMASK(SSPSTAT), 6
#define SMP                            BANKMASK(SSPSTAT), 7
#ifndef _LIB_BUILD
#endif
SSPCON1                                equ 0215h
SSPCON                                 equ 0215h
#define SSPM0                          BANKMASK(SSPCON1), 0
#define SSPM1                          BANKMASK(SSPCON1), 1
#define SSPM2                          BANKMASK(SSPCON1), 2
#define SSPM3                          BANKMASK(SSPCON1), 3
#define CKP                            BANKMASK(SSPCON1), 4
#define SSPEN                          BANKMASK(SSPCON1), 5
#define SSPOV                          BANKMASK(SSPCON1), 6
#define WCOL                           BANKMASK(SSPCON1), 7
#ifndef _LIB_BUILD
#endif
SSPCON2                                equ 0216h
#define SEN                            BANKMASK(SSPCON2), 0
#define RSEN                           BANKMASK(SSPCON2), 1
#define PEN                            BANKMASK(SSPCON2), 2
#define RCEN                           BANKMASK(SSPCON2), 3
#define ACKEN                          BANKMASK(SSPCON2), 4
#define ACKDT                          BANKMASK(SSPCON2), 5
#define ACKSTAT                        BANKMASK(SSPCON2), 6
#define GCEN                           BANKMASK(SSPCON2), 7
#ifndef _LIB_BUILD
#endif
SSPCON3                                equ 0217h
#define DHEN                           BANKMASK(SSPCON3), 0
#define AHEN                           BANKMASK(SSPCON3), 1
#define SBCDE                          BANKMASK(SSPCON3), 2
#define SDAHT                          BANKMASK(SSPCON3), 3
#define BOEN                           BANKMASK(SSPCON3), 4
#define SCIE                           BANKMASK(SSPCON3), 5
#define PCIE                           BANKMASK(SSPCON3), 6
#define ACKTIM                         BANKMASK(SSPCON3), 7
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0291h
CCPR1H                                 equ 0292h
CCP1CON                                equ 0293h
#define CCP1M0                         BANKMASK(CCP1CON), 0
#define CCP1M1                         BANKMASK(CCP1CON), 1
#define CCP1M2                         BANKMASK(CCP1CON), 2
#define CCP1M3                         BANKMASK(CCP1CON), 3
#define DC1B0                          BANKMASK(CCP1CON), 4
#define DC1B1                          BANKMASK(CCP1CON), 5
#define P1M0                           BANKMASK(CCP1CON), 6
#define P1M1                           BANKMASK(CCP1CON), 7
#ifndef _LIB_BUILD
#endif
PWM1CON                                equ 0294h
#define P1DC0                          BANKMASK(PWM1CON), 0
#define P1DC1                          BANKMASK(PWM1CON), 1
#define P1DC2                          BANKMASK(PWM1CON), 2
#define P1DC3                          BANKMASK(PWM1CON), 3
#define P1DC4                          BANKMASK(PWM1CON), 4
#define P1DC5                          BANKMASK(PWM1CON), 5
#define P1DC6                          BANKMASK(PWM1CON), 6
#define P1RSEN                         BANKMASK(PWM1CON), 7
#ifndef _LIB_BUILD
#endif
CCP1AS                                 equ 0295h
ECCP1AS                                equ 0295h
#define PSS1BD0                        BANKMASK(CCP1AS), 0
#define PSS1BD1                        BANKMASK(CCP1AS), 1
#define PSS1AC0                        BANKMASK(CCP1AS), 2
#define PSS1AC1                        BANKMASK(CCP1AS), 3
#define CCP1AS0                        BANKMASK(CCP1AS), 4
#define CCP1AS1                        BANKMASK(CCP1AS), 5
#define CCP1AS2                        BANKMASK(CCP1AS), 6
#define CCP1ASE                        BANKMASK(CCP1AS), 7
#ifndef _LIB_BUILD
#endif
PSTR1CON                               equ 0296h
#define STR1A                          BANKMASK(PSTR1CON), 0
#define STR1B                          BANKMASK(PSTR1CON), 1
#define STR1C                          BANKMASK(PSTR1CON), 2
#define STR1D                          BANKMASK(PSTR1CON), 3
#define STR1SYNC                       BANKMASK(PSTR1CON), 4
#ifndef _LIB_BUILD
#endif
CCPR2L                                 equ 0298h
CCPR2H                                 equ 0299h
CCP2CON                                equ 029Ah
#define CCP2M0                         BANKMASK(CCP2CON), 0
#define CCP2M1                         BANKMASK(CCP2CON), 1
#define CCP2M2                         BANKMASK(CCP2CON), 2
#define CCP2M3                         BANKMASK(CCP2CON), 3
#define DC2B0                          BANKMASK(CCP2CON), 4
#define DC2B1                          BANKMASK(CCP2CON), 5
#define P2M0                           BANKMASK(CCP2CON), 6
#define P2M1                           BANKMASK(CCP2CON), 7
#ifndef _LIB_BUILD
#endif
PWM2CON                                equ 029Bh
#define P2DC0                          BANKMASK(PWM2CON), 0
#define P2DC1                          BANKMASK(PWM2CON), 1
#define P2DC2                          BANKMASK(PWM2CON), 2
#define P2DC3                          BANKMASK(PWM2CON), 3
#define P2DC4                          BANKMASK(PWM2CON), 4
#define P2DC5                          BANKMASK(PWM2CON), 5
#define P2DC6                          BANKMASK(PWM2CON), 6
#define P2RSEN                         BANKMASK(PWM2CON), 7
#ifndef _LIB_BUILD
#endif
CCP2AS                                 equ 029Ch
ECCP2AS                                equ 029Ch
#define PSS2BD0                        BANKMASK(CCP2AS), 0
#define PSS2BD1                        BANKMASK(CCP2AS), 1
#define PSS2AC0                        BANKMASK(CCP2AS), 2
#define PSS2AC1                        BANKMASK(CCP2AS), 3
#define CCP2AS0                        BANKMASK(CCP2AS), 4
#define CCP2AS1                        BANKMASK(CCP2AS), 5
#define CCP2AS2                        BANKMASK(CCP2AS), 6
#define CCP2ASE                        BANKMASK(CCP2AS), 7
#ifndef _LIB_BUILD
#endif
PSTR2CON                               equ 029Dh
#define STR2A                          BANKMASK(PSTR2CON), 0
#define STR2B                          BANKMASK(PSTR2CON), 1
#define STR2C                          BANKMASK(PSTR2CON), 2
#define STR2D                          BANKMASK(PSTR2CON), 3
#define STR2SYNC                       BANKMASK(PSTR2CON), 4
#ifndef _LIB_BUILD
#endif
CCPTMRS0                               equ 029Eh
#define C1TSEL0                        BANKMASK(CCPTMRS0), 0
#define C1TSEL1                        BANKMASK(CCPTMRS0), 1
#define C2TSEL0                        BANKMASK(CCPTMRS0), 2
#define C2TSEL1                        BANKMASK(CCPTMRS0), 3
#define C3TSEL0                        BANKMASK(CCPTMRS0), 4
#define C3TSEL1                        BANKMASK(CCPTMRS0), 5
#define C4TSEL0                        BANKMASK(CCPTMRS0), 6
#define C4TSEL1                        BANKMASK(CCPTMRS0), 7
#ifndef _LIB_BUILD
#endif
CCPTMRS1                               equ 029Fh
#define C5TSEL0                        BANKMASK(CCPTMRS1), 0
#define C5TSEL1                        BANKMASK(CCPTMRS1), 1
#ifndef _LIB_BUILD
#endif
CCPR3L                                 equ 0311h
CCPR3H                                 equ 0312h
CCP3CON                                equ 0313h
#define CCP3M0                         BANKMASK(CCP3CON), 0
#define CCP3M1                         BANKMASK(CCP3CON), 1
#define CCP3M2                         BANKMASK(CCP3CON), 2
#define CCP3M3                         BANKMASK(CCP3CON), 3
#define DC3B0                          BANKMASK(CCP3CON), 4
#define DC3B1                          BANKMASK(CCP3CON), 5
#define P3M0                           BANKMASK(CCP3CON), 6
#define P3M1                           BANKMASK(CCP3CON), 7
#ifndef _LIB_BUILD
#endif
PWM3CON                                equ 0314h
#define P3DC0                          BANKMASK(PWM3CON), 0
#define P3DC1                          BANKMASK(PWM3CON), 1
#define P3DC2                          BANKMASK(PWM3CON), 2
#define P3DC3                          BANKMASK(PWM3CON), 3
#define P3DC4                          BANKMASK(PWM3CON), 4
#define P3DC5                          BANKMASK(PWM3CON), 5
#define P3DC6                          BANKMASK(PWM3CON), 6
#define P3RSEN                         BANKMASK(PWM3CON), 7
#ifndef _LIB_BUILD
#endif
CCP3AS                                 equ 0315h
ECCP3AS                                equ 0315h
#define PSS3BD0                        BANKMASK(CCP3AS), 0
#define PSS3BD1                        BANKMASK(CCP3AS), 1
#define PSS3AC0                        BANKMASK(CCP3AS), 2
#define PSS3AC1                        BANKMASK(CCP3AS), 3
#define CCP3AS0                        BANKMASK(CCP3AS), 4
#define CCP3AS1                        BANKMASK(CCP3AS), 5
#define CCP3AS2                        BANKMASK(CCP3AS), 6
#define CCP3ASE                        BANKMASK(CCP3AS), 7
#ifndef _LIB_BUILD
#endif
PSTR3CON                               equ 0316h
#define STR3A                          BANKMASK(PSTR3CON), 0
#define STR3B                          BANKMASK(PSTR3CON), 1
#define STR3C                          BANKMASK(PSTR3CON), 2
#define STR3D                          BANKMASK(PSTR3CON), 3
#define STR3SYNC                       BANKMASK(PSTR3CON), 4
#ifndef _LIB_BUILD
#endif
CCPR4L                                 equ 0318h
CCPR4H                                 equ 0319h
CCP4CON                                equ 031Ah
#define CCP4M0                         BANKMASK(CCP4CON), 0
#define CCP4M1                         BANKMASK(CCP4CON), 1
#define CCP4M2                         BANKMASK(CCP4CON), 2
#define CCP4M3                         BANKMASK(CCP4CON), 3
#define DC4B0                          BANKMASK(CCP4CON), 4
#define DC4B1                          BANKMASK(CCP4CON), 5
#ifndef _LIB_BUILD
#endif
CCPR5L                                 equ 031Ch
CCPR5H                                 equ 031Dh
CCP5CON                                equ 031Eh
#define CCP5M0                         BANKMASK(CCP5CON), 0
#define CCP5M1                         BANKMASK(CCP5CON), 1
#define CCP5M2                         BANKMASK(CCP5CON), 2
#define CCP5M3                         BANKMASK(CCP5CON), 3
#define DC5B0                          BANKMASK(CCP5CON), 4
#define DC5B1                          BANKMASK(CCP5CON), 5
#ifndef _LIB_BUILD
#endif
IOCBP                                  equ 0394h
#define IOCBP0                         BANKMASK(IOCBP), 0
#define IOCBP1                         BANKMASK(IOCBP), 1
#define IOCBP2                         BANKMASK(IOCBP), 2
#define IOCBP3                         BANKMASK(IOCBP), 3
#define IOCBP4                         BANKMASK(IOCBP), 4
#define IOCBP5                         BANKMASK(IOCBP), 5
#define IOCBP6                         BANKMASK(IOCBP), 6
#define IOCBP7                         BANKMASK(IOCBP), 7
#ifndef _LIB_BUILD
#endif
IOCBN                                  equ 0395h
#define IOCBN0                         BANKMASK(IOCBN), 0
#define IOCBN1                         BANKMASK(IOCBN), 1
#define IOCBN2                         BANKMASK(IOCBN), 2
#define IOCBN3                         BANKMASK(IOCBN), 3
#define IOCBN4                         BANKMASK(IOCBN), 4
#define IOCBN5                         BANKMASK(IOCBN), 5
#define IOCBN6                         BANKMASK(IOCBN), 6
#define IOCBN7                         BANKMASK(IOCBN), 7
#ifndef _LIB_BUILD
#endif
IOCBF                                  equ 0396h
#define IOCBF0                         BANKMASK(IOCBF), 0
#define IOCBF1                         BANKMASK(IOCBF), 1
#define IOCBF2                         BANKMASK(IOCBF), 2
#define IOCBF3                         BANKMASK(IOCBF), 3
#define IOCBF4                         BANKMASK(IOCBF), 4
#define IOCBF5                         BANKMASK(IOCBF), 5
#define IOCBF6                         BANKMASK(IOCBF), 6
#define IOCBF7                         BANKMASK(IOCBF), 7
#ifndef _LIB_BUILD
#endif
TMR4                                   equ 0415h
PR4                                    equ 0416h
T4CON                                  equ 0417h
#define T4CKPS0                        BANKMASK(T4CON), 0
#define T4CKPS1                        BANKMASK(T4CON), 1
#define TMR4ON                         BANKMASK(T4CON), 2
#define T4OUTPS0                       BANKMASK(T4CON), 3
#define T4OUTPS1                       BANKMASK(T4CON), 4
#define T4OUTPS2                       BANKMASK(T4CON), 5
#define T4OUTPS3                       BANKMASK(T4CON), 6
#ifndef _LIB_BUILD
#endif
TMR6                                   equ 041Ch
PR6                                    equ 041Dh
T6CON                                  equ 041Eh
#define T6CKPS0                        BANKMASK(T6CON), 0
#define T6CKPS1                        BANKMASK(T6CON), 1
#define TMR6ON                         BANKMASK(T6CON), 2
#define T6OUTPS0                       BANKMASK(T6CON), 3
#define T6OUTPS1                       BANKMASK(T6CON), 4
#define T6OUTPS2                       BANKMASK(T6CON), 5
#define T6OUTPS3                       BANKMASK(T6CON), 6
#ifndef _LIB_BUILD
#endif
LCDCON                                 equ 0791h
#define LMUX0                          BANKMASK(LCDCON), 0
#define LMUX1                          BANKMASK(LCDCON), 1
#define CS0                            BANKMASK(LCDCON), 2
#define CS1                            BANKMASK(LCDCON), 3
#define WERR                           BANKMASK(LCDCON), 5
#define SLPEN                          BANKMASK(LCDCON), 6
#define LCDEN                          BANKMASK(LCDCON), 7
#ifndef _LIB_BUILD
#endif
LCDPS                                  equ 0792h
#define LP0                            BANKMASK(LCDPS), 0
#define LP1                            BANKMASK(LCDPS), 1
#define LP2                            BANKMASK(LCDPS), 2
#define LP3                            BANKMASK(LCDPS), 3
#define WA                             BANKMASK(LCDPS), 4
#define LCDA                           BANKMASK(LCDPS), 5
#define BIASMD                         BANKMASK(LCDPS), 6
#define WFT                            BANKMASK(LCDPS), 7
#ifndef _LIB_BUILD
#endif
LCDREF                                 equ 0793h
#define VLCD1PE                        BANKMASK(LCDREF), 1
#define VLCD2PE                        BANKMASK(LCDREF), 2
#define VLCD3PE                        BANKMASK(LCDREF), 3
#define LCDIRI                         BANKMASK(LCDREF), 5
#define LCDIRS                         BANKMASK(LCDREF), 6
#define LCDIRE                         BANKMASK(LCDREF), 7
#ifndef _LIB_BUILD
#endif
LCDCST                                 equ 0794h
#define LCDCST0                        BANKMASK(LCDCST), 0
#define LCDCST1                        BANKMASK(LCDCST), 1
#define LCDCST2                        BANKMASK(LCDCST), 2
#ifndef _LIB_BUILD
#endif
LCDRL                                  equ 0795h
#define LRLAT0                         BANKMASK(LCDRL), 0
#define LRLAT1                         BANKMASK(LCDRL), 1
#define LRLAT2                         BANKMASK(LCDRL), 2
#define LRLBP0                         BANKMASK(LCDRL), 4
#define LRLBP1                         BANKMASK(LCDRL), 5
#define LRLAP0                         BANKMASK(LCDRL), 6
#define LRLAP1                         BANKMASK(LCDRL), 7
#ifndef _LIB_BUILD
#endif
LCDSE0                                 equ 0798h
#define SE0                            BANKMASK(LCDSE0), 0
#define SE1                            BANKMASK(LCDSE0), 1
#define SE2                            BANKMASK(LCDSE0), 2
#define SE3                            BANKMASK(LCDSE0), 3
#define SE4                            BANKMASK(LCDSE0), 4
#define SE5                            BANKMASK(LCDSE0), 5
#define SE6                            BANKMASK(LCDSE0), 6
#define SE7                            BANKMASK(LCDSE0), 7
#ifndef _LIB_BUILD
#endif
LCDSE1                                 equ 0799h
#define SE8                            BANKMASK(LCDSE1), 0
#define SE9                            BANKMASK(LCDSE1), 1
#define SE10                           BANKMASK(LCDSE1), 2
#define SE11                           BANKMASK(LCDSE1), 3
#define SE12                           BANKMASK(LCDSE1), 4
#define SE13                           BANKMASK(LCDSE1), 5
#define SE14                           BANKMASK(LCDSE1), 6
#define SE15                           BANKMASK(LCDSE1), 7
#ifndef _LIB_BUILD
#endif
LCDSE2                                 equ 079Ah
#define SE16                           BANKMASK(LCDSE2), 0
#define SE17                           BANKMASK(LCDSE2), 1
#define SE18                           BANKMASK(LCDSE2), 2
#define SE19                           BANKMASK(LCDSE2), 3
#define SE20                           BANKMASK(LCDSE2), 4
#define SE21                           BANKMASK(LCDSE2), 5
#define SE22                           BANKMASK(LCDSE2), 6
#define SE23                           BANKMASK(LCDSE2), 7
#ifndef _LIB_BUILD
#endif
LCDDATA0                               equ 07A0h
#define SEG0COM0                       BANKMASK(LCDDATA0), 0
#define SEG1COM0                       BANKMASK(LCDDATA0), 1
#define SEG2COM0                       BANKMASK(LCDDATA0), 2
#define SEG3COM0                       BANKMASK(LCDDATA0), 3
#define SEG4COM0                       BANKMASK(LCDDATA0), 4
#define SEG5COM0                       BANKMASK(LCDDATA0), 5
#define SEG6COM0                       BANKMASK(LCDDATA0), 6
#define SEG7COM0                       BANKMASK(LCDDATA0), 7
#ifndef _LIB_BUILD
#endif
LCDDATA1                               equ 07A1h
#define SEG8COM0                       BANKMASK(LCDDATA1), 0
#define SEG9COM0                       BANKMASK(LCDDATA1), 1
#define SEG10COM0                      BANKMASK(LCDDATA1), 2
#define SEG11COM0                      BANKMASK(LCDDATA1), 3
#define SEG12COM0                      BANKMASK(LCDDATA1), 4
#define SEG13COM0                      BANKMASK(LCDDATA1), 5
#define SEG14COM0                      BANKMASK(LCDDATA1), 6
#define SEG15COM0                      BANKMASK(LCDDATA1), 7
#ifndef _LIB_BUILD
#endif
LCDDATA2                               equ 07A2h
#define SEG16COM0                      BANKMASK(LCDDATA2), 0
#define SEG17COM0                      BANKMASK(LCDDATA2), 1
#define SEG18COM0                      BANKMASK(LCDDATA2), 2
#define SEG19COM0                      BANKMASK(LCDDATA2), 3
#define SEG20COM0                      BANKMASK(LCDDATA2), 4
#define SEG21COM0                      BANKMASK(LCDDATA2), 5
#define SEG22COM0                      BANKMASK(LCDDATA2), 6
#define SEG23COM0                      BANKMASK(LCDDATA2), 7
#ifndef _LIB_BUILD
#endif
LCDDATA3                               equ 07A3h
#define SEG0COM1                       BANKMASK(LCDDATA3), 0
#define SEG1COM1                       BANKMASK(LCDDATA3), 1
#define SEG2COM1                       BANKMASK(LCDDATA3), 2
#define SEG3COM1                       BANKMASK(LCDDATA3), 3
#define SEG4COM1                       BANKMASK(LCDDATA3), 4
#define SEG5COM1                       BANKMASK(LCDDATA3), 5
#define SEG6COM1                       BANKMASK(LCDDATA3), 6
#define SEG7COM1                       BANKMASK(LCDDATA3), 7
#ifndef _LIB_BUILD
#endif
LCDDATA4                               equ 07A4h
#define SEG8COM1                       BANKMASK(LCDDATA4), 0
#define SEG9COM1                       BANKMASK(LCDDATA4), 1
#define SEG10COM1                      BANKMASK(LCDDATA4), 2
#define SEG11COM1                      BANKMASK(LCDDATA4), 3
#define SEG12COM1                      BANKMASK(LCDDATA4), 4
#define SEG13COM1                      BANKMASK(LCDDATA4), 5
#define SEG14COM1                      BANKMASK(LCDDATA4), 6
#define SEG15COM1                      BANKMASK(LCDDATA4), 7
#ifndef _LIB_BUILD
#endif
LCDDATA5                               equ 07A5h
#define SEG16COM1                      BANKMASK(LCDDATA5), 0
#define SEG17COM1                      BANKMASK(LCDDATA5), 1
#define SEG18COM1                      BANKMASK(LCDDATA5), 2
#define SEG19COM1                      BANKMASK(LCDDATA5), 3
#define SEG20COM1                      BANKMASK(LCDDATA5), 4
#define SEG21COM1                      BANKMASK(LCDDATA5), 5
#define SEG22COM1                      BANKMASK(LCDDATA5), 6
#define SEG23COM1                      BANKMASK(LCDDATA5), 7
#ifndef _LIB_BUILD
#endif
LCDDATA6                               equ 07A6h
#define SEG0COM2                       BANKMASK(LCDDATA6), 0
#define SEG1COM2                       BANKMASK(LCDDATA6), 1
#define SEG2COM2                       BANKMASK(LCDDATA6), 2
#define SEG3COM2                       BANKMASK(LCDDATA6), 3
#define SEG4COM2                       BANKMASK(LCDDATA6), 4
#define SEG5COM2                       BANKMASK(LCDDATA6), 5
#define SEG6COM2                       BANKMASK(LCDDATA6), 6
#define SEG7COM2                       BANKMASK(LCDDATA6), 7
#ifndef _LIB_BUILD
#endif
LCDDATA7                               equ 07A7h
#define SEG8COM2                       BANKMASK(LCDDATA7), 0
#define SEG9COM2                       BANKMASK(LCDDATA7), 1
#define SEG10COM2                      BANKMASK(LCDDATA7), 2
#define SEG11COM2                      BANKMASK(LCDDATA7), 3
#define SEG12COM2                      BANKMASK(LCDDATA7), 4
#define SEG13COM2                      BANKMASK(LCDDATA7), 5
#define SEG14COM2                      BANKMASK(LCDDATA7), 6
#define SEG15COM2                      BANKMASK(LCDDATA7), 7
#ifndef _LIB_BUILD
#endif
LCDDATA8                               equ 07A8h
#define SEG16COM2                      BANKMASK(LCDDATA8), 0
#define SEG17COM2                      BANKMASK(LCDDATA8), 1
#define SEG18COM2                      BANKMASK(LCDDATA8), 2
#define SEG19COM2                      BANKMASK(LCDDATA8), 3
#define SEG20COM2                      BANKMASK(LCDDATA8), 4
#define SEG21COM2                      BANKMASK(LCDDATA8), 5
#define SEG22COM2                      BANKMASK(LCDDATA8), 6
#define SEG23COM2                      BANKMASK(LCDDATA8), 7
#ifndef _LIB_BUILD
#endif
LCDDATA9                               equ 07A9h
#define SEG0COM3                       BANKMASK(LCDDATA9), 0
#define SEG1COM3                       BANKMASK(LCDDATA9), 1
#define SEG2COM3                       BANKMASK(LCDDATA9), 2
#define SEG3COM3                       BANKMASK(LCDDATA9), 3
#define SEG4COM3                       BANKMASK(LCDDATA9), 4
#define SEG5COM3                       BANKMASK(LCDDATA9), 5
#define SEG6COM3                       BANKMASK(LCDDATA9), 6
#define SEG7COM3                       BANKMASK(LCDDATA9), 7
#ifndef _LIB_BUILD
#endif
LCDDATA10                              equ 07AAh
#define SEG8COM3                       BANKMASK(LCDDATA10), 0
#define SEG9COM3                       BANKMASK(LCDDATA10), 1
#define SEG10COM3                      BANKMASK(LCDDATA10), 2
#define SEG11COM3                      BANKMASK(LCDDATA10), 3
#define SEG12COM3                      BANKMASK(LCDDATA10), 4
#define SEG13COM3                      BANKMASK(LCDDATA10), 5
#define SEG14COM3                      BANKMASK(LCDDATA10), 6
#define SEG15COM3                      BANKMASK(LCDDATA10), 7
#ifndef _LIB_BUILD
#endif
LCDDATA11                              equ 07ABh
#define SEG16COM3                      BANKMASK(LCDDATA11), 0
#define SEG17COM3                      BANKMASK(LCDDATA11), 1
#define SEG18COM3                      BANKMASK(LCDDATA11), 2
#define SEG19COM3                      BANKMASK(LCDDATA11), 3
#define SEG20COM3                      BANKMASK(LCDDATA11), 4
#define SEG21COM3                      BANKMASK(LCDDATA11), 5
#define SEG22COM3                      BANKMASK(LCDDATA11), 6
#define SEG23COM3                      BANKMASK(LCDDATA11), 7
#ifndef _LIB_BUILD
#endif
STATUS_SHAD                            equ 0FE4h
#define C_SHAD                         BANKMASK(STATUS_SHAD), 0
#define DC_SHAD                        BANKMASK(STATUS_SHAD), 1
#define Z_SHAD                         BANKMASK(STATUS_SHAD), 2
#ifndef _LIB_BUILD
#endif
WREG_SHAD                              equ 0FE5h
BSR_SHAD                               equ 0FE6h
#ifndef _LIB_BUILD
#endif
PCLATH_SHAD                            equ 0FE7h
#ifndef _LIB_BUILD
#endif
FSR0L_SHAD                             equ 0FE8h
FSR0H_SHAD                             equ 0FE9h
FSR1L_SHAD                             equ 0FEAh
FSR1H_SHAD                             equ 0FEBh
STKPTR                                 equ 0FEDh
#ifndef _LIB_BUILD
#endif
TOSL                                   equ 0FEEh
TOSH                                   equ 0FEFh
#ifndef _LIB_BUILD
#endif

#endif
#endif

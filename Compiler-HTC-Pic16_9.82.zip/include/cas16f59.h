#ifndef _CASPIC_H_
#warning Header file cas16f59.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS16F59_H_
#define _CAS16F59_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define PA0_bit                        BANKMASK(STATUS), 5
#define PA1_bit                        BANKMASK(STATUS), 6
#define PA2_bit                        BANKMASK(STATUS), 7
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define RA0_bit                        BANKMASK(PORTA), 0
#define RA1_bit                        BANKMASK(PORTA), 1
#define RA2_bit                        BANKMASK(PORTA), 2
#define RA3_bit                        BANKMASK(PORTA), 3
#define T0CKI_bit                      BANKMASK(PORTA), 4
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 0006h
#define RB0_bit                        BANKMASK(PORTB), 0
#define RB1_bit                        BANKMASK(PORTB), 1
#define RB2_bit                        BANKMASK(PORTB), 2
#define RB3_bit                        BANKMASK(PORTB), 3
#define RB4_bit                        BANKMASK(PORTB), 4
#define RB5_bit                        BANKMASK(PORTB), 5
#define RB6_bit                        BANKMASK(PORTB), 6
#define RB7_bit                        BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 0007h
#define RC0_bit                        BANKMASK(PORTC), 0
#define RC1_bit                        BANKMASK(PORTC), 1
#define RC2_bit                        BANKMASK(PORTC), 2
#define RC3_bit                        BANKMASK(PORTC), 3
#define RC4_bit                        BANKMASK(PORTC), 4
#define RC5_bit                        BANKMASK(PORTC), 5
#define RC6_bit                        BANKMASK(PORTC), 6
#define RC7_bit                        BANKMASK(PORTC), 7
#ifndef _LIB_BUILD
#endif
PORTD                                  equ 0008h
#define RD0_bit                        BANKMASK(PORTD), 0
#define RD1_bit                        BANKMASK(PORTD), 1
#define RD2_bit                        BANKMASK(PORTD), 2
#define RD3_bit                        BANKMASK(PORTD), 3
#define RD4_bit                        BANKMASK(PORTD), 4
#define RD5_bit                        BANKMASK(PORTD), 5
#define RD6_bit                        BANKMASK(PORTD), 6
#define RD7_bit                        BANKMASK(PORTD), 7
#ifndef _LIB_BUILD
#endif
PORTE                                  equ 0009h
#define RE4_bit                        BANKMASK(PORTE), 4
#define RE5_bit                        BANKMASK(PORTE), 5
#define RE6_bit                        BANKMASK(PORTE), 6
#define RE7_bit                        BANKMASK(PORTE), 7
#ifndef _LIB_BUILD
#endif

#endif
#endif

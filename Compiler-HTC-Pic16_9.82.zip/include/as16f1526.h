#ifndef _ASPIC_H_
#warning Header file as16f1526.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS16F1526_H_
#define _AS16F1526_H_

INDF0                                  equ 0000h
INDF1                                  equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#ifndef _LIB_BUILD
#endif
FSR0L                                  equ 0004h
FSR0H                                  equ 0005h
FSR1L                                  equ 0006h
FSR1H                                  equ 0007h
BSR                                    equ 0008h
#define BSR0                           BANKMASK(BSR), 0
#define BSR1                           BANKMASK(BSR), 1
#define BSR2                           BANKMASK(BSR), 2
#define BSR3                           BANKMASK(BSR), 3
#define BSR4                           BANKMASK(BSR), 4
#ifndef _LIB_BUILD
#endif
WREG                                   equ 0009h
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define IOCIF                          BANKMASK(INTCON), 0
#define INTF                           BANKMASK(INTCON), 1
#define TMR0IF                         BANKMASK(INTCON), 2
#define IOCIE                          BANKMASK(INTCON), 3
#define INTE                           BANKMASK(INTCON), 4
#define TMR0IE                         BANKMASK(INTCON), 5
#define PEIE                           BANKMASK(INTCON), 6
#define GIE                            BANKMASK(INTCON), 7
#define T0IF                           BANKMASK(INTCON), 2
#define T0IE                           BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PORTA                                  equ 000Ch
#define RA0                            BANKMASK(PORTA), 0
#define RA1                            BANKMASK(PORTA), 1
#define RA2                            BANKMASK(PORTA), 2
#define RA3                            BANKMASK(PORTA), 3
#define RA4                            BANKMASK(PORTA), 4
#define RA5                            BANKMASK(PORTA), 5
#define RA6                            BANKMASK(PORTA), 6
#define RA7                            BANKMASK(PORTA), 7
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 000Dh
#define RB0                            BANKMASK(PORTB), 0
#define RB1                            BANKMASK(PORTB), 1
#define RB2                            BANKMASK(PORTB), 2
#define RB3                            BANKMASK(PORTB), 3
#define RB4                            BANKMASK(PORTB), 4
#define RB5                            BANKMASK(PORTB), 5
#define RB6                            BANKMASK(PORTB), 6
#define RB7                            BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 000Eh
#define RC0                            BANKMASK(PORTC), 0
#define RC1                            BANKMASK(PORTC), 1
#define RC2                            BANKMASK(PORTC), 2
#define RC3                            BANKMASK(PORTC), 3
#define RC4                            BANKMASK(PORTC), 4
#define RC5                            BANKMASK(PORTC), 5
#define RC6                            BANKMASK(PORTC), 6
#define RC7                            BANKMASK(PORTC), 7
#ifndef _LIB_BUILD
#endif
PORTD                                  equ 000Fh
#define RD0                            BANKMASK(PORTD), 0
#define RD1                            BANKMASK(PORTD), 1
#define RD2                            BANKMASK(PORTD), 2
#define RD3                            BANKMASK(PORTD), 3
#define RD4                            BANKMASK(PORTD), 4
#define RD5                            BANKMASK(PORTD), 5
#define RD6                            BANKMASK(PORTD), 6
#define RD7                            BANKMASK(PORTD), 7
#ifndef _LIB_BUILD
#endif
PORTE                                  equ 0010h
#define RE0                            BANKMASK(PORTE), 0
#define RE1                            BANKMASK(PORTE), 1
#define RE2                            BANKMASK(PORTE), 2
#define RE3                            BANKMASK(PORTE), 3
#define RE4                            BANKMASK(PORTE), 4
#define RE5                            BANKMASK(PORTE), 5
#define RE6                            BANKMASK(PORTE), 6
#define RE7                            BANKMASK(PORTE), 7
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 0011h
#define TMR1IF                         BANKMASK(PIR1), 0
#define TMR2IF                         BANKMASK(PIR1), 1
#define CCP1IF                         BANKMASK(PIR1), 2
#define SSP1IF                         BANKMASK(PIR1), 3
#define TX1IF                          BANKMASK(PIR1), 4
#define RC1IF                          BANKMASK(PIR1), 5
#define ADIF                           BANKMASK(PIR1), 6
#define TMR1GIF                        BANKMASK(PIR1), 7
#define SSPIF                          BANKMASK(PIR1), 3
#define TXIF                           BANKMASK(PIR1), 4
#define RCIF                           BANKMASK(PIR1), 5
#ifndef _LIB_BUILD
#endif
PIR2                                   equ 0012h
#define CCP2IF                         BANKMASK(PIR2), 0
#define TMR8IF                         BANKMASK(PIR2), 1
#define TMR10IF                        BANKMASK(PIR2), 2
#define BCL1IF                         BANKMASK(PIR2), 3
#define TMR3GIF                        BANKMASK(PIR2), 5
#define TMR5GIF                        BANKMASK(PIR2), 6
#define OSFIF                          BANKMASK(PIR2), 7
#define BCLIF                          BANKMASK(PIR2), 3
#ifndef _LIB_BUILD
#endif
PIR3                                   equ 0013h
#define TMR3IF                         BANKMASK(PIR3), 0
#define TMR4IF                         BANKMASK(PIR3), 1
#define TMR5IF                         BANKMASK(PIR3), 2
#define TMR6IF                         BANKMASK(PIR3), 3
#define CCP3IF                         BANKMASK(PIR3), 4
#define CCP4IF                         BANKMASK(PIR3), 5
#define CCP5IF                         BANKMASK(PIR3), 6
#define CCP6IF                         BANKMASK(PIR3), 7
#ifndef _LIB_BUILD
#endif
PIR4                                   equ 0014h
#define SSP2IF                         BANKMASK(PIR4), 0
#define BCL2IF                         BANKMASK(PIR4), 1
#define CCP7IF                         BANKMASK(PIR4), 2
#define CCP8IF                         BANKMASK(PIR4), 3
#define TX2IF                          BANKMASK(PIR4), 4
#define RC2IF                          BANKMASK(PIR4), 5
#define CCP9IF                         BANKMASK(PIR4), 6
#define CCP10IF                        BANKMASK(PIR4), 7
#ifndef _LIB_BUILD
#endif
TMR0                                   equ 0015h
TMR1L                                  equ 0016h
TMR1H                                  equ 0017h
T1CON                                  equ 0018h
#define TMR1ON                         BANKMASK(T1CON), 0
#define nT1SYNC                        BANKMASK(T1CON), 2
#define T1OSCEN                        BANKMASK(T1CON), 3
#define T1CKPS0                        BANKMASK(T1CON), 4
#define T1CKPS1                        BANKMASK(T1CON), 5
#define TMR1CS0                        BANKMASK(T1CON), 6
#define TMR1CS1                        BANKMASK(T1CON), 7
#ifndef _LIB_BUILD
#endif
T1GCON                                 equ 0019h
#define T1GVAL                         BANKMASK(T1GCON), 2
#define T1GGO_nDONE                    BANKMASK(T1GCON), 3
#define T1GSPM                         BANKMASK(T1GCON), 4
#define T1GTM                          BANKMASK(T1GCON), 5
#define T1GPOL                         BANKMASK(T1GCON), 6
#define TMR1GE                         BANKMASK(T1GCON), 7
#define T1GSS0                         BANKMASK(T1GCON), 0
#define T1GSS1                         BANKMASK(T1GCON), 1
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 001Ah
PR2                                    equ 001Bh
T2CON                                  equ 001Ch
#define TMR2ON                         BANKMASK(T2CON), 2
#define T2CKPS0                        BANKMASK(T2CON), 0
#define T2CKPS1                        BANKMASK(T2CON), 1
#define T2OUTPS0                       BANKMASK(T2CON), 3
#define T2OUTPS1                       BANKMASK(T2CON), 4
#define T2OUTPS2                       BANKMASK(T2CON), 5
#define T2OUTPS3                       BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 008Ch
#define TRISA0                         BANKMASK(TRISA), 0
#define TRISA1                         BANKMASK(TRISA), 1
#define TRISA2                         BANKMASK(TRISA), 2
#define TRISA3                         BANKMASK(TRISA), 3
#define TRISA4                         BANKMASK(TRISA), 4
#define TRISA5                         BANKMASK(TRISA), 5
#define TRISA6                         BANKMASK(TRISA), 6
#define TRISA7                         BANKMASK(TRISA), 7
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 008Dh
#define TRISB0                         BANKMASK(TRISB), 0
#define TRISB1                         BANKMASK(TRISB), 1
#define TRISB2                         BANKMASK(TRISB), 2
#define TRISB3                         BANKMASK(TRISB), 3
#define TRISB4                         BANKMASK(TRISB), 4
#define TRISB5                         BANKMASK(TRISB), 5
#define TRISB6                         BANKMASK(TRISB), 6
#define TRISB7                         BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
TRISC                                  equ 008Eh
#define TRISC0                         BANKMASK(TRISC), 0
#define TRISC1                         BANKMASK(TRISC), 1
#define TRISC2                         BANKMASK(TRISC), 2
#define TRISC3                         BANKMASK(TRISC), 3
#define TRISC4                         BANKMASK(TRISC), 4
#define TRISC5                         BANKMASK(TRISC), 5
#define TRISC6                         BANKMASK(TRISC), 6
#define TRISC7                         BANKMASK(TRISC), 7
#ifndef _LIB_BUILD
#endif
TRISD                                  equ 008Fh
#define TRISD0                         BANKMASK(TRISD), 0
#define TRISD1                         BANKMASK(TRISD), 1
#define TRISD2                         BANKMASK(TRISD), 2
#define TRISD3                         BANKMASK(TRISD), 3
#define TRISD4                         BANKMASK(TRISD), 4
#define TRISD5                         BANKMASK(TRISD), 5
#define TRISD6                         BANKMASK(TRISD), 6
#define TRISD7                         BANKMASK(TRISD), 7
#ifndef _LIB_BUILD
#endif
TRISE                                  equ 0090h
#define TRISE0                         BANKMASK(TRISE), 0
#define TRISE1                         BANKMASK(TRISE), 1
#define TRISE2                         BANKMASK(TRISE), 2
#define TRISE3                         BANKMASK(TRISE), 3
#define TRISE4                         BANKMASK(TRISE), 4
#define TRISE5                         BANKMASK(TRISE), 5
#define TRISE6                         BANKMASK(TRISE), 6
#define TRISE7                         BANKMASK(TRISE), 7
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 0091h
#define TMR1IE                         BANKMASK(PIE1), 0
#define TMR2IE                         BANKMASK(PIE1), 1
#define CCP1IE                         BANKMASK(PIE1), 2
#define SSP1IE                         BANKMASK(PIE1), 3
#define TX1IE                          BANKMASK(PIE1), 4
#define RC1IE                          BANKMASK(PIE1), 5
#define ADIE                           BANKMASK(PIE1), 6
#define TMR1GIE                        BANKMASK(PIE1), 7
#define SSPIE                          BANKMASK(PIE1), 3
#define TXIE                           BANKMASK(PIE1), 4
#define RCIE                           BANKMASK(PIE1), 5
#ifndef _LIB_BUILD
#endif
PIE2                                   equ 0092h
#define CCP2IE                         BANKMASK(PIE2), 0
#define TMR8IE                         BANKMASK(PIE2), 1
#define TMR10IE                        BANKMASK(PIE2), 2
#define BCL1IE                         BANKMASK(PIE2), 3
#define TMR3GIE                        BANKMASK(PIE2), 5
#define TMR5GIE                        BANKMASK(PIE2), 6
#define OSFIE                          BANKMASK(PIE2), 7
#define BCLIE                          BANKMASK(PIE2), 3
#ifndef _LIB_BUILD
#endif
PIE3                                   equ 0093h
#define TMR3IE                         BANKMASK(PIE3), 0
#define TMR4IE                         BANKMASK(PIE3), 1
#define TMR5IE                         BANKMASK(PIE3), 2
#define TMR6IE                         BANKMASK(PIE3), 3
#define CCP3IE                         BANKMASK(PIE3), 4
#define CCP4IE                         BANKMASK(PIE3), 5
#define CCP5IE                         BANKMASK(PIE3), 6
#define CCP6IE                         BANKMASK(PIE3), 7
#ifndef _LIB_BUILD
#endif
PIE4                                   equ 0094h
#define SSP2IE                         BANKMASK(PIE4), 0
#define BCL2IE                         BANKMASK(PIE4), 1
#define CCP7IE                         BANKMASK(PIE4), 2
#define CCP8IE                         BANKMASK(PIE4), 3
#define TX2IE                          BANKMASK(PIE4), 4
#define RC2IE                          BANKMASK(PIE4), 5
#define CCP9IE                         BANKMASK(PIE4), 6
#define CCP10IE                        BANKMASK(PIE4), 7
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0095h
#define PSA                            BANKMASK(OPTION_REG), 3
#define TMR0SE                         BANKMASK(OPTION_REG), 4
#define TMR0CS                         BANKMASK(OPTION_REG), 5
#define INTEDG                         BANKMASK(OPTION_REG), 6
#define nWPUEN                         BANKMASK(OPTION_REG), 7
#define PS0                            BANKMASK(OPTION_REG), 0
#define PS1                            BANKMASK(OPTION_REG), 1
#define PS2                            BANKMASK(OPTION_REG), 2
#define T0SE                           BANKMASK(OPTION_REG), 4
#define T0CS                           BANKMASK(OPTION_REG), 5
#ifndef _LIB_BUILD
#endif
PCON                                   equ 0096h
#define nBOR                           BANKMASK(PCON), 0
#define nPOR                           BANKMASK(PCON), 1
#define nRI                            BANKMASK(PCON), 2
#define nRMCLR                         BANKMASK(PCON), 3
#define nRWDT                          BANKMASK(PCON), 4
#define STKUNF                         BANKMASK(PCON), 6
#define STKOVF                         BANKMASK(PCON), 7
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0097h
#define SWDTEN                         BANKMASK(WDTCON), 0
#define WDTPS0                         BANKMASK(WDTCON), 1
#define WDTPS1                         BANKMASK(WDTCON), 2
#define WDTPS2                         BANKMASK(WDTCON), 3
#define WDTPS3                         BANKMASK(WDTCON), 4
#define WDTPS4                         BANKMASK(WDTCON), 5
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 0099h
#define SCS0                           BANKMASK(OSCCON), 0
#define SCS1                           BANKMASK(OSCCON), 1
#define IRCF0                          BANKMASK(OSCCON), 3
#define IRCF1                          BANKMASK(OSCCON), 4
#define IRCF2                          BANKMASK(OSCCON), 5
#define IRCF3                          BANKMASK(OSCCON), 6
#ifndef _LIB_BUILD
#endif
OSCSTAT                                equ 009Ah
#define HFIOFS                         BANKMASK(OSCSTAT), 0
#define LFIOFR                         BANKMASK(OSCSTAT), 1
#define HFIOFR                         BANKMASK(OSCSTAT), 4
#define OSTS                           BANKMASK(OSCSTAT), 5
#define SOSCR                          BANKMASK(OSCSTAT), 7
#define T1OSCR                         BANKMASK(OSCSTAT), 7
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 009Bh
ADRESH                                 equ 009Ch
ADCON0                                 equ 009Dh
#define ADON                           BANKMASK(ADCON0), 0
#define GO_nDONE                       BANKMASK(ADCON0), 1
#define ADGO                           BANKMASK(ADCON0), 1
#define CHS0                           BANKMASK(ADCON0), 2
#define CHS1                           BANKMASK(ADCON0), 3
#define CHS2                           BANKMASK(ADCON0), 4
#define CHS3                           BANKMASK(ADCON0), 5
#define CHS4                           BANKMASK(ADCON0), 6
#define GO                             BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 009Eh
#define ADFM                           BANKMASK(ADCON1), 7
#define ADPREF0                        BANKMASK(ADCON1), 0
#define ADPREF1                        BANKMASK(ADCON1), 1
#define ADCS0                          BANKMASK(ADCON1), 4
#define ADCS1                          BANKMASK(ADCON1), 5
#define ADCS2                          BANKMASK(ADCON1), 6
#ifndef _LIB_BUILD
#endif
LATA                                   equ 010Ch
#define LATA0                          BANKMASK(LATA), 0
#define LATA1                          BANKMASK(LATA), 1
#define LATA2                          BANKMASK(LATA), 2
#define LATA3                          BANKMASK(LATA), 3
#define LATA4                          BANKMASK(LATA), 4
#define LATA5                          BANKMASK(LATA), 5
#define LATA6                          BANKMASK(LATA), 6
#define LATA7                          BANKMASK(LATA), 7
#ifndef _LIB_BUILD
#endif
LATB                                   equ 010Dh
#define LATB0                          BANKMASK(LATB), 0
#define LATB1                          BANKMASK(LATB), 1
#define LATB2                          BANKMASK(LATB), 2
#define LATB3                          BANKMASK(LATB), 3
#define LATB4                          BANKMASK(LATB), 4
#define LATB5                          BANKMASK(LATB), 5
#define LATB6                          BANKMASK(LATB), 6
#define LATB7                          BANKMASK(LATB), 7
#ifndef _LIB_BUILD
#endif
LATC                                   equ 010Eh
#define LATC0                          BANKMASK(LATC), 0
#define LATC1                          BANKMASK(LATC), 1
#define LATC2                          BANKMASK(LATC), 2
#define LATC3                          BANKMASK(LATC), 3
#define LATC4                          BANKMASK(LATC), 4
#define LATC5                          BANKMASK(LATC), 5
#define LATC6                          BANKMASK(LATC), 6
#define LATC7                          BANKMASK(LATC), 7
#ifndef _LIB_BUILD
#endif
LATD                                   equ 010Fh
#define LATD0                          BANKMASK(LATD), 0
#define LATD1                          BANKMASK(LATD), 1
#define LATD2                          BANKMASK(LATD), 2
#define LATD3                          BANKMASK(LATD), 3
#define LATD4                          BANKMASK(LATD), 4
#define LATD5                          BANKMASK(LATD), 5
#define LATD6                          BANKMASK(LATD), 6
#define LATD7                          BANKMASK(LATD), 7
#ifndef _LIB_BUILD
#endif
LATE                                   equ 0110h
#define LATE0                          BANKMASK(LATE), 0
#define LATE1                          BANKMASK(LATE), 1
#define LATE2                          BANKMASK(LATE), 2
#define LATE3                          BANKMASK(LATE), 3
#define LATE4                          BANKMASK(LATE), 4
#define LATE5                          BANKMASK(LATE), 5
#define LATE6                          BANKMASK(LATE), 6
#define LATE7                          BANKMASK(LATE), 7
#ifndef _LIB_BUILD
#endif
BORCON                                 equ 0116h
#define BORRDY                         BANKMASK(BORCON), 0
#define BORFS                          BANKMASK(BORCON), 6
#define SBOREN                         BANKMASK(BORCON), 7
#ifndef _LIB_BUILD
#endif
FVRCON                                 equ 0117h
#define TSRNG                          BANKMASK(FVRCON), 4
#define TSEN                           BANKMASK(FVRCON), 5
#define FVRRDY                         BANKMASK(FVRCON), 6
#define FVREN                          BANKMASK(FVRCON), 7
#define ADFVR0                         BANKMASK(FVRCON), 0
#define ADFVR1                         BANKMASK(FVRCON), 1
#ifndef _LIB_BUILD
#endif
APFCON                                 equ 011Dh
#define CCP2SEL                        BANKMASK(APFCON), 0
#define T3CKISEL                       BANKMASK(APFCON), 1
#ifndef _LIB_BUILD
#endif
ANSELA                                 equ 018Ch
#define ANSA0                          BANKMASK(ANSELA), 0
#define ANSA1                          BANKMASK(ANSELA), 1
#define ANSA2                          BANKMASK(ANSELA), 2
#define ANSA3                          BANKMASK(ANSELA), 3
#define ANSA5                          BANKMASK(ANSELA), 5
#ifndef _LIB_BUILD
#endif
ANSELB                                 equ 018Dh
#define ANSB0                          BANKMASK(ANSELB), 0
#define ANSB1                          BANKMASK(ANSELB), 1
#define ANSB2                          BANKMASK(ANSELB), 2
#define ANSB3                          BANKMASK(ANSELB), 3
#define ANSB4                          BANKMASK(ANSELB), 4
#define ANSB5                          BANKMASK(ANSELB), 5
#ifndef _LIB_BUILD
#endif
ANSELD                                 equ 018Fh
#define ANSD0                          BANKMASK(ANSELD), 0
#define ANSD1                          BANKMASK(ANSELD), 1
#define ANSD2                          BANKMASK(ANSELD), 2
#define ANSD3                          BANKMASK(ANSELD), 3
#ifndef _LIB_BUILD
#endif
ANSELE                                 equ 0190h
#define ANSE0                          BANKMASK(ANSELE), 0
#define ANSE1                          BANKMASK(ANSELE), 1
#define ANSE2                          BANKMASK(ANSELE), 2
#ifndef _LIB_BUILD
#endif
PMADRL                                 equ 0191h
PMADRH                                 equ 0192h
#ifndef _LIB_BUILD
#endif
PMDATL                                 equ 0193h
PMDATH                                 equ 0194h
#ifndef _LIB_BUILD
#endif
PMCON1                                 equ 0195h
#define RD                             BANKMASK(PMCON1), 0
#define WR                             BANKMASK(PMCON1), 1
#define WREN                           BANKMASK(PMCON1), 2
#define WRERR                          BANKMASK(PMCON1), 3
#define FREE                           BANKMASK(PMCON1), 4
#define LWLO                           BANKMASK(PMCON1), 5
#define CFGS                           BANKMASK(PMCON1), 6
#ifndef _LIB_BUILD
#endif
PMCON2                                 equ 0196h
VREGCON                                equ 0197h
#define VREGPM                         BANKMASK(VREGCON), 1
#ifndef _LIB_BUILD
#endif
RC1REG                                 equ 0199h
RCREG                                  equ 0199h
RCREG1                                 equ 0199h
TX1REG                                 equ 019Ah
TXREG                                  equ 019Ah
TXREG1                                 equ 019Ah
SP1BRGL                                equ 019Bh
SPBRG                                  equ 019Bh
SPBRGL                                 equ 019Bh
SPBRGL1                                equ 019Bh
SP1BRGH                                equ 019Ch
SPBRGH                                 equ 019Ch
SPBRGH1                                equ 019Ch
RC1STA                                 equ 019Dh
RCSTA                                  equ 019Dh
RCSTA1                                 equ 019Dh
#ifndef _LIB_BUILD
#endif
TX1STA                                 equ 019Eh
TXSTA                                  equ 019Eh
TXSTA1                                 equ 019Eh
#ifndef _LIB_BUILD
#endif
BAUD1CON                               equ 019Fh
BAUDCON                                equ 019Fh
BAUDCON1                               equ 019Fh
#ifndef _LIB_BUILD
#endif
WPUB                                   equ 020Dh
#define WPUB0                          BANKMASK(WPUB), 0
#define WPUB1                          BANKMASK(WPUB), 1
#define WPUB2                          BANKMASK(WPUB), 2
#define WPUB3                          BANKMASK(WPUB), 3
#define WPUB4                          BANKMASK(WPUB), 4
#define WPUB5                          BANKMASK(WPUB), 5
#define WPUB6                          BANKMASK(WPUB), 6
#define WPUB7                          BANKMASK(WPUB), 7
#ifndef _LIB_BUILD
#endif
WPUD                                   equ 020Fh
#define WPUD0                          BANKMASK(WPUD), 0
#define WPUD1                          BANKMASK(WPUD), 1
#define WPUD2                          BANKMASK(WPUD), 2
#define WPUD3                          BANKMASK(WPUD), 3
#define WPUD4                          BANKMASK(WPUD), 4
#define WPUD5                          BANKMASK(WPUD), 5
#define WPUD6                          BANKMASK(WPUD), 6
#define WPUD7                          BANKMASK(WPUD), 7
#ifndef _LIB_BUILD
#endif
WPUE                                   equ 0210h
#define WPUE0                          BANKMASK(WPUE), 0
#define WPUE1                          BANKMASK(WPUE), 1
#define WPUE2                          BANKMASK(WPUE), 2
#define WPUE3                          BANKMASK(WPUE), 3
#define WPUE4                          BANKMASK(WPUE), 4
#define WPUE5                          BANKMASK(WPUE), 5
#define WPUE6                          BANKMASK(WPUE), 6
#define WPUE7                          BANKMASK(WPUE), 7
#ifndef _LIB_BUILD
#endif
SSP1BUF                                equ 0211h
SSPBUF                                 equ 0211h
SSP1ADD                                equ 0212h
SSPADD                                 equ 0212h
SSP1MSK                                equ 0213h
SSPMSK                                 equ 0213h
SSP1STAT                               equ 0214h
SSPSTAT                                equ 0214h
#ifndef _LIB_BUILD
#endif
SSP1CON1                               equ 0215h
SSPCON                                 equ 0215h
SSPCON1                                equ 0215h
#ifndef _LIB_BUILD
#endif
SSP1CON2                               equ 0216h
SSPCON2                                equ 0216h
#ifndef _LIB_BUILD
#endif
SSP1CON3                               equ 0217h
SSPCON3                                equ 0217h
#ifndef _LIB_BUILD
#endif
SSP2BUF                                equ 0219h
SSP2ADD                                equ 021Ah
SSP2MSK                                equ 021Bh
SSP2STAT                               equ 021Ch
#ifndef _LIB_BUILD
#endif
SSP2CON1                               equ 021Dh
#ifndef _LIB_BUILD
#endif
SSP2CON2                               equ 021Eh
#ifndef _LIB_BUILD
#endif
SSP2CON3                               equ 021Fh
#ifndef _LIB_BUILD
#endif
PORTF                                  equ 028Ch
#define RF0                            BANKMASK(PORTF), 0
#define RF1                            BANKMASK(PORTF), 1
#define RF2                            BANKMASK(PORTF), 2
#define RF3                            BANKMASK(PORTF), 3
#define RF4                            BANKMASK(PORTF), 4
#define RF5                            BANKMASK(PORTF), 5
#define RF6                            BANKMASK(PORTF), 6
#define RF7                            BANKMASK(PORTF), 7
#ifndef _LIB_BUILD
#endif
PORTG                                  equ 028Dh
#define RG0                            BANKMASK(PORTG), 0
#define RG1                            BANKMASK(PORTG), 1
#define RG2                            BANKMASK(PORTG), 2
#define RG3                            BANKMASK(PORTG), 3
#define RG4                            BANKMASK(PORTG), 4
#define RG5                            BANKMASK(PORTG), 5
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0291h
CCPR1H                                 equ 0292h
CCP1CON                                equ 0293h
#define CCP1M0                         BANKMASK(CCP1CON), 0
#define CCP1M1                         BANKMASK(CCP1CON), 1
#define CCP1M2                         BANKMASK(CCP1CON), 2
#define CCP1M3                         BANKMASK(CCP1CON), 3
#define DC1B0                          BANKMASK(CCP1CON), 4
#define DC1B1                          BANKMASK(CCP1CON), 5
#ifndef _LIB_BUILD
#endif
CCPR2L                                 equ 0298h
CCPR2H                                 equ 0299h
CCP2CON                                equ 029Ah
#define CCP2M0                         BANKMASK(CCP2CON), 0
#define CCP2M1                         BANKMASK(CCP2CON), 1
#define CCP2M2                         BANKMASK(CCP2CON), 2
#define CCP2M3                         BANKMASK(CCP2CON), 3
#define DC2B0                          BANKMASK(CCP2CON), 4
#define DC2B1                          BANKMASK(CCP2CON), 5
#ifndef _LIB_BUILD
#endif
CCPTMRS0                               equ 029Dh
#define C1TSEL0                        BANKMASK(CCPTMRS0), 0
#define C1TSEL1                        BANKMASK(CCPTMRS0), 1
#define C2TSEL0                        BANKMASK(CCPTMRS0), 2
#define C2TSEL1                        BANKMASK(CCPTMRS0), 3
#define C3TSEL0                        BANKMASK(CCPTMRS0), 4
#define C3TSEL1                        BANKMASK(CCPTMRS0), 5
#define C4TSEL0                        BANKMASK(CCPTMRS0), 6
#define C4TSEL1                        BANKMASK(CCPTMRS0), 7
#ifndef _LIB_BUILD
#endif
CCPTMRS1                               equ 029Eh
#define C5TSEL0                        BANKMASK(CCPTMRS1), 0
#define C5TSEL1                        BANKMASK(CCPTMRS1), 1
#define C6TSEL0                        BANKMASK(CCPTMRS1), 2
#define C6TSEL1                        BANKMASK(CCPTMRS1), 3
#define C7TSEL0                        BANKMASK(CCPTMRS1), 4
#define C7TSEL1                        BANKMASK(CCPTMRS1), 5
#define C8TSEL0                        BANKMASK(CCPTMRS1), 6
#define C8TSEL1                        BANKMASK(CCPTMRS1), 7
#ifndef _LIB_BUILD
#endif
CCPTMRS2                               equ 029Fh
#define C9TSEL0                        BANKMASK(CCPTMRS2), 0
#define C9TSEL1                        BANKMASK(CCPTMRS2), 1
#define C10TSEL0                       BANKMASK(CCPTMRS2), 2
#define C10TSEL1                       BANKMASK(CCPTMRS2), 3
#ifndef _LIB_BUILD
#endif
TRISF                                  equ 030Ch
#define TRISF0                         BANKMASK(TRISF), 0
#define TRISF1                         BANKMASK(TRISF), 1
#define TRISF2                         BANKMASK(TRISF), 2
#define TRISF3                         BANKMASK(TRISF), 3
#define TRISF4                         BANKMASK(TRISF), 4
#define TRISF5                         BANKMASK(TRISF), 5
#define TRISF6                         BANKMASK(TRISF), 6
#define TRISF7                         BANKMASK(TRISF), 7
#ifndef _LIB_BUILD
#endif
TRISG                                  equ 030Dh
#define TRISG0                         BANKMASK(TRISG), 0
#define TRISG1                         BANKMASK(TRISG), 1
#define TRISG2                         BANKMASK(TRISG), 2
#define TRISG3                         BANKMASK(TRISG), 3
#define TRISG4                         BANKMASK(TRISG), 4
#ifndef _LIB_BUILD
#endif
CCPR3L                                 equ 0311h
CCPR3H                                 equ 0312h
CCP3CON                                equ 0313h
#define CCP3M0                         BANKMASK(CCP3CON), 0
#define CCP3M1                         BANKMASK(CCP3CON), 1
#define CCP3M2                         BANKMASK(CCP3CON), 2
#define CCP3M3                         BANKMASK(CCP3CON), 3
#define DC3B0                          BANKMASK(CCP3CON), 4
#define DC3B1                          BANKMASK(CCP3CON), 5
#ifndef _LIB_BUILD
#endif
CCPR4L                                 equ 0318h
CCPR4H                                 equ 0319h
CCP4CON                                equ 031Ah
#define CCP4M0                         BANKMASK(CCP4CON), 0
#define CCP4M1                         BANKMASK(CCP4CON), 1
#define CCP4M2                         BANKMASK(CCP4CON), 2
#define CCP4M3                         BANKMASK(CCP4CON), 3
#define DC4B0                          BANKMASK(CCP4CON), 4
#define DC4B1                          BANKMASK(CCP4CON), 5
#ifndef _LIB_BUILD
#endif
CCPR5L                                 equ 031Ch
CCPR5H                                 equ 031Dh
CCP5CON                                equ 031Eh
#define CCP5M0                         BANKMASK(CCP5CON), 0
#define CCP5M1                         BANKMASK(CCP5CON), 1
#define CCP5M2                         BANKMASK(CCP5CON), 2
#define CCP5M3                         BANKMASK(CCP5CON), 3
#define DC5B0                          BANKMASK(CCP5CON), 4
#define DC5B1                          BANKMASK(CCP5CON), 5
#ifndef _LIB_BUILD
#endif
LATF                                   equ 038Ch
#define LATF0                          BANKMASK(LATF), 0
#define LATF1                          BANKMASK(LATF), 1
#define LATF2                          BANKMASK(LATF), 2
#define LATF3                          BANKMASK(LATF), 3
#define LATF4                          BANKMASK(LATF), 4
#define LATF5                          BANKMASK(LATF), 5
#define LATF6                          BANKMASK(LATF), 6
#define LATF7                          BANKMASK(LATF), 7
#ifndef _LIB_BUILD
#endif
LATG                                   equ 038Dh
#define LATG0                          BANKMASK(LATG), 0
#define LATG1                          BANKMASK(LATG), 1
#define LATG2                          BANKMASK(LATG), 2
#define LATG3                          BANKMASK(LATG), 3
#define LATG4                          BANKMASK(LATG), 4
#ifndef _LIB_BUILD
#endif
IOCBP                                  equ 0394h
#define IOCBP0                         BANKMASK(IOCBP), 0
#define IOCBP1                         BANKMASK(IOCBP), 1
#define IOCBP2                         BANKMASK(IOCBP), 2
#define IOCBP3                         BANKMASK(IOCBP), 3
#define IOCBP4                         BANKMASK(IOCBP), 4
#define IOCBP5                         BANKMASK(IOCBP), 5
#define IOCBP6                         BANKMASK(IOCBP), 6
#define IOCBP7                         BANKMASK(IOCBP), 7
#ifndef _LIB_BUILD
#endif
IOCBN                                  equ 0395h
#define IOCBN0                         BANKMASK(IOCBN), 0
#define IOCBN1                         BANKMASK(IOCBN), 1
#define IOCBN2                         BANKMASK(IOCBN), 2
#define IOCBN3                         BANKMASK(IOCBN), 3
#define IOCBN4                         BANKMASK(IOCBN), 4
#define IOCBN5                         BANKMASK(IOCBN), 5
#define IOCBN6                         BANKMASK(IOCBN), 6
#define IOCBN7                         BANKMASK(IOCBN), 7
#ifndef _LIB_BUILD
#endif
IOCBF                                  equ 0396h
#define IOCBF0                         BANKMASK(IOCBF), 0
#define IOCBF1                         BANKMASK(IOCBF), 1
#define IOCBF2                         BANKMASK(IOCBF), 2
#define IOCBF3                         BANKMASK(IOCBF), 3
#define IOCBF4                         BANKMASK(IOCBF), 4
#define IOCBF5                         BANKMASK(IOCBF), 5
#define IOCBF6                         BANKMASK(IOCBF), 6
#define IOCBF7                         BANKMASK(IOCBF), 7
#ifndef _LIB_BUILD
#endif
ANSELF                                 equ 040Ch
#define ANSF0                          BANKMASK(ANSELF), 0
#define ANSF1                          BANKMASK(ANSELF), 1
#define ANSF2                          BANKMASK(ANSELF), 2
#define ANSF3                          BANKMASK(ANSELF), 3
#define ANSF4                          BANKMASK(ANSELF), 4
#define ANSF5                          BANKMASK(ANSELF), 5
#define ANSF6                          BANKMASK(ANSELF), 6
#define ANSF7                          BANKMASK(ANSELF), 7
#ifndef _LIB_BUILD
#endif
ANSELG                                 equ 040Dh
#define ANSG1                          BANKMASK(ANSELG), 1
#define ANSG2                          BANKMASK(ANSELG), 2
#define ANSG3                          BANKMASK(ANSELG), 3
#define ANSG4                          BANKMASK(ANSELG), 4
#ifndef _LIB_BUILD
#endif
TMR3L                                  equ 0411h
TMR3H                                  equ 0412h
T3CON                                  equ 0413h
#define TMR3ON                         BANKMASK(T3CON), 0
#define nT3SYNC                        BANKMASK(T3CON), 2
#define T3OSCEN                        BANKMASK(T3CON), 3
#define T3CKPS0                        BANKMASK(T3CON), 4
#define T3CKPS1                        BANKMASK(T3CON), 5
#define TMR3CS0                        BANKMASK(T3CON), 6
#define TMR3CS1                        BANKMASK(T3CON), 7
#ifndef _LIB_BUILD
#endif
T3GCON                                 equ 0414h
#define T3GVAL                         BANKMASK(T3GCON), 2
#define T3GGO_nDONE                    BANKMASK(T3GCON), 3
#define T3GSPM                         BANKMASK(T3GCON), 4
#define T3GTM                          BANKMASK(T3GCON), 5
#define T3GPOL                         BANKMASK(T3GCON), 6
#define TMR3GE                         BANKMASK(T3GCON), 7
#define T3GSS0                         BANKMASK(T3GCON), 0
#define T3GSS1                         BANKMASK(T3GCON), 1
#ifndef _LIB_BUILD
#endif
TMR4                                   equ 0415h
PR4                                    equ 0416h
T4CON                                  equ 0417h
#define TMR4ON                         BANKMASK(T4CON), 2
#define T4CKPS0                        BANKMASK(T4CON), 0
#define T4CKPS1                        BANKMASK(T4CON), 1
#define T4OUTPS0                       BANKMASK(T4CON), 3
#define T4OUTPS1                       BANKMASK(T4CON), 4
#define T4OUTPS2                       BANKMASK(T4CON), 5
#define T4OUTPS3                       BANKMASK(T4CON), 6
#ifndef _LIB_BUILD
#endif
TMR5L                                  equ 0418h
TMR5H                                  equ 0419h
T5CON                                  equ 041Ah
#define TMR5ON                         BANKMASK(T5CON), 0
#define nT5SYNC                        BANKMASK(T5CON), 2
#define T5OSCEN                        BANKMASK(T5CON), 3
#define T5CKPS0                        BANKMASK(T5CON), 4
#define T5CKPS1                        BANKMASK(T5CON), 5
#define TMR5CS0                        BANKMASK(T5CON), 6
#define TMR5CS1                        BANKMASK(T5CON), 7
#ifndef _LIB_BUILD
#endif
T5GCON                                 equ 041Bh
#define T5GVAL                         BANKMASK(T5GCON), 2
#define T5GGO_nDONE                    BANKMASK(T5GCON), 3
#define T5GSPM                         BANKMASK(T5GCON), 4
#define T5GTM                          BANKMASK(T5GCON), 5
#define T5GPOL                         BANKMASK(T5GCON), 6
#define TMR5GE                         BANKMASK(T5GCON), 7
#define T5GSS0                         BANKMASK(T5GCON), 0
#define T5GSS1                         BANKMASK(T5GCON), 1
#ifndef _LIB_BUILD
#endif
TMR6                                   equ 041Ch
PR6                                    equ 041Dh
T6CON                                  equ 041Eh
#define TMR6ON                         BANKMASK(T6CON), 2
#define T6CKPS0                        BANKMASK(T6CON), 0
#define T6CKPS1                        BANKMASK(T6CON), 1
#define T6OUTPS0                       BANKMASK(T6CON), 3
#define T6OUTPS1                       BANKMASK(T6CON), 4
#define T6OUTPS2                       BANKMASK(T6CON), 5
#define T6OUTPS3                       BANKMASK(T6CON), 6
#ifndef _LIB_BUILD
#endif
WPUG                                   equ 048Dh
#define WPUG5                          BANKMASK(WPUG), 5
#ifndef _LIB_BUILD
#endif
RC2REG                                 equ 0491h
RCREG2                                 equ 0491h
TX2REG                                 equ 0492h
TXREG2                                 equ 0492h
SP2BRGL                                equ 0493h
SPBRGL2                                equ 0493h
SP2BRGH                                equ 0494h
SPBRGH2                                equ 0494h
RC2STA                                 equ 0495h
RCSTA2                                 equ 0495h
#ifndef _LIB_BUILD
#endif
TX2STA                                 equ 0496h
TXSTA2                                 equ 0496h
#ifndef _LIB_BUILD
#endif
BAUD2CON                               equ 0497h
BAUDCON2                               equ 0497h
#ifndef _LIB_BUILD
#endif
TMR8                                   equ 0595h
PR8                                    equ 0596h
T8CON                                  equ 0597h
#define TMR8ON                         BANKMASK(T8CON), 2
#define T8CKPS0                        BANKMASK(T8CON), 0
#define T8CKPS1                        BANKMASK(T8CON), 1
#define T8OUTPS0                       BANKMASK(T8CON), 3
#define T8OUTPS1                       BANKMASK(T8CON), 4
#define T8OUTPS2                       BANKMASK(T8CON), 5
#define T8OUTPS3                       BANKMASK(T8CON), 6
#ifndef _LIB_BUILD
#endif
TMR10                                  equ 059Ch
PR10                                   equ 059Dh
T10CON                                 equ 059Eh
#define TMR10ON                        BANKMASK(T10CON), 2
#define T10CKPS0                       BANKMASK(T10CON), 0
#define T10CKPS1                       BANKMASK(T10CON), 1
#define T10OUTPS0                      BANKMASK(T10CON), 3
#define T10OUTPS1                      BANKMASK(T10CON), 4
#define T10OUTPS2                      BANKMASK(T10CON), 5
#define T10OUTPS3                      BANKMASK(T10CON), 6
#ifndef _LIB_BUILD
#endif
CCPR6L                                 equ 0611h
CCPR6H                                 equ 0612h
CCP6CON                                equ 0613h
#define CCP6M0                         BANKMASK(CCP6CON), 0
#define CCP6M1                         BANKMASK(CCP6CON), 1
#define CCP6M2                         BANKMASK(CCP6CON), 2
#define CCP6M3                         BANKMASK(CCP6CON), 3
#define DC6B0                          BANKMASK(CCP6CON), 4
#define DC6B1                          BANKMASK(CCP6CON), 5
#ifndef _LIB_BUILD
#endif
CCPR7L                                 equ 0614h
CCPR7H                                 equ 0615h
CCP7CON                                equ 0616h
#define CCP7M0                         BANKMASK(CCP7CON), 0
#define CCP7M1                         BANKMASK(CCP7CON), 1
#define CCP7M2                         BANKMASK(CCP7CON), 2
#define CCP7M3                         BANKMASK(CCP7CON), 3
#define DC7B0                          BANKMASK(CCP7CON), 4
#define DC7B1                          BANKMASK(CCP7CON), 5
#ifndef _LIB_BUILD
#endif
CCPR8L                                 equ 0617h
CCPR8H                                 equ 0618h
CCP8CON                                equ 0619h
#define CCP8M0                         BANKMASK(CCP8CON), 0
#define CCP8M1                         BANKMASK(CCP8CON), 1
#define CCP8M2                         BANKMASK(CCP8CON), 2
#define CCP8M3                         BANKMASK(CCP8CON), 3
#define DC8B0                          BANKMASK(CCP8CON), 4
#define DC8B1                          BANKMASK(CCP8CON), 5
#ifndef _LIB_BUILD
#endif
CCPR9L                                 equ 061Ah
CCPR9H                                 equ 061Bh
CCP9CON                                equ 061Ch
#define CCP9M0                         BANKMASK(CCP9CON), 0
#define CCP9M1                         BANKMASK(CCP9CON), 1
#define CCP9M2                         BANKMASK(CCP9CON), 2
#define CCP9M3                         BANKMASK(CCP9CON), 3
#define DC9B0                          BANKMASK(CCP9CON), 4
#define DC9B1                          BANKMASK(CCP9CON), 5
#ifndef _LIB_BUILD
#endif
CCPR10L                                equ 061Dh
CCPR10H                                equ 061Eh
CCP10CON                               equ 061Fh
#define CCP10M0                        BANKMASK(CCP10CON), 0
#define CCP10M1                        BANKMASK(CCP10CON), 1
#define CCP10M2                        BANKMASK(CCP10CON), 2
#define CCP10M3                        BANKMASK(CCP10CON), 3
#define DC10B0                         BANKMASK(CCP10CON), 4
#define DC10B1                         BANKMASK(CCP10CON), 5
#ifndef _LIB_BUILD
#endif
STATUS_SHAD                            equ 0FE4h
#define C_SHAD                         BANKMASK(STATUS_SHAD), 0
#define DC_SHAD                        BANKMASK(STATUS_SHAD), 1
#define Z_SHAD                         BANKMASK(STATUS_SHAD), 2
#ifndef _LIB_BUILD
#endif
WREG_SHAD                              equ 0FE5h
BSR_SHAD                               equ 0FE6h
#ifndef _LIB_BUILD
#endif
PCLATH_SHAD                            equ 0FE7h
#ifndef _LIB_BUILD
#endif
FSR0L_SHAD                             equ 0FE8h
FSR0H_SHAD                             equ 0FE9h
FSR1L_SHAD                             equ 0FEAh
FSR1H_SHAD                             equ 0FEBh
STKPTR                                 equ 0FEDh
#ifndef _LIB_BUILD
#endif
TOSL                                   equ 0FEEh
TOSH                                   equ 0FEFh
#ifndef _LIB_BUILD
#endif

#endif
#endif

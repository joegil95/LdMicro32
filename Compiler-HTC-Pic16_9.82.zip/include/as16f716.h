#ifndef _ASPIC_H_
#warning Header file as16f716.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS16F716_H_
#define _AS16F716_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define IRP                            BANKMASK(STATUS), 7
#define RP0                            BANKMASK(STATUS), 5
#define RP1                            BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define RA0                            BANKMASK(PORTA), 0
#define RA1                            BANKMASK(PORTA), 1
#define RA2                            BANKMASK(PORTA), 2
#define RA3                            BANKMASK(PORTA), 3
#define RA4                            BANKMASK(PORTA), 4
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 0006h
DATACCP                                equ 0006h
#define RB0                            BANKMASK(PORTB), 0
#define RB1                            BANKMASK(PORTB), 1
#define RB2                            BANKMASK(PORTB), 2
#define RB3                            BANKMASK(PORTB), 3
#define RB4                            BANKMASK(PORTB), 4
#define RB5                            BANKMASK(PORTB), 5
#define RB6                            BANKMASK(PORTB), 6
#define RB7                            BANKMASK(PORTB), 7
#define DT1CK                          BANKMASK(PORTB), 1
#define DCCP                           BANKMASK(PORTB), 3
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define RBIF                           BANKMASK(INTCON), 0
#define INTF                           BANKMASK(INTCON), 1
#define TMR0IF                         BANKMASK(INTCON), 2
#define RBIE                           BANKMASK(INTCON), 3
#define INTE                           BANKMASK(INTCON), 4
#define TMR0IE                         BANKMASK(INTCON), 5
#define PEIE                           BANKMASK(INTCON), 6
#define GIE                            BANKMASK(INTCON), 7
#define T0IF                           BANKMASK(INTCON), 2
#define T0IE                           BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF                         BANKMASK(PIR1), 0
#define TMR2IF                         BANKMASK(PIR1), 1
#define CCP1IF                         BANKMASK(PIR1), 2
#define ADIF                           BANKMASK(PIR1), 6
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Eh
TMR1H                                  equ 000Fh
T1CON                                  equ 0010h
#define TMR1ON                         BANKMASK(T1CON), 0
#define TMR1CS                         BANKMASK(T1CON), 1
#define nT1SYNC                        BANKMASK(T1CON), 2
#define T1OSCEN                        BANKMASK(T1CON), 3
#define T1SYNC                         BANKMASK(T1CON), 2
#define T1CKPS0                        BANKMASK(T1CON), 4
#define T1CKPS1                        BANKMASK(T1CON), 5
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 0011h
T2CON                                  equ 0012h
#define TMR2ON                         BANKMASK(T2CON), 2
#define T2CKPS0                        BANKMASK(T2CON), 0
#define T2CKPS1                        BANKMASK(T2CON), 1
#define TOUTPS0                        BANKMASK(T2CON), 3
#define TOUTPS1                        BANKMASK(T2CON), 4
#define TOUTPS2                        BANKMASK(T2CON), 5
#define TOUTPS3                        BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0015h
CCPR1H                                 equ 0016h
CCP1CON                                equ 0017h
#define CCP1M0                         BANKMASK(CCP1CON), 0
#define CCP1M1                         BANKMASK(CCP1CON), 1
#define CCP1M2                         BANKMASK(CCP1CON), 2
#define CCP1M3                         BANKMASK(CCP1CON), 3
#define DC1B0                          BANKMASK(CCP1CON), 4
#define DC1B1                          BANKMASK(CCP1CON), 5
#define P1M0                           BANKMASK(CCP1CON), 6
#define P1M1                           BANKMASK(CCP1CON), 7
#ifndef _LIB_BUILD
#endif
PWM1CON                                equ 0018h
#define PRSEN                          BANKMASK(PWM1CON), 7
#define PDC0                           BANKMASK(PWM1CON), 0
#define PDC1                           BANKMASK(PWM1CON), 1
#define PDC2                           BANKMASK(PWM1CON), 2
#define PDC3                           BANKMASK(PWM1CON), 3
#define PDC4                           BANKMASK(PWM1CON), 4
#define PDC5                           BANKMASK(PWM1CON), 5
#define PDC6                           BANKMASK(PWM1CON), 6
#ifndef _LIB_BUILD
#endif
ECCPAS                                 equ 0019h
#define ECCPAS0                        BANKMASK(ECCPAS), 4
#define ECCPAS2                        BANKMASK(ECCPAS), 6
#define ECCPASE                        BANKMASK(ECCPAS), 7
#define PSSBD0                         BANKMASK(ECCPAS), 0
#define PSSBD1                         BANKMASK(ECCPAS), 1
#define PSSAC0                         BANKMASK(ECCPAS), 2
#define PSSAC1                         BANKMASK(ECCPAS), 3
#define ECCPAS1                        BANKMASK(ECCPAS), 5
#ifndef _LIB_BUILD
#endif
ADRES                                  equ 001Eh
ADCON0                                 equ 001Fh
#define ADON                           BANKMASK(ADCON0), 0
#define GO_nDONE                       BANKMASK(ADCON0), 2
#define GO                             BANKMASK(ADCON0), 2
#define CHS0                           BANKMASK(ADCON0), 3
#define CHS1                           BANKMASK(ADCON0), 4
#define CHS2                           BANKMASK(ADCON0), 5
#define ADCS0                          BANKMASK(ADCON0), 6
#define ADCS1                          BANKMASK(ADCON0), 7
#define nDONE                          BANKMASK(ADCON0), 2
#define GO_DONE                        BANKMASK(ADCON0), 2
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA                            BANKMASK(OPTION_REG), 3
#define T0SE                           BANKMASK(OPTION_REG), 4
#define T0CS                           BANKMASK(OPTION_REG), 5
#define INTEDG                         BANKMASK(OPTION_REG), 6
#define nRBPU                          BANKMASK(OPTION_REG), 7
#define PS0                            BANKMASK(OPTION_REG), 0
#define PS1                            BANKMASK(OPTION_REG), 1
#define PS2                            BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 0085h
#define TRISA0                         BANKMASK(TRISA), 0
#define TRISA1                         BANKMASK(TRISA), 1
#define TRISA2                         BANKMASK(TRISA), 2
#define TRISA3                         BANKMASK(TRISA), 3
#define TRISA4                         BANKMASK(TRISA), 4
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 0086h
TRISCP                                 equ 0086h
#define TRISB0                         BANKMASK(TRISB), 0
#define TRISB1                         BANKMASK(TRISB), 1
#define TRISB2                         BANKMASK(TRISB), 2
#define TRISB3                         BANKMASK(TRISB), 3
#define TRISB4                         BANKMASK(TRISB), 4
#define TRISB5                         BANKMASK(TRISB), 5
#define TRISB6                         BANKMASK(TRISB), 6
#define TRISB7                         BANKMASK(TRISB), 7
#define TT1CK                          BANKMASK(TRISB), 1
#define TCCP                           BANKMASK(TRISB), 3
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE                         BANKMASK(PIE1), 0
#define TMR2IE                         BANKMASK(PIE1), 1
#define CCP1IE                         BANKMASK(PIE1), 2
#define ADIE                           BANKMASK(PIE1), 6
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOR                           BANKMASK(PCON), 0
#define nPOR                           BANKMASK(PCON), 1
#define nBO                            BANKMASK(PCON), 0
#define nBOD                           BANKMASK(PCON), 0
#ifndef _LIB_BUILD
#endif
PR2                                    equ 0092h
ADCON1                                 equ 009Fh
#define PCFG0                          BANKMASK(ADCON1), 0
#define PCFG1                          BANKMASK(ADCON1), 1
#define PCFG2                          BANKMASK(ADCON1), 2
#ifndef _LIB_BUILD
#endif

#endif
#endif

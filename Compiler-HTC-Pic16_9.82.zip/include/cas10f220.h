#ifndef _CASPIC_H_
#warning Header file cas10f220.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS10F220_H_
#define _CAS10F220_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define GPWUF_bit                      BANKMASK(STATUS), 7
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
OSCCAL                                 equ 0005h
#define FOSC4_bit                      BANKMASK(OSCCAL), 0
#define CAL0_bit                       BANKMASK(OSCCAL), 1
#define CAL1_bit                       BANKMASK(OSCCAL), 2
#define CAL2_bit                       BANKMASK(OSCCAL), 3
#define CAL3_bit                       BANKMASK(OSCCAL), 4
#define CAL4_bit                       BANKMASK(OSCCAL), 5
#define CAL5_bit                       BANKMASK(OSCCAL), 6
#define CAL6_bit                       BANKMASK(OSCCAL), 7
#ifndef _LIB_BUILD
#endif
GPIO                                   equ 0006h
#define GP0_bit                        BANKMASK(GPIO), 0
#define GP1_bit                        BANKMASK(GPIO), 1
#define GP2_bit                        BANKMASK(GPIO), 2
#define GP3_bit                        BANKMASK(GPIO), 3
#ifndef _LIB_BUILD
#endif
ADCON0                                 equ 0007h
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 1
#define GO_bit                         BANKMASK(ADCON0), 1
#define CHS0_bit                       BANKMASK(ADCON0), 2
#define CHS1_bit                       BANKMASK(ADCON0), 3
#define ANS0_bit                       BANKMASK(ADCON0), 6
#define ANS1_bit                       BANKMASK(ADCON0), 7
#define nDONE_bit                      BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
ADRES                                  equ 0008h
#define ADRES0_bit                     BANKMASK(ADRES), 0
#define ADRES1_bit                     BANKMASK(ADRES), 1
#define ADRES2_bit                     BANKMASK(ADRES), 2
#define ADRES3_bit                     BANKMASK(ADRES), 3
#define ADRES4_bit                     BANKMASK(ADRES), 4
#define ADRES5_bit                     BANKMASK(ADRES), 5
#define ADRES6_bit                     BANKMASK(ADRES), 6
#define ADRES7_bit                     BANKMASK(ADRES), 7
#ifndef _LIB_BUILD
#endif

#endif
#endif

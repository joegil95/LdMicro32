#ifndef _CASPIC_H_
#warning Header file cas16c781.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS16C781_H_
#define _CAS16C781_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define IRP_bit                        BANKMASK(STATUS), 7
#define RP0_bit                        BANKMASK(STATUS), 5
#define RP1_bit                        BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define RA0_bit                        BANKMASK(PORTA), 0
#define RA1_bit                        BANKMASK(PORTA), 1
#define RA2_bit                        BANKMASK(PORTA), 2
#define RA3_bit                        BANKMASK(PORTA), 3
#define RA4_bit                        BANKMASK(PORTA), 4
#define RA5_bit                        BANKMASK(PORTA), 5
#define RA6_bit                        BANKMASK(PORTA), 6
#define RA7_bit                        BANKMASK(PORTA), 7
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 0006h
#define RB0_bit                        BANKMASK(PORTB), 0
#define RB1_bit                        BANKMASK(PORTB), 1
#define RB2_bit                        BANKMASK(PORTB), 2
#define RB3_bit                        BANKMASK(PORTB), 3
#define RB4_bit                        BANKMASK(PORTB), 4
#define RB5_bit                        BANKMASK(PORTB), 5
#define RB6_bit                        BANKMASK(PORTB), 6
#define RB7_bit                        BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define RBIF_bit                       BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define T0IF_bit                       BANKMASK(INTCON), 2
#define RBIE_bit                       BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define T0IE_bit                       BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF_bit                     BANKMASK(PIR1), 0
#define C1IF_bit                       BANKMASK(PIR1), 4
#define C2IF_bit                       BANKMASK(PIR1), 5
#define ADIF_bit                       BANKMASK(PIR1), 6
#define LVDIF_bit                      BANKMASK(PIR1), 7
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Eh
TMR1H                                  equ 000Fh
T1CON                                  equ 0010h
#define TMR1ON_bit                     BANKMASK(T1CON), 0
#define TMR1CS_bit                     BANKMASK(T1CON), 1
#define nT1SYNC_bit                    BANKMASK(T1CON), 2
#define T1OSCEN_bit                    BANKMASK(T1CON), 3
#define TMR1GE_bit                     BANKMASK(T1CON), 6
#define T1INSYNC_bit                   BANKMASK(T1CON), 2
#define T1CKPS0_bit                    BANKMASK(T1CON), 4
#define T1CKPS1_bit                    BANKMASK(T1CON), 5
#ifndef _LIB_BUILD
#endif
ADRES                                  equ 001Eh
ADCON0                                 equ 001Fh
#define ADON_bit                       BANKMASK(ADCON0), 0
#define CHS3_bit                       BANKMASK(ADCON0), 1
#define GO_nDONE_bit                   BANKMASK(ADCON0), 2
#define GO_bit                         BANKMASK(ADCON0), 2
#define CHS0_bit                       BANKMASK(ADCON0), 3
#define CHS1_bit                       BANKMASK(ADCON0), 4
#define CHS2_bit                       BANKMASK(ADCON0), 5
#define ADCS0_bit                      BANKMASK(ADCON0), 6
#define ADCS1_bit                      BANKMASK(ADCON0), 7
#define nDONE_bit                      BANKMASK(ADCON0), 2
#define GO_DONE_bit                    BANKMASK(ADCON0), 2
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nRBPU_bit                      BANKMASK(OPTION_REG), 7
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 0085h
#define TRISA0_bit                     BANKMASK(TRISA), 0
#define TRISA1_bit                     BANKMASK(TRISA), 1
#define TRISA2_bit                     BANKMASK(TRISA), 2
#define TRISA3_bit                     BANKMASK(TRISA), 3
#define TRISA4_bit                     BANKMASK(TRISA), 4
#define TRISA5_bit                     BANKMASK(TRISA), 5
#define TRISA6_bit                     BANKMASK(TRISA), 6
#define TRISA7_bit                     BANKMASK(TRISA), 7
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 0086h
#define TRISB0_bit                     BANKMASK(TRISB), 0
#define TRISB1_bit                     BANKMASK(TRISB), 1
#define TRISB2_bit                     BANKMASK(TRISB), 2
#define TRISB3_bit                     BANKMASK(TRISB), 3
#define TRISB4_bit                     BANKMASK(TRISB), 4
#define TRISB5_bit                     BANKMASK(TRISB), 5
#define TRISB6_bit                     BANKMASK(TRISB), 6
#define TRISB7_bit                     BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE_bit                     BANKMASK(PIE1), 0
#define C1IE_bit                       BANKMASK(PIE1), 4
#define C2IE_bit                       BANKMASK(PIE1), 5
#define ADIE_bit                       BANKMASK(PIE1), 6
#define LVDIE_bit                      BANKMASK(PIE1), 7
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOR_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#define OSCF_bit                       BANKMASK(PCON), 3
#define WDTON_bit                      BANKMASK(PCON), 4
#define nBO_bit                        BANKMASK(PCON), 0
#ifndef _LIB_BUILD
#endif
WPUB                                   equ 0095h
#define WPUB0_bit                      BANKMASK(WPUB), 0
#define WPUB1_bit                      BANKMASK(WPUB), 1
#define WPUB2_bit                      BANKMASK(WPUB), 2
#define WPUB3_bit                      BANKMASK(WPUB), 3
#define WPUB4_bit                      BANKMASK(WPUB), 4
#define WPUB5_bit                      BANKMASK(WPUB), 5
#define WPUB6_bit                      BANKMASK(WPUB), 6
#define WPUB7_bit                      BANKMASK(WPUB), 7
#ifndef _LIB_BUILD
#endif
IOCB                                   equ 0096h
#define IOCB0_bit                      BANKMASK(IOCB), 0
#define IOCB1_bit                      BANKMASK(IOCB), 1
#define IOCB2_bit                      BANKMASK(IOCB), 2
#define IOCB3_bit                      BANKMASK(IOCB), 3
#define IOCB4_bit                      BANKMASK(IOCB), 4
#define IOCB5_bit                      BANKMASK(IOCB), 5
#define IOCB6_bit                      BANKMASK(IOCB), 6
#define IOCB7_bit                      BANKMASK(IOCB), 7
#ifndef _LIB_BUILD
#endif
REFCON                                 equ 009Bh
#define VROE_bit                       BANKMASK(REFCON), 2
#define VREN_bit                       BANKMASK(REFCON), 3
#define VREFOE_bit                     BANKMASK(REFCON), 2
#define VREFEN_bit                     BANKMASK(REFCON), 3
#ifndef _LIB_BUILD
#endif
LVDCON                                 equ 009Ch
#define LVDEN_bit                      BANKMASK(LVDCON), 4
#define BGST_bit                       BANKMASK(LVDCON), 5
#define LV0_bit                        BANKMASK(LVDCON), 0
#define LV1_bit                        BANKMASK(LVDCON), 1
#define LV2_bit                        BANKMASK(LVDCON), 2
#define LV3_bit                        BANKMASK(LVDCON), 3
#ifndef _LIB_BUILD
#endif
ANSEL                                  equ 009Dh
#define ANS0_bit                       BANKMASK(ANSEL), 0
#define ANS1_bit                       BANKMASK(ANSEL), 1
#define ANS2_bit                       BANKMASK(ANSEL), 2
#define ANS3_bit                       BANKMASK(ANSEL), 3
#define ANS4_bit                       BANKMASK(ANSEL), 4
#define ANS5_bit                       BANKMASK(ANSEL), 5
#define ANS6_bit                       BANKMASK(ANSEL), 6
#define ANS7_bit                       BANKMASK(ANSEL), 7
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 009Fh
#define VCFG0_bit                      BANKMASK(ADCON1), 4
#define VCFG1_bit                      BANKMASK(ADCON1), 5
#ifndef _LIB_BUILD
#endif
PMDATL                                 equ 010Ch
PMADRL                                 equ 010Dh
PMDATH                                 equ 010Eh
#ifndef _LIB_BUILD
#endif
PMADRH                                 equ 010Fh
#ifndef _LIB_BUILD
#endif
CALCON                                 equ 0110h
#define CALREF_bit                     BANKMASK(CALCON), 5
#define CALERR_bit                     BANKMASK(CALCON), 6
#define CAL_bit                        BANKMASK(CALCON), 7
#ifndef _LIB_BUILD
#endif
PSMCCON0                               equ 0111h
#define DC0_bit                        BANKMASK(PSMCCON0), 0
#define DC1_bit                        BANKMASK(PSMCCON0), 1
#define MAXDC0_bit                     BANKMASK(PSMCCON0), 2
#define MAXDC1_bit                     BANKMASK(PSMCCON0), 3
#define MINDC0_bit                     BANKMASK(PSMCCON0), 4
#define MINDC1_bit                     BANKMASK(PSMCCON0), 5
#define SMCCL0_bit                     BANKMASK(PSMCCON0), 6
#define SMCCL1_bit                     BANKMASK(PSMCCON0), 7
#ifndef _LIB_BUILD
#endif
PSMCCON1                               equ 0112h
#define SMCCS_bit                      BANKMASK(PSMCCON1), 0
#define PWM_nPSM_bit                   BANKMASK(PSMCCON1), 1
#define SMCOM_bit                      BANKMASK(PSMCCON1), 2
#define SCEN_bit                       BANKMASK(PSMCCON1), 3
#define S1BPOL_bit                     BANKMASK(PSMCCON1), 5
#define S1APOL_bit                     BANKMASK(PSMCCON1), 6
#define SMCON_bit                      BANKMASK(PSMCCON1), 7
#define PWM_bit                        BANKMASK(PSMCCON1), 1
#define PSM_bit                        BANKMASK(PSMCCON1), 1
#define nPSM_bit                       BANKMASK(PSMCCON1), 1
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 0119h
#define C1R_bit                        BANKMASK(CM1CON0), 2
#define C1SP_bit                       BANKMASK(CM1CON0), 3
#define C1POL_bit                      BANKMASK(CM1CON0), 4
#define C1OE_bit                       BANKMASK(CM1CON0), 5
#define C1OUT_bit                      BANKMASK(CM1CON0), 6
#define C1ON_bit                       BANKMASK(CM1CON0), 7
#define C1CH0_bit                      BANKMASK(CM1CON0), 0
#define C1CH1_bit                      BANKMASK(CM1CON0), 1
#ifndef _LIB_BUILD
#endif
CM2CON0                                equ 011Ah
#define C2R_bit                        BANKMASK(CM2CON0), 2
#define C2SP_bit                       BANKMASK(CM2CON0), 3
#define C2POL_bit                      BANKMASK(CM2CON0), 4
#define C2OE_bit                       BANKMASK(CM2CON0), 5
#define C2OUT_bit                      BANKMASK(CM2CON0), 6
#define C2ON_bit                       BANKMASK(CM2CON0), 7
#define C2CH0_bit                      BANKMASK(CM2CON0), 0
#define C2CH1_bit                      BANKMASK(CM2CON0), 1
#ifndef _LIB_BUILD
#endif
CM2CON1                                equ 011Bh
#define C2SYNC_bit                     BANKMASK(CM2CON1), 0
#define MC2OUT_bit                     BANKMASK(CM2CON1), 6
#define MC1OUT_bit                     BANKMASK(CM2CON1), 7
#ifndef _LIB_BUILD
#endif
OPACON                                 equ 011Ch
#define GBWP_bit                       BANKMASK(OPACON), 0
#define CMPEN_bit                      BANKMASK(OPACON), 6
#define OPAON_bit                      BANKMASK(OPACON), 7
#ifndef _LIB_BUILD
#endif
DAC                                    equ 011Eh
#define DA0_bit                        BANKMASK(DAC), 0
#define DA1_bit                        BANKMASK(DAC), 1
#define DA2_bit                        BANKMASK(DAC), 2
#define DA3_bit                        BANKMASK(DAC), 3
#define DA4_bit                        BANKMASK(DAC), 4
#define DA5_bit                        BANKMASK(DAC), 5
#define DA6_bit                        BANKMASK(DAC), 6
#define DA7_bit                        BANKMASK(DAC), 7
#ifndef _LIB_BUILD
#endif
DACON0                                 equ 011Fh
#define DAOE_bit                       BANKMASK(DACON0), 6
#define DAON_bit                       BANKMASK(DACON0), 7
#define DARS0_bit                      BANKMASK(DACON0), 0
#define DARS1_bit                      BANKMASK(DACON0), 1
#ifndef _LIB_BUILD
#endif
PMCON1                                 equ 018Ch
#define RD_bit                         BANKMASK(PMCON1), 0
#ifndef _LIB_BUILD
#endif

#endif
#endif

#ifndef _ASPIC_H_
#warning Header file as16lf1503.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS16LF1503_H_
#define _AS16LF1503_H_

INDF0                                  equ 0000h
INDF1                                  equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#ifndef _LIB_BUILD
#endif
FSR0L                                  equ 0004h
FSR0H                                  equ 0005h
FSR1L                                  equ 0006h
FSR1H                                  equ 0007h
BSR                                    equ 0008h
#define BSR0                           BANKMASK(BSR), 0
#define BSR1                           BANKMASK(BSR), 1
#define BSR2                           BANKMASK(BSR), 2
#define BSR3                           BANKMASK(BSR), 3
#define BSR4                           BANKMASK(BSR), 4
#ifndef _LIB_BUILD
#endif
WREG                                   equ 0009h
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define IOCIF                          BANKMASK(INTCON), 0
#define INTF                           BANKMASK(INTCON), 1
#define TMR0IF                         BANKMASK(INTCON), 2
#define IOCIE                          BANKMASK(INTCON), 3
#define INTE                           BANKMASK(INTCON), 4
#define TMR0IE                         BANKMASK(INTCON), 5
#define PEIE                           BANKMASK(INTCON), 6
#define GIE                            BANKMASK(INTCON), 7
#define T0IF                           BANKMASK(INTCON), 2
#define T0IE                           BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PORTA                                  equ 000Ch
#define RA0                            BANKMASK(PORTA), 0
#define RA1                            BANKMASK(PORTA), 1
#define RA2                            BANKMASK(PORTA), 2
#define RA3                            BANKMASK(PORTA), 3
#define RA4                            BANKMASK(PORTA), 4
#define RA5                            BANKMASK(PORTA), 5
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 000Eh
#define RC0                            BANKMASK(PORTC), 0
#define RC1                            BANKMASK(PORTC), 1
#define RC2                            BANKMASK(PORTC), 2
#define RC3                            BANKMASK(PORTC), 3
#define RC4                            BANKMASK(PORTC), 4
#define RC5                            BANKMASK(PORTC), 5
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 0011h
#define TMR1IF                         BANKMASK(PIR1), 0
#define TMR2IF                         BANKMASK(PIR1), 1
#define SSP1IF                         BANKMASK(PIR1), 3
#define ADIF                           BANKMASK(PIR1), 6
#define TMR1GIF                        BANKMASK(PIR1), 7
#ifndef _LIB_BUILD
#endif
PIR2                                   equ 0012h
#define NCO1IF                         BANKMASK(PIR2), 2
#define BCL1IF                         BANKMASK(PIR2), 3
#define C1IF                           BANKMASK(PIR2), 5
#define C2IF                           BANKMASK(PIR2), 6
#ifndef _LIB_BUILD
#endif
PIR3                                   equ 0013h
#define CLC1IF                         BANKMASK(PIR3), 0
#define CLC2IF                         BANKMASK(PIR3), 1
#ifndef _LIB_BUILD
#endif
TMR0                                   equ 0015h
TMR1L                                  equ 0016h
TMR1H                                  equ 0017h
T1CON                                  equ 0018h
#define TMR1ON                         BANKMASK(T1CON), 0
#define nT1SYNC                        BANKMASK(T1CON), 2
#define T1OSCEN                        BANKMASK(T1CON), 3
#define T1CKPS0                        BANKMASK(T1CON), 4
#define T1CKPS1                        BANKMASK(T1CON), 5
#define TMR1CS0                        BANKMASK(T1CON), 6
#define TMR1CS1                        BANKMASK(T1CON), 7
#ifndef _LIB_BUILD
#endif
T1GCON                                 equ 0019h
#define T1GVAL                         BANKMASK(T1GCON), 2
#define T1GGO_nDONE                    BANKMASK(T1GCON), 3
#define T1GSPM                         BANKMASK(T1GCON), 4
#define T1GTM                          BANKMASK(T1GCON), 5
#define T1GPOL                         BANKMASK(T1GCON), 6
#define TMR1GE                         BANKMASK(T1GCON), 7
#define T1GSS0                         BANKMASK(T1GCON), 0
#define T1GSS1                         BANKMASK(T1GCON), 1
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 001Ah
PR2                                    equ 001Bh
T2CON                                  equ 001Ch
#define TMR2ON                         BANKMASK(T2CON), 2
#define T2CKPS0                        BANKMASK(T2CON), 0
#define T2CKPS1                        BANKMASK(T2CON), 1
#define TOUTPS0                        BANKMASK(T2CON), 3
#define TOUTPS1                        BANKMASK(T2CON), 4
#define TOUTPS2                        BANKMASK(T2CON), 5
#define TOUTPS3                        BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 008Ch
#define TRISA0                         BANKMASK(TRISA), 0
#define TRISA1                         BANKMASK(TRISA), 1
#define TRISA2                         BANKMASK(TRISA), 2
#define TRISA3                         BANKMASK(TRISA), 3
#define TRISA4                         BANKMASK(TRISA), 4
#define TRISA5                         BANKMASK(TRISA), 5
#ifndef _LIB_BUILD
#endif
TRISC                                  equ 008Eh
#define TRISC0                         BANKMASK(TRISC), 0
#define TRISC1                         BANKMASK(TRISC), 1
#define TRISC2                         BANKMASK(TRISC), 2
#define TRISC3                         BANKMASK(TRISC), 3
#define TRISC4                         BANKMASK(TRISC), 4
#define TRISC5                         BANKMASK(TRISC), 5
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 0091h
#define TMR1IE                         BANKMASK(PIE1), 0
#define TMR2IE                         BANKMASK(PIE1), 1
#define SSP1IE                         BANKMASK(PIE1), 3
#define ADIE                           BANKMASK(PIE1), 6
#define TMR1GIE                        BANKMASK(PIE1), 7
#ifndef _LIB_BUILD
#endif
PIE2                                   equ 0092h
#define NCO1IE                         BANKMASK(PIE2), 2
#define BCL1IE                         BANKMASK(PIE2), 3
#define C1IE                           BANKMASK(PIE2), 5
#define C2IE                           BANKMASK(PIE2), 6
#ifndef _LIB_BUILD
#endif
PIE3                                   equ 0093h
#define CLC1E                          BANKMASK(PIE3), 0
#define CLC2IE                         BANKMASK(PIE3), 1
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0095h
#define PSA                            BANKMASK(OPTION_REG), 3
#define TMR0SE                         BANKMASK(OPTION_REG), 4
#define TMR0CS                         BANKMASK(OPTION_REG), 5
#define INTEDG                         BANKMASK(OPTION_REG), 6
#define nWPUEN                         BANKMASK(OPTION_REG), 7
#define PS0                            BANKMASK(OPTION_REG), 0
#define PS1                            BANKMASK(OPTION_REG), 1
#define PS2                            BANKMASK(OPTION_REG), 2
#define T0SE                           BANKMASK(OPTION_REG), 4
#define T0CS                           BANKMASK(OPTION_REG), 5
#ifndef _LIB_BUILD
#endif
PCON                                   equ 0096h
#define nBOR                           BANKMASK(PCON), 0
#define nPOR                           BANKMASK(PCON), 1
#define nRI                            BANKMASK(PCON), 2
#define nRMCLR                         BANKMASK(PCON), 3
#define nRWDT                          BANKMASK(PCON), 4
#define STKUNF                         BANKMASK(PCON), 6
#define STKOVF                         BANKMASK(PCON), 7
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0097h
#define SWDTEN                         BANKMASK(WDTCON), 0
#define WDTPS0                         BANKMASK(WDTCON), 1
#define WDTPS1                         BANKMASK(WDTCON), 2
#define WDTPS2                         BANKMASK(WDTCON), 3
#define WDTPS3                         BANKMASK(WDTCON), 4
#define WDTPS4                         BANKMASK(WDTCON), 5
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 0099h
#define SCS0                           BANKMASK(OSCCON), 0
#define SCS1                           BANKMASK(OSCCON), 1
#define IRCF0                          BANKMASK(OSCCON), 3
#define IRCF1                          BANKMASK(OSCCON), 4
#define IRCF2                          BANKMASK(OSCCON), 5
#define IRCF3                          BANKMASK(OSCCON), 6
#ifndef _LIB_BUILD
#endif
OSCSTAT                                equ 009Ah
#define HFIOFS                         BANKMASK(OSCSTAT), 0
#define LFIOFR                         BANKMASK(OSCSTAT), 1
#define HFIOFR                         BANKMASK(OSCSTAT), 4
#define OSTS                           BANKMASK(OSCSTAT), 5
#define SOSCR                          BANKMASK(OSCSTAT), 7
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 009Bh
ADRESH                                 equ 009Ch
ADCON0                                 equ 009Dh
#define ADON                           BANKMASK(ADCON0), 0
#define GO_nDONE                       BANKMASK(ADCON0), 1
#define ADGO                           BANKMASK(ADCON0), 1
#define CHS0                           BANKMASK(ADCON0), 2
#define CHS1                           BANKMASK(ADCON0), 3
#define CHS2                           BANKMASK(ADCON0), 4
#define CHS3                           BANKMASK(ADCON0), 5
#define CHS4                           BANKMASK(ADCON0), 6
#define GO                             BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 009Eh
#define ADFM                           BANKMASK(ADCON1), 7
#define ADPREF0                        BANKMASK(ADCON1), 0
#define ADPREF1                        BANKMASK(ADCON1), 1
#ifndef _LIB_BUILD
#endif
ADCON2                                 equ 009Fh
#define TRIGSEL0                       BANKMASK(ADCON2), 4
#define TRIGSEL1                       BANKMASK(ADCON2), 5
#define TRIGSEL2                       BANKMASK(ADCON2), 6
#define TRIGSEL3                       BANKMASK(ADCON2), 7
#ifndef _LIB_BUILD
#endif
LATA                                   equ 010Ch
#define LATA0                          BANKMASK(LATA), 0
#define LATA1                          BANKMASK(LATA), 1
#define LATA2                          BANKMASK(LATA), 2
#define LATA4                          BANKMASK(LATA), 4
#define LATA5                          BANKMASK(LATA), 5
#ifndef _LIB_BUILD
#endif
LATC                                   equ 010Eh
#define LATC0                          BANKMASK(LATC), 0
#define LATC1                          BANKMASK(LATC), 1
#define LATC2                          BANKMASK(LATC), 2
#define LATC3                          BANKMASK(LATC), 3
#define LATC4                          BANKMASK(LATC), 4
#define LATC5                          BANKMASK(LATC), 5
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 0111h
#define C1SYNC                         BANKMASK(CM1CON0), 0
#define C1HYS                          BANKMASK(CM1CON0), 1
#define C1SP                           BANKMASK(CM1CON0), 2
#define C1POL                          BANKMASK(CM1CON0), 4
#define C1OE                           BANKMASK(CM1CON0), 5
#define C1OUT                          BANKMASK(CM1CON0), 6
#define C1ON                           BANKMASK(CM1CON0), 7
#ifndef _LIB_BUILD
#endif
CM1CON1                                equ 0112h
#define C1NCH0                         BANKMASK(CM1CON1), 0
#define C1NCH1                         BANKMASK(CM1CON1), 1
#define C1PCH0                         BANKMASK(CM1CON1), 4
#define C1PCH1                         BANKMASK(CM1CON1), 5
#define C1INTN                         BANKMASK(CM1CON1), 6
#define C1INTP                         BANKMASK(CM1CON1), 7
#ifndef _LIB_BUILD
#endif
CM2CON0                                equ 0113h
#define C2SYNC                         BANKMASK(CM2CON0), 0
#define C2HYS                          BANKMASK(CM2CON0), 1
#define C2SP                           BANKMASK(CM2CON0), 2
#define C2POL                          BANKMASK(CM2CON0), 4
#define C2OE                           BANKMASK(CM2CON0), 5
#define C2OUT                          BANKMASK(CM2CON0), 6
#define C2ON                           BANKMASK(CM2CON0), 7
#ifndef _LIB_BUILD
#endif
CM2CON1                                equ 0114h
#define C2NCH0                         BANKMASK(CM2CON1), 0
#define C2NCH1                         BANKMASK(CM2CON1), 1
#define C2PCH0                         BANKMASK(CM2CON1), 4
#define C2PCH1                         BANKMASK(CM2CON1), 5
#define C2INTN                         BANKMASK(CM2CON1), 6
#define C2INTP                         BANKMASK(CM2CON1), 7
#ifndef _LIB_BUILD
#endif
CMOUT                                  equ 0115h
#define MC1OUT                         BANKMASK(CMOUT), 0
#define MC2OUT                         BANKMASK(CMOUT), 1
#ifndef _LIB_BUILD
#endif
BORCON                                 equ 0116h
#define BORRDY                         BANKMASK(BORCON), 0
#define BORFS                          BANKMASK(BORCON), 6
#define SBOREN                         BANKMASK(BORCON), 7
#ifndef _LIB_BUILD
#endif
FVRCON                                 equ 0117h
#define FVRRDY                         BANKMASK(FVRCON), 6
#define FVREN                          BANKMASK(FVRCON), 7
#define ADFVR0                         BANKMASK(FVRCON), 0
#define ADFVR1                         BANKMASK(FVRCON), 1
#ifndef _LIB_BUILD
#endif
DACCON0                                equ 0118h
#define DACNSS                         BANKMASK(DACCON0), 0
#define DACPSS0                        BANKMASK(DACCON0), 2
#define DACPSS1                        BANKMASK(DACCON0), 3
#define DACOE                          BANKMASK(DACCON0), 5
#define DACLPS                         BANKMASK(DACCON0), 6
#define DACEN                          BANKMASK(DACCON0), 7
#ifndef _LIB_BUILD
#endif
DACCON1                                equ 0119h
#define DACR0                          BANKMASK(DACCON1), 0
#define DACR1                          BANKMASK(DACCON1), 1
#define DACR2                          BANKMASK(DACCON1), 2
#define DACR3                          BANKMASK(DACCON1), 3
#define DACR4                          BANKMASK(DACCON1), 4
#ifndef _LIB_BUILD
#endif
APFCON                                 equ 011Dh
#define NCOSEL                         BANKMASK(APFCON), 0
#define CLC1SEL                        BANKMASK(APFCON), 1
#define T1GSEL                         BANKMASK(APFCON), 3
#define SSSEL                          BANKMASK(APFCON), 4
#define SDOSEL                         BANKMASK(APFCON), 5
#ifndef _LIB_BUILD
#endif
ANSELA                                 equ 018Ch
#define ANSA0                          BANKMASK(ANSELA), 0
#define ANSA1                          BANKMASK(ANSELA), 1
#define ANSA2                          BANKMASK(ANSELA), 2
#define ANSA4                          BANKMASK(ANSELA), 4
#ifndef _LIB_BUILD
#endif
ANSELC                                 equ 018Eh
#define ANSC0                          BANKMASK(ANSELC), 0
#define ANSC1                          BANKMASK(ANSELC), 1
#define ANSC2                          BANKMASK(ANSELC), 2
#define ANSC3                          BANKMASK(ANSELC), 3
#ifndef _LIB_BUILD
#endif
PMADRL                                 equ 0191h
PMADRH                                 equ 0192h
#ifndef _LIB_BUILD
#endif
PMDATL                                 equ 0193h
PMDATH                                 equ 0194h
#ifndef _LIB_BUILD
#endif
PMCON1                                 equ 0195h
#define RD                             BANKMASK(PMCON1), 0
#define WR                             BANKMASK(PMCON1), 1
#define WREN                           BANKMASK(PMCON1), 2
#define WRERR                          BANKMASK(PMCON1), 3
#define FREE                           BANKMASK(PMCON1), 4
#define LWLO                           BANKMASK(PMCON1), 5
#define CFGS                           BANKMASK(PMCON1), 6
#define EEPGD                          BANKMASK(PMCON1), 7
#ifndef _LIB_BUILD
#endif
PMCON2                                 equ 0196h
WPUA                                   equ 020Ch
#define WPUA0                          BANKMASK(WPUA), 0
#define WPUA1                          BANKMASK(WPUA), 1
#define WPUA2                          BANKMASK(WPUA), 2
#define WPUA3                          BANKMASK(WPUA), 3
#define WPUA4                          BANKMASK(WPUA), 4
#define WPUA5                          BANKMASK(WPUA), 5
#ifndef _LIB_BUILD
#endif
SSPBUF                                 equ 020Dh
SSPADD                                 equ 020Eh
SSPMSK                                 equ 020Fh
SSPSTAT                                equ 0210h
#define BF                             BANKMASK(SSPSTAT), 0
#define UA                             BANKMASK(SSPSTAT), 1
#define R_nW                           BANKMASK(SSPSTAT), 2
#define S                              BANKMASK(SSPSTAT), 3
#define P                              BANKMASK(SSPSTAT), 4
#define D_nA                           BANKMASK(SSPSTAT), 5
#define CKE                            BANKMASK(SSPSTAT), 6
#define SMP                            BANKMASK(SSPSTAT), 7
#ifndef _LIB_BUILD
#endif
SSPCON1                                equ 0211h
SSPCON                                 equ 0211h
#define SSPM0                          BANKMASK(SSPCON1), 0
#define SSPM1                          BANKMASK(SSPCON1), 1
#define SSPM2                          BANKMASK(SSPCON1), 2
#define SSPM3                          BANKMASK(SSPCON1), 3
#define CKP                            BANKMASK(SSPCON1), 4
#define SSPEN                          BANKMASK(SSPCON1), 5
#define SSPOV                          BANKMASK(SSPCON1), 6
#define WCOL                           BANKMASK(SSPCON1), 7
#ifndef _LIB_BUILD
#endif
SSPCON2                                equ 0212h
#define SEN                            BANKMASK(SSPCON2), 0
#define RSEN                           BANKMASK(SSPCON2), 1
#define PEN                            BANKMASK(SSPCON2), 2
#define RCEN                           BANKMASK(SSPCON2), 3
#define ACKEN                          BANKMASK(SSPCON2), 4
#define ACKDT                          BANKMASK(SSPCON2), 5
#define ACKSTAT                        BANKMASK(SSPCON2), 6
#define GCEN                           BANKMASK(SSPCON2), 7
#ifndef _LIB_BUILD
#endif
SSPCON3                                equ 0213h
#define DHEN                           BANKMASK(SSPCON3), 0
#define AHEN                           BANKMASK(SSPCON3), 1
#define SBCDE                          BANKMASK(SSPCON3), 2
#define SDAHT                          BANKMASK(SSPCON3), 3
#define BOEN                           BANKMASK(SSPCON3), 4
#define SCIE                           BANKMASK(SSPCON3), 5
#define PCIE                           BANKMASK(SSPCON3), 6
#define ACKTIM                         BANKMASK(SSPCON3), 7
#ifndef _LIB_BUILD
#endif
IOCAP                                  equ 0391h
#define IOCAP0                         BANKMASK(IOCAP), 0
#define IOCAP1                         BANKMASK(IOCAP), 1
#define IOCAP2                         BANKMASK(IOCAP), 2
#define IOCAP3                         BANKMASK(IOCAP), 3
#define IOCAP4                         BANKMASK(IOCAP), 4
#define IOCAP5                         BANKMASK(IOCAP), 5
#ifndef _LIB_BUILD
#endif
IOCAN                                  equ 0392h
#define IOCAN0                         BANKMASK(IOCAN), 0
#define IOCAN1                         BANKMASK(IOCAN), 1
#define IOCAN2                         BANKMASK(IOCAN), 2
#define IOCAN3                         BANKMASK(IOCAN), 3
#define IOCAN4                         BANKMASK(IOCAN), 4
#define IOCAN5                         BANKMASK(IOCAN), 5
#ifndef _LIB_BUILD
#endif
IOCAF                                  equ 0393h
#define IOCAF0                         BANKMASK(IOCAF), 0
#define IOCAF1                         BANKMASK(IOCAF), 1
#define IOCAF2                         BANKMASK(IOCAF), 2
#define IOCAF3                         BANKMASK(IOCAF), 3
#define IOCAF4                         BANKMASK(IOCAF), 4
#define IOCAF5                         BANKMASK(IOCAF), 5
#ifndef _LIB_BUILD
#endif
CLCDATA                                equ 0F0Fh
#define MCLC1OUT                       BANKMASK(CLCDATA), 0
#define MCLC2OUT                       BANKMASK(CLCDATA), 1
#ifndef _LIB_BUILD
#endif
BSR_ICDSHAD                            equ 0FE3h
#ifndef _LIB_BUILD
#endif
STATUS_SHAD                            equ 0FE4h
#define C_SHAD                         BANKMASK(STATUS_SHAD), 0
#define DC_SHAD                        BANKMASK(STATUS_SHAD), 1
#define Z_SHAD                         BANKMASK(STATUS_SHAD), 2
#ifndef _LIB_BUILD
#endif
WREG_SHAD                              equ 0FE5h
BSR_SHAD                               equ 0FE6h
#ifndef _LIB_BUILD
#endif
PCLATH_SHAD                            equ 0FE7h
#ifndef _LIB_BUILD
#endif
FSR0L_SHAD                             equ 0FE8h
FSR0H_SHAD                             equ 0FE9h
FSR1L_SHAD                             equ 0FEAh
FSR1H_SHAD                             equ 0FEBh
STKPTR                                 equ 0FEDh
#ifndef _LIB_BUILD
#endif
TOSL                                   equ 0FEEh
TOSH                                   equ 0FEFh
#ifndef _LIB_BUILD
#endif

#endif
#endif

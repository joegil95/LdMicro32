#ifndef _CASPIC_H_
#warning Header file cas12f510.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS12F510_H_
#define _CAS12F510_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define PA0_bit                        BANKMASK(STATUS), 5
#define CWUF_bit                       BANKMASK(STATUS), 6
#define GPWUF_bit                      BANKMASK(STATUS), 7
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
OSCCAL                                 equ 0005h
#define CAL0_bit                       BANKMASK(OSCCAL), 1
#define CAL1_bit                       BANKMASK(OSCCAL), 2
#define CAL2_bit                       BANKMASK(OSCCAL), 3
#define CAL3_bit                       BANKMASK(OSCCAL), 4
#define CAL4_bit                       BANKMASK(OSCCAL), 5
#define CAL5_bit                       BANKMASK(OSCCAL), 6
#define CAL6_bit                       BANKMASK(OSCCAL), 7
#ifndef _LIB_BUILD
#endif
GPIO                                   equ 0006h
#define GP0_bit                        BANKMASK(GPIO), 0
#define GP1_bit                        BANKMASK(GPIO), 1
#define GP2_bit                        BANKMASK(GPIO), 2
#define GP3_bit                        BANKMASK(GPIO), 3
#define GP4_bit                        BANKMASK(GPIO), 4
#define GP5_bit                        BANKMASK(GPIO), 5
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 0007h
#define nC1WU_bit                      BANKMASK(CM1CON0), 0
#define C1PREF_bit                     BANKMASK(CM1CON0), 1
#define C1NREF_bit                     BANKMASK(CM1CON0), 2
#define C1ON_bit                       BANKMASK(CM1CON0), 3
#define nC1T0CS_bit                    BANKMASK(CM1CON0), 4
#define C1POL_bit                      BANKMASK(CM1CON0), 5
#define nC1OUTEN_bit                   BANKMASK(CM1CON0), 6
#define C1OUT_bit                      BANKMASK(CM1CON0), 7
#ifndef _LIB_BUILD
#endif
ADCON0                                 equ 0008h
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 1
#define GO_bit                         BANKMASK(ADCON0), 1
#define CHS0_bit                       BANKMASK(ADCON0), 2
#define CHS1_bit                       BANKMASK(ADCON0), 3
#define ADCS0_bit                      BANKMASK(ADCON0), 4
#define ADCS1_bit                      BANKMASK(ADCON0), 5
#define ANS0_bit                       BANKMASK(ADCON0), 6
#define ANS1_bit                       BANKMASK(ADCON0), 7
#define nDONE_bit                      BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
ADRES                                  equ 0009h

#endif
#endif

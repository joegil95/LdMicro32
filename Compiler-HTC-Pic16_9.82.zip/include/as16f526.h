#ifndef _ASPIC_H_
#warning Header file as16f526.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS16F526_H_
#define _AS16F526_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define PA0                            BANKMASK(STATUS), 5
#define CWUF                           BANKMASK(STATUS), 6
#define RBWUF                          BANKMASK(STATUS), 7
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
OSCCAL                                 equ 0005h
#define CAL0                           BANKMASK(OSCCAL), 1
#define CAL1                           BANKMASK(OSCCAL), 2
#define CAL2                           BANKMASK(OSCCAL), 3
#define CAL3                           BANKMASK(OSCCAL), 4
#define CAL4                           BANKMASK(OSCCAL), 5
#define CAL5                           BANKMASK(OSCCAL), 6
#define CAL6                           BANKMASK(OSCCAL), 7
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 0006h
#define RB0                            BANKMASK(PORTB), 0
#define RB1                            BANKMASK(PORTB), 1
#define RB2                            BANKMASK(PORTB), 2
#define RB3                            BANKMASK(PORTB), 3
#define RB4                            BANKMASK(PORTB), 4
#define RB5                            BANKMASK(PORTB), 5
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 0007h
#define RC0                            BANKMASK(PORTC), 0
#define RC1                            BANKMASK(PORTC), 1
#define RC2                            BANKMASK(PORTC), 2
#define RC3                            BANKMASK(PORTC), 3
#define RC4                            BANKMASK(PORTC), 4
#define RC5                            BANKMASK(PORTC), 5
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 0008h
#define nC1WU                          BANKMASK(CM1CON0), 0
#define C1PREF                         BANKMASK(CM1CON0), 1
#define C1NREF                         BANKMASK(CM1CON0), 2
#define C1ON                           BANKMASK(CM1CON0), 3
#define nC1T0CS                        BANKMASK(CM1CON0), 4
#define C1POL                          BANKMASK(CM1CON0), 5
#define nC1OUTEN                       BANKMASK(CM1CON0), 6
#define C1OUT                          BANKMASK(CM1CON0), 7
#ifndef _LIB_BUILD
#endif
ADCON0                                 equ 0009h
#define ADON                           BANKMASK(ADCON0), 0
#define GO_nDONE                       BANKMASK(ADCON0), 1
#define GO                             BANKMASK(ADCON0), 1
#define CHS0                           BANKMASK(ADCON0), 2
#define CHS1                           BANKMASK(ADCON0), 3
#define ADCS0                          BANKMASK(ADCON0), 4
#define ADCS1                          BANKMASK(ADCON0), 5
#define ANS0                           BANKMASK(ADCON0), 6
#define ANS1                           BANKMASK(ADCON0), 7
#define NOT_DONE                       BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
ADRES                                  equ 000Ah
#define ADRES0                         BANKMASK(ADRES), 0
#define ADRES1                         BANKMASK(ADRES), 1
#define ADRES2                         BANKMASK(ADRES), 2
#define ADRES3                         BANKMASK(ADRES), 3
#define ADRES4                         BANKMASK(ADRES), 4
#define ADRES5                         BANKMASK(ADRES), 5
#define ADRES6                         BANKMASK(ADRES), 6
#define ADRES7                         BANKMASK(ADRES), 7
#ifndef _LIB_BUILD
#endif
CM2CON0                                equ 000Bh
#define nC2WU                          BANKMASK(CM2CON0), 0
#define C2PREF1                        BANKMASK(CM2CON0), 1
#define C2NREF                         BANKMASK(CM2CON0), 2
#define C2ON                           BANKMASK(CM2CON0), 3
#define C2PREF2                        BANKMASK(CM2CON0), 4
#define C2POL                          BANKMASK(CM2CON0), 5
#define nC2OUTEN                       BANKMASK(CM2CON0), 6
#define C2OUT                          BANKMASK(CM2CON0), 7
#ifndef _LIB_BUILD
#endif
VRCON                                  equ 000Ch
#define VRR                            BANKMASK(VRCON), 5
#define VROE                           BANKMASK(VRCON), 6
#define VREN                           BANKMASK(VRCON), 7
#define VR0                            BANKMASK(VRCON), 0
#define VR1                            BANKMASK(VRCON), 1
#define VR2                            BANKMASK(VRCON), 2
#define VR3                            BANKMASK(VRCON), 3
#ifndef _LIB_BUILD
#endif
EECON                                  equ 0021h
#define RD                             BANKMASK(EECON), 0
#define WR                             BANKMASK(EECON), 1
#define WREN                           BANKMASK(EECON), 2
#define WRERR                          BANKMASK(EECON), 3
#define FREE                           BANKMASK(EECON), 4
#ifndef _LIB_BUILD
#endif
EEDATA                                 equ 0025h
EEADR                                  equ 0026h

#endif
#endif

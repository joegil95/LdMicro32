#ifndef _CASPIC_H_
#warning Header file cas16f1507.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS16F1507_H_
#define _CAS16F1507_H_

INDF0                                  equ 0000h
INDF1                                  equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#ifndef _LIB_BUILD
#endif
FSR0L                                  equ 0004h
FSR0H                                  equ 0005h
FSR1L                                  equ 0006h
FSR1H                                  equ 0007h
BSR                                    equ 0008h
#define BSR0_bit                       BANKMASK(BSR), 0
#define BSR1_bit                       BANKMASK(BSR), 1
#define BSR2_bit                       BANKMASK(BSR), 2
#define BSR3_bit                       BANKMASK(BSR), 3
#define BSR4_bit                       BANKMASK(BSR), 4
#ifndef _LIB_BUILD
#endif
WREG                                   equ 0009h
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define IOCIF_bit                      BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define TMR0IF_bit                     BANKMASK(INTCON), 2
#define IOCIE_bit                      BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define TMR0IE_bit                     BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#define T0IF_bit                       BANKMASK(INTCON), 2
#define T0IE_bit                       BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PORTA                                  equ 000Ch
#define RA0_bit                        BANKMASK(PORTA), 0
#define RA1_bit                        BANKMASK(PORTA), 1
#define RA2_bit                        BANKMASK(PORTA), 2
#define RA3_bit                        BANKMASK(PORTA), 3
#define RA4_bit                        BANKMASK(PORTA), 4
#define RA5_bit                        BANKMASK(PORTA), 5
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 000Dh
#define RB4_bit                        BANKMASK(PORTB), 4
#define RB5_bit                        BANKMASK(PORTB), 5
#define RB6_bit                        BANKMASK(PORTB), 6
#define RB7_bit                        BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 000Eh
#define RC0_bit                        BANKMASK(PORTC), 0
#define RC1_bit                        BANKMASK(PORTC), 1
#define RC2_bit                        BANKMASK(PORTC), 2
#define RC3_bit                        BANKMASK(PORTC), 3
#define RC4_bit                        BANKMASK(PORTC), 4
#define RC5_bit                        BANKMASK(PORTC), 5
#define RC6_bit                        BANKMASK(PORTC), 6
#define RC7_bit                        BANKMASK(PORTC), 7
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 0011h
#define TMR1IF_bit                     BANKMASK(PIR1), 0
#define TMR2IF_bit                     BANKMASK(PIR1), 1
#define ADIF_bit                       BANKMASK(PIR1), 6
#define TMR1GIF_bit                    BANKMASK(PIR1), 7
#ifndef _LIB_BUILD
#endif
PIR2                                   equ 0012h
#define NCOIF_bit                      BANKMASK(PIR2), 2
#ifndef _LIB_BUILD
#endif
PIR3                                   equ 0013h
#define CLC1IF_bit                     BANKMASK(PIR3), 0
#define CLC2IF_bit                     BANKMASK(PIR3), 1
#ifndef _LIB_BUILD
#endif
TMR0                                   equ 0015h
TMR1L                                  equ 0016h
TMR1H                                  equ 0017h
T1CON                                  equ 0018h
#define TMR1ON_bit                     BANKMASK(T1CON), 0
#define nT1SYNC_bit                    BANKMASK(T1CON), 2
#define T1OSCEN_bit                    BANKMASK(T1CON), 3
#define T1CKPS0_bit                    BANKMASK(T1CON), 4
#define T1CKPS1_bit                    BANKMASK(T1CON), 5
#define TMR1CS0_bit                    BANKMASK(T1CON), 6
#define TMR1CS1_bit                    BANKMASK(T1CON), 7
#ifndef _LIB_BUILD
#endif
T1GCON                                 equ 0019h
#define T1GVAL_bit                     BANKMASK(T1GCON), 2
#define T1GGO_nDONE_bit                BANKMASK(T1GCON), 3
#define T1GSPM_bit                     BANKMASK(T1GCON), 4
#define T1GTM_bit                      BANKMASK(T1GCON), 5
#define T1GPOL_bit                     BANKMASK(T1GCON), 6
#define TMR1GE_bit                     BANKMASK(T1GCON), 7
#define T1GSS0_bit                     BANKMASK(T1GCON), 0
#define T1GSS1_bit                     BANKMASK(T1GCON), 1
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 001Ah
PR2                                    equ 001Bh
T2CON                                  equ 001Ch
#define TMR2ON_bit                     BANKMASK(T2CON), 2
#define T2CKPS0_bit                    BANKMASK(T2CON), 0
#define T2CKPS1_bit                    BANKMASK(T2CON), 1
#define TOUTPS0_bit                    BANKMASK(T2CON), 3
#define TOUTPS1_bit                    BANKMASK(T2CON), 4
#define TOUTPS2_bit                    BANKMASK(T2CON), 5
#define TOUTPS3_bit                    BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 008Ch
#define TRISA0_bit                     BANKMASK(TRISA), 0
#define TRISA1_bit                     BANKMASK(TRISA), 1
#define TRISA2_bit                     BANKMASK(TRISA), 2
#define TRISA3_bit                     BANKMASK(TRISA), 3
#define TRISA4_bit                     BANKMASK(TRISA), 4
#define TRISA5_bit                     BANKMASK(TRISA), 5
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 008Dh
#define TRISB4_bit                     BANKMASK(TRISB), 4
#define TRISB5_bit                     BANKMASK(TRISB), 5
#define TRISB6_bit                     BANKMASK(TRISB), 6
#define TRISB7_bit                     BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
TRISC                                  equ 008Eh
#define TRISC0_bit                     BANKMASK(TRISC), 0
#define TRISC1_bit                     BANKMASK(TRISC), 1
#define TRISC2_bit                     BANKMASK(TRISC), 2
#define TRISC3_bit                     BANKMASK(TRISC), 3
#define TRISC4_bit                     BANKMASK(TRISC), 4
#define TRISC5_bit                     BANKMASK(TRISC), 5
#define TRISC6_bit                     BANKMASK(TRISC), 6
#define TRISC7_bit                     BANKMASK(TRISC), 7
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 0091h
#define TMR1IE_bit                     BANKMASK(PIE1), 0
#define TMR2IE_bit                     BANKMASK(PIE1), 1
#define ADIE_bit                       BANKMASK(PIE1), 6
#define TMR1GIE_bit                    BANKMASK(PIE1), 7
#ifndef _LIB_BUILD
#endif
PIE2                                   equ 0092h
#define NCOIE_bit                      BANKMASK(PIE2), 2
#ifndef _LIB_BUILD
#endif
PIE3                                   equ 0093h
#define CLC1E_bit                      BANKMASK(PIE3), 0
#define CLC2IE_bit                     BANKMASK(PIE3), 1
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0095h
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define TMR0SE_bit                     BANKMASK(OPTION_REG), 4
#define TMR0CS_bit                     BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nWPUEN_bit                     BANKMASK(OPTION_REG), 7
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#ifndef _LIB_BUILD
#endif
PCON                                   equ 0096h
#define nBOR_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#define nRI_bit                        BANKMASK(PCON), 2
#define nRMCLR_bit                     BANKMASK(PCON), 3
#define nRWDT_bit                      BANKMASK(PCON), 4
#define STKUNF_bit                     BANKMASK(PCON), 6
#define STKOVF_bit                     BANKMASK(PCON), 7
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0097h
#define SWDTEN_bit                     BANKMASK(WDTCON), 0
#define WDTPS0_bit                     BANKMASK(WDTCON), 1
#define WDTPS1_bit                     BANKMASK(WDTCON), 2
#define WDTPS2_bit                     BANKMASK(WDTCON), 3
#define WDTPS3_bit                     BANKMASK(WDTCON), 4
#define WDTPS4_bit                     BANKMASK(WDTCON), 5
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 0099h
#define SCS0_bit                       BANKMASK(OSCCON), 0
#define SCS1_bit                       BANKMASK(OSCCON), 1
#define IRCF0_bit                      BANKMASK(OSCCON), 3
#define IRCF1_bit                      BANKMASK(OSCCON), 4
#define IRCF2_bit                      BANKMASK(OSCCON), 5
#define IRCF3_bit                      BANKMASK(OSCCON), 6
#ifndef _LIB_BUILD
#endif
OSCSTAT                                equ 009Ah
#define HFIOFS_bit                     BANKMASK(OSCSTAT), 0
#define LFIOFR_bit                     BANKMASK(OSCSTAT), 1
#define HFIOFR_bit                     BANKMASK(OSCSTAT), 4
#define OSTS_bit                       BANKMASK(OSCSTAT), 5
#define SOSCR_bit                      BANKMASK(OSCSTAT), 7
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 009Bh
ADRESH                                 equ 009Ch
ADCON0                                 equ 009Dh
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 1
#define ADGO_bit                       BANKMASK(ADCON0), 1
#define CHS0_bit                       BANKMASK(ADCON0), 2
#define CHS1_bit                       BANKMASK(ADCON0), 3
#define CHS2_bit                       BANKMASK(ADCON0), 4
#define CHS3_bit                       BANKMASK(ADCON0), 5
#define CHS4_bit                       BANKMASK(ADCON0), 6
#define GO_bit                         BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 009Eh
#define ADFM_bit                       BANKMASK(ADCON1), 7
#define ADPREF0_bit                    BANKMASK(ADCON1), 0
#define ADPREF1_bit                    BANKMASK(ADCON1), 1
#define ADCS0_bit                      BANKMASK(ADCON1), 4
#define ADCS1_bit                      BANKMASK(ADCON1), 5
#define ADCS2_bit                      BANKMASK(ADCON1), 6
#ifndef _LIB_BUILD
#endif
ADCON2                                 equ 009Fh
#define TRIGSEL0_bit                   BANKMASK(ADCON2), 4
#define TRIGSEL1_bit                   BANKMASK(ADCON2), 5
#define TRIGSEL2_bit                   BANKMASK(ADCON2), 6
#define TRIGSEL3_bit                   BANKMASK(ADCON2), 7
#ifndef _LIB_BUILD
#endif
LATA                                   equ 010Ch
#define LATA0_bit                      BANKMASK(LATA), 0
#define LATA1_bit                      BANKMASK(LATA), 1
#define LATA2_bit                      BANKMASK(LATA), 2
#define LATA4_bit                      BANKMASK(LATA), 4
#define LATA5_bit                      BANKMASK(LATA), 5
#ifndef _LIB_BUILD
#endif
LATB                                   equ 010Dh
#define LATB4_bit                      BANKMASK(LATB), 4
#define LATB5_bit                      BANKMASK(LATB), 5
#define LATB6_bit                      BANKMASK(LATB), 6
#define LATB7_bit                      BANKMASK(LATB), 7
#ifndef _LIB_BUILD
#endif
LATC                                   equ 010Eh
#define LATC0_bit                      BANKMASK(LATC), 0
#define LATC1_bit                      BANKMASK(LATC), 1
#define LATC2_bit                      BANKMASK(LATC), 2
#define LATC3_bit                      BANKMASK(LATC), 3
#define LATC4_bit                      BANKMASK(LATC), 4
#define LATC5_bit                      BANKMASK(LATC), 5
#define LATC6_bit                      BANKMASK(LATC), 6
#define LATC7_bit                      BANKMASK(LATC), 7
#ifndef _LIB_BUILD
#endif
BORCON                                 equ 0116h
#define BORRDY_bit                     BANKMASK(BORCON), 0
#define BORFS_bit                      BANKMASK(BORCON), 6
#define SBOREN_bit                     BANKMASK(BORCON), 7
#ifndef _LIB_BUILD
#endif
FVRCON                                 equ 0117h
#define FVRRDY_bit                     BANKMASK(FVRCON), 6
#define FVREN_bit                      BANKMASK(FVRCON), 7
#define ADFVR0_bit                     BANKMASK(FVRCON), 0
#define ADFVR1_bit                     BANKMASK(FVRCON), 1
#ifndef _LIB_BUILD
#endif
APFCON                                 equ 011Dh
#define NCOSEL_bit                     BANKMASK(APFCON), 0
#define CLC1SEL_bit                    BANKMASK(APFCON), 1
#ifndef _LIB_BUILD
#endif
ANSELA                                 equ 018Ch
#define ANSA0_bit                      BANKMASK(ANSELA), 0
#define ANSA1_bit                      BANKMASK(ANSELA), 1
#define ANSA2_bit                      BANKMASK(ANSELA), 2
#define ANSA4_bit                      BANKMASK(ANSELA), 4
#ifndef _LIB_BUILD
#endif
ANSELB                                 equ 018Dh
#define ANSB4_bit                      BANKMASK(ANSELB), 4
#define ANSB5_bit                      BANKMASK(ANSELB), 5
#ifndef _LIB_BUILD
#endif
ANSELC                                 equ 018Eh
#define ANSC0_bit                      BANKMASK(ANSELC), 0
#define ANSC1_bit                      BANKMASK(ANSELC), 1
#define ANSC2_bit                      BANKMASK(ANSELC), 2
#define ANSC3_bit                      BANKMASK(ANSELC), 3
#define ANSC6_bit                      BANKMASK(ANSELC), 6
#define ANSC7_bit                      BANKMASK(ANSELC), 7
#ifndef _LIB_BUILD
#endif
PMADRL                                 equ 0191h
PMADRH                                 equ 0192h
#ifndef _LIB_BUILD
#endif
PMDATL                                 equ 0193h
PMDATH                                 equ 0194h
#ifndef _LIB_BUILD
#endif
PMCON1                                 equ 0195h
#define RD_bit                         BANKMASK(PMCON1), 0
#define WR_bit                         BANKMASK(PMCON1), 1
#define WREN_bit                       BANKMASK(PMCON1), 2
#define WRERR_bit                      BANKMASK(PMCON1), 3
#define FREE_bit                       BANKMASK(PMCON1), 4
#define LWLO_bit                       BANKMASK(PMCON1), 5
#define CFGS_bit                       BANKMASK(PMCON1), 6
#define EEPGD_bit                      BANKMASK(PMCON1), 7
#ifndef _LIB_BUILD
#endif
PMCON2                                 equ 0196h
VREGCON                                equ 0197h
#define VREGPM0_bit                    BANKMASK(VREGCON), 0
#define VREGPM1_bit                    BANKMASK(VREGCON), 1
#ifndef _LIB_BUILD
#endif
WPUA                                   equ 020Ch
#define WPUA0_bit                      BANKMASK(WPUA), 0
#define WPUA1_bit                      BANKMASK(WPUA), 1
#define WPUA2_bit                      BANKMASK(WPUA), 2
#define WPUA3_bit                      BANKMASK(WPUA), 3
#define WPUA4_bit                      BANKMASK(WPUA), 4
#define WPUA5_bit                      BANKMASK(WPUA), 5
#ifndef _LIB_BUILD
#endif
WPUB                                   equ 020Dh
#define WPUB4_bit                      BANKMASK(WPUB), 4
#define WPUB5_bit                      BANKMASK(WPUB), 5
#define WPUB6_bit                      BANKMASK(WPUB), 6
#define WPUB7_bit                      BANKMASK(WPUB), 7
#ifndef _LIB_BUILD
#endif
IOCAP                                  equ 0391h
#define IOCAP0_bit                     BANKMASK(IOCAP), 0
#define IOCAP1_bit                     BANKMASK(IOCAP), 1
#define IOCAP2_bit                     BANKMASK(IOCAP), 2
#define IOCAP3_bit                     BANKMASK(IOCAP), 3
#define IOCAP4_bit                     BANKMASK(IOCAP), 4
#define IOCAP5_bit                     BANKMASK(IOCAP), 5
#ifndef _LIB_BUILD
#endif
IOCAN                                  equ 0392h
#define IOCAN0_bit                     BANKMASK(IOCAN), 0
#define IOCAN1_bit                     BANKMASK(IOCAN), 1
#define IOCAN2_bit                     BANKMASK(IOCAN), 2
#define IOCAN3_bit                     BANKMASK(IOCAN), 3
#define IOCAN4_bit                     BANKMASK(IOCAN), 4
#define IOCAN5_bit                     BANKMASK(IOCAN), 5
#ifndef _LIB_BUILD
#endif
IOCAF                                  equ 0393h
#define IOCAF0_bit                     BANKMASK(IOCAF), 0
#define IOCAF1_bit                     BANKMASK(IOCAF), 1
#define IOCAF2_bit                     BANKMASK(IOCAF), 2
#define IOCAF3_bit                     BANKMASK(IOCAF), 3
#define IOCAF4_bit                     BANKMASK(IOCAF), 4
#define IOCAF5_bit                     BANKMASK(IOCAF), 5
#ifndef _LIB_BUILD
#endif
IOCBP                                  equ 0394h
#define IOCBP4_bit                     BANKMASK(IOCBP), 4
#define IOCBP5_bit                     BANKMASK(IOCBP), 5
#define IOCBP6_bit                     BANKMASK(IOCBP), 6
#define IOCBP7_bit                     BANKMASK(IOCBP), 7
#ifndef _LIB_BUILD
#endif
IOCBN                                  equ 0395h
#define IOCBN4_bit                     BANKMASK(IOCBN), 4
#define IOCBN5_bit                     BANKMASK(IOCBN), 5
#define IOCBN6_bit                     BANKMASK(IOCBN), 6
#define IOCBN7_bit                     BANKMASK(IOCBN), 7
#ifndef _LIB_BUILD
#endif
IOCBF                                  equ 0396h
#define IOCBF4_bit                     BANKMASK(IOCBF), 4
#define IOCBF5_bit                     BANKMASK(IOCBF), 5
#define IOCBF6_bit                     BANKMASK(IOCBF), 6
#define IOCBF7_bit                     BANKMASK(IOCBF), 7
#ifndef _LIB_BUILD
#endif
CLCDATA                                equ 0F0Fh
#define MCLC1OUT_bit                   BANKMASK(CLCDATA), 0
#define MCLC2OUT_bit                   BANKMASK(CLCDATA), 1
#ifndef _LIB_BUILD
#endif
BSR_ICDSHAD                            equ 0FE3h
#ifndef _LIB_BUILD
#endif
STATUS_SHAD                            equ 0FE4h
#define C_SHAD_bit                     BANKMASK(STATUS_SHAD), 0
#define DC_SHAD_bit                    BANKMASK(STATUS_SHAD), 1
#define Z_SHAD_bit                     BANKMASK(STATUS_SHAD), 2
#ifndef _LIB_BUILD
#endif
WREG_SHAD                              equ 0FE5h
BSR_SHAD                               equ 0FE6h
#ifndef _LIB_BUILD
#endif
PCLATH_SHAD                            equ 0FE7h
#ifndef _LIB_BUILD
#endif
FSR0L_SHAD                             equ 0FE8h
FSR0H_SHAD                             equ 0FE9h
FSR1L_SHAD                             equ 0FEAh
FSR1H_SHAD                             equ 0FEBh
STKPTR                                 equ 0FEDh
#ifndef _LIB_BUILD
#endif
TOSL                                   equ 0FEEh
TOSH                                   equ 0FEFh
#ifndef _LIB_BUILD
#endif

#endif
#endif

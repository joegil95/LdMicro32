#ifndef _CASPIC_H_
#warning Header file cas12f683.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS12F683_H_
#define _CAS12F683_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define IRP_bit                        BANKMASK(STATUS), 7
#define RP0_bit                        BANKMASK(STATUS), 5
#define RP1_bit                        BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
GPIO                                   equ 0005h
#define GP0_bit                        BANKMASK(GPIO), 0
#define GP1_bit                        BANKMASK(GPIO), 1
#define GP2_bit                        BANKMASK(GPIO), 2
#define GP3_bit                        BANKMASK(GPIO), 3
#define GP4_bit                        BANKMASK(GPIO), 4
#define GP5_bit                        BANKMASK(GPIO), 5
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define GPIF_bit                       BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define T0IF_bit                       BANKMASK(INTCON), 2
#define GPIE_bit                       BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define T0IE_bit                       BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#define TMR0IF_bit                     BANKMASK(INTCON), 2
#define TMR0IE_bit                     BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF_bit                     BANKMASK(PIR1), 0
#define TMR2IF_bit                     BANKMASK(PIR1), 1
#define OSFIF_bit                      BANKMASK(PIR1), 2
#define CMIF_bit                       BANKMASK(PIR1), 3
#define CCP1IF_bit                     BANKMASK(PIR1), 5
#define ADIF_bit                       BANKMASK(PIR1), 6
#define EEIF_bit                       BANKMASK(PIR1), 7
#define T1IF_bit                       BANKMASK(PIR1), 0
#define T2IF_bit                       BANKMASK(PIR1), 1
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Eh
TMR1H                                  equ 000Fh
T1CON                                  equ 0010h
#define TMR1ON_bit                     BANKMASK(T1CON), 0
#define TMR1CS_bit                     BANKMASK(T1CON), 1
#define nT1SYNC_bit                    BANKMASK(T1CON), 2
#define T1OSCEN_bit                    BANKMASK(T1CON), 3
#define TMR1GE_bit                     BANKMASK(T1CON), 6
#define T1GINV_bit                     BANKMASK(T1CON), 7
#define T1CKPS0_bit                    BANKMASK(T1CON), 4
#define T1CKPS1_bit                    BANKMASK(T1CON), 5
#define T1GE_bit                       BANKMASK(T1CON), 6
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 0011h
T2CON                                  equ 0012h
#define TMR2ON_bit                     BANKMASK(T2CON), 2
#define T2CKPS0_bit                    BANKMASK(T2CON), 0
#define T2CKPS1_bit                    BANKMASK(T2CON), 1
#define TOUTPS0_bit                    BANKMASK(T2CON), 3
#define TOUTPS1_bit                    BANKMASK(T2CON), 4
#define TOUTPS2_bit                    BANKMASK(T2CON), 5
#define TOUTPS3_bit                    BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0013h
CCPR1H                                 equ 0014h
CCP1CON                                equ 0015h
#define CCP1M0_bit                     BANKMASK(CCP1CON), 0
#define CCP1M1_bit                     BANKMASK(CCP1CON), 1
#define CCP1M2_bit                     BANKMASK(CCP1CON), 2
#define CCP1M3_bit                     BANKMASK(CCP1CON), 3
#define DC1B0_bit                      BANKMASK(CCP1CON), 4
#define DC1B1_bit                      BANKMASK(CCP1CON), 5
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0018h
#define SWDTEN_bit                     BANKMASK(WDTCON), 0
#define WDTPS0_bit                     BANKMASK(WDTCON), 1
#define WDTPS1_bit                     BANKMASK(WDTCON), 2
#define WDTPS2_bit                     BANKMASK(WDTCON), 3
#define WDTPS3_bit                     BANKMASK(WDTCON), 4
#ifndef _LIB_BUILD
#endif
CMCON0                                 equ 0019h
#define CIS_bit                        BANKMASK(CMCON0), 3
#define CINV_bit                       BANKMASK(CMCON0), 4
#define COUT_bit                       BANKMASK(CMCON0), 6
#define CM0_bit                        BANKMASK(CMCON0), 0
#define CM1_bit                        BANKMASK(CMCON0), 1
#define CM2_bit                        BANKMASK(CMCON0), 2
#ifndef _LIB_BUILD
#endif
CMCON1                                 equ 001Ah
#define CMSYNC_bit                     BANKMASK(CMCON1), 0
#define T1GSS_bit                      BANKMASK(CMCON1), 1
#ifndef _LIB_BUILD
#endif
ADRESH                                 equ 001Eh
ADCON0                                 equ 001Fh
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 1
#define VCFG_bit                       BANKMASK(ADCON0), 6
#define ADFM_bit                       BANKMASK(ADCON0), 7
#define GO_bit                         BANKMASK(ADCON0), 1
#define CHS0_bit                       BANKMASK(ADCON0), 2
#define CHS1_bit                       BANKMASK(ADCON0), 3
#define CHS2_bit                       BANKMASK(ADCON0), 4
#define nDONE_bit                      BANKMASK(ADCON0), 1
#define GO_DONE_bit                    BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nGPPU_bit                      BANKMASK(OPTION_REG), 7
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISIO                                 equ 0085h
#define TRISIO0_bit                    BANKMASK(TRISIO), 0
#define TRISIO1_bit                    BANKMASK(TRISIO), 1
#define TRISIO2_bit                    BANKMASK(TRISIO), 2
#define TRISIO3_bit                    BANKMASK(TRISIO), 3
#define TRISIO4_bit                    BANKMASK(TRISIO), 4
#define TRISIO5_bit                    BANKMASK(TRISIO), 5
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE_bit                     BANKMASK(PIE1), 0
#define TMR2IE_bit                     BANKMASK(PIE1), 1
#define OSFIE_bit                      BANKMASK(PIE1), 2
#define CMIE_bit                       BANKMASK(PIE1), 3
#define CCP1IE_bit                     BANKMASK(PIE1), 5
#define ADIE_bit                       BANKMASK(PIE1), 6
#define EEIE_bit                       BANKMASK(PIE1), 7
#define T1IE_bit                       BANKMASK(PIE1), 0
#define T2IE_bit                       BANKMASK(PIE1), 1
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOD_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#define SBODEN_bit                     BANKMASK(PCON), 4
#define ULPWUE_bit                     BANKMASK(PCON), 5
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 008Fh
#define SCS_bit                        BANKMASK(OSCCON), 0
#define LTS_bit                        BANKMASK(OSCCON), 1
#define HTS_bit                        BANKMASK(OSCCON), 2
#define OSTS_bit                       BANKMASK(OSCCON), 3
#define IRCF0_bit                      BANKMASK(OSCCON), 4
#define IRCF1_bit                      BANKMASK(OSCCON), 5
#define IRCF2_bit                      BANKMASK(OSCCON), 6
#ifndef _LIB_BUILD
#endif
OSCTUNE                                equ 0090h
#define TUN0_bit                       BANKMASK(OSCTUNE), 0
#define TUN1_bit                       BANKMASK(OSCTUNE), 1
#define TUN2_bit                       BANKMASK(OSCTUNE), 2
#define TUN3_bit                       BANKMASK(OSCTUNE), 3
#define TUN4_bit                       BANKMASK(OSCTUNE), 4
#ifndef _LIB_BUILD
#endif
PR2                                    equ 0092h
WPU                                    equ 0095h
WPUA                                   equ 0095h
#define WPU0_bit                       BANKMASK(WPU), 0
#define WPU1_bit                       BANKMASK(WPU), 1
#define WPU2_bit                       BANKMASK(WPU), 2
#define WPU4_bit                       BANKMASK(WPU), 4
#define WPU5_bit                       BANKMASK(WPU), 5
#define WPUA0_bit                      BANKMASK(WPU), 0
#define WPUA1_bit                      BANKMASK(WPU), 1
#define WPUA2_bit                      BANKMASK(WPU), 2
#define WPUA4_bit                      BANKMASK(WPU), 4
#define WPUA5_bit                      BANKMASK(WPU), 5
#ifndef _LIB_BUILD
#endif
IOC                                    equ 0096h
IOCA                                   equ 0096h
#define IOC0_bit                       BANKMASK(IOC), 0
#define IOC1_bit                       BANKMASK(IOC), 1
#define IOC2_bit                       BANKMASK(IOC), 2
#define IOC3_bit                       BANKMASK(IOC), 3
#define IOC4_bit                       BANKMASK(IOC), 4
#define IOC5_bit                       BANKMASK(IOC), 5
#define IOCA0_bit                      BANKMASK(IOC), 0
#define IOCA1_bit                      BANKMASK(IOC), 1
#define IOCA2_bit                      BANKMASK(IOC), 2
#define IOCA3_bit                      BANKMASK(IOC), 3
#define IOCA4_bit                      BANKMASK(IOC), 4
#define IOCA5_bit                      BANKMASK(IOC), 5
#ifndef _LIB_BUILD
#endif
VRCON                                  equ 0099h
#define VRR_bit                        BANKMASK(VRCON), 5
#define VREN_bit                       BANKMASK(VRCON), 7
#define VR0_bit                        BANKMASK(VRCON), 0
#define VR1_bit                        BANKMASK(VRCON), 1
#define VR2_bit                        BANKMASK(VRCON), 2
#define VR3_bit                        BANKMASK(VRCON), 3
#ifndef _LIB_BUILD
#endif
EEDAT                                  equ 009Ah
EEDATA                                 equ 009Ah
EEADR                                  equ 009Bh
EECON1                                 equ 009Ch
#define RD_bit                         BANKMASK(EECON1), 0
#define WR_bit                         BANKMASK(EECON1), 1
#define WREN_bit                       BANKMASK(EECON1), 2
#define WRERR_bit                      BANKMASK(EECON1), 3
#ifndef _LIB_BUILD
#endif
EECON2                                 equ 009Dh
ADRESL                                 equ 009Eh
ANSEL                                  equ 009Fh
#define ANS0_bit                       BANKMASK(ANSEL), 0
#define ANS1_bit                       BANKMASK(ANSEL), 1
#define ANS2_bit                       BANKMASK(ANSEL), 2
#define ANS3_bit                       BANKMASK(ANSEL), 3
#define ADCS0_bit                      BANKMASK(ANSEL), 4
#define ADCS1_bit                      BANKMASK(ANSEL), 5
#define ADCS2_bit                      BANKMASK(ANSEL), 6
#ifndef _LIB_BUILD
#endif

#endif
#endif

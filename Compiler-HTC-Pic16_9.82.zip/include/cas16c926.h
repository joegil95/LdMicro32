#ifndef _CASPIC_H_
#warning Header file cas16c926.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS16C926_H_
#define _CAS16C926_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define IRP_bit                        BANKMASK(STATUS), 7
#define RP0_bit                        BANKMASK(STATUS), 5
#define RP1_bit                        BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define RA0_bit                        BANKMASK(PORTA), 0
#define RA1_bit                        BANKMASK(PORTA), 1
#define RA2_bit                        BANKMASK(PORTA), 2
#define RA3_bit                        BANKMASK(PORTA), 3
#define RA4_bit                        BANKMASK(PORTA), 4
#define RA5_bit                        BANKMASK(PORTA), 5
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 0006h
#define RB0_bit                        BANKMASK(PORTB), 0
#define RB1_bit                        BANKMASK(PORTB), 1
#define RB2_bit                        BANKMASK(PORTB), 2
#define RB3_bit                        BANKMASK(PORTB), 3
#define RB4_bit                        BANKMASK(PORTB), 4
#define RB5_bit                        BANKMASK(PORTB), 5
#define RB6_bit                        BANKMASK(PORTB), 6
#define RB7_bit                        BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 0007h
#define RC0_bit                        BANKMASK(PORTC), 0
#define RC1_bit                        BANKMASK(PORTC), 1
#define RC2_bit                        BANKMASK(PORTC), 2
#define RC3_bit                        BANKMASK(PORTC), 3
#define RC4_bit                        BANKMASK(PORTC), 4
#define RC5_bit                        BANKMASK(PORTC), 5
#ifndef _LIB_BUILD
#endif
PORTD                                  equ 0008h
#define RD0_bit                        BANKMASK(PORTD), 0
#define RD1_bit                        BANKMASK(PORTD), 1
#define RD2_bit                        BANKMASK(PORTD), 2
#define RD3_bit                        BANKMASK(PORTD), 3
#define RD4_bit                        BANKMASK(PORTD), 4
#define RD5_bit                        BANKMASK(PORTD), 5
#define RD6_bit                        BANKMASK(PORTD), 6
#define RD7_bit                        BANKMASK(PORTD), 7
#ifndef _LIB_BUILD
#endif
PORTE                                  equ 0009h
#define RE0_bit                        BANKMASK(PORTE), 0
#define RE1_bit                        BANKMASK(PORTE), 1
#define RE2_bit                        BANKMASK(PORTE), 2
#define RE3_bit                        BANKMASK(PORTE), 3
#define RE4_bit                        BANKMASK(PORTE), 4
#define RE5_bit                        BANKMASK(PORTE), 5
#define RE6_bit                        BANKMASK(PORTE), 6
#define RE7_bit                        BANKMASK(PORTE), 7
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define RBIF_bit                       BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define T0IF_bit                       BANKMASK(INTCON), 2
#define RBIE_bit                       BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define T0IE_bit                       BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#define TMR0IF_bit                     BANKMASK(INTCON), 2
#define TMR0IE_bit                     BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF_bit                     BANKMASK(PIR1), 0
#define TMR2IF_bit                     BANKMASK(PIR1), 1
#define CCP1IF_bit                     BANKMASK(PIR1), 2
#define SSPIF_bit                      BANKMASK(PIR1), 3
#define ADIF_bit                       BANKMASK(PIR1), 6
#define LCDIF_bit                      BANKMASK(PIR1), 7
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Eh
TMR1H                                  equ 000Fh
T1CON                                  equ 0010h
#define TMR1ON_bit                     BANKMASK(T1CON), 0
#define TMR1CS_bit                     BANKMASK(T1CON), 1
#define nT1SYNC_bit                    BANKMASK(T1CON), 2
#define T1OSCEN_bit                    BANKMASK(T1CON), 3
#define T1INSYNC_bit                   BANKMASK(T1CON), 2
#define T1CKPS0_bit                    BANKMASK(T1CON), 4
#define T1CKPS1_bit                    BANKMASK(T1CON), 5
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 0011h
T2CON                                  equ 0012h
#define TMR2ON_bit                     BANKMASK(T2CON), 2
#define T2CKPS0_bit                    BANKMASK(T2CON), 0
#define T2CKPS1_bit                    BANKMASK(T2CON), 1
#define TOUTPS0_bit                    BANKMASK(T2CON), 3
#define TOUTPS1_bit                    BANKMASK(T2CON), 4
#define TOUTPS2_bit                    BANKMASK(T2CON), 5
#define TOUTPS3_bit                    BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
SSPBUF                                 equ 0013h
SSPCON                                 equ 0014h
#define CKP_bit                        BANKMASK(SSPCON), 4
#define SSPEN_bit                      BANKMASK(SSPCON), 5
#define SSPOV_bit                      BANKMASK(SSPCON), 6
#define WCOL_bit                       BANKMASK(SSPCON), 7
#define SSPM0_bit                      BANKMASK(SSPCON), 0
#define SSPM1_bit                      BANKMASK(SSPCON), 1
#define SSPM2_bit                      BANKMASK(SSPCON), 2
#define SSPM3_bit                      BANKMASK(SSPCON), 3
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0015h
CCPR1H                                 equ 0016h
CCP1CON                                equ 0017h
#define CCP1M0_bit                     BANKMASK(CCP1CON), 0
#define CCP1M1_bit                     BANKMASK(CCP1CON), 1
#define CCP1M2_bit                     BANKMASK(CCP1CON), 2
#define CCP1M3_bit                     BANKMASK(CCP1CON), 3
#define CCP1Y_bit                      BANKMASK(CCP1CON), 4
#define CCP1X_bit                      BANKMASK(CCP1CON), 5
#ifndef _LIB_BUILD
#endif
ADRESH                                 equ 001Eh
ADCON0                                 equ 001Fh
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 2
#define GO_bit                         BANKMASK(ADCON0), 2
#define CHS0_bit                       BANKMASK(ADCON0), 3
#define CHS1_bit                       BANKMASK(ADCON0), 4
#define CHS2_bit                       BANKMASK(ADCON0), 5
#define ADCS0_bit                      BANKMASK(ADCON0), 6
#define ADCS1_bit                      BANKMASK(ADCON0), 7
#define nDONE_bit                      BANKMASK(ADCON0), 2
#define GO_DONE_bit                    BANKMASK(ADCON0), 2
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nRBPU_bit                      BANKMASK(OPTION_REG), 7
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 0085h
#define TRISA0_bit                     BANKMASK(TRISA), 0
#define TRISA1_bit                     BANKMASK(TRISA), 1
#define TRISA2_bit                     BANKMASK(TRISA), 2
#define TRISA3_bit                     BANKMASK(TRISA), 3
#define TRISA4_bit                     BANKMASK(TRISA), 4
#define TRISA5_bit                     BANKMASK(TRISA), 5
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 0086h
#define TRISB0_bit                     BANKMASK(TRISB), 0
#define TRISB1_bit                     BANKMASK(TRISB), 1
#define TRISB2_bit                     BANKMASK(TRISB), 2
#define TRISB3_bit                     BANKMASK(TRISB), 3
#define TRISB4_bit                     BANKMASK(TRISB), 4
#define TRISB5_bit                     BANKMASK(TRISB), 5
#define TRISB6_bit                     BANKMASK(TRISB), 6
#define TRISB7_bit                     BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
TRISC                                  equ 0087h
#define TRISC0_bit                     BANKMASK(TRISC), 0
#define TRISC1_bit                     BANKMASK(TRISC), 1
#define TRISC2_bit                     BANKMASK(TRISC), 2
#define TRISC3_bit                     BANKMASK(TRISC), 3
#define TRISC4_bit                     BANKMASK(TRISC), 4
#define TRISC5_bit                     BANKMASK(TRISC), 5
#ifndef _LIB_BUILD
#endif
TRISD                                  equ 0088h
#define TRISD0_bit                     BANKMASK(TRISD), 0
#define TRISD1_bit                     BANKMASK(TRISD), 1
#define TRISD2_bit                     BANKMASK(TRISD), 2
#define TRISD3_bit                     BANKMASK(TRISD), 3
#define TRISD4_bit                     BANKMASK(TRISD), 4
#define TRISD5_bit                     BANKMASK(TRISD), 5
#define TRISD6_bit                     BANKMASK(TRISD), 6
#define TRISD7_bit                     BANKMASK(TRISD), 7
#ifndef _LIB_BUILD
#endif
TRISE                                  equ 0089h
#define TRISE0_bit                     BANKMASK(TRISE), 0
#define TRISE1_bit                     BANKMASK(TRISE), 1
#define TRISE2_bit                     BANKMASK(TRISE), 2
#define TRISE3_bit                     BANKMASK(TRISE), 3
#define TRISE4_bit                     BANKMASK(TRISE), 4
#define TRISE5_bit                     BANKMASK(TRISE), 5
#define TRISE6_bit                     BANKMASK(TRISE), 6
#define TRISE7_bit                     BANKMASK(TRISE), 7
#define PSPMODE_bit                    BANKMASK(TRISE), 4
#define IBOV_bit                       BANKMASK(TRISE), 5
#define OBF_bit                        BANKMASK(TRISE), 6
#define IBF_bit                        BANKMASK(TRISE), 7
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE_bit                     BANKMASK(PIE1), 0
#define TMR2IE_bit                     BANKMASK(PIE1), 1
#define CCP1IE_bit                     BANKMASK(PIE1), 2
#define SSPIE_bit                      BANKMASK(PIE1), 3
#define ADIE_bit                       BANKMASK(PIE1), 6
#define LCDIE_bit                      BANKMASK(PIE1), 7
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOR_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#ifndef _LIB_BUILD
#endif
PR2                                    equ 0092h
SSPADD                                 equ 0093h
SSPSTAT                                equ 0094h
#define BF_bit                         BANKMASK(SSPSTAT), 0
#define UA_bit                         BANKMASK(SSPSTAT), 1
#define R_nW_bit                       BANKMASK(SSPSTAT), 2
#define S_bit                          BANKMASK(SSPSTAT), 3
#define P_bit                          BANKMASK(SSPSTAT), 4
#define D_nA_bit                       BANKMASK(SSPSTAT), 5
#define CKE_bit                        BANKMASK(SSPSTAT), 6
#define SMP_bit                        BANKMASK(SSPSTAT), 7
#define R_bit                          BANKMASK(SSPSTAT), 2
#define D_bit                          BANKMASK(SSPSTAT), 5
#define I2C_READ_bit                   BANKMASK(SSPSTAT), 2
#define I2C_START_bit                  BANKMASK(SSPSTAT), 3
#define I2C_STOP_bit                   BANKMASK(SSPSTAT), 4
#define I2C_DATA_bit                   BANKMASK(SSPSTAT), 5
#define R_W_bit                        BANKMASK(SSPSTAT), 2
#define D_A_bit                        BANKMASK(SSPSTAT), 5
#define READ_WRITE_bit                 BANKMASK(SSPSTAT), 2
#define DATA_ADDRESS_bit               BANKMASK(SSPSTAT), 5
#define nW_bit                         BANKMASK(SSPSTAT), 2
#define nA_bit                         BANKMASK(SSPSTAT), 5
#define nWRITE_bit                     BANKMASK(SSPSTAT), 2
#define nADDRESS_bit                   BANKMASK(SSPSTAT), 5
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 009Eh
ADCON1                                 equ 009Fh
#define ADFM_bit                       BANKMASK(ADCON1), 7
#define PCFG0_bit                      BANKMASK(ADCON1), 0
#define PCFG1_bit                      BANKMASK(ADCON1), 1
#define PCFG2_bit                      BANKMASK(ADCON1), 2
#define PCFG3_bit                      BANKMASK(ADCON1), 3
#ifndef _LIB_BUILD
#endif
PORTF                                  equ 0107h
#define RF0_bit                        BANKMASK(PORTF), 0
#define RF1_bit                        BANKMASK(PORTF), 1
#define RF2_bit                        BANKMASK(PORTF), 2
#define RF3_bit                        BANKMASK(PORTF), 3
#define RF4_bit                        BANKMASK(PORTF), 4
#define RF5_bit                        BANKMASK(PORTF), 5
#define RF6_bit                        BANKMASK(PORTF), 6
#define RF7_bit                        BANKMASK(PORTF), 7
#ifndef _LIB_BUILD
#endif
PORTG                                  equ 0108h
#define RG0_bit                        BANKMASK(PORTG), 0
#define RG1_bit                        BANKMASK(PORTG), 1
#define RG2_bit                        BANKMASK(PORTG), 2
#define RG3_bit                        BANKMASK(PORTG), 3
#define RG4_bit                        BANKMASK(PORTG), 4
#define RG5_bit                        BANKMASK(PORTG), 5
#define RG6_bit                        BANKMASK(PORTG), 6
#define RG7_bit                        BANKMASK(PORTG), 7
#ifndef _LIB_BUILD
#endif
PMCON1                                 equ 010Ch
#define RD_bit                         BANKMASK(PMCON1), 0
#ifndef _LIB_BUILD
#endif
LCDSE                                  equ 010Dh
#define SE0_bit                        BANKMASK(LCDSE), 0
#define SE5_bit                        BANKMASK(LCDSE), 1
#define SE9_bit                        BANKMASK(LCDSE), 2
#define SE12_bit                       BANKMASK(LCDSE), 3
#define SE16_bit                       BANKMASK(LCDSE), 4
#define SE20_bit                       BANKMASK(LCDSE), 5
#define SE27_bit                       BANKMASK(LCDSE), 6
#define SE29_bit                       BANKMASK(LCDSE), 7
#ifndef _LIB_BUILD
#endif
LCDPS                                  equ 010Eh
#define LP0_bit                        BANKMASK(LCDPS), 0
#define LP1_bit                        BANKMASK(LCDPS), 1
#define LP2_bit                        BANKMASK(LCDPS), 2
#define LP3_bit                        BANKMASK(LCDPS), 3
#ifndef _LIB_BUILD
#endif
LCDCON                                 equ 010Fh
#define VGEN_bit                       BANKMASK(LCDCON), 4
#define SLPEN_bit                      BANKMASK(LCDCON), 6
#define LCDEN_bit                      BANKMASK(LCDCON), 7
#define LMUX0_bit                      BANKMASK(LCDCON), 0
#define LMUX1_bit                      BANKMASK(LCDCON), 1
#define CS0_bit                        BANKMASK(LCDCON), 2
#define CS1_bit                        BANKMASK(LCDCON), 3
#define BIAS_bit                       BANKMASK(LCDCON), 4
#define WERR_bit                       BANKMASK(LCDCON), 5
#ifndef _LIB_BUILD
#endif
LCDD00                                 equ 0110h
#ifndef _LIB_BUILD
#endif
LCDD01                                 equ 0111h
#ifndef _LIB_BUILD
#endif
LCDD02                                 equ 0112h
#ifndef _LIB_BUILD
#endif
LCDD03                                 equ 0113h
#ifndef _LIB_BUILD
#endif
LCDD04                                 equ 0114h
#ifndef _LIB_BUILD
#endif
LCDD05                                 equ 0115h
#ifndef _LIB_BUILD
#endif
LCDD06                                 equ 0116h
#ifndef _LIB_BUILD
#endif
LCDD07                                 equ 0117h
#ifndef _LIB_BUILD
#endif
LCDD08                                 equ 0118h
#ifndef _LIB_BUILD
#endif
LCDD09                                 equ 0119h
#ifndef _LIB_BUILD
#endif
LCDD10                                 equ 011Ah
#ifndef _LIB_BUILD
#endif
LCDD11                                 equ 011Bh
#ifndef _LIB_BUILD
#endif
LCDD12                                 equ 011Ch
#ifndef _LIB_BUILD
#endif
LCDD13                                 equ 011Dh
#ifndef _LIB_BUILD
#endif
LCDD14                                 equ 011Eh
#ifndef _LIB_BUILD
#endif
LCDD15                                 equ 011Fh
#ifndef _LIB_BUILD
#endif
TRISF                                  equ 0187h
#define TRISF0_bit                     BANKMASK(TRISF), 0
#define TRISF1_bit                     BANKMASK(TRISF), 1
#define TRISF2_bit                     BANKMASK(TRISF), 2
#define TRISF3_bit                     BANKMASK(TRISF), 3
#define TRISF4_bit                     BANKMASK(TRISF), 4
#define TRISF5_bit                     BANKMASK(TRISF), 5
#define TRISF6_bit                     BANKMASK(TRISF), 6
#define TRISF7_bit                     BANKMASK(TRISF), 7
#ifndef _LIB_BUILD
#endif
TRISG                                  equ 0188h
#define TRISG0_bit                     BANKMASK(TRISG), 0
#define TRISG1_bit                     BANKMASK(TRISG), 1
#define TRISG2_bit                     BANKMASK(TRISG), 2
#define TRISG3_bit                     BANKMASK(TRISG), 3
#define TRISG4_bit                     BANKMASK(TRISG), 4
#define TRISG5_bit                     BANKMASK(TRISG), 5
#define TRISG6_bit                     BANKMASK(TRISG), 6
#define TRISG7_bit                     BANKMASK(TRISG), 7
#ifndef _LIB_BUILD
#endif
PMDATA                                 equ 018Ch
PMADR                                  equ 018Dh
PMDATH                                 equ 018Eh
#ifndef _LIB_BUILD
#endif
PMADRH                                 equ 018Fh
#ifndef _LIB_BUILD
#endif

#endif
#endif

#ifndef _CASPIC_H_
#warning Header file cas16f1947.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS16F1947_H_
#define _CAS16F1947_H_

INDF0                                  equ 0000h
INDF1                                  equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#ifndef _LIB_BUILD
#endif
FSR0L                                  equ 0004h
FSR0H                                  equ 0005h
FSR1L                                  equ 0006h
FSR1H                                  equ 0007h
BSR                                    equ 0008h
#define BSR0_bit                       BANKMASK(BSR), 0
#define BSR1_bit                       BANKMASK(BSR), 1
#define BSR2_bit                       BANKMASK(BSR), 2
#define BSR3_bit                       BANKMASK(BSR), 3
#define BSR4_bit                       BANKMASK(BSR), 4
#ifndef _LIB_BUILD
#endif
WREG                                   equ 0009h
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define IOCIF_bit                      BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define TMR0IF_bit                     BANKMASK(INTCON), 2
#define IOCIE_bit                      BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define TMR0IE_bit                     BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#define T0IF_bit                       BANKMASK(INTCON), 2
#define T0IE_bit                       BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PORTA                                  equ 000Ch
#define RA0_bit                        BANKMASK(PORTA), 0
#define RA1_bit                        BANKMASK(PORTA), 1
#define RA2_bit                        BANKMASK(PORTA), 2
#define RA3_bit                        BANKMASK(PORTA), 3
#define RA4_bit                        BANKMASK(PORTA), 4
#define RA5_bit                        BANKMASK(PORTA), 5
#define RA6_bit                        BANKMASK(PORTA), 6
#define RA7_bit                        BANKMASK(PORTA), 7
#define AN0_bit                        BANKMASK(PORTA), 0
#define AN1_bit                        BANKMASK(PORTA), 1
#define AN2_bit                        BANKMASK(PORTA), 2
#define AN3_bit                        BANKMASK(PORTA), 3
#define AN4_bit                        BANKMASK(PORTA), 5
#define CPS0_bit                       BANKMASK(PORTA), 0
#define CPS1_bit                       BANKMASK(PORTA), 1
#define CPS2_bit                       BANKMASK(PORTA), 2
#define CPS3_bit                       BANKMASK(PORTA), 3
#define CPS4_bit                       BANKMASK(PORTA), 5
#define SEG33_bit                      BANKMASK(PORTA), 0
#define SEG18_bit                      BANKMASK(PORTA), 1
#define SEG34_bit                      BANKMASK(PORTA), 2
#define SEG35_bit                      BANKMASK(PORTA), 3
#define SEG14_bit                      BANKMASK(PORTA), 4
#define SEG15_bit                      BANKMASK(PORTA), 5
#define SEG36_bit                      BANKMASK(PORTA), 6
#define SEG37_bit                      BANKMASK(PORTA), 7
#define VREFM_bit                      BANKMASK(PORTA), 2
#define VREFP_bit                      BANKMASK(PORTA), 3
#define T0CKI_bit                      BANKMASK(PORTA), 4
#define OSC2_bit                       BANKMASK(PORTA), 6
#define OSC1_bit                       BANKMASK(PORTA), 7
#define CLKOUT_bit                     BANKMASK(PORTA), 6
#define CLKIN_bit                      BANKMASK(PORTA), 7
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 000Dh
#define RB0_bit                        BANKMASK(PORTB), 0
#define RB1_bit                        BANKMASK(PORTB), 1
#define RB2_bit                        BANKMASK(PORTB), 2
#define RB3_bit                        BANKMASK(PORTB), 3
#define RB4_bit                        BANKMASK(PORTB), 4
#define RB5_bit                        BANKMASK(PORTB), 5
#define RB6_bit                        BANKMASK(PORTB), 6
#define RB7_bit                        BANKMASK(PORTB), 7
#define SEG30_bit                      BANKMASK(PORTB), 0
#define SEG8_bit                       BANKMASK(PORTB), 1
#define SEG9_bit                       BANKMASK(PORTB), 2
#define SEG10_bit                      BANKMASK(PORTB), 3
#define SEG11_bit                      BANKMASK(PORTB), 4
#define SEG29_bit                      BANKMASK(PORTB), 5
#define SEG38_bit                      BANKMASK(PORTB), 6
#define SEG39_bit                      BANKMASK(PORTB), 7
#define SRI_bit                        BANKMASK(PORTB), 0
#define T1G_bit                        BANKMASK(PORTB), 5
#define FLT0_bit                       BANKMASK(PORTB), 0
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 000Eh
#define RC0_bit                        BANKMASK(PORTC), 0
#define RC1_bit                        BANKMASK(PORTC), 1
#define RC2_bit                        BANKMASK(PORTC), 2
#define RC3_bit                        BANKMASK(PORTC), 3
#define RC4_bit                        BANKMASK(PORTC), 4
#define RC5_bit                        BANKMASK(PORTC), 5
#define RC6_bit                        BANKMASK(PORTC), 6
#define RC7_bit                        BANKMASK(PORTC), 7
#define SEG40_bit                      BANKMASK(PORTC), 0
#define SEG32_bit                      BANKMASK(PORTC), 1
#define SEG13_bit                      BANKMASK(PORTC), 2
#define SEG17_bit                      BANKMASK(PORTC), 3
#define SEG16_bit                      BANKMASK(PORTC), 4
#define SEG12_bit                      BANKMASK(PORTC), 5
#define SEG27_bit                      BANKMASK(PORTC), 6
#define SEG28_bit                      BANKMASK(PORTC), 7
#define T1OSO_bit                      BANKMASK(PORTC), 0
#define T1OSI_bit                      BANKMASK(PORTC), 1
#define SCK1_bit                       BANKMASK(PORTC), 3
#define SDI1_bit                       BANKMASK(PORTC), 4
#define SDO1_bit                       BANKMASK(PORTC), 5
#define TX1_bit                        BANKMASK(PORTC), 6
#define RX1_bit                        BANKMASK(PORTC), 7
#define T1CKI_bit                      BANKMASK(PORTC), 0
#define CCP1_bit                       BANKMASK(PORTC), 2
#define SCL1_bit                       BANKMASK(PORTC), 3
#define SDA1_bit                       BANKMASK(PORTC), 4
#define CK1_bit                        BANKMASK(PORTC), 6
#define DT1_bit                        BANKMASK(PORTC), 7
#define P1A_bit                        BANKMASK(PORTC), 2
#ifndef _LIB_BUILD
#endif
PORTD                                  equ 000Fh
#define RD0_bit                        BANKMASK(PORTD), 0
#define RD1_bit                        BANKMASK(PORTD), 1
#define RD2_bit                        BANKMASK(PORTD), 2
#define RD3_bit                        BANKMASK(PORTD), 3
#define RD4_bit                        BANKMASK(PORTD), 4
#define RD5_bit                        BANKMASK(PORTD), 5
#define RD6_bit                        BANKMASK(PORTD), 6
#define RD7_bit                        BANKMASK(PORTD), 7
#define SEG0_bit                       BANKMASK(PORTD), 0
#define SEG1_bit                       BANKMASK(PORTD), 1
#define SEG2_bit                       BANKMASK(PORTD), 2
#define SEG3_bit                       BANKMASK(PORTD), 3
#define SEG4_bit                       BANKMASK(PORTD), 4
#define SEG5_bit                       BANKMASK(PORTD), 5
#define SEG6_bit                       BANKMASK(PORTD), 6
#define SEG7_bit                       BANKMASK(PORTD), 7
#define SDO2_bit                       BANKMASK(PORTD), 4
#define SDI2_bit                       BANKMASK(PORTD), 5
#define SCK2_bit                       BANKMASK(PORTD), 6
#define nSS2_bit                       BANKMASK(PORTD), 7
#define SDA2_bit                       BANKMASK(PORTD), 5
#define SCL2_bit                       BANKMASK(PORTD), 6
#ifndef _LIB_BUILD
#endif
PORTE                                  equ 0010h
#define RE0_bit                        BANKMASK(PORTE), 0
#define RE1_bit                        BANKMASK(PORTE), 1
#define RE2_bit                        BANKMASK(PORTE), 2
#define RE3_bit                        BANKMASK(PORTE), 3
#define RE4_bit                        BANKMASK(PORTE), 4
#define RE5_bit                        BANKMASK(PORTE), 5
#define RE6_bit                        BANKMASK(PORTE), 6
#define RE7_bit                        BANKMASK(PORTE), 7
#define VLCD1_bit                      BANKMASK(PORTE), 0
#define VLCD2_bit                      BANKMASK(PORTE), 1
#define VLCD3_bit                      BANKMASK(PORTE), 2
#define COM0_bit                       BANKMASK(PORTE), 3
#define COM1_bit                       BANKMASK(PORTE), 4
#define COM2_bit                       BANKMASK(PORTE), 5
#define COM3_bit                       BANKMASK(PORTE), 6
#define SEG31_bit                      BANKMASK(PORTE), 7
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 0011h
#define TMR1IF_bit                     BANKMASK(PIR1), 0
#define TMR2IF_bit                     BANKMASK(PIR1), 1
#define CCP1IF_bit                     BANKMASK(PIR1), 2
#define SSP1IF_bit                     BANKMASK(PIR1), 3
#define TXIF_bit                       BANKMASK(PIR1), 4
#define RCIF_bit                       BANKMASK(PIR1), 5
#define ADIF_bit                       BANKMASK(PIR1), 6
#define TMR1GIF_bit                    BANKMASK(PIR1), 7
#define SSPIF_bit                      BANKMASK(PIR1), 3
#ifndef _LIB_BUILD
#endif
PIR2                                   equ 0012h
#define CCP2IF_bit                     BANKMASK(PIR2), 0
#define C3IF_bit                       BANKMASK(PIR2), 1
#define LCDIF_bit                      BANKMASK(PIR2), 2
#define BCLIF_bit                      BANKMASK(PIR2), 3
#define EEIF_bit                       BANKMASK(PIR2), 4
#define C1IF_bit                       BANKMASK(PIR2), 5
#define C2IF_bit                       BANKMASK(PIR2), 6
#define OSFIF_bit                      BANKMASK(PIR2), 7
#ifndef _LIB_BUILD
#endif
PIR3                                   equ 0013h
#define TMR4IF_bit                     BANKMASK(PIR3), 1
#define TMR6IF_bit                     BANKMASK(PIR3), 3
#define CCP3IF_bit                     BANKMASK(PIR3), 4
#define CCP4IF_bit                     BANKMASK(PIR3), 5
#define CCP5IF_bit                     BANKMASK(PIR3), 6
#ifndef _LIB_BUILD
#endif
PIR4                                   equ 0014h
#define SSP2IF_bit                     BANKMASK(PIR4), 0
#define BCL2IF_bit                     BANKMASK(PIR4), 1
#define TX2IF_bit                      BANKMASK(PIR4), 4
#define RC2IF_bit                      BANKMASK(PIR4), 5
#ifndef _LIB_BUILD
#endif
TMR0                                   equ 0015h
TMR1L                                  equ 0016h
TMR1H                                  equ 0017h
T1CON                                  equ 0018h
#define TMR1ON_bit                     BANKMASK(T1CON), 0
#define nT1SYNC_bit                    BANKMASK(T1CON), 2
#define T1OSCEN_bit                    BANKMASK(T1CON), 3
#define T1CKPS0_bit                    BANKMASK(T1CON), 4
#define T1CKPS1_bit                    BANKMASK(T1CON), 5
#define TMR1CS0_bit                    BANKMASK(T1CON), 6
#define TMR1CS1_bit                    BANKMASK(T1CON), 7
#ifndef _LIB_BUILD
#endif
T1GCON                                 equ 0019h
#define T1GSS0_bit                     BANKMASK(T1GCON), 0
#define T1GSS1_bit                     BANKMASK(T1GCON), 1
#define T1GVAL_bit                     BANKMASK(T1GCON), 2
#define T1GGO_nDONE_bit                BANKMASK(T1GCON), 3
#define T1GSPM_bit                     BANKMASK(T1GCON), 4
#define T1GTM_bit                      BANKMASK(T1GCON), 5
#define T1GPOL_bit                     BANKMASK(T1GCON), 6
#define TMR1GE_bit                     BANKMASK(T1GCON), 7
#define T1GGO_bit                      BANKMASK(T1GCON), 3
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 001Ah
PR2                                    equ 001Bh
T2CON                                  equ 001Ch
#define T2CKPS0_bit                    BANKMASK(T2CON), 0
#define T2CKPS1_bit                    BANKMASK(T2CON), 1
#define TMR2ON_bit                     BANKMASK(T2CON), 2
#define T2OUTPS0_bit                   BANKMASK(T2CON), 3
#define T2OUTPS1_bit                   BANKMASK(T2CON), 4
#define T2OUTPS2_bit                   BANKMASK(T2CON), 5
#define T2OUTPS3_bit                   BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
CPSCON0                                equ 001Eh
#define T0XCS_bit                      BANKMASK(CPSCON0), 0
#define CPSOUT_bit                     BANKMASK(CPSCON0), 1
#define CPSRNG0_bit                    BANKMASK(CPSCON0), 2
#define CPSRNG1_bit                    BANKMASK(CPSCON0), 3
#define CPSRM_bit                      BANKMASK(CPSCON0), 6
#define CPSON_bit                      BANKMASK(CPSCON0), 7
#ifndef _LIB_BUILD
#endif
CPSCON1                                equ 001Fh
#define CPSCH0_bit                     BANKMASK(CPSCON1), 0
#define CPSCH1_bit                     BANKMASK(CPSCON1), 1
#define CPSCH2_bit                     BANKMASK(CPSCON1), 2
#define CPSCH3_bit                     BANKMASK(CPSCON1), 3
#define CPSCH4_bit                     BANKMASK(CPSCON1), 4
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 008Ch
#define TRISA0_bit                     BANKMASK(TRISA), 0
#define TRISA1_bit                     BANKMASK(TRISA), 1
#define TRISA2_bit                     BANKMASK(TRISA), 2
#define TRISA3_bit                     BANKMASK(TRISA), 3
#define TRISA4_bit                     BANKMASK(TRISA), 4
#define TRISA5_bit                     BANKMASK(TRISA), 5
#define TRISA6_bit                     BANKMASK(TRISA), 6
#define TRISA7_bit                     BANKMASK(TRISA), 7
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 008Dh
#define TRISB0_bit                     BANKMASK(TRISB), 0
#define TRISB1_bit                     BANKMASK(TRISB), 1
#define TRISB2_bit                     BANKMASK(TRISB), 2
#define TRISB3_bit                     BANKMASK(TRISB), 3
#define TRISB4_bit                     BANKMASK(TRISB), 4
#define TRISB5_bit                     BANKMASK(TRISB), 5
#define TRISB6_bit                     BANKMASK(TRISB), 6
#define TRISB7_bit                     BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
TRISC                                  equ 008Eh
#define TRISC0_bit                     BANKMASK(TRISC), 0
#define TRISC1_bit                     BANKMASK(TRISC), 1
#define TRISC2_bit                     BANKMASK(TRISC), 2
#define TRISC3_bit                     BANKMASK(TRISC), 3
#define TRISC4_bit                     BANKMASK(TRISC), 4
#define TRISC5_bit                     BANKMASK(TRISC), 5
#define TRISC6_bit                     BANKMASK(TRISC), 6
#define TRISC7_bit                     BANKMASK(TRISC), 7
#ifndef _LIB_BUILD
#endif
TRISD                                  equ 008Fh
#define TRISD0_bit                     BANKMASK(TRISD), 0
#define TRISD1_bit                     BANKMASK(TRISD), 1
#define TRISD2_bit                     BANKMASK(TRISD), 2
#define TRISD3_bit                     BANKMASK(TRISD), 3
#define TRISD4_bit                     BANKMASK(TRISD), 4
#define TRISD5_bit                     BANKMASK(TRISD), 5
#define TRISD6_bit                     BANKMASK(TRISD), 6
#define TRISD7_bit                     BANKMASK(TRISD), 7
#ifndef _LIB_BUILD
#endif
TRISE                                  equ 0090h
#define TRISE0_bit                     BANKMASK(TRISE), 0
#define TRISE1_bit                     BANKMASK(TRISE), 1
#define TRISE2_bit                     BANKMASK(TRISE), 2
#define TRISE3_bit                     BANKMASK(TRISE), 3
#define TRISE4_bit                     BANKMASK(TRISE), 4
#define TRISE5_bit                     BANKMASK(TRISE), 5
#define TRISE6_bit                     BANKMASK(TRISE), 6
#define TRISE7_bit                     BANKMASK(TRISE), 7
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 0091h
#define TMR1IE_bit                     BANKMASK(PIE1), 0
#define TMR2IE_bit                     BANKMASK(PIE1), 1
#define CCP1IE_bit                     BANKMASK(PIE1), 2
#define SSP1IE_bit                     BANKMASK(PIE1), 3
#define TXIE_bit                       BANKMASK(PIE1), 4
#define RCIE_bit                       BANKMASK(PIE1), 5
#define ADIE_bit                       BANKMASK(PIE1), 6
#define TMR1GIE_bit                    BANKMASK(PIE1), 7
#define SSPIE_bit                      BANKMASK(PIE1), 3
#ifndef _LIB_BUILD
#endif
PIE2                                   equ 0092h
#define CCP2IE_bit                     BANKMASK(PIE2), 0
#define C3IE_bit                       BANKMASK(PIE2), 1
#define LCDIE_bit                      BANKMASK(PIE2), 2
#define BCLIE_bit                      BANKMASK(PIE2), 3
#define EEIE_bit                       BANKMASK(PIE2), 4
#define C1IE_bit                       BANKMASK(PIE2), 5
#define C2IE_bit                       BANKMASK(PIE2), 6
#define OSFIE_bit                      BANKMASK(PIE2), 7
#ifndef _LIB_BUILD
#endif
PIE3                                   equ 0093h
#define TMR4IE_bit                     BANKMASK(PIE3), 1
#define TMR6IE_bit                     BANKMASK(PIE3), 3
#define CCP3IE_bit                     BANKMASK(PIE3), 4
#define CCP4IE_bit                     BANKMASK(PIE3), 5
#define CCP5IE_bit                     BANKMASK(PIE3), 6
#ifndef _LIB_BUILD
#endif
PIE4                                   equ 0094h
#define SSP2IE_bit                     BANKMASK(PIE4), 0
#define BCL2IE_bit                     BANKMASK(PIE4), 1
#define TX2IE_bit                      BANKMASK(PIE4), 4
#define RC2IE_bit                      BANKMASK(PIE4), 5
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0095h
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nWPUEN_bit                     BANKMASK(OPTION_REG), 7
#define TMR0SE_bit                     BANKMASK(OPTION_REG), 4
#define TMR0CS_bit                     BANKMASK(OPTION_REG), 5
#ifndef _LIB_BUILD
#endif
PCON                                   equ 0096h
#define nBOR_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#define nRI_bit                        BANKMASK(PCON), 2
#define nRMCLR_bit                     BANKMASK(PCON), 3
#define STKUNF_bit                     BANKMASK(PCON), 6
#define STKOVF_bit                     BANKMASK(PCON), 7
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0097h
#define SWDTEN_bit                     BANKMASK(WDTCON), 0
#define WDTPS0_bit                     BANKMASK(WDTCON), 1
#define WDTPS1_bit                     BANKMASK(WDTCON), 2
#define WDTPS2_bit                     BANKMASK(WDTCON), 3
#define WDTPS3_bit                     BANKMASK(WDTCON), 4
#define WDTPS4_bit                     BANKMASK(WDTCON), 5
#ifndef _LIB_BUILD
#endif
OSCTUNE                                equ 0098h
#define TUN0_bit                       BANKMASK(OSCTUNE), 0
#define TUN1_bit                       BANKMASK(OSCTUNE), 1
#define TUN2_bit                       BANKMASK(OSCTUNE), 2
#define TUN3_bit                       BANKMASK(OSCTUNE), 3
#define TUN4_bit                       BANKMASK(OSCTUNE), 4
#define TUN5_bit                       BANKMASK(OSCTUNE), 5
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 0099h
#define SCS0_bit                       BANKMASK(OSCCON), 0
#define SCS1_bit                       BANKMASK(OSCCON), 1
#define IRCF0_bit                      BANKMASK(OSCCON), 3
#define IRCF1_bit                      BANKMASK(OSCCON), 4
#define IRCF2_bit                      BANKMASK(OSCCON), 5
#define IRCF3_bit                      BANKMASK(OSCCON), 6
#define SPLLEN_bit                     BANKMASK(OSCCON), 7
#ifndef _LIB_BUILD
#endif
OSCSTAT                                equ 009Ah
#define HFIOFS_bit                     BANKMASK(OSCSTAT), 0
#define LFIOFR_bit                     BANKMASK(OSCSTAT), 1
#define MFIOFR_bit                     BANKMASK(OSCSTAT), 2
#define HFIOFL_bit                     BANKMASK(OSCSTAT), 3
#define HFIOFR_bit                     BANKMASK(OSCSTAT), 4
#define OSTS_bit                       BANKMASK(OSCSTAT), 5
#define PLLR_bit                       BANKMASK(OSCSTAT), 6
#define T1OSCR_bit                     BANKMASK(OSCSTAT), 7
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 009Bh
ADRESH                                 equ 009Ch
ADCON0                                 equ 009Dh
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 1
#define CHS0_bit                       BANKMASK(ADCON0), 2
#define CHS1_bit                       BANKMASK(ADCON0), 3
#define CHS2_bit                       BANKMASK(ADCON0), 4
#define CHS3_bit                       BANKMASK(ADCON0), 5
#define CHS4_bit                       BANKMASK(ADCON0), 6
#define ADGO_bit                       BANKMASK(ADCON0), 1
#define GO_bit                         BANKMASK(ADCON0), 1
#define nDONE_bit                      BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 009Eh
#define ADPREF0_bit                    BANKMASK(ADCON1), 0
#define ADPREF1_bit                    BANKMASK(ADCON1), 1
#define ADNREF_bit                     BANKMASK(ADCON1), 2
#define ADCS0_bit                      BANKMASK(ADCON1), 4
#define ADCS1_bit                      BANKMASK(ADCON1), 5
#define ADCS2_bit                      BANKMASK(ADCON1), 6
#define ADFM_bit                       BANKMASK(ADCON1), 7
#ifndef _LIB_BUILD
#endif
LATA                                   equ 010Ch
#define LATA0_bit                      BANKMASK(LATA), 0
#define LATA1_bit                      BANKMASK(LATA), 1
#define LATA2_bit                      BANKMASK(LATA), 2
#define LATA3_bit                      BANKMASK(LATA), 3
#define LATA4_bit                      BANKMASK(LATA), 4
#define LATA5_bit                      BANKMASK(LATA), 5
#define LATA6_bit                      BANKMASK(LATA), 6
#define LATA7_bit                      BANKMASK(LATA), 7
#ifndef _LIB_BUILD
#endif
LATB                                   equ 010Dh
#define LATB0_bit                      BANKMASK(LATB), 0
#define LATB1_bit                      BANKMASK(LATB), 1
#define LATB2_bit                      BANKMASK(LATB), 2
#define LATB3_bit                      BANKMASK(LATB), 3
#define LATB4_bit                      BANKMASK(LATB), 4
#define LATB5_bit                      BANKMASK(LATB), 5
#define LATB6_bit                      BANKMASK(LATB), 6
#define LATB7_bit                      BANKMASK(LATB), 7
#ifndef _LIB_BUILD
#endif
LATC                                   equ 010Eh
#define LATC0_bit                      BANKMASK(LATC), 0
#define LATC1_bit                      BANKMASK(LATC), 1
#define LATC2_bit                      BANKMASK(LATC), 2
#define LATC3_bit                      BANKMASK(LATC), 3
#define LATC4_bit                      BANKMASK(LATC), 4
#define LATC5_bit                      BANKMASK(LATC), 5
#define LATC6_bit                      BANKMASK(LATC), 6
#define LATC7_bit                      BANKMASK(LATC), 7
#ifndef _LIB_BUILD
#endif
LATD                                   equ 010Fh
#define LATD0_bit                      BANKMASK(LATD), 0
#define LATD1_bit                      BANKMASK(LATD), 1
#define LATD2_bit                      BANKMASK(LATD), 2
#define LATD3_bit                      BANKMASK(LATD), 3
#define LATD4_bit                      BANKMASK(LATD), 4
#define LATD5_bit                      BANKMASK(LATD), 5
#define LATD6_bit                      BANKMASK(LATD), 6
#define LATD7_bit                      BANKMASK(LATD), 7
#ifndef _LIB_BUILD
#endif
LATE                                   equ 0110h
#define LATE0_bit                      BANKMASK(LATE), 0
#define LATE1_bit                      BANKMASK(LATE), 1
#define LATE2_bit                      BANKMASK(LATE), 2
#define LATE3_bit                      BANKMASK(LATE), 3
#define LATE4_bit                      BANKMASK(LATE), 4
#define LATE5_bit                      BANKMASK(LATE), 5
#define LATE6_bit                      BANKMASK(LATE), 6
#define LATE7_bit                      BANKMASK(LATE), 7
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 0111h
#define C1SYNC_bit                     BANKMASK(CM1CON0), 0
#define C1HYS_bit                      BANKMASK(CM1CON0), 1
#define C1SP_bit                       BANKMASK(CM1CON0), 2
#define C1POL_bit                      BANKMASK(CM1CON0), 4
#define C1OE_bit                       BANKMASK(CM1CON0), 5
#define C1ON_bit                       BANKMASK(CM1CON0), 7
#ifndef _LIB_BUILD
#endif
CM1CON1                                equ 0112h
#define C1NCH0_bit                     BANKMASK(CM1CON1), 0
#define C1NCH1_bit                     BANKMASK(CM1CON1), 1
#define C1PCH0_bit                     BANKMASK(CM1CON1), 4
#define C1PCH1_bit                     BANKMASK(CM1CON1), 5
#define C1INTN_bit                     BANKMASK(CM1CON1), 6
#define C1INTP_bit                     BANKMASK(CM1CON1), 7
#ifndef _LIB_BUILD
#endif
CM2CON0                                equ 0113h
#define C2SYNC_bit                     BANKMASK(CM2CON0), 0
#define C2HYS_bit                      BANKMASK(CM2CON0), 1
#define C2SP_bit                       BANKMASK(CM2CON0), 2
#define C2POL_bit                      BANKMASK(CM2CON0), 4
#define C2OE_bit                       BANKMASK(CM2CON0), 5
#define C2ON_bit                       BANKMASK(CM2CON0), 7
#ifndef _LIB_BUILD
#endif
CM2CON1                                equ 0114h
#define C2NCH0_bit                     BANKMASK(CM2CON1), 0
#define C2NCH1_bit                     BANKMASK(CM2CON1), 1
#define C2PCH0_bit                     BANKMASK(CM2CON1), 4
#define C2PCH1_bit                     BANKMASK(CM2CON1), 5
#define C2INTN_bit                     BANKMASK(CM2CON1), 6
#define C2INTP_bit                     BANKMASK(CM2CON1), 7
#ifndef _LIB_BUILD
#endif
CMOUT                                  equ 0115h
#define MC1OUT_bit                     BANKMASK(CMOUT), 0
#define MC2OUT_bit                     BANKMASK(CMOUT), 1
#define MC3OUT_bit                     BANKMASK(CMOUT), 2
#ifndef _LIB_BUILD
#endif
BORCON                                 equ 0116h
#define BORRDY_bit                     BANKMASK(BORCON), 0
#define SBOREN_bit                     BANKMASK(BORCON), 7
#ifndef _LIB_BUILD
#endif
FVRCON                                 equ 0117h
#define ADFVR0_bit                     BANKMASK(FVRCON), 0
#define ADFVR1_bit                     BANKMASK(FVRCON), 1
#define CDAFVR0_bit                    BANKMASK(FVRCON), 2
#define CDAFVR1_bit                    BANKMASK(FVRCON), 3
#define FVRRDY_bit                     BANKMASK(FVRCON), 6
#define FVREN_bit                      BANKMASK(FVRCON), 7
#ifndef _LIB_BUILD
#endif
DACCON0                                equ 0118h
#define DACNSS_bit                     BANKMASK(DACCON0), 0
#define DACPSS0_bit                    BANKMASK(DACCON0), 2
#define DACPSS1_bit                    BANKMASK(DACCON0), 3
#define DACOE_bit                      BANKMASK(DACCON0), 5
#define DACLPS_bit                     BANKMASK(DACCON0), 6
#define DACEN_bit                      BANKMASK(DACCON0), 7
#ifndef _LIB_BUILD
#endif
DACCON1                                equ 0119h
#define DACR0_bit                      BANKMASK(DACCON1), 0
#define DACR1_bit                      BANKMASK(DACCON1), 1
#define DACR2_bit                      BANKMASK(DACCON1), 2
#define DACR3_bit                      BANKMASK(DACCON1), 3
#define DACR4_bit                      BANKMASK(DACCON1), 4
#ifndef _LIB_BUILD
#endif
SRCON0                                 equ 011Ah
#define SRPR_bit                       BANKMASK(SRCON0), 0
#define SRPS_bit                       BANKMASK(SRCON0), 1
#define SRNQEN_bit                     BANKMASK(SRCON0), 2
#define SRQEN_bit                      BANKMASK(SRCON0), 3
#define SRCLK0_bit                     BANKMASK(SRCON0), 4
#define SRCLK1_bit                     BANKMASK(SRCON0), 5
#define SRCLK2_bit                     BANKMASK(SRCON0), 6
#define SRLEN_bit                      BANKMASK(SRCON0), 7
#ifndef _LIB_BUILD
#endif
SRCON1                                 equ 011Bh
#define SRRC1E_bit                     BANKMASK(SRCON1), 0
#define SRRC2E_bit                     BANKMASK(SRCON1), 1
#define SRRCKE_bit                     BANKMASK(SRCON1), 2
#define SRRPE_bit                      BANKMASK(SRCON1), 3
#define SRSC1E_bit                     BANKMASK(SRCON1), 4
#define SRSC2E_bit                     BANKMASK(SRCON1), 5
#define SRSCKE_bit                     BANKMASK(SRCON1), 6
#define SRSPE_bit                      BANKMASK(SRCON1), 7
#ifndef _LIB_BUILD
#endif
APFCON                                 equ 011Dh
#define P1BSEL_bit                     BANKMASK(APFCON), 0
#define P1CSEL_bit                     BANKMASK(APFCON), 1
#define CCP2SEL_bit                    BANKMASK(APFCON), 2
#define P2BSEL_bit                     BANKMASK(APFCON), 3
#define P2CSEL_bit                     BANKMASK(APFCON), 4
#define P2DSEL_bit                     BANKMASK(APFCON), 5
#define P3BSEL_bit                     BANKMASK(APFCON), 6
#define P3CSEL_bit                     BANKMASK(APFCON), 7
#ifndef _LIB_BUILD
#endif
CM3CON0                                equ 011Eh
#define C3SYNC_bit                     BANKMASK(CM3CON0), 0
#define C3HYS_bit                      BANKMASK(CM3CON0), 1
#define C3SP_bit                       BANKMASK(CM3CON0), 2
#define C3POL_bit                      BANKMASK(CM3CON0), 4
#define C3OE_bit                       BANKMASK(CM3CON0), 5
#define C3ON_bit                       BANKMASK(CM3CON0), 7
#ifndef _LIB_BUILD
#endif
CM3CON1                                equ 011Fh
#define C3NCH0_bit                     BANKMASK(CM3CON1), 0
#define C3NCH1_bit                     BANKMASK(CM3CON1), 1
#define C3PCH0_bit                     BANKMASK(CM3CON1), 4
#define C3PCH1_bit                     BANKMASK(CM3CON1), 5
#define C3INTN_bit                     BANKMASK(CM3CON1), 6
#define C3INTP_bit                     BANKMASK(CM3CON1), 7
#ifndef _LIB_BUILD
#endif
ANSELA                                 equ 018Ch
#define ANSA0_bit                      BANKMASK(ANSELA), 0
#define ANSA1_bit                      BANKMASK(ANSELA), 1
#define ANSA2_bit                      BANKMASK(ANSELA), 2
#define ANSA3_bit                      BANKMASK(ANSELA), 3
#define ANSA5_bit                      BANKMASK(ANSELA), 5
#ifndef _LIB_BUILD
#endif
ANSELE                                 equ 0190h
#define ANSE0_bit                      BANKMASK(ANSELE), 0
#define ANSE1_bit                      BANKMASK(ANSELE), 1
#define ANSE2_bit                      BANKMASK(ANSELE), 2
#ifndef _LIB_BUILD
#endif
EEADRL                                 equ 0191h
EEADRH                                 equ 0192h
#ifndef _LIB_BUILD
#endif
EEDATL                                 equ 0193h
EEDATA                                 equ 0193h
EEDATH                                 equ 0194h
#ifndef _LIB_BUILD
#endif
EECON1                                 equ 0195h
#define RD_bit                         BANKMASK(EECON1), 0
#define WR_bit                         BANKMASK(EECON1), 1
#define WREN_bit                       BANKMASK(EECON1), 2
#define WRERR_bit                      BANKMASK(EECON1), 3
#define FREE_bit                       BANKMASK(EECON1), 4
#define LWLO_bit                       BANKMASK(EECON1), 5
#define CFGS_bit                       BANKMASK(EECON1), 6
#define EEPGD_bit                      BANKMASK(EECON1), 7
#ifndef _LIB_BUILD
#endif
EECON2                                 equ 0196h
RC1REG                                 equ 0199h
RCREG                                  equ 0199h
TX1REG                                 equ 019Ah
TXREG                                  equ 019Ah
SP1BRGL                                equ 019Bh
SPBRG                                  equ 019Bh
SPBRGL                                 equ 019Bh
SP1BRGH                                equ 019Ch
SPBRGH                                 equ 019Ch
RC1STA                                 equ 019Dh
RCSTA                                  equ 019Dh
#ifndef _LIB_BUILD
#endif
TX1STA                                 equ 019Eh
TXSTA                                  equ 019Eh
#ifndef _LIB_BUILD
#endif
BAUD1CON                               equ 019Fh
#ifndef _LIB_BUILD
#endif
WPUB                                   equ 020Dh
#define WPUB0_bit                      BANKMASK(WPUB), 0
#define WPUB1_bit                      BANKMASK(WPUB), 1
#define WPUB2_bit                      BANKMASK(WPUB), 2
#define WPUB3_bit                      BANKMASK(WPUB), 3
#define WPUB4_bit                      BANKMASK(WPUB), 4
#define WPUB5_bit                      BANKMASK(WPUB), 5
#define WPUB6_bit                      BANKMASK(WPUB), 6
#define WPUB7_bit                      BANKMASK(WPUB), 7
#ifndef _LIB_BUILD
#endif
SSP1BUF                                equ 0211h
SSPBUF                                 equ 0211h
SSP1ADD                                equ 0212h
SSPADD                                 equ 0212h
SSP1MSK                                equ 0213h
SSPMSK                                 equ 0213h
SSP1STAT                               equ 0214h
SSPSTAT                                equ 0214h
#ifndef _LIB_BUILD
#endif
SSP1CON1                               equ 0215h
SSPCON                                 equ 0215h
SSPCON1                                equ 0215h
#ifndef _LIB_BUILD
#endif
SSP1CON2                               equ 0216h
SSPCON2                                equ 0216h
#ifndef _LIB_BUILD
#endif
SSP1CON3                               equ 0217h
SSPCON3                                equ 0217h
#ifndef _LIB_BUILD
#endif
SSP2BUF                                equ 0219h
SSP2ADD                                equ 021Ah
SSP2MSK                                equ 021Bh
SSP2STAT                               equ 021Ch
#ifndef _LIB_BUILD
#endif
SSP2CON1                               equ 021Dh
#ifndef _LIB_BUILD
#endif
SSP2CON2                               equ 021Eh
#ifndef _LIB_BUILD
#endif
SSP2CON3                               equ 021Fh
#ifndef _LIB_BUILD
#endif
PORTF                                  equ 028Ch
#define RF0_bit                        BANKMASK(PORTF), 0
#define RF1_bit                        BANKMASK(PORTF), 1
#define RF2_bit                        BANKMASK(PORTF), 2
#define RF3_bit                        BANKMASK(PORTF), 3
#define RF4_bit                        BANKMASK(PORTF), 4
#define RF5_bit                        BANKMASK(PORTF), 5
#define RF6_bit                        BANKMASK(PORTF), 6
#define RF7_bit                        BANKMASK(PORTF), 7
#define AN16_bit                       BANKMASK(PORTF), 0
#define AN6_bit                        BANKMASK(PORTF), 1
#define AN7_bit                        BANKMASK(PORTF), 2
#define AN8_bit                        BANKMASK(PORTF), 3
#define AN9_bit                        BANKMASK(PORTF), 4
#define AN10_bit                       BANKMASK(PORTF), 5
#define AN11_bit                       BANKMASK(PORTF), 6
#define AN5_bit                        BANKMASK(PORTF), 7
#define SEG41_bit                      BANKMASK(PORTF), 0
#define SEG19_bit                      BANKMASK(PORTF), 1
#define SEG20_bit                      BANKMASK(PORTF), 2
#define SEG21_bit                      BANKMASK(PORTF), 3
#define SEG22_bit                      BANKMASK(PORTF), 4
#define SEG23_bit                      BANKMASK(PORTF), 5
#define SEG24_bit                      BANKMASK(PORTF), 6
#define SEG25_bit                      BANKMASK(PORTF), 7
#define CPS16_bit                      BANKMASK(PORTF), 0
#define CPS6_bit                       BANKMASK(PORTF), 1
#define CPS7_bit                       BANKMASK(PORTF), 2
#define CPS8_bit                       BANKMASK(PORTF), 3
#define CPS9_bit                       BANKMASK(PORTF), 4
#define CPS10_bit                      BANKMASK(PORTF), 5
#define CPS11_bit                      BANKMASK(PORTF), 6
#define CPS5_bit                       BANKMASK(PORTF), 7
#define C1IN0N_bit                     BANKMASK(PORTF), 0
#define C1IN2N_bit                     BANKMASK(PORTF), 3
#define C2INP_bit                      BANKMASK(PORTF), 4
#define C1IN1N_bit                     BANKMASK(PORTF), 5
#define C1INP_bit                      BANKMASK(PORTF), 6
#define C1IN3N_bit                     BANKMASK(PORTF), 7
#define C2IN0N_bit                     BANKMASK(PORTF), 0
#define SRNQ_bit                       BANKMASK(PORTF), 1
#define SRQ_bit                        BANKMASK(PORTF), 2
#define C2IN2N_bit                     BANKMASK(PORTF), 3
#define C2IN1N_bit                     BANKMASK(PORTF), 5
#define C2IN3N_bit                     BANKMASK(PORTF), 7
#define C3IN2N_bit                     BANKMASK(PORTF), 3
#define DACOUT_bit                     BANKMASK(PORTF), 5
#define C3IN3N_bit                     BANKMASK(PORTF), 7
#ifndef _LIB_BUILD
#endif
PORTG                                  equ 028Dh
#define RG0_bit                        BANKMASK(PORTG), 0
#define RG1_bit                        BANKMASK(PORTG), 1
#define RG2_bit                        BANKMASK(PORTG), 2
#define RG3_bit                        BANKMASK(PORTG), 3
#define RG4_bit                        BANKMASK(PORTG), 4
#define RG5_bit                        BANKMASK(PORTG), 5
#define AN15_bit                       BANKMASK(PORTG), 1
#define AN14_bit                       BANKMASK(PORTG), 2
#define AN13_bit                       BANKMASK(PORTG), 3
#define AN12_bit                       BANKMASK(PORTG), 4
#define nMCLR_bit                      BANKMASK(PORTG), 5
#define SEG42_bit                      BANKMASK(PORTG), 0
#define SEG43_bit                      BANKMASK(PORTG), 1
#define SEG44_bit                      BANKMASK(PORTG), 2
#define SEG45_bit                      BANKMASK(PORTG), 3
#define SEG26_bit                      BANKMASK(PORTG), 4
#define CPS15_bit                      BANKMASK(PORTG), 1
#define CPS14_bit                      BANKMASK(PORTG), 2
#define CPS13_bit                      BANKMASK(PORTG), 3
#define CPS12_bit                      BANKMASK(PORTG), 4
#define C3INP_bit                      BANKMASK(PORTG), 2
#define C3IN0N_bit                     BANKMASK(PORTG), 3
#define C3IN1N_bit                     BANKMASK(PORTG), 4
#define CCP3_bit                       BANKMASK(PORTG), 0
#define TX2_bit                        BANKMASK(PORTG), 1
#define RX2_bit                        BANKMASK(PORTG), 2
#define CCP4_bit                       BANKMASK(PORTG), 3
#define CCP5_bit                       BANKMASK(PORTG), 4
#define P3A_bit                        BANKMASK(PORTG), 0
#define CK2_bit                        BANKMASK(PORTG), 1
#define DT2_bit                        BANKMASK(PORTG), 2
#define P3D_bit                        BANKMASK(PORTG), 3
#define P1D_bit                        BANKMASK(PORTG), 4
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0291h
CCPR1H                                 equ 0292h
CCP1CON                                equ 0293h
#define CCP1M0_bit                     BANKMASK(CCP1CON), 0
#define CCP1M1_bit                     BANKMASK(CCP1CON), 1
#define CCP1M2_bit                     BANKMASK(CCP1CON), 2
#define CCP1M3_bit                     BANKMASK(CCP1CON), 3
#define DC1B0_bit                      BANKMASK(CCP1CON), 4
#define DC1B1_bit                      BANKMASK(CCP1CON), 5
#define P1M0_bit                       BANKMASK(CCP1CON), 6
#define P1M1_bit                       BANKMASK(CCP1CON), 7
#ifndef _LIB_BUILD
#endif
PWM1CON                                equ 0294h
#define P1DC0_bit                      BANKMASK(PWM1CON), 0
#define P1DC1_bit                      BANKMASK(PWM1CON), 1
#define P1DC2_bit                      BANKMASK(PWM1CON), 2
#define P1DC3_bit                      BANKMASK(PWM1CON), 3
#define P1DC4_bit                      BANKMASK(PWM1CON), 4
#define P1DC5_bit                      BANKMASK(PWM1CON), 5
#define P1DC6_bit                      BANKMASK(PWM1CON), 6
#define P1RSEN_bit                     BANKMASK(PWM1CON), 7
#ifndef _LIB_BUILD
#endif
CCP1AS                                 equ 0295h
ECCP1AS                                equ 0295h
#define PSS1BD0_bit                    BANKMASK(CCP1AS), 0
#define PSS1BD1_bit                    BANKMASK(CCP1AS), 1
#define PSS1AC0_bit                    BANKMASK(CCP1AS), 2
#define PSS1AC1_bit                    BANKMASK(CCP1AS), 3
#define CCP1AS0_bit                    BANKMASK(CCP1AS), 4
#define CCP1AS1_bit                    BANKMASK(CCP1AS), 5
#define CCP1AS2_bit                    BANKMASK(CCP1AS), 6
#define CCP1ASE_bit                    BANKMASK(CCP1AS), 7
#ifndef _LIB_BUILD
#endif
PSTR1CON                               equ 0296h
#define STR1A_bit                      BANKMASK(PSTR1CON), 0
#define STR1B_bit                      BANKMASK(PSTR1CON), 1
#define STR1C_bit                      BANKMASK(PSTR1CON), 2
#define STR1D_bit                      BANKMASK(PSTR1CON), 3
#define STR1SYNC_bit                   BANKMASK(PSTR1CON), 4
#ifndef _LIB_BUILD
#endif
CCPR2L                                 equ 0298h
CCPR2H                                 equ 0299h
CCP2CON                                equ 029Ah
#define CCP2M0_bit                     BANKMASK(CCP2CON), 0
#define CCP2M1_bit                     BANKMASK(CCP2CON), 1
#define CCP2M2_bit                     BANKMASK(CCP2CON), 2
#define CCP2M3_bit                     BANKMASK(CCP2CON), 3
#define DC2B0_bit                      BANKMASK(CCP2CON), 4
#define DC2B1_bit                      BANKMASK(CCP2CON), 5
#define P2M0_bit                       BANKMASK(CCP2CON), 6
#define P2M1_bit                       BANKMASK(CCP2CON), 7
#ifndef _LIB_BUILD
#endif
PWM2CON                                equ 029Bh
#define P2DC0_bit                      BANKMASK(PWM2CON), 0
#define P2DC1_bit                      BANKMASK(PWM2CON), 1
#define P2DC2_bit                      BANKMASK(PWM2CON), 2
#define P2DC3_bit                      BANKMASK(PWM2CON), 3
#define P2DC4_bit                      BANKMASK(PWM2CON), 4
#define P2DC5_bit                      BANKMASK(PWM2CON), 5
#define P2DC6_bit                      BANKMASK(PWM2CON), 6
#define P2RSEN_bit                     BANKMASK(PWM2CON), 7
#ifndef _LIB_BUILD
#endif
CCP2AS                                 equ 029Ch
ECCP2AS                                equ 029Ch
#define PSS2BD0_bit                    BANKMASK(CCP2AS), 0
#define PSS2BD1_bit                    BANKMASK(CCP2AS), 1
#define PSS2AC0_bit                    BANKMASK(CCP2AS), 2
#define PSS2AC1_bit                    BANKMASK(CCP2AS), 3
#define CCP2AS0_bit                    BANKMASK(CCP2AS), 4
#define CCP2AS1_bit                    BANKMASK(CCP2AS), 5
#define CCP2AS2_bit                    BANKMASK(CCP2AS), 6
#define CCP2ASE_bit                    BANKMASK(CCP2AS), 7
#ifndef _LIB_BUILD
#endif
PSTR2CON                               equ 029Dh
#define STR2A_bit                      BANKMASK(PSTR2CON), 0
#define STR2B_bit                      BANKMASK(PSTR2CON), 1
#define STR2C_bit                      BANKMASK(PSTR2CON), 2
#define STR2D_bit                      BANKMASK(PSTR2CON), 3
#define STR2SYNC_bit                   BANKMASK(PSTR2CON), 4
#ifndef _LIB_BUILD
#endif
CCPTMRS0                               equ 029Eh
#define C1TSEL0_bit                    BANKMASK(CCPTMRS0), 0
#define C1TSEL1_bit                    BANKMASK(CCPTMRS0), 1
#define C2TSEL0_bit                    BANKMASK(CCPTMRS0), 2
#define C2TSEL1_bit                    BANKMASK(CCPTMRS0), 3
#define C3TSEL0_bit                    BANKMASK(CCPTMRS0), 4
#define C3TSEL1_bit                    BANKMASK(CCPTMRS0), 5
#define C4TSEL0_bit                    BANKMASK(CCPTMRS0), 6
#define C4TSEL1_bit                    BANKMASK(CCPTMRS0), 7
#ifndef _LIB_BUILD
#endif
CCPTMRS1                               equ 029Fh
#define C5TSEL0_bit                    BANKMASK(CCPTMRS1), 0
#define C5TSEL1_bit                    BANKMASK(CCPTMRS1), 1
#ifndef _LIB_BUILD
#endif
TRISF                                  equ 030Ch
#define TRISF0_bit                     BANKMASK(TRISF), 0
#define TRISF1_bit                     BANKMASK(TRISF), 1
#define TRISF2_bit                     BANKMASK(TRISF), 2
#define TRISF3_bit                     BANKMASK(TRISF), 3
#define TRISF4_bit                     BANKMASK(TRISF), 4
#define TRISF5_bit                     BANKMASK(TRISF), 5
#define TRISF6_bit                     BANKMASK(TRISF), 6
#define TRISF7_bit                     BANKMASK(TRISF), 7
#ifndef _LIB_BUILD
#endif
TRISG                                  equ 030Dh
#define TRISG0_bit                     BANKMASK(TRISG), 0
#define TRISG1_bit                     BANKMASK(TRISG), 1
#define TRISG2_bit                     BANKMASK(TRISG), 2
#define TRISG3_bit                     BANKMASK(TRISG), 3
#define TRISG4_bit                     BANKMASK(TRISG), 4
#define TRISG5_bit                     BANKMASK(TRISG), 5
#ifndef _LIB_BUILD
#endif
CCPR3L                                 equ 0311h
CCPR3H                                 equ 0312h
CCP3CON                                equ 0313h
#define CCP3M0_bit                     BANKMASK(CCP3CON), 0
#define CCP3M1_bit                     BANKMASK(CCP3CON), 1
#define CCP3M2_bit                     BANKMASK(CCP3CON), 2
#define CCP3M3_bit                     BANKMASK(CCP3CON), 3
#define DC3B0_bit                      BANKMASK(CCP3CON), 4
#define DC3B1_bit                      BANKMASK(CCP3CON), 5
#define P3M0_bit                       BANKMASK(CCP3CON), 6
#define P3M1_bit                       BANKMASK(CCP3CON), 7
#ifndef _LIB_BUILD
#endif
PWM3CON                                equ 0314h
#define P3DC0_bit                      BANKMASK(PWM3CON), 0
#define P3DC1_bit                      BANKMASK(PWM3CON), 1
#define P3DC2_bit                      BANKMASK(PWM3CON), 2
#define P3DC3_bit                      BANKMASK(PWM3CON), 3
#define P3DC4_bit                      BANKMASK(PWM3CON), 4
#define P3DC5_bit                      BANKMASK(PWM3CON), 5
#define P3DC6_bit                      BANKMASK(PWM3CON), 6
#define P3RSEN_bit                     BANKMASK(PWM3CON), 7
#ifndef _LIB_BUILD
#endif
CCP3AS                                 equ 0315h
ECCP3AS                                equ 0315h
#define PSS3BD0_bit                    BANKMASK(CCP3AS), 0
#define PSS3BD1_bit                    BANKMASK(CCP3AS), 1
#define PSS3AC0_bit                    BANKMASK(CCP3AS), 2
#define PSS3AC1_bit                    BANKMASK(CCP3AS), 3
#define CCP3AS0_bit                    BANKMASK(CCP3AS), 4
#define CCP3AS1_bit                    BANKMASK(CCP3AS), 5
#define CCP3AS2_bit                    BANKMASK(CCP3AS), 6
#define CCP3ASE_bit                    BANKMASK(CCP3AS), 7
#ifndef _LIB_BUILD
#endif
PSTR3CON                               equ 0316h
#define STR3A_bit                      BANKMASK(PSTR3CON), 0
#define STR3B_bit                      BANKMASK(PSTR3CON), 1
#define STR3C_bit                      BANKMASK(PSTR3CON), 2
#define STR3D_bit                      BANKMASK(PSTR3CON), 3
#define STR3SYNC_bit                   BANKMASK(PSTR3CON), 4
#ifndef _LIB_BUILD
#endif
CCPR4L                                 equ 0318h
CCPR4H                                 equ 0319h
CCP4CON                                equ 031Ah
#define CCP4M0_bit                     BANKMASK(CCP4CON), 0
#define CCP4M1_bit                     BANKMASK(CCP4CON), 1
#define CCP4M2_bit                     BANKMASK(CCP4CON), 2
#define CCP4M3_bit                     BANKMASK(CCP4CON), 3
#define DC4B0_bit                      BANKMASK(CCP4CON), 4
#define DC4B1_bit                      BANKMASK(CCP4CON), 5
#ifndef _LIB_BUILD
#endif
CCPR5L                                 equ 031Ch
CCPR5H                                 equ 031Dh
CCP5CON                                equ 031Eh
#define CCP5M0_bit                     BANKMASK(CCP5CON), 0
#define CCP5M1_bit                     BANKMASK(CCP5CON), 1
#define CCP5M2_bit                     BANKMASK(CCP5CON), 2
#define CCP5M3_bit                     BANKMASK(CCP5CON), 3
#define DC5B0_bit                      BANKMASK(CCP5CON), 4
#define DC5B1_bit                      BANKMASK(CCP5CON), 5
#ifndef _LIB_BUILD
#endif
LATF                                   equ 038Ch
#define LATF0_bit                      BANKMASK(LATF), 0
#define LATF1_bit                      BANKMASK(LATF), 1
#define LATF2_bit                      BANKMASK(LATF), 2
#define LATF3_bit                      BANKMASK(LATF), 3
#define LATF4_bit                      BANKMASK(LATF), 4
#define LATF5_bit                      BANKMASK(LATF), 5
#define LATF6_bit                      BANKMASK(LATF), 6
#define LATF7_bit                      BANKMASK(LATF), 7
#ifndef _LIB_BUILD
#endif
LATG                                   equ 038Dh
#define LATG0_bit                      BANKMASK(LATG), 0
#define LATG1_bit                      BANKMASK(LATG), 1
#define LATG2_bit                      BANKMASK(LATG), 2
#define LATG3_bit                      BANKMASK(LATG), 3
#define LATG4_bit                      BANKMASK(LATG), 4
#define LATG5_bit                      BANKMASK(LATG), 5
#ifndef _LIB_BUILD
#endif
IOCBP                                  equ 0394h
#define IOCBP0_bit                     BANKMASK(IOCBP), 0
#define IOCBP1_bit                     BANKMASK(IOCBP), 1
#define IOCBP2_bit                     BANKMASK(IOCBP), 2
#define IOCBP3_bit                     BANKMASK(IOCBP), 3
#define IOCBP4_bit                     BANKMASK(IOCBP), 4
#define IOCBP5_bit                     BANKMASK(IOCBP), 5
#define IOCBP6_bit                     BANKMASK(IOCBP), 6
#define IOCBP7_bit                     BANKMASK(IOCBP), 7
#ifndef _LIB_BUILD
#endif
IOCBN                                  equ 0395h
#define IOCBN0_bit                     BANKMASK(IOCBN), 0
#define IOCBN1_bit                     BANKMASK(IOCBN), 1
#define IOCBN2_bit                     BANKMASK(IOCBN), 2
#define IOCBN3_bit                     BANKMASK(IOCBN), 3
#define IOCBN4_bit                     BANKMASK(IOCBN), 4
#define IOCBN5_bit                     BANKMASK(IOCBN), 5
#define IOCBN6_bit                     BANKMASK(IOCBN), 6
#define IOCBN7_bit                     BANKMASK(IOCBN), 7
#ifndef _LIB_BUILD
#endif
IOCBF                                  equ 0396h
#define IOCBF0_bit                     BANKMASK(IOCBF), 0
#define IOCBF1_bit                     BANKMASK(IOCBF), 1
#define IOCBF2_bit                     BANKMASK(IOCBF), 2
#define IOCBF3_bit                     BANKMASK(IOCBF), 3
#define IOCBF4_bit                     BANKMASK(IOCBF), 4
#define IOCBF5_bit                     BANKMASK(IOCBF), 5
#define IOCBF6_bit                     BANKMASK(IOCBF), 6
#define IOCBF7_bit                     BANKMASK(IOCBF), 7
#ifndef _LIB_BUILD
#endif
ANSELF                                 equ 040Ch
#define ANSF0_bit                      BANKMASK(ANSELF), 0
#define ANSF1_bit                      BANKMASK(ANSELF), 1
#define ANSF2_bit                      BANKMASK(ANSELF), 2
#define ANSF3_bit                      BANKMASK(ANSELF), 3
#define ANSF4_bit                      BANKMASK(ANSELF), 4
#define ANSF5_bit                      BANKMASK(ANSELF), 5
#define ANSF6_bit                      BANKMASK(ANSELF), 6
#define ANSF7_bit                      BANKMASK(ANSELF), 7
#ifndef _LIB_BUILD
#endif
ANSELG                                 equ 040Dh
#define ANSG1_bit                      BANKMASK(ANSELG), 1
#define ANSG2_bit                      BANKMASK(ANSELG), 2
#define ANSG3_bit                      BANKMASK(ANSELG), 3
#define ANSG4_bit                      BANKMASK(ANSELG), 4
#ifndef _LIB_BUILD
#endif
TMR4                                   equ 0415h
PR4                                    equ 0416h
T4CON                                  equ 0417h
#define T4CKPS0_bit                    BANKMASK(T4CON), 0
#define T4CKPS1_bit                    BANKMASK(T4CON), 1
#define TMR4ON_bit                     BANKMASK(T4CON), 2
#define T4OUTPS0_bit                   BANKMASK(T4CON), 3
#define T4OUTPS1_bit                   BANKMASK(T4CON), 4
#define T4OUTPS2_bit                   BANKMASK(T4CON), 5
#define T4OUTPS3_bit                   BANKMASK(T4CON), 6
#ifndef _LIB_BUILD
#endif
TMR6                                   equ 041Ch
PR6                                    equ 041Dh
T6CON                                  equ 041Eh
#define T6CKPS0_bit                    BANKMASK(T6CON), 0
#define T6CKPS1_bit                    BANKMASK(T6CON), 1
#define TMR6ON_bit                     BANKMASK(T6CON), 2
#define T6OUTPS0_bit                   BANKMASK(T6CON), 3
#define T6OUTPS1_bit                   BANKMASK(T6CON), 4
#define T6OUTPS2_bit                   BANKMASK(T6CON), 5
#define T6OUTPS3_bit                   BANKMASK(T6CON), 6
#ifndef _LIB_BUILD
#endif
WPUG                                   equ 048Dh
#define WPUG5_bit                      BANKMASK(WPUG), 5
#ifndef _LIB_BUILD
#endif
RC2REG                                 equ 0491h
TX2REG                                 equ 0492h
SP2BRGL                                equ 0493h
SPBRG2                                 equ 0493h
SP2BRGH                                equ 0494h
RC2STA                                 equ 0495h
#ifndef _LIB_BUILD
#endif
TX2STA                                 equ 0496h
#ifndef _LIB_BUILD
#endif
BAUD2CON                               equ 0497h
#ifndef _LIB_BUILD
#endif
LCDCON                                 equ 0791h
#define LMUX0_bit                      BANKMASK(LCDCON), 0
#define LMUX1_bit                      BANKMASK(LCDCON), 1
#define CS0_bit                        BANKMASK(LCDCON), 2
#define CS1_bit                        BANKMASK(LCDCON), 3
#define WERR_bit                       BANKMASK(LCDCON), 5
#define SLPEN_bit                      BANKMASK(LCDCON), 6
#define LCDEN_bit                      BANKMASK(LCDCON), 7
#ifndef _LIB_BUILD
#endif
LCDPS                                  equ 0792h
#define LP0_bit                        BANKMASK(LCDPS), 0
#define LP1_bit                        BANKMASK(LCDPS), 1
#define LP2_bit                        BANKMASK(LCDPS), 2
#define LP3_bit                        BANKMASK(LCDPS), 3
#define WA_bit                         BANKMASK(LCDPS), 4
#define LCDA_bit                       BANKMASK(LCDPS), 5
#define BIASMD_bit                     BANKMASK(LCDPS), 6
#define WFT_bit                        BANKMASK(LCDPS), 7
#ifndef _LIB_BUILD
#endif
LCDREF                                 equ 0793h
#define VLCD1PE_bit                    BANKMASK(LCDREF), 1
#define VLCD2PE_bit                    BANKMASK(LCDREF), 2
#define VLCD3PE_bit                    BANKMASK(LCDREF), 3
#define LCDIRI_bit                     BANKMASK(LCDREF), 5
#define LCDIRS_bit                     BANKMASK(LCDREF), 6
#define LCDIRE_bit                     BANKMASK(LCDREF), 7
#ifndef _LIB_BUILD
#endif
LCDCST                                 equ 0794h
#define LCDCST0_bit                    BANKMASK(LCDCST), 0
#define LCDCST1_bit                    BANKMASK(LCDCST), 1
#define LCDCST2_bit                    BANKMASK(LCDCST), 2
#ifndef _LIB_BUILD
#endif
LCDRL                                  equ 0795h
#define LRLAT0_bit                     BANKMASK(LCDRL), 0
#define LRLAT1_bit                     BANKMASK(LCDRL), 1
#define LRLAT2_bit                     BANKMASK(LCDRL), 2
#define LRLBP0_bit                     BANKMASK(LCDRL), 4
#define LRLBP1_bit                     BANKMASK(LCDRL), 5
#define LRLAP0_bit                     BANKMASK(LCDRL), 6
#define LRLAP1_bit                     BANKMASK(LCDRL), 7
#ifndef _LIB_BUILD
#endif
LCDSE0                                 equ 0798h
#define SE0_bit                        BANKMASK(LCDSE0), 0
#define SE1_bit                        BANKMASK(LCDSE0), 1
#define SE2_bit                        BANKMASK(LCDSE0), 2
#define SE3_bit                        BANKMASK(LCDSE0), 3
#define SE4_bit                        BANKMASK(LCDSE0), 4
#define SE5_bit                        BANKMASK(LCDSE0), 5
#define SE6_bit                        BANKMASK(LCDSE0), 6
#define SE7_bit                        BANKMASK(LCDSE0), 7
#ifndef _LIB_BUILD
#endif
LCDSE1                                 equ 0799h
#define SE8_bit                        BANKMASK(LCDSE1), 0
#define SE9_bit                        BANKMASK(LCDSE1), 1
#define SE10_bit                       BANKMASK(LCDSE1), 2
#define SE11_bit                       BANKMASK(LCDSE1), 3
#define SE12_bit                       BANKMASK(LCDSE1), 4
#define SE13_bit                       BANKMASK(LCDSE1), 5
#define SE14_bit                       BANKMASK(LCDSE1), 6
#define SE15_bit                       BANKMASK(LCDSE1), 7
#ifndef _LIB_BUILD
#endif
LCDSE2                                 equ 079Ah
#define SE16_bit                       BANKMASK(LCDSE2), 0
#define SE17_bit                       BANKMASK(LCDSE2), 1
#define SE18_bit                       BANKMASK(LCDSE2), 2
#define SE19_bit                       BANKMASK(LCDSE2), 3
#define SE20_bit                       BANKMASK(LCDSE2), 4
#define SE21_bit                       BANKMASK(LCDSE2), 5
#define SE22_bit                       BANKMASK(LCDSE2), 6
#define SE23_bit                       BANKMASK(LCDSE2), 7
#ifndef _LIB_BUILD
#endif
LCDSE3                                 equ 079Bh
#define SE24_bit                       BANKMASK(LCDSE3), 0
#define SE25_bit                       BANKMASK(LCDSE3), 1
#define SE26_bit                       BANKMASK(LCDSE3), 2
#define SE27_bit                       BANKMASK(LCDSE3), 3
#define SE28_bit                       BANKMASK(LCDSE3), 4
#define SE29_bit                       BANKMASK(LCDSE3), 5
#define SE30_bit                       BANKMASK(LCDSE3), 6
#define SE31_bit                       BANKMASK(LCDSE3), 7
#ifndef _LIB_BUILD
#endif
LCDSE4                                 equ 079Ch
#define SE32_bit                       BANKMASK(LCDSE4), 0
#define SE33_bit                       BANKMASK(LCDSE4), 1
#define SE34_bit                       BANKMASK(LCDSE4), 2
#define SE35_bit                       BANKMASK(LCDSE4), 3
#define SE36_bit                       BANKMASK(LCDSE4), 4
#define SE37_bit                       BANKMASK(LCDSE4), 5
#define SE38_bit                       BANKMASK(LCDSE4), 6
#define SE39_bit                       BANKMASK(LCDSE4), 7
#ifndef _LIB_BUILD
#endif
LCDSE5                                 equ 079Dh
#define SE40_bit                       BANKMASK(LCDSE5), 0
#define SE41_bit                       BANKMASK(LCDSE5), 1
#define SE42_bit                       BANKMASK(LCDSE5), 2
#define SE43_bit                       BANKMASK(LCDSE5), 3
#define SE44_bit                       BANKMASK(LCDSE5), 4
#define SE45_bit                       BANKMASK(LCDSE5), 5
#ifndef _LIB_BUILD
#endif
LCDDATA0                               equ 07A0h
#define SEG0COM0_bit                   BANKMASK(LCDDATA0), 0
#define SEG1COM0_bit                   BANKMASK(LCDDATA0), 1
#define SEG2COM0_bit                   BANKMASK(LCDDATA0), 2
#define SEG3COM0_bit                   BANKMASK(LCDDATA0), 3
#define SEG4COM0_bit                   BANKMASK(LCDDATA0), 4
#define SEG5COM0_bit                   BANKMASK(LCDDATA0), 5
#define SEG6COM0_bit                   BANKMASK(LCDDATA0), 6
#define SEG7COM0_bit                   BANKMASK(LCDDATA0), 7
#ifndef _LIB_BUILD
#endif
LCDDATA1                               equ 07A1h
#define SEG8COM0_bit                   BANKMASK(LCDDATA1), 0
#define SEG9COM0_bit                   BANKMASK(LCDDATA1), 1
#define SEG10COM0_bit                  BANKMASK(LCDDATA1), 2
#define SEG11COM0_bit                  BANKMASK(LCDDATA1), 3
#define SEG12COM0_bit                  BANKMASK(LCDDATA1), 4
#define SEG13COM0_bit                  BANKMASK(LCDDATA1), 5
#define SEG14COM0_bit                  BANKMASK(LCDDATA1), 6
#define SEG15COM0_bit                  BANKMASK(LCDDATA1), 7
#ifndef _LIB_BUILD
#endif
LCDDATA2                               equ 07A2h
#define SEG16COM0_bit                  BANKMASK(LCDDATA2), 0
#define SEG17COM0_bit                  BANKMASK(LCDDATA2), 1
#define SEG18COM0_bit                  BANKMASK(LCDDATA2), 2
#define SEG19COM0_bit                  BANKMASK(LCDDATA2), 3
#define SEG20COM0_bit                  BANKMASK(LCDDATA2), 4
#define SEG21COM0_bit                  BANKMASK(LCDDATA2), 5
#define SEG22COM0_bit                  BANKMASK(LCDDATA2), 6
#define SEG23COM0_bit                  BANKMASK(LCDDATA2), 7
#ifndef _LIB_BUILD
#endif
LCDDATA3                               equ 07A3h
#define SEG0COM1_bit                   BANKMASK(LCDDATA3), 0
#define SEG1COM1_bit                   BANKMASK(LCDDATA3), 1
#define SEG2COM1_bit                   BANKMASK(LCDDATA3), 2
#define SEG3COM1_bit                   BANKMASK(LCDDATA3), 3
#define SEG4COM1_bit                   BANKMASK(LCDDATA3), 4
#define SEG5COM1_bit                   BANKMASK(LCDDATA3), 5
#define SEG6COM1_bit                   BANKMASK(LCDDATA3), 6
#define SEG7COM1_bit                   BANKMASK(LCDDATA3), 7
#ifndef _LIB_BUILD
#endif
LCDDATA4                               equ 07A4h
#define SEG8COM1_bit                   BANKMASK(LCDDATA4), 0
#define SEG9COM1_bit                   BANKMASK(LCDDATA4), 1
#define SEG10COM1_bit                  BANKMASK(LCDDATA4), 2
#define SEG11COM1_bit                  BANKMASK(LCDDATA4), 3
#define SEG12COM1_bit                  BANKMASK(LCDDATA4), 4
#define SEG13COM1_bit                  BANKMASK(LCDDATA4), 5
#define SEG14COM1_bit                  BANKMASK(LCDDATA4), 6
#define SEG15COM1_bit                  BANKMASK(LCDDATA4), 7
#ifndef _LIB_BUILD
#endif
LCDDATA5                               equ 07A5h
#define SEG16COM1_bit                  BANKMASK(LCDDATA5), 0
#define SEG17COM1_bit                  BANKMASK(LCDDATA5), 1
#define SEG18COM1_bit                  BANKMASK(LCDDATA5), 2
#define SEG19COM1_bit                  BANKMASK(LCDDATA5), 3
#define SEG20COM1_bit                  BANKMASK(LCDDATA5), 4
#define SEG21COM1_bit                  BANKMASK(LCDDATA5), 5
#define SEG22COM1_bit                  BANKMASK(LCDDATA5), 6
#define SEG23COM1_bit                  BANKMASK(LCDDATA5), 7
#ifndef _LIB_BUILD
#endif
LCDDATA6                               equ 07A6h
#define SEG0COM2_bit                   BANKMASK(LCDDATA6), 0
#define SEG1COM2_bit                   BANKMASK(LCDDATA6), 1
#define SEG2COM2_bit                   BANKMASK(LCDDATA6), 2
#define SEG3COM2_bit                   BANKMASK(LCDDATA6), 3
#define SEG4COM2_bit                   BANKMASK(LCDDATA6), 4
#define SEG5COM2_bit                   BANKMASK(LCDDATA6), 5
#define SEG6COM2_bit                   BANKMASK(LCDDATA6), 6
#define SEG7COM2_bit                   BANKMASK(LCDDATA6), 7
#ifndef _LIB_BUILD
#endif
LCDDATA7                               equ 07A7h
#define SEG8COM2_bit                   BANKMASK(LCDDATA7), 0
#define SEG9COM2_bit                   BANKMASK(LCDDATA7), 1
#define SEG10COM2_bit                  BANKMASK(LCDDATA7), 2
#define SEG11COM2_bit                  BANKMASK(LCDDATA7), 3
#define SEG12COM2_bit                  BANKMASK(LCDDATA7), 4
#define SEG13COM2_bit                  BANKMASK(LCDDATA7), 5
#define SEG14COM2_bit                  BANKMASK(LCDDATA7), 6
#define SEG15COM2_bit                  BANKMASK(LCDDATA7), 7
#ifndef _LIB_BUILD
#endif
LCDDATA8                               equ 07A8h
#define SEG16COM2_bit                  BANKMASK(LCDDATA8), 0
#define SEG17COM2_bit                  BANKMASK(LCDDATA8), 1
#define SEG18COM2_bit                  BANKMASK(LCDDATA8), 2
#define SEG19COM2_bit                  BANKMASK(LCDDATA8), 3
#define SEG20COM2_bit                  BANKMASK(LCDDATA8), 4
#define SEG21COM2_bit                  BANKMASK(LCDDATA8), 5
#define SEG22COM2_bit                  BANKMASK(LCDDATA8), 6
#define SEG23COM2_bit                  BANKMASK(LCDDATA8), 7
#ifndef _LIB_BUILD
#endif
LCDDATA9                               equ 07A9h
#define SEG0COM3_bit                   BANKMASK(LCDDATA9), 0
#define SEG1COM3_bit                   BANKMASK(LCDDATA9), 1
#define SEG2COM3_bit                   BANKMASK(LCDDATA9), 2
#define SEG3COM3_bit                   BANKMASK(LCDDATA9), 3
#define SEG4COM3_bit                   BANKMASK(LCDDATA9), 4
#define SEG5COM3_bit                   BANKMASK(LCDDATA9), 5
#define SEG6COM3_bit                   BANKMASK(LCDDATA9), 6
#define SEG7COM3_bit                   BANKMASK(LCDDATA9), 7
#ifndef _LIB_BUILD
#endif
LCDDATA10                              equ 07AAh
#define SEG8COM3_bit                   BANKMASK(LCDDATA10), 0
#define SEG9COM3_bit                   BANKMASK(LCDDATA10), 1
#define SEG10COM3_bit                  BANKMASK(LCDDATA10), 2
#define SEG11COM3_bit                  BANKMASK(LCDDATA10), 3
#define SEG12COM3_bit                  BANKMASK(LCDDATA10), 4
#define SEG13COM3_bit                  BANKMASK(LCDDATA10), 5
#define SEG14COM3_bit                  BANKMASK(LCDDATA10), 6
#define SEG15COM3_bit                  BANKMASK(LCDDATA10), 7
#ifndef _LIB_BUILD
#endif
LCDDATA11                              equ 07ABh
#define SEG16COM3_bit                  BANKMASK(LCDDATA11), 0
#define SEG17COM3_bit                  BANKMASK(LCDDATA11), 1
#define SEG18COM3_bit                  BANKMASK(LCDDATA11), 2
#define SEG19COM3_bit                  BANKMASK(LCDDATA11), 3
#define SEG20COM3_bit                  BANKMASK(LCDDATA11), 4
#define SEG21COM3_bit                  BANKMASK(LCDDATA11), 5
#define SEG22COM3_bit                  BANKMASK(LCDDATA11), 6
#define SEG23COM3_bit                  BANKMASK(LCDDATA11), 7
#ifndef _LIB_BUILD
#endif
LCDDATA12                              equ 07ACh
#define SEG24COM0_bit                  BANKMASK(LCDDATA12), 0
#define SEG25COM0_bit                  BANKMASK(LCDDATA12), 1
#define SEG26COM0_bit                  BANKMASK(LCDDATA12), 2
#define SEG27COM0_bit                  BANKMASK(LCDDATA12), 3
#define SEG28COM0_bit                  BANKMASK(LCDDATA12), 4
#define SEG29COM0_bit                  BANKMASK(LCDDATA12), 5
#define SEG30COM0_bit                  BANKMASK(LCDDATA12), 6
#define SEG31COM0_bit                  BANKMASK(LCDDATA12), 7
#ifndef _LIB_BUILD
#endif
LCDDATA13                              equ 07ADh
#define SEG32COM0_bit                  BANKMASK(LCDDATA13), 0
#define SEG33COM0_bit                  BANKMASK(LCDDATA13), 1
#define SEG34COM0_bit                  BANKMASK(LCDDATA13), 2
#define SEG35COM0_bit                  BANKMASK(LCDDATA13), 3
#define SEG36COM0_bit                  BANKMASK(LCDDATA13), 4
#define SEG37COM0_bit                  BANKMASK(LCDDATA13), 5
#define SEG38COM0_bit                  BANKMASK(LCDDATA13), 6
#define SEG39COM0_bit                  BANKMASK(LCDDATA13), 7
#ifndef _LIB_BUILD
#endif
LCDDATA14                              equ 07AEh
#define SEG40COM0_bit                  BANKMASK(LCDDATA14), 0
#define SEG41COM0_bit                  BANKMASK(LCDDATA14), 1
#define SEG42COM0_bit                  BANKMASK(LCDDATA14), 2
#define SEG43COM0_bit                  BANKMASK(LCDDATA14), 3
#define SEG44COM0_bit                  BANKMASK(LCDDATA14), 4
#define SEG45COM0_bit                  BANKMASK(LCDDATA14), 5
#ifndef _LIB_BUILD
#endif
LCDDATA15                              equ 07AFh
#define SEG24COM1_bit                  BANKMASK(LCDDATA15), 0
#define SEG25COM1_bit                  BANKMASK(LCDDATA15), 1
#define SEG26COM1_bit                  BANKMASK(LCDDATA15), 2
#define SEG27COM1_bit                  BANKMASK(LCDDATA15), 3
#define SEG28COM1_bit                  BANKMASK(LCDDATA15), 4
#define SEG29COM1_bit                  BANKMASK(LCDDATA15), 5
#define SEG30COM1_bit                  BANKMASK(LCDDATA15), 6
#define SEG31COM1_bit                  BANKMASK(LCDDATA15), 7
#ifndef _LIB_BUILD
#endif
LCDDATA16                              equ 07B0h
#define SEG32COM1_bit                  BANKMASK(LCDDATA16), 0
#define SEG33COM1_bit                  BANKMASK(LCDDATA16), 1
#define SEG34COM1_bit                  BANKMASK(LCDDATA16), 2
#define SEG35COM1_bit                  BANKMASK(LCDDATA16), 3
#define SEG36COM1_bit                  BANKMASK(LCDDATA16), 4
#define SEG37COM1_bit                  BANKMASK(LCDDATA16), 5
#define SEG38COM1_bit                  BANKMASK(LCDDATA16), 6
#define SEG39COM1_bit                  BANKMASK(LCDDATA16), 7
#ifndef _LIB_BUILD
#endif
LCDDATA17                              equ 07B1h
#define SEG40COM1_bit                  BANKMASK(LCDDATA17), 0
#define SEG41COM1_bit                  BANKMASK(LCDDATA17), 1
#define SEG42COM1_bit                  BANKMASK(LCDDATA17), 2
#define SEG43COM1_bit                  BANKMASK(LCDDATA17), 3
#define SEG44COM1_bit                  BANKMASK(LCDDATA17), 4
#define SEG45COM1_bit                  BANKMASK(LCDDATA17), 5
#ifndef _LIB_BUILD
#endif
LCDDATA18                              equ 07B2h
#define SEG24COM2_bit                  BANKMASK(LCDDATA18), 0
#define SEG25COM2_bit                  BANKMASK(LCDDATA18), 1
#define SEG26COM2_bit                  BANKMASK(LCDDATA18), 2
#define SEG27COM2_bit                  BANKMASK(LCDDATA18), 3
#define SEG28COM2_bit                  BANKMASK(LCDDATA18), 4
#define SEG29COM2_bit                  BANKMASK(LCDDATA18), 5
#define SEG30COM2_bit                  BANKMASK(LCDDATA18), 6
#define SEG31COM2_bit                  BANKMASK(LCDDATA18), 7
#ifndef _LIB_BUILD
#endif
LCDDATA19                              equ 07B3h
#define SEG32COM2_bit                  BANKMASK(LCDDATA19), 0
#define SEG33COM2_bit                  BANKMASK(LCDDATA19), 1
#define SEG34COM2_bit                  BANKMASK(LCDDATA19), 2
#define SEG35COM2_bit                  BANKMASK(LCDDATA19), 3
#define SEG36COM2_bit                  BANKMASK(LCDDATA19), 4
#define SEG37COM2_bit                  BANKMASK(LCDDATA19), 5
#define SEG38COM2_bit                  BANKMASK(LCDDATA19), 6
#define SEG39COM2_bit                  BANKMASK(LCDDATA19), 7
#ifndef _LIB_BUILD
#endif
LCDDATA20                              equ 07B4h
#define SEG40COM2_bit                  BANKMASK(LCDDATA20), 0
#define SEG41COM2_bit                  BANKMASK(LCDDATA20), 1
#define SEG42COM2_bit                  BANKMASK(LCDDATA20), 2
#define SEG43COM2_bit                  BANKMASK(LCDDATA20), 3
#define SEG44COM2_bit                  BANKMASK(LCDDATA20), 4
#define SEG45COM2_bit                  BANKMASK(LCDDATA20), 5
#ifndef _LIB_BUILD
#endif
LCDDATA21                              equ 07B5h
#define SEG24COM3_bit                  BANKMASK(LCDDATA21), 0
#define SEG25COM3_bit                  BANKMASK(LCDDATA21), 1
#define SEG26COM3_bit                  BANKMASK(LCDDATA21), 2
#define SEG27COM3_bit                  BANKMASK(LCDDATA21), 3
#define SEG28COM3_bit                  BANKMASK(LCDDATA21), 4
#define SEG29COM3_bit                  BANKMASK(LCDDATA21), 5
#define SEG30COM3_bit                  BANKMASK(LCDDATA21), 6
#define SEG31COM3_bit                  BANKMASK(LCDDATA21), 7
#ifndef _LIB_BUILD
#endif
LCDDATA22                              equ 07B6h
#define SEG32COM3_bit                  BANKMASK(LCDDATA22), 0
#define SEG33COM3_bit                  BANKMASK(LCDDATA22), 1
#define SEG34COM3_bit                  BANKMASK(LCDDATA22), 2
#define SEG35COM3_bit                  BANKMASK(LCDDATA22), 3
#define SEG36COM3_bit                  BANKMASK(LCDDATA22), 4
#define SEG37COM3_bit                  BANKMASK(LCDDATA22), 5
#define SEG38COM3_bit                  BANKMASK(LCDDATA22), 6
#define SEG39COM3_bit                  BANKMASK(LCDDATA22), 7
#ifndef _LIB_BUILD
#endif
LCDDATA23                              equ 07B7h
#define SEG40COM3_bit                  BANKMASK(LCDDATA23), 0
#define SEG41COM3_bit                  BANKMASK(LCDDATA23), 1
#define SEG42COM3_bit                  BANKMASK(LCDDATA23), 2
#define SEG43COM3_bit                  BANKMASK(LCDDATA23), 3
#define SEG44COM3_bit                  BANKMASK(LCDDATA23), 4
#define SEG45COM3_bit                  BANKMASK(LCDDATA23), 5
#ifndef _LIB_BUILD
#endif
STATUS_SHAD                            equ 0FE4h
#define C_SHAD_bit                     BANKMASK(STATUS_SHAD), 0
#define DC_SHAD_bit                    BANKMASK(STATUS_SHAD), 1
#define Z_SHAD_bit                     BANKMASK(STATUS_SHAD), 2
#ifndef _LIB_BUILD
#endif
WREG_SHAD                              equ 0FE5h
BSR_SHAD                               equ 0FE6h
#ifndef _LIB_BUILD
#endif
PCLATH_SHAD                            equ 0FE7h
#ifndef _LIB_BUILD
#endif
FSR0L_SHAD                             equ 0FE8h
FSR0H_SHAD                             equ 0FE9h
FSR1L_SHAD                             equ 0FEAh
FSR1H_SHAD                             equ 0FEBh
STKPTR                                 equ 0FEDh
#ifndef _LIB_BUILD
#endif
TOSL                                   equ 0FEEh
TOSH                                   equ 0FEFh
#ifndef _LIB_BUILD
#endif

#endif
#endif

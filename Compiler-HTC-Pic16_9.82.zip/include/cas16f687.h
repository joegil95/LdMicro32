#ifndef _CASPIC_H_
#warning Header file cas16f687.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS16F687_H_
#define _CAS16F687_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define IRP_bit                        BANKMASK(STATUS), 7
#define RP0_bit                        BANKMASK(STATUS), 5
#define RP1_bit                        BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define RA0_bit                        BANKMASK(PORTA), 0
#define RA1_bit                        BANKMASK(PORTA), 1
#define RA2_bit                        BANKMASK(PORTA), 2
#define RA3_bit                        BANKMASK(PORTA), 3
#define RA4_bit                        BANKMASK(PORTA), 4
#define RA5_bit                        BANKMASK(PORTA), 5
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 0006h
#define RB4_bit                        BANKMASK(PORTB), 4
#define RB5_bit                        BANKMASK(PORTB), 5
#define RB6_bit                        BANKMASK(PORTB), 6
#define RB7_bit                        BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 0007h
#define RC0_bit                        BANKMASK(PORTC), 0
#define RC1_bit                        BANKMASK(PORTC), 1
#define RC2_bit                        BANKMASK(PORTC), 2
#define RC3_bit                        BANKMASK(PORTC), 3
#define RC4_bit                        BANKMASK(PORTC), 4
#define RC5_bit                        BANKMASK(PORTC), 5
#define RC6_bit                        BANKMASK(PORTC), 6
#define RC7_bit                        BANKMASK(PORTC), 7
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define RABIF_bit                      BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define T0IF_bit                       BANKMASK(INTCON), 2
#define RABIE_bit                      BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define T0IE_bit                       BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF_bit                     BANKMASK(PIR1), 0
#define SSPIF_bit                      BANKMASK(PIR1), 3
#define TXIF_bit                       BANKMASK(PIR1), 4
#define RCIF_bit                       BANKMASK(PIR1), 5
#define ADIF_bit                       BANKMASK(PIR1), 6
#define T1IF_bit                       BANKMASK(PIR1), 0
#ifndef _LIB_BUILD
#endif
PIR2                                   equ 000Dh
#define EEIF_bit                       BANKMASK(PIR2), 4
#define C1IF_bit                       BANKMASK(PIR2), 5
#define C2IF_bit                       BANKMASK(PIR2), 6
#define OSFIF_bit                      BANKMASK(PIR2), 7
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Eh
TMR1H                                  equ 000Fh
T1CON                                  equ 0010h
#define TMR1ON_bit                     BANKMASK(T1CON), 0
#define TMR1CS_bit                     BANKMASK(T1CON), 1
#define nT1SYNC_bit                    BANKMASK(T1CON), 2
#define T1OSCEN_bit                    BANKMASK(T1CON), 3
#define TMR1GE_bit                     BANKMASK(T1CON), 6
#define T1GINV_bit                     BANKMASK(T1CON), 7
#define T1CKPS0_bit                    BANKMASK(T1CON), 4
#define T1CKPS1_bit                    BANKMASK(T1CON), 5
#ifndef _LIB_BUILD
#endif
SSPBUF                                 equ 0013h
SSPCON                                 equ 0014h
#define CKP_bit                        BANKMASK(SSPCON), 4
#define SSPEN_bit                      BANKMASK(SSPCON), 5
#define SSPOV_bit                      BANKMASK(SSPCON), 6
#define WCOL_bit                       BANKMASK(SSPCON), 7
#define SSPM0_bit                      BANKMASK(SSPCON), 0
#define SSPM1_bit                      BANKMASK(SSPCON), 1
#define SSPM2_bit                      BANKMASK(SSPCON), 2
#define SSPM3_bit                      BANKMASK(SSPCON), 3
#ifndef _LIB_BUILD
#endif
RCSTA                                  equ 0018h
#define RX9D_bit                       BANKMASK(RCSTA), 0
#define OERR_bit                       BANKMASK(RCSTA), 1
#define FERR_bit                       BANKMASK(RCSTA), 2
#define ADDEN_bit                      BANKMASK(RCSTA), 3
#define CREN_bit                       BANKMASK(RCSTA), 4
#define SREN_bit                       BANKMASK(RCSTA), 5
#define RX9_bit                        BANKMASK(RCSTA), 6
#define SPEN_bit                       BANKMASK(RCSTA), 7
#ifndef _LIB_BUILD
#endif
TXREG                                  equ 0019h
RCREG                                  equ 001Ah
ADRESH                                 equ 001Eh
ADCON0                                 equ 001Fh
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 1
#define VCFG_bit                       BANKMASK(ADCON0), 6
#define ADFM_bit                       BANKMASK(ADCON0), 7
#define GO_bit                         BANKMASK(ADCON0), 1
#define CHS0_bit                       BANKMASK(ADCON0), 2
#define CHS1_bit                       BANKMASK(ADCON0), 3
#define CHS2_bit                       BANKMASK(ADCON0), 4
#define CHS3_bit                       BANKMASK(ADCON0), 5
#define nDONE_bit                      BANKMASK(ADCON0), 1
#define GO_DONE_bit                    BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nRABPU_bit                     BANKMASK(OPTION_REG), 7
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 0085h
#define TRISA0_bit                     BANKMASK(TRISA), 0
#define TRISA1_bit                     BANKMASK(TRISA), 1
#define TRISA2_bit                     BANKMASK(TRISA), 2
#define TRISA3_bit                     BANKMASK(TRISA), 3
#define TRISA4_bit                     BANKMASK(TRISA), 4
#define TRISA5_bit                     BANKMASK(TRISA), 5
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 0086h
#define TRISB4_bit                     BANKMASK(TRISB), 4
#define TRISB5_bit                     BANKMASK(TRISB), 5
#define TRISB6_bit                     BANKMASK(TRISB), 6
#define TRISB7_bit                     BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
TRISC                                  equ 0087h
#define TRISC0_bit                     BANKMASK(TRISC), 0
#define TRISC1_bit                     BANKMASK(TRISC), 1
#define TRISC2_bit                     BANKMASK(TRISC), 2
#define TRISC3_bit                     BANKMASK(TRISC), 3
#define TRISC4_bit                     BANKMASK(TRISC), 4
#define TRISC5_bit                     BANKMASK(TRISC), 5
#define TRISC6_bit                     BANKMASK(TRISC), 6
#define TRISC7_bit                     BANKMASK(TRISC), 7
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE_bit                     BANKMASK(PIE1), 0
#define SSPIE_bit                      BANKMASK(PIE1), 3
#define TXIE_bit                       BANKMASK(PIE1), 4
#define RCIE_bit                       BANKMASK(PIE1), 5
#define ADIE_bit                       BANKMASK(PIE1), 6
#define T1IE_bit                       BANKMASK(PIE1), 0
#ifndef _LIB_BUILD
#endif
PIE2                                   equ 008Dh
#define EEIE_bit                       BANKMASK(PIE2), 4
#define C1IE_bit                       BANKMASK(PIE2), 5
#define C2IE_bit                       BANKMASK(PIE2), 6
#define OSFIE_bit                      BANKMASK(PIE2), 7
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOR_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#define SBOREN_bit                     BANKMASK(PCON), 4
#define ULPWUE_bit                     BANKMASK(PCON), 5
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 008Fh
#define SCS_bit                        BANKMASK(OSCCON), 0
#define LTS_bit                        BANKMASK(OSCCON), 1
#define HTS_bit                        BANKMASK(OSCCON), 2
#define OSTS_bit                       BANKMASK(OSCCON), 3
#define IRCF0_bit                      BANKMASK(OSCCON), 4
#define IRCF1_bit                      BANKMASK(OSCCON), 5
#define IRCF2_bit                      BANKMASK(OSCCON), 6
#ifndef _LIB_BUILD
#endif
OSCTUNE                                equ 0090h
#define TUN0_bit                       BANKMASK(OSCTUNE), 0
#define TUN1_bit                       BANKMASK(OSCTUNE), 1
#define TUN2_bit                       BANKMASK(OSCTUNE), 2
#define TUN3_bit                       BANKMASK(OSCTUNE), 3
#define TUN4_bit                       BANKMASK(OSCTUNE), 4
#ifndef _LIB_BUILD
#endif
SSPADD                                 equ 0093h
SSPMSK                                 equ 0093h
MSK                                    equ 0093h
#define MSK0_bit                       BANKMASK(SSPMSK), 0
#define MSK1_bit                       BANKMASK(SSPMSK), 1
#define MSK2_bit                       BANKMASK(SSPMSK), 2
#define MSK3_bit                       BANKMASK(SSPMSK), 3
#define MSK4_bit                       BANKMASK(SSPMSK), 4
#define MSK5_bit                       BANKMASK(SSPMSK), 5
#define MSK6_bit                       BANKMASK(SSPMSK), 6
#define MSK7_bit                       BANKMASK(SSPMSK), 7
#ifndef _LIB_BUILD
#endif
SSPSTAT                                equ 0094h
#define BF_bit                         BANKMASK(SSPSTAT), 0
#define UA_bit                         BANKMASK(SSPSTAT), 1
#define R_nW_bit                       BANKMASK(SSPSTAT), 2
#define S_bit                          BANKMASK(SSPSTAT), 3
#define P_bit                          BANKMASK(SSPSTAT), 4
#define D_nA_bit                       BANKMASK(SSPSTAT), 5
#define CKE_bit                        BANKMASK(SSPSTAT), 6
#define SMP_bit                        BANKMASK(SSPSTAT), 7
#define R_bit                          BANKMASK(SSPSTAT), 2
#define D_bit                          BANKMASK(SSPSTAT), 5
#define I2C_READ_bit                   BANKMASK(SSPSTAT), 2
#define I2C_START_bit                  BANKMASK(SSPSTAT), 3
#define I2C_STOP_bit                   BANKMASK(SSPSTAT), 4
#define I2C_DATA_bit                   BANKMASK(SSPSTAT), 5
#define nW_bit                         BANKMASK(SSPSTAT), 2
#define nA_bit                         BANKMASK(SSPSTAT), 5
#define nWRITE_bit                     BANKMASK(SSPSTAT), 2
#define nADDRESS_bit                   BANKMASK(SSPSTAT), 5
#define R_W_bit                        BANKMASK(SSPSTAT), 2
#define D_A_bit                        BANKMASK(SSPSTAT), 5
#define READ_WRITE_bit                 BANKMASK(SSPSTAT), 2
#define DATA_ADDRESS_bit               BANKMASK(SSPSTAT), 5
#ifndef _LIB_BUILD
#endif
WPUA                                   equ 0095h
WPU                                    equ 0095h
#define WPUA0_bit                      BANKMASK(WPUA), 0
#define WPUA1_bit                      BANKMASK(WPUA), 1
#define WPUA2_bit                      BANKMASK(WPUA), 2
#define WPUA4_bit                      BANKMASK(WPUA), 4
#define WPUA5_bit                      BANKMASK(WPUA), 5
#define WPU0_bit                       BANKMASK(WPUA), 0
#define WPU1_bit                       BANKMASK(WPUA), 1
#define WPU2_bit                       BANKMASK(WPUA), 2
#define WPU4_bit                       BANKMASK(WPUA), 4
#define WPU5_bit                       BANKMASK(WPUA), 5
#ifndef _LIB_BUILD
#endif
IOCA                                   equ 0096h
IOC                                    equ 0096h
#define IOCA0_bit                      BANKMASK(IOCA), 0
#define IOCA1_bit                      BANKMASK(IOCA), 1
#define IOCA2_bit                      BANKMASK(IOCA), 2
#define IOCA3_bit                      BANKMASK(IOCA), 3
#define IOCA4_bit                      BANKMASK(IOCA), 4
#define IOCA5_bit                      BANKMASK(IOCA), 5
#define IOC0_bit                       BANKMASK(IOCA), 0
#define IOC1_bit                       BANKMASK(IOCA), 1
#define IOC2_bit                       BANKMASK(IOCA), 2
#define IOC3_bit                       BANKMASK(IOCA), 3
#define IOC4_bit                       BANKMASK(IOCA), 4
#define IOC5_bit                       BANKMASK(IOCA), 5
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0097h
#define SWDTEN_bit                     BANKMASK(WDTCON), 0
#define WDTPS0_bit                     BANKMASK(WDTCON), 1
#define WDTPS1_bit                     BANKMASK(WDTCON), 2
#define WDTPS2_bit                     BANKMASK(WDTCON), 3
#define WDTPS3_bit                     BANKMASK(WDTCON), 4
#ifndef _LIB_BUILD
#endif
TXSTA                                  equ 0098h
#define TX9D_bit                       BANKMASK(TXSTA), 0
#define TRMT_bit                       BANKMASK(TXSTA), 1
#define BRGH_bit                       BANKMASK(TXSTA), 2
#define SENDB_bit                      BANKMASK(TXSTA), 3
#define SYNC_bit                       BANKMASK(TXSTA), 4
#define TXEN_bit                       BANKMASK(TXSTA), 5
#define TX9_bit                        BANKMASK(TXSTA), 6
#define CSRC_bit                       BANKMASK(TXSTA), 7
#define SENB_bit                       BANKMASK(TXSTA), 3
#ifndef _LIB_BUILD
#endif
SPBRG                                  equ 0099h
#define BRG0_bit                       BANKMASK(SPBRG), 0
#define BRG1_bit                       BANKMASK(SPBRG), 1
#define BRG2_bit                       BANKMASK(SPBRG), 2
#define BRG3_bit                       BANKMASK(SPBRG), 3
#define BRG4_bit                       BANKMASK(SPBRG), 4
#define BRG5_bit                       BANKMASK(SPBRG), 5
#define BRG6_bit                       BANKMASK(SPBRG), 6
#define BRG7_bit                       BANKMASK(SPBRG), 7
#ifndef _LIB_BUILD
#endif
SPBRGH                                 equ 009Ah
#define BRG8_bit                       BANKMASK(SPBRGH), 0
#define BRG9_bit                       BANKMASK(SPBRGH), 1
#define BRG10_bit                      BANKMASK(SPBRGH), 2
#define BRG11_bit                      BANKMASK(SPBRGH), 3
#define BRG12_bit                      BANKMASK(SPBRGH), 4
#define BRG13_bit                      BANKMASK(SPBRGH), 5
#define BRG14_bit                      BANKMASK(SPBRGH), 6
#define BRG15_bit                      BANKMASK(SPBRGH), 7
#ifndef _LIB_BUILD
#endif
BAUDCTL                                equ 009Bh
#define ABDEN_bit                      BANKMASK(BAUDCTL), 0
#define WUE_bit                        BANKMASK(BAUDCTL), 1
#define BRG16_bit                      BANKMASK(BAUDCTL), 3
#define SCKP_bit                       BANKMASK(BAUDCTL), 4
#define RCIDL_bit                      BANKMASK(BAUDCTL), 6
#define ABDOVF_bit                     BANKMASK(BAUDCTL), 7
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 009Eh
ADCON1                                 equ 009Fh
#define ADCS0_bit                      BANKMASK(ADCON1), 4
#define ADCS1_bit                      BANKMASK(ADCON1), 5
#define ADCS2_bit                      BANKMASK(ADCON1), 6
#ifndef _LIB_BUILD
#endif
EEDAT                                  equ 010Ch
EEDATA                                 equ 010Ch
EEADR                                  equ 010Dh
WPUB                                   equ 0115h
#define WPUB4_bit                      BANKMASK(WPUB), 4
#define WPUB5_bit                      BANKMASK(WPUB), 5
#define WPUB6_bit                      BANKMASK(WPUB), 6
#define WPUB7_bit                      BANKMASK(WPUB), 7
#ifndef _LIB_BUILD
#endif
IOCB                                   equ 0116h
#define IOCB4_bit                      BANKMASK(IOCB), 4
#define IOCB5_bit                      BANKMASK(IOCB), 5
#define IOCB6_bit                      BANKMASK(IOCB), 6
#define IOCB7_bit                      BANKMASK(IOCB), 7
#ifndef _LIB_BUILD
#endif
VRCON                                  equ 0118h
#define VP6EN_bit                      BANKMASK(VRCON), 4
#define VRR_bit                        BANKMASK(VRCON), 5
#define C2VREN_bit                     BANKMASK(VRCON), 6
#define C1VREN_bit                     BANKMASK(VRCON), 7
#define VR0_bit                        BANKMASK(VRCON), 0
#define VR1_bit                        BANKMASK(VRCON), 1
#define VR2_bit                        BANKMASK(VRCON), 2
#define VR3_bit                        BANKMASK(VRCON), 3
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 0119h
#define C1R_bit                        BANKMASK(CM1CON0), 2
#define C1POL_bit                      BANKMASK(CM1CON0), 4
#define C1OE_bit                       BANKMASK(CM1CON0), 5
#define C1OUT_bit                      BANKMASK(CM1CON0), 6
#define C1ON_bit                       BANKMASK(CM1CON0), 7
#define C1CH0_bit                      BANKMASK(CM1CON0), 0
#define C1CH1_bit                      BANKMASK(CM1CON0), 1
#ifndef _LIB_BUILD
#endif
CM2CON0                                equ 011Ah
#define C2R_bit                        BANKMASK(CM2CON0), 2
#define C2POL_bit                      BANKMASK(CM2CON0), 4
#define C2OE_bit                       BANKMASK(CM2CON0), 5
#define C2OUT_bit                      BANKMASK(CM2CON0), 6
#define C2ON_bit                       BANKMASK(CM2CON0), 7
#define C2CH0_bit                      BANKMASK(CM2CON0), 0
#define C2CH1_bit                      BANKMASK(CM2CON0), 1
#ifndef _LIB_BUILD
#endif
CM2CON1                                equ 011Bh
#define C2SYNC_bit                     BANKMASK(CM2CON1), 0
#define T1GSS_bit                      BANKMASK(CM2CON1), 1
#define MC2OUT_bit                     BANKMASK(CM2CON1), 6
#define MC1OUT_bit                     BANKMASK(CM2CON1), 7
#ifndef _LIB_BUILD
#endif
ANSEL                                  equ 011Eh
#define ANS0_bit                       BANKMASK(ANSEL), 0
#define ANS1_bit                       BANKMASK(ANSEL), 1
#define ANS2_bit                       BANKMASK(ANSEL), 2
#define ANS3_bit                       BANKMASK(ANSEL), 3
#define ANS4_bit                       BANKMASK(ANSEL), 4
#define ANS5_bit                       BANKMASK(ANSEL), 5
#define ANS6_bit                       BANKMASK(ANSEL), 6
#define ANS7_bit                       BANKMASK(ANSEL), 7
#ifndef _LIB_BUILD
#endif
ANSELH                                 equ 011Fh
#define ANS8_bit                       BANKMASK(ANSELH), 0
#define ANS9_bit                       BANKMASK(ANSELH), 1
#define ANS10_bit                      BANKMASK(ANSELH), 2
#define ANS11_bit                      BANKMASK(ANSELH), 3
#ifndef _LIB_BUILD
#endif
EECON1                                 equ 018Ch
#define RD_bit                         BANKMASK(EECON1), 0
#define WR_bit                         BANKMASK(EECON1), 1
#define WREN_bit                       BANKMASK(EECON1), 2
#define WRERR_bit                      BANKMASK(EECON1), 3
#ifndef _LIB_BUILD
#endif
EECON2                                 equ 018Dh
SRCON                                  equ 019Eh
#define PULSR_bit                      BANKMASK(SRCON), 2
#define PULSS_bit                      BANKMASK(SRCON), 3
#define C2REN_bit                      BANKMASK(SRCON), 4
#define C1SEN_bit                      BANKMASK(SRCON), 5
#define SR0_bit                        BANKMASK(SRCON), 6
#define SR1_bit                        BANKMASK(SRCON), 7
#ifndef _LIB_BUILD
#endif

#endif
#endif

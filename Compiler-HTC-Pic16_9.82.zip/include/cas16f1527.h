#ifndef _CASPIC_H_
#warning Header file cas16f1527.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS16F1527_H_
#define _CAS16F1527_H_

INDF0                                  equ 0000h
INDF1                                  equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#ifndef _LIB_BUILD
#endif
FSR0L                                  equ 0004h
FSR0H                                  equ 0005h
FSR1L                                  equ 0006h
FSR1H                                  equ 0007h
BSR                                    equ 0008h
#define BSR0_bit                       BANKMASK(BSR), 0
#define BSR1_bit                       BANKMASK(BSR), 1
#define BSR2_bit                       BANKMASK(BSR), 2
#define BSR3_bit                       BANKMASK(BSR), 3
#define BSR4_bit                       BANKMASK(BSR), 4
#ifndef _LIB_BUILD
#endif
WREG                                   equ 0009h
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define IOCIF_bit                      BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define TMR0IF_bit                     BANKMASK(INTCON), 2
#define IOCIE_bit                      BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define TMR0IE_bit                     BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#define T0IF_bit                       BANKMASK(INTCON), 2
#define T0IE_bit                       BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PORTA                                  equ 000Ch
#define RA0_bit                        BANKMASK(PORTA), 0
#define RA1_bit                        BANKMASK(PORTA), 1
#define RA2_bit                        BANKMASK(PORTA), 2
#define RA3_bit                        BANKMASK(PORTA), 3
#define RA4_bit                        BANKMASK(PORTA), 4
#define RA5_bit                        BANKMASK(PORTA), 5
#define RA6_bit                        BANKMASK(PORTA), 6
#define RA7_bit                        BANKMASK(PORTA), 7
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 000Dh
#define RB0_bit                        BANKMASK(PORTB), 0
#define RB1_bit                        BANKMASK(PORTB), 1
#define RB2_bit                        BANKMASK(PORTB), 2
#define RB3_bit                        BANKMASK(PORTB), 3
#define RB4_bit                        BANKMASK(PORTB), 4
#define RB5_bit                        BANKMASK(PORTB), 5
#define RB6_bit                        BANKMASK(PORTB), 6
#define RB7_bit                        BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 000Eh
#define RC0_bit                        BANKMASK(PORTC), 0
#define RC1_bit                        BANKMASK(PORTC), 1
#define RC2_bit                        BANKMASK(PORTC), 2
#define RC3_bit                        BANKMASK(PORTC), 3
#define RC4_bit                        BANKMASK(PORTC), 4
#define RC5_bit                        BANKMASK(PORTC), 5
#define RC6_bit                        BANKMASK(PORTC), 6
#define RC7_bit                        BANKMASK(PORTC), 7
#ifndef _LIB_BUILD
#endif
PORTD                                  equ 000Fh
#define RD0_bit                        BANKMASK(PORTD), 0
#define RD1_bit                        BANKMASK(PORTD), 1
#define RD2_bit                        BANKMASK(PORTD), 2
#define RD3_bit                        BANKMASK(PORTD), 3
#define RD4_bit                        BANKMASK(PORTD), 4
#define RD5_bit                        BANKMASK(PORTD), 5
#define RD6_bit                        BANKMASK(PORTD), 6
#define RD7_bit                        BANKMASK(PORTD), 7
#ifndef _LIB_BUILD
#endif
PORTE                                  equ 0010h
#define RE0_bit                        BANKMASK(PORTE), 0
#define RE1_bit                        BANKMASK(PORTE), 1
#define RE2_bit                        BANKMASK(PORTE), 2
#define RE3_bit                        BANKMASK(PORTE), 3
#define RE4_bit                        BANKMASK(PORTE), 4
#define RE5_bit                        BANKMASK(PORTE), 5
#define RE6_bit                        BANKMASK(PORTE), 6
#define RE7_bit                        BANKMASK(PORTE), 7
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 0011h
#define TMR1IF_bit                     BANKMASK(PIR1), 0
#define TMR2IF_bit                     BANKMASK(PIR1), 1
#define CCP1IF_bit                     BANKMASK(PIR1), 2
#define SSP1IF_bit                     BANKMASK(PIR1), 3
#define TX1IF_bit                      BANKMASK(PIR1), 4
#define RC1IF_bit                      BANKMASK(PIR1), 5
#define ADIF_bit                       BANKMASK(PIR1), 6
#define TMR1GIF_bit                    BANKMASK(PIR1), 7
#define SSPIF_bit                      BANKMASK(PIR1), 3
#define TXIF_bit                       BANKMASK(PIR1), 4
#define RCIF_bit                       BANKMASK(PIR1), 5
#ifndef _LIB_BUILD
#endif
PIR2                                   equ 0012h
#define CCP2IF_bit                     BANKMASK(PIR2), 0
#define TMR8IF_bit                     BANKMASK(PIR2), 1
#define TMR10IF_bit                    BANKMASK(PIR2), 2
#define BCL1IF_bit                     BANKMASK(PIR2), 3
#define TMR3GIF_bit                    BANKMASK(PIR2), 5
#define TMR5GIF_bit                    BANKMASK(PIR2), 6
#define OSFIF_bit                      BANKMASK(PIR2), 7
#define BCLIF_bit                      BANKMASK(PIR2), 3
#ifndef _LIB_BUILD
#endif
PIR3                                   equ 0013h
#define TMR3IF_bit                     BANKMASK(PIR3), 0
#define TMR4IF_bit                     BANKMASK(PIR3), 1
#define TMR5IF_bit                     BANKMASK(PIR3), 2
#define TMR6IF_bit                     BANKMASK(PIR3), 3
#define CCP3IF_bit                     BANKMASK(PIR3), 4
#define CCP4IF_bit                     BANKMASK(PIR3), 5
#define CCP5IF_bit                     BANKMASK(PIR3), 6
#define CCP6IF_bit                     BANKMASK(PIR3), 7
#ifndef _LIB_BUILD
#endif
PIR4                                   equ 0014h
#define SSP2IF_bit                     BANKMASK(PIR4), 0
#define BCL2IF_bit                     BANKMASK(PIR4), 1
#define CCP7IF_bit                     BANKMASK(PIR4), 2
#define CCP8IF_bit                     BANKMASK(PIR4), 3
#define TX2IF_bit                      BANKMASK(PIR4), 4
#define RC2IF_bit                      BANKMASK(PIR4), 5
#define CCP9IF_bit                     BANKMASK(PIR4), 6
#define CCP10IF_bit                    BANKMASK(PIR4), 7
#ifndef _LIB_BUILD
#endif
TMR0                                   equ 0015h
TMR1L                                  equ 0016h
TMR1H                                  equ 0017h
T1CON                                  equ 0018h
#define TMR1ON_bit                     BANKMASK(T1CON), 0
#define nT1SYNC_bit                    BANKMASK(T1CON), 2
#define T1OSCEN_bit                    BANKMASK(T1CON), 3
#define T1CKPS0_bit                    BANKMASK(T1CON), 4
#define T1CKPS1_bit                    BANKMASK(T1CON), 5
#define TMR1CS0_bit                    BANKMASK(T1CON), 6
#define TMR1CS1_bit                    BANKMASK(T1CON), 7
#ifndef _LIB_BUILD
#endif
T1GCON                                 equ 0019h
#define T1GVAL_bit                     BANKMASK(T1GCON), 2
#define T1GGO_nDONE_bit                BANKMASK(T1GCON), 3
#define T1GSPM_bit                     BANKMASK(T1GCON), 4
#define T1GTM_bit                      BANKMASK(T1GCON), 5
#define T1GPOL_bit                     BANKMASK(T1GCON), 6
#define TMR1GE_bit                     BANKMASK(T1GCON), 7
#define T1GSS0_bit                     BANKMASK(T1GCON), 0
#define T1GSS1_bit                     BANKMASK(T1GCON), 1
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 001Ah
PR2                                    equ 001Bh
T2CON                                  equ 001Ch
#define TMR2ON_bit                     BANKMASK(T2CON), 2
#define T2CKPS0_bit                    BANKMASK(T2CON), 0
#define T2CKPS1_bit                    BANKMASK(T2CON), 1
#define T2OUTPS0_bit                   BANKMASK(T2CON), 3
#define T2OUTPS1_bit                   BANKMASK(T2CON), 4
#define T2OUTPS2_bit                   BANKMASK(T2CON), 5
#define T2OUTPS3_bit                   BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 008Ch
#define TRISA0_bit                     BANKMASK(TRISA), 0
#define TRISA1_bit                     BANKMASK(TRISA), 1
#define TRISA2_bit                     BANKMASK(TRISA), 2
#define TRISA3_bit                     BANKMASK(TRISA), 3
#define TRISA4_bit                     BANKMASK(TRISA), 4
#define TRISA5_bit                     BANKMASK(TRISA), 5
#define TRISA6_bit                     BANKMASK(TRISA), 6
#define TRISA7_bit                     BANKMASK(TRISA), 7
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 008Dh
#define TRISB0_bit                     BANKMASK(TRISB), 0
#define TRISB1_bit                     BANKMASK(TRISB), 1
#define TRISB2_bit                     BANKMASK(TRISB), 2
#define TRISB3_bit                     BANKMASK(TRISB), 3
#define TRISB4_bit                     BANKMASK(TRISB), 4
#define TRISB5_bit                     BANKMASK(TRISB), 5
#define TRISB6_bit                     BANKMASK(TRISB), 6
#define TRISB7_bit                     BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
TRISC                                  equ 008Eh
#define TRISC0_bit                     BANKMASK(TRISC), 0
#define TRISC1_bit                     BANKMASK(TRISC), 1
#define TRISC2_bit                     BANKMASK(TRISC), 2
#define TRISC3_bit                     BANKMASK(TRISC), 3
#define TRISC4_bit                     BANKMASK(TRISC), 4
#define TRISC5_bit                     BANKMASK(TRISC), 5
#define TRISC6_bit                     BANKMASK(TRISC), 6
#define TRISC7_bit                     BANKMASK(TRISC), 7
#ifndef _LIB_BUILD
#endif
TRISD                                  equ 008Fh
#define TRISD0_bit                     BANKMASK(TRISD), 0
#define TRISD1_bit                     BANKMASK(TRISD), 1
#define TRISD2_bit                     BANKMASK(TRISD), 2
#define TRISD3_bit                     BANKMASK(TRISD), 3
#define TRISD4_bit                     BANKMASK(TRISD), 4
#define TRISD5_bit                     BANKMASK(TRISD), 5
#define TRISD6_bit                     BANKMASK(TRISD), 6
#define TRISD7_bit                     BANKMASK(TRISD), 7
#ifndef _LIB_BUILD
#endif
TRISE                                  equ 0090h
#define TRISE0_bit                     BANKMASK(TRISE), 0
#define TRISE1_bit                     BANKMASK(TRISE), 1
#define TRISE2_bit                     BANKMASK(TRISE), 2
#define TRISE3_bit                     BANKMASK(TRISE), 3
#define TRISE4_bit                     BANKMASK(TRISE), 4
#define TRISE5_bit                     BANKMASK(TRISE), 5
#define TRISE6_bit                     BANKMASK(TRISE), 6
#define TRISE7_bit                     BANKMASK(TRISE), 7
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 0091h
#define TMR1IE_bit                     BANKMASK(PIE1), 0
#define TMR2IE_bit                     BANKMASK(PIE1), 1
#define CCP1IE_bit                     BANKMASK(PIE1), 2
#define SSP1IE_bit                     BANKMASK(PIE1), 3
#define TX1IE_bit                      BANKMASK(PIE1), 4
#define RC1IE_bit                      BANKMASK(PIE1), 5
#define ADIE_bit                       BANKMASK(PIE1), 6
#define TMR1GIE_bit                    BANKMASK(PIE1), 7
#define SSPIE_bit                      BANKMASK(PIE1), 3
#define TXIE_bit                       BANKMASK(PIE1), 4
#define RCIE_bit                       BANKMASK(PIE1), 5
#ifndef _LIB_BUILD
#endif
PIE2                                   equ 0092h
#define CCP2IE_bit                     BANKMASK(PIE2), 0
#define TMR8IE_bit                     BANKMASK(PIE2), 1
#define TMR10IE_bit                    BANKMASK(PIE2), 2
#define BCL1IE_bit                     BANKMASK(PIE2), 3
#define TMR3GIE_bit                    BANKMASK(PIE2), 5
#define TMR5GIE_bit                    BANKMASK(PIE2), 6
#define OSFIE_bit                      BANKMASK(PIE2), 7
#define BCLIE_bit                      BANKMASK(PIE2), 3
#ifndef _LIB_BUILD
#endif
PIE3                                   equ 0093h
#define TMR3IE_bit                     BANKMASK(PIE3), 0
#define TMR4IE_bit                     BANKMASK(PIE3), 1
#define TMR5IE_bit                     BANKMASK(PIE3), 2
#define TMR6IE_bit                     BANKMASK(PIE3), 3
#define CCP3IE_bit                     BANKMASK(PIE3), 4
#define CCP4IE_bit                     BANKMASK(PIE3), 5
#define CCP5IE_bit                     BANKMASK(PIE3), 6
#define CCP6IE_bit                     BANKMASK(PIE3), 7
#ifndef _LIB_BUILD
#endif
PIE4                                   equ 0094h
#define SSP2IE_bit                     BANKMASK(PIE4), 0
#define BCL2IE_bit                     BANKMASK(PIE4), 1
#define CCP7IE_bit                     BANKMASK(PIE4), 2
#define CCP8IE_bit                     BANKMASK(PIE4), 3
#define TX2IE_bit                      BANKMASK(PIE4), 4
#define RC2IE_bit                      BANKMASK(PIE4), 5
#define CCP9IE_bit                     BANKMASK(PIE4), 6
#define CCP10IE_bit                    BANKMASK(PIE4), 7
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0095h
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define TMR0SE_bit                     BANKMASK(OPTION_REG), 4
#define TMR0CS_bit                     BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nWPUEN_bit                     BANKMASK(OPTION_REG), 7
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#ifndef _LIB_BUILD
#endif
PCON                                   equ 0096h
#define nBOR_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#define nRI_bit                        BANKMASK(PCON), 2
#define nRMCLR_bit                     BANKMASK(PCON), 3
#define nRWDT_bit                      BANKMASK(PCON), 4
#define STKUNF_bit                     BANKMASK(PCON), 6
#define STKOVF_bit                     BANKMASK(PCON), 7
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0097h
#define SWDTEN_bit                     BANKMASK(WDTCON), 0
#define WDTPS0_bit                     BANKMASK(WDTCON), 1
#define WDTPS1_bit                     BANKMASK(WDTCON), 2
#define WDTPS2_bit                     BANKMASK(WDTCON), 3
#define WDTPS3_bit                     BANKMASK(WDTCON), 4
#define WDTPS4_bit                     BANKMASK(WDTCON), 5
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 0099h
#define SCS0_bit                       BANKMASK(OSCCON), 0
#define SCS1_bit                       BANKMASK(OSCCON), 1
#define IRCF0_bit                      BANKMASK(OSCCON), 3
#define IRCF1_bit                      BANKMASK(OSCCON), 4
#define IRCF2_bit                      BANKMASK(OSCCON), 5
#define IRCF3_bit                      BANKMASK(OSCCON), 6
#ifndef _LIB_BUILD
#endif
OSCSTAT                                equ 009Ah
#define HFIOFS_bit                     BANKMASK(OSCSTAT), 0
#define LFIOFR_bit                     BANKMASK(OSCSTAT), 1
#define HFIOFR_bit                     BANKMASK(OSCSTAT), 4
#define OSTS_bit                       BANKMASK(OSCSTAT), 5
#define SOSCR_bit                      BANKMASK(OSCSTAT), 7
#define T1OSCR_bit                     BANKMASK(OSCSTAT), 7
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 009Bh
ADRESH                                 equ 009Ch
ADCON0                                 equ 009Dh
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 1
#define ADGO_bit                       BANKMASK(ADCON0), 1
#define CHS0_bit                       BANKMASK(ADCON0), 2
#define CHS1_bit                       BANKMASK(ADCON0), 3
#define CHS2_bit                       BANKMASK(ADCON0), 4
#define CHS3_bit                       BANKMASK(ADCON0), 5
#define CHS4_bit                       BANKMASK(ADCON0), 6
#define GO_bit                         BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 009Eh
#define ADFM_bit                       BANKMASK(ADCON1), 7
#define ADPREF0_bit                    BANKMASK(ADCON1), 0
#define ADPREF1_bit                    BANKMASK(ADCON1), 1
#define ADCS0_bit                      BANKMASK(ADCON1), 4
#define ADCS1_bit                      BANKMASK(ADCON1), 5
#define ADCS2_bit                      BANKMASK(ADCON1), 6
#ifndef _LIB_BUILD
#endif
LATA                                   equ 010Ch
#define LATA0_bit                      BANKMASK(LATA), 0
#define LATA1_bit                      BANKMASK(LATA), 1
#define LATA2_bit                      BANKMASK(LATA), 2
#define LATA3_bit                      BANKMASK(LATA), 3
#define LATA4_bit                      BANKMASK(LATA), 4
#define LATA5_bit                      BANKMASK(LATA), 5
#define LATA6_bit                      BANKMASK(LATA), 6
#define LATA7_bit                      BANKMASK(LATA), 7
#ifndef _LIB_BUILD
#endif
LATB                                   equ 010Dh
#define LATB0_bit                      BANKMASK(LATB), 0
#define LATB1_bit                      BANKMASK(LATB), 1
#define LATB2_bit                      BANKMASK(LATB), 2
#define LATB3_bit                      BANKMASK(LATB), 3
#define LATB4_bit                      BANKMASK(LATB), 4
#define LATB5_bit                      BANKMASK(LATB), 5
#define LATB6_bit                      BANKMASK(LATB), 6
#define LATB7_bit                      BANKMASK(LATB), 7
#ifndef _LIB_BUILD
#endif
LATC                                   equ 010Eh
#define LATC0_bit                      BANKMASK(LATC), 0
#define LATC1_bit                      BANKMASK(LATC), 1
#define LATC2_bit                      BANKMASK(LATC), 2
#define LATC3_bit                      BANKMASK(LATC), 3
#define LATC4_bit                      BANKMASK(LATC), 4
#define LATC5_bit                      BANKMASK(LATC), 5
#define LATC6_bit                      BANKMASK(LATC), 6
#define LATC7_bit                      BANKMASK(LATC), 7
#ifndef _LIB_BUILD
#endif
LATD                                   equ 010Fh
#define LATD0_bit                      BANKMASK(LATD), 0
#define LATD1_bit                      BANKMASK(LATD), 1
#define LATD2_bit                      BANKMASK(LATD), 2
#define LATD3_bit                      BANKMASK(LATD), 3
#define LATD4_bit                      BANKMASK(LATD), 4
#define LATD5_bit                      BANKMASK(LATD), 5
#define LATD6_bit                      BANKMASK(LATD), 6
#define LATD7_bit                      BANKMASK(LATD), 7
#ifndef _LIB_BUILD
#endif
LATE                                   equ 0110h
#define LATE0_bit                      BANKMASK(LATE), 0
#define LATE1_bit                      BANKMASK(LATE), 1
#define LATE2_bit                      BANKMASK(LATE), 2
#define LATE3_bit                      BANKMASK(LATE), 3
#define LATE4_bit                      BANKMASK(LATE), 4
#define LATE5_bit                      BANKMASK(LATE), 5
#define LATE6_bit                      BANKMASK(LATE), 6
#define LATE7_bit                      BANKMASK(LATE), 7
#ifndef _LIB_BUILD
#endif
BORCON                                 equ 0116h
#define BORRDY_bit                     BANKMASK(BORCON), 0
#define BORFS_bit                      BANKMASK(BORCON), 6
#define SBOREN_bit                     BANKMASK(BORCON), 7
#ifndef _LIB_BUILD
#endif
FVRCON                                 equ 0117h
#define TSRNG_bit                      BANKMASK(FVRCON), 4
#define TSEN_bit                       BANKMASK(FVRCON), 5
#define FVRRDY_bit                     BANKMASK(FVRCON), 6
#define FVREN_bit                      BANKMASK(FVRCON), 7
#define ADFVR0_bit                     BANKMASK(FVRCON), 0
#define ADFVR1_bit                     BANKMASK(FVRCON), 1
#ifndef _LIB_BUILD
#endif
APFCON                                 equ 011Dh
#define CCP2SEL_bit                    BANKMASK(APFCON), 0
#define T3CKISEL_bit                   BANKMASK(APFCON), 1
#ifndef _LIB_BUILD
#endif
ANSELA                                 equ 018Ch
#define ANSA0_bit                      BANKMASK(ANSELA), 0
#define ANSA1_bit                      BANKMASK(ANSELA), 1
#define ANSA2_bit                      BANKMASK(ANSELA), 2
#define ANSA3_bit                      BANKMASK(ANSELA), 3
#define ANSA5_bit                      BANKMASK(ANSELA), 5
#ifndef _LIB_BUILD
#endif
ANSELB                                 equ 018Dh
#define ANSB0_bit                      BANKMASK(ANSELB), 0
#define ANSB1_bit                      BANKMASK(ANSELB), 1
#define ANSB2_bit                      BANKMASK(ANSELB), 2
#define ANSB3_bit                      BANKMASK(ANSELB), 3
#define ANSB4_bit                      BANKMASK(ANSELB), 4
#define ANSB5_bit                      BANKMASK(ANSELB), 5
#ifndef _LIB_BUILD
#endif
ANSELD                                 equ 018Fh
#define ANSD0_bit                      BANKMASK(ANSELD), 0
#define ANSD1_bit                      BANKMASK(ANSELD), 1
#define ANSD2_bit                      BANKMASK(ANSELD), 2
#define ANSD3_bit                      BANKMASK(ANSELD), 3
#ifndef _LIB_BUILD
#endif
ANSELE                                 equ 0190h
#define ANSE0_bit                      BANKMASK(ANSELE), 0
#define ANSE1_bit                      BANKMASK(ANSELE), 1
#define ANSE2_bit                      BANKMASK(ANSELE), 2
#ifndef _LIB_BUILD
#endif
PMADRL                                 equ 0191h
PMADRH                                 equ 0192h
#ifndef _LIB_BUILD
#endif
PMDATL                                 equ 0193h
PMDATH                                 equ 0194h
#ifndef _LIB_BUILD
#endif
PMCON1                                 equ 0195h
#define RD_bit                         BANKMASK(PMCON1), 0
#define WR_bit                         BANKMASK(PMCON1), 1
#define WREN_bit                       BANKMASK(PMCON1), 2
#define WRERR_bit                      BANKMASK(PMCON1), 3
#define FREE_bit                       BANKMASK(PMCON1), 4
#define LWLO_bit                       BANKMASK(PMCON1), 5
#define CFGS_bit                       BANKMASK(PMCON1), 6
#ifndef _LIB_BUILD
#endif
PMCON2                                 equ 0196h
VREGCON                                equ 0197h
#define VREGPM_bit                     BANKMASK(VREGCON), 1
#ifndef _LIB_BUILD
#endif
RC1REG                                 equ 0199h
RCREG                                  equ 0199h
RCREG1                                 equ 0199h
TX1REG                                 equ 019Ah
TXREG                                  equ 019Ah
TXREG1                                 equ 019Ah
SP1BRGL                                equ 019Bh
SPBRG                                  equ 019Bh
SPBRGL                                 equ 019Bh
SPBRGL1                                equ 019Bh
SP1BRGH                                equ 019Ch
SPBRGH                                 equ 019Ch
SPBRGH1                                equ 019Ch
RC1STA                                 equ 019Dh
RCSTA                                  equ 019Dh
RCSTA1                                 equ 019Dh
#ifndef _LIB_BUILD
#endif
TX1STA                                 equ 019Eh
TXSTA                                  equ 019Eh
TXSTA1                                 equ 019Eh
#ifndef _LIB_BUILD
#endif
BAUD1CON                               equ 019Fh
BAUDCON                                equ 019Fh
BAUDCON1                               equ 019Fh
#ifndef _LIB_BUILD
#endif
WPUB                                   equ 020Dh
#define WPUB0_bit                      BANKMASK(WPUB), 0
#define WPUB1_bit                      BANKMASK(WPUB), 1
#define WPUB2_bit                      BANKMASK(WPUB), 2
#define WPUB3_bit                      BANKMASK(WPUB), 3
#define WPUB4_bit                      BANKMASK(WPUB), 4
#define WPUB5_bit                      BANKMASK(WPUB), 5
#define WPUB6_bit                      BANKMASK(WPUB), 6
#define WPUB7_bit                      BANKMASK(WPUB), 7
#ifndef _LIB_BUILD
#endif
WPUD                                   equ 020Fh
#define WPUD0_bit                      BANKMASK(WPUD), 0
#define WPUD1_bit                      BANKMASK(WPUD), 1
#define WPUD2_bit                      BANKMASK(WPUD), 2
#define WPUD3_bit                      BANKMASK(WPUD), 3
#define WPUD4_bit                      BANKMASK(WPUD), 4
#define WPUD5_bit                      BANKMASK(WPUD), 5
#define WPUD6_bit                      BANKMASK(WPUD), 6
#define WPUD7_bit                      BANKMASK(WPUD), 7
#ifndef _LIB_BUILD
#endif
WPUE                                   equ 0210h
#define WPUE0_bit                      BANKMASK(WPUE), 0
#define WPUE1_bit                      BANKMASK(WPUE), 1
#define WPUE2_bit                      BANKMASK(WPUE), 2
#define WPUE3_bit                      BANKMASK(WPUE), 3
#define WPUE4_bit                      BANKMASK(WPUE), 4
#define WPUE5_bit                      BANKMASK(WPUE), 5
#define WPUE6_bit                      BANKMASK(WPUE), 6
#define WPUE7_bit                      BANKMASK(WPUE), 7
#ifndef _LIB_BUILD
#endif
SSP1BUF                                equ 0211h
SSPBUF                                 equ 0211h
SSP1ADD                                equ 0212h
SSPADD                                 equ 0212h
SSP1MSK                                equ 0213h
SSPMSK                                 equ 0213h
SSP1STAT                               equ 0214h
SSPSTAT                                equ 0214h
#ifndef _LIB_BUILD
#endif
SSP1CON1                               equ 0215h
SSPCON                                 equ 0215h
SSPCON1                                equ 0215h
#ifndef _LIB_BUILD
#endif
SSP1CON2                               equ 0216h
SSPCON2                                equ 0216h
#ifndef _LIB_BUILD
#endif
SSP1CON3                               equ 0217h
SSPCON3                                equ 0217h
#ifndef _LIB_BUILD
#endif
SSP2BUF                                equ 0219h
SSP2ADD                                equ 021Ah
SSP2MSK                                equ 021Bh
SSP2STAT                               equ 021Ch
#ifndef _LIB_BUILD
#endif
SSP2CON1                               equ 021Dh
#ifndef _LIB_BUILD
#endif
SSP2CON2                               equ 021Eh
#ifndef _LIB_BUILD
#endif
SSP2CON3                               equ 021Fh
#ifndef _LIB_BUILD
#endif
PORTF                                  equ 028Ch
#define RF0_bit                        BANKMASK(PORTF), 0
#define RF1_bit                        BANKMASK(PORTF), 1
#define RF2_bit                        BANKMASK(PORTF), 2
#define RF3_bit                        BANKMASK(PORTF), 3
#define RF4_bit                        BANKMASK(PORTF), 4
#define RF5_bit                        BANKMASK(PORTF), 5
#define RF6_bit                        BANKMASK(PORTF), 6
#define RF7_bit                        BANKMASK(PORTF), 7
#ifndef _LIB_BUILD
#endif
PORTG                                  equ 028Dh
#define RG0_bit                        BANKMASK(PORTG), 0
#define RG1_bit                        BANKMASK(PORTG), 1
#define RG2_bit                        BANKMASK(PORTG), 2
#define RG3_bit                        BANKMASK(PORTG), 3
#define RG4_bit                        BANKMASK(PORTG), 4
#define RG5_bit                        BANKMASK(PORTG), 5
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0291h
CCPR1H                                 equ 0292h
CCP1CON                                equ 0293h
#define CCP1M0_bit                     BANKMASK(CCP1CON), 0
#define CCP1M1_bit                     BANKMASK(CCP1CON), 1
#define CCP1M2_bit                     BANKMASK(CCP1CON), 2
#define CCP1M3_bit                     BANKMASK(CCP1CON), 3
#define DC1B0_bit                      BANKMASK(CCP1CON), 4
#define DC1B1_bit                      BANKMASK(CCP1CON), 5
#ifndef _LIB_BUILD
#endif
CCPR2L                                 equ 0298h
CCPR2H                                 equ 0299h
CCP2CON                                equ 029Ah
#define CCP2M0_bit                     BANKMASK(CCP2CON), 0
#define CCP2M1_bit                     BANKMASK(CCP2CON), 1
#define CCP2M2_bit                     BANKMASK(CCP2CON), 2
#define CCP2M3_bit                     BANKMASK(CCP2CON), 3
#define DC2B0_bit                      BANKMASK(CCP2CON), 4
#define DC2B1_bit                      BANKMASK(CCP2CON), 5
#ifndef _LIB_BUILD
#endif
CCPTMRS0                               equ 029Dh
#define C1TSEL0_bit                    BANKMASK(CCPTMRS0), 0
#define C1TSEL1_bit                    BANKMASK(CCPTMRS0), 1
#define C2TSEL0_bit                    BANKMASK(CCPTMRS0), 2
#define C2TSEL1_bit                    BANKMASK(CCPTMRS0), 3
#define C3TSEL0_bit                    BANKMASK(CCPTMRS0), 4
#define C3TSEL1_bit                    BANKMASK(CCPTMRS0), 5
#define C4TSEL0_bit                    BANKMASK(CCPTMRS0), 6
#define C4TSEL1_bit                    BANKMASK(CCPTMRS0), 7
#ifndef _LIB_BUILD
#endif
CCPTMRS1                               equ 029Eh
#define C5TSEL0_bit                    BANKMASK(CCPTMRS1), 0
#define C5TSEL1_bit                    BANKMASK(CCPTMRS1), 1
#define C6TSEL0_bit                    BANKMASK(CCPTMRS1), 2
#define C6TSEL1_bit                    BANKMASK(CCPTMRS1), 3
#define C7TSEL0_bit                    BANKMASK(CCPTMRS1), 4
#define C7TSEL1_bit                    BANKMASK(CCPTMRS1), 5
#define C8TSEL0_bit                    BANKMASK(CCPTMRS1), 6
#define C8TSEL1_bit                    BANKMASK(CCPTMRS1), 7
#ifndef _LIB_BUILD
#endif
CCPTMRS2                               equ 029Fh
#define C9TSEL0_bit                    BANKMASK(CCPTMRS2), 0
#define C9TSEL1_bit                    BANKMASK(CCPTMRS2), 1
#define C10TSEL0_bit                   BANKMASK(CCPTMRS2), 2
#define C10TSEL1_bit                   BANKMASK(CCPTMRS2), 3
#ifndef _LIB_BUILD
#endif
TRISF                                  equ 030Ch
#define TRISF0_bit                     BANKMASK(TRISF), 0
#define TRISF1_bit                     BANKMASK(TRISF), 1
#define TRISF2_bit                     BANKMASK(TRISF), 2
#define TRISF3_bit                     BANKMASK(TRISF), 3
#define TRISF4_bit                     BANKMASK(TRISF), 4
#define TRISF5_bit                     BANKMASK(TRISF), 5
#define TRISF6_bit                     BANKMASK(TRISF), 6
#define TRISF7_bit                     BANKMASK(TRISF), 7
#ifndef _LIB_BUILD
#endif
TRISG                                  equ 030Dh
#define TRISG0_bit                     BANKMASK(TRISG), 0
#define TRISG1_bit                     BANKMASK(TRISG), 1
#define TRISG2_bit                     BANKMASK(TRISG), 2
#define TRISG3_bit                     BANKMASK(TRISG), 3
#define TRISG4_bit                     BANKMASK(TRISG), 4
#ifndef _LIB_BUILD
#endif
CCPR3L                                 equ 0311h
CCPR3H                                 equ 0312h
CCP3CON                                equ 0313h
#define CCP3M0_bit                     BANKMASK(CCP3CON), 0
#define CCP3M1_bit                     BANKMASK(CCP3CON), 1
#define CCP3M2_bit                     BANKMASK(CCP3CON), 2
#define CCP3M3_bit                     BANKMASK(CCP3CON), 3
#define DC3B0_bit                      BANKMASK(CCP3CON), 4
#define DC3B1_bit                      BANKMASK(CCP3CON), 5
#ifndef _LIB_BUILD
#endif
CCPR4L                                 equ 0318h
CCPR4H                                 equ 0319h
CCP4CON                                equ 031Ah
#define CCP4M0_bit                     BANKMASK(CCP4CON), 0
#define CCP4M1_bit                     BANKMASK(CCP4CON), 1
#define CCP4M2_bit                     BANKMASK(CCP4CON), 2
#define CCP4M3_bit                     BANKMASK(CCP4CON), 3
#define DC4B0_bit                      BANKMASK(CCP4CON), 4
#define DC4B1_bit                      BANKMASK(CCP4CON), 5
#ifndef _LIB_BUILD
#endif
CCPR5L                                 equ 031Ch
CCPR5H                                 equ 031Dh
CCP5CON                                equ 031Eh
#define CCP5M0_bit                     BANKMASK(CCP5CON), 0
#define CCP5M1_bit                     BANKMASK(CCP5CON), 1
#define CCP5M2_bit                     BANKMASK(CCP5CON), 2
#define CCP5M3_bit                     BANKMASK(CCP5CON), 3
#define DC5B0_bit                      BANKMASK(CCP5CON), 4
#define DC5B1_bit                      BANKMASK(CCP5CON), 5
#ifndef _LIB_BUILD
#endif
LATF                                   equ 038Ch
#define LATF0_bit                      BANKMASK(LATF), 0
#define LATF1_bit                      BANKMASK(LATF), 1
#define LATF2_bit                      BANKMASK(LATF), 2
#define LATF3_bit                      BANKMASK(LATF), 3
#define LATF4_bit                      BANKMASK(LATF), 4
#define LATF5_bit                      BANKMASK(LATF), 5
#define LATF6_bit                      BANKMASK(LATF), 6
#define LATF7_bit                      BANKMASK(LATF), 7
#ifndef _LIB_BUILD
#endif
LATG                                   equ 038Dh
#define LATG0_bit                      BANKMASK(LATG), 0
#define LATG1_bit                      BANKMASK(LATG), 1
#define LATG2_bit                      BANKMASK(LATG), 2
#define LATG3_bit                      BANKMASK(LATG), 3
#define LATG4_bit                      BANKMASK(LATG), 4
#ifndef _LIB_BUILD
#endif
IOCBP                                  equ 0394h
#define IOCBP0_bit                     BANKMASK(IOCBP), 0
#define IOCBP1_bit                     BANKMASK(IOCBP), 1
#define IOCBP2_bit                     BANKMASK(IOCBP), 2
#define IOCBP3_bit                     BANKMASK(IOCBP), 3
#define IOCBP4_bit                     BANKMASK(IOCBP), 4
#define IOCBP5_bit                     BANKMASK(IOCBP), 5
#define IOCBP6_bit                     BANKMASK(IOCBP), 6
#define IOCBP7_bit                     BANKMASK(IOCBP), 7
#ifndef _LIB_BUILD
#endif
IOCBN                                  equ 0395h
#define IOCBN0_bit                     BANKMASK(IOCBN), 0
#define IOCBN1_bit                     BANKMASK(IOCBN), 1
#define IOCBN2_bit                     BANKMASK(IOCBN), 2
#define IOCBN3_bit                     BANKMASK(IOCBN), 3
#define IOCBN4_bit                     BANKMASK(IOCBN), 4
#define IOCBN5_bit                     BANKMASK(IOCBN), 5
#define IOCBN6_bit                     BANKMASK(IOCBN), 6
#define IOCBN7_bit                     BANKMASK(IOCBN), 7
#ifndef _LIB_BUILD
#endif
IOCBF                                  equ 0396h
#define IOCBF0_bit                     BANKMASK(IOCBF), 0
#define IOCBF1_bit                     BANKMASK(IOCBF), 1
#define IOCBF2_bit                     BANKMASK(IOCBF), 2
#define IOCBF3_bit                     BANKMASK(IOCBF), 3
#define IOCBF4_bit                     BANKMASK(IOCBF), 4
#define IOCBF5_bit                     BANKMASK(IOCBF), 5
#define IOCBF6_bit                     BANKMASK(IOCBF), 6
#define IOCBF7_bit                     BANKMASK(IOCBF), 7
#ifndef _LIB_BUILD
#endif
ANSELF                                 equ 040Ch
#define ANSF0_bit                      BANKMASK(ANSELF), 0
#define ANSF1_bit                      BANKMASK(ANSELF), 1
#define ANSF2_bit                      BANKMASK(ANSELF), 2
#define ANSF3_bit                      BANKMASK(ANSELF), 3
#define ANSF4_bit                      BANKMASK(ANSELF), 4
#define ANSF5_bit                      BANKMASK(ANSELF), 5
#define ANSF6_bit                      BANKMASK(ANSELF), 6
#define ANSF7_bit                      BANKMASK(ANSELF), 7
#ifndef _LIB_BUILD
#endif
ANSELG                                 equ 040Dh
#define ANSG1_bit                      BANKMASK(ANSELG), 1
#define ANSG2_bit                      BANKMASK(ANSELG), 2
#define ANSG3_bit                      BANKMASK(ANSELG), 3
#define ANSG4_bit                      BANKMASK(ANSELG), 4
#ifndef _LIB_BUILD
#endif
TMR3L                                  equ 0411h
TMR3H                                  equ 0412h
T3CON                                  equ 0413h
#define TMR3ON_bit                     BANKMASK(T3CON), 0
#define nT3SYNC_bit                    BANKMASK(T3CON), 2
#define T3OSCEN_bit                    BANKMASK(T3CON), 3
#define T3CKPS0_bit                    BANKMASK(T3CON), 4
#define T3CKPS1_bit                    BANKMASK(T3CON), 5
#define TMR3CS0_bit                    BANKMASK(T3CON), 6
#define TMR3CS1_bit                    BANKMASK(T3CON), 7
#ifndef _LIB_BUILD
#endif
T3GCON                                 equ 0414h
#define T3GVAL_bit                     BANKMASK(T3GCON), 2
#define T3GGO_nDONE_bit                BANKMASK(T3GCON), 3
#define T3GSPM_bit                     BANKMASK(T3GCON), 4
#define T3GTM_bit                      BANKMASK(T3GCON), 5
#define T3GPOL_bit                     BANKMASK(T3GCON), 6
#define TMR3GE_bit                     BANKMASK(T3GCON), 7
#define T3GSS0_bit                     BANKMASK(T3GCON), 0
#define T3GSS1_bit                     BANKMASK(T3GCON), 1
#ifndef _LIB_BUILD
#endif
TMR4                                   equ 0415h
PR4                                    equ 0416h
T4CON                                  equ 0417h
#define TMR4ON_bit                     BANKMASK(T4CON), 2
#define T4CKPS0_bit                    BANKMASK(T4CON), 0
#define T4CKPS1_bit                    BANKMASK(T4CON), 1
#define T4OUTPS0_bit                   BANKMASK(T4CON), 3
#define T4OUTPS1_bit                   BANKMASK(T4CON), 4
#define T4OUTPS2_bit                   BANKMASK(T4CON), 5
#define T4OUTPS3_bit                   BANKMASK(T4CON), 6
#ifndef _LIB_BUILD
#endif
TMR5L                                  equ 0418h
TMR5H                                  equ 0419h
T5CON                                  equ 041Ah
#define TMR5ON_bit                     BANKMASK(T5CON), 0
#define nT5SYNC_bit                    BANKMASK(T5CON), 2
#define T5OSCEN_bit                    BANKMASK(T5CON), 3
#define T5CKPS0_bit                    BANKMASK(T5CON), 4
#define T5CKPS1_bit                    BANKMASK(T5CON), 5
#define TMR5CS0_bit                    BANKMASK(T5CON), 6
#define TMR5CS1_bit                    BANKMASK(T5CON), 7
#ifndef _LIB_BUILD
#endif
T5GCON                                 equ 041Bh
#define T5GVAL_bit                     BANKMASK(T5GCON), 2
#define T5GGO_nDONE_bit                BANKMASK(T5GCON), 3
#define T5GSPM_bit                     BANKMASK(T5GCON), 4
#define T5GTM_bit                      BANKMASK(T5GCON), 5
#define T5GPOL_bit                     BANKMASK(T5GCON), 6
#define TMR5GE_bit                     BANKMASK(T5GCON), 7
#define T5GSS0_bit                     BANKMASK(T5GCON), 0
#define T5GSS1_bit                     BANKMASK(T5GCON), 1
#ifndef _LIB_BUILD
#endif
TMR6                                   equ 041Ch
PR6                                    equ 041Dh
T6CON                                  equ 041Eh
#define TMR6ON_bit                     BANKMASK(T6CON), 2
#define T6CKPS0_bit                    BANKMASK(T6CON), 0
#define T6CKPS1_bit                    BANKMASK(T6CON), 1
#define T6OUTPS0_bit                   BANKMASK(T6CON), 3
#define T6OUTPS1_bit                   BANKMASK(T6CON), 4
#define T6OUTPS2_bit                   BANKMASK(T6CON), 5
#define T6OUTPS3_bit                   BANKMASK(T6CON), 6
#ifndef _LIB_BUILD
#endif
WPUG                                   equ 048Dh
#define WPUG5_bit                      BANKMASK(WPUG), 5
#ifndef _LIB_BUILD
#endif
RC2REG                                 equ 0491h
RCREG2                                 equ 0491h
TX2REG                                 equ 0492h
TXREG2                                 equ 0492h
SP2BRGL                                equ 0493h
SPBRGL2                                equ 0493h
SP2BRGH                                equ 0494h
SPBRGH2                                equ 0494h
RC2STA                                 equ 0495h
RCSTA2                                 equ 0495h
#ifndef _LIB_BUILD
#endif
TX2STA                                 equ 0496h
TXSTA2                                 equ 0496h
#ifndef _LIB_BUILD
#endif
BAUD2CON                               equ 0497h
BAUDCON2                               equ 0497h
#ifndef _LIB_BUILD
#endif
TMR8                                   equ 0595h
PR8                                    equ 0596h
T8CON                                  equ 0597h
#define TMR8ON_bit                     BANKMASK(T8CON), 2
#define T8CKPS0_bit                    BANKMASK(T8CON), 0
#define T8CKPS1_bit                    BANKMASK(T8CON), 1
#define T8OUTPS0_bit                   BANKMASK(T8CON), 3
#define T8OUTPS1_bit                   BANKMASK(T8CON), 4
#define T8OUTPS2_bit                   BANKMASK(T8CON), 5
#define T8OUTPS3_bit                   BANKMASK(T8CON), 6
#ifndef _LIB_BUILD
#endif
TMR10                                  equ 059Ch
PR10                                   equ 059Dh
T10CON                                 equ 059Eh
#define TMR10ON_bit                    BANKMASK(T10CON), 2
#define T10CKPS0_bit                   BANKMASK(T10CON), 0
#define T10CKPS1_bit                   BANKMASK(T10CON), 1
#define T10OUTPS0_bit                  BANKMASK(T10CON), 3
#define T10OUTPS1_bit                  BANKMASK(T10CON), 4
#define T10OUTPS2_bit                  BANKMASK(T10CON), 5
#define T10OUTPS3_bit                  BANKMASK(T10CON), 6
#ifndef _LIB_BUILD
#endif
CCPR6L                                 equ 0611h
CCPR6H                                 equ 0612h
CCP6CON                                equ 0613h
#define CCP6M0_bit                     BANKMASK(CCP6CON), 0
#define CCP6M1_bit                     BANKMASK(CCP6CON), 1
#define CCP6M2_bit                     BANKMASK(CCP6CON), 2
#define CCP6M3_bit                     BANKMASK(CCP6CON), 3
#define DC6B0_bit                      BANKMASK(CCP6CON), 4
#define DC6B1_bit                      BANKMASK(CCP6CON), 5
#ifndef _LIB_BUILD
#endif
CCPR7L                                 equ 0614h
CCPR7H                                 equ 0615h
CCP7CON                                equ 0616h
#define CCP7M0_bit                     BANKMASK(CCP7CON), 0
#define CCP7M1_bit                     BANKMASK(CCP7CON), 1
#define CCP7M2_bit                     BANKMASK(CCP7CON), 2
#define CCP7M3_bit                     BANKMASK(CCP7CON), 3
#define DC7B0_bit                      BANKMASK(CCP7CON), 4
#define DC7B1_bit                      BANKMASK(CCP7CON), 5
#ifndef _LIB_BUILD
#endif
CCPR8L                                 equ 0617h
CCPR8H                                 equ 0618h
CCP8CON                                equ 0619h
#define CCP8M0_bit                     BANKMASK(CCP8CON), 0
#define CCP8M1_bit                     BANKMASK(CCP8CON), 1
#define CCP8M2_bit                     BANKMASK(CCP8CON), 2
#define CCP8M3_bit                     BANKMASK(CCP8CON), 3
#define DC8B0_bit                      BANKMASK(CCP8CON), 4
#define DC8B1_bit                      BANKMASK(CCP8CON), 5
#ifndef _LIB_BUILD
#endif
CCPR9L                                 equ 061Ah
CCPR9H                                 equ 061Bh
CCP9CON                                equ 061Ch
#define CCP9M0_bit                     BANKMASK(CCP9CON), 0
#define CCP9M1_bit                     BANKMASK(CCP9CON), 1
#define CCP9M2_bit                     BANKMASK(CCP9CON), 2
#define CCP9M3_bit                     BANKMASK(CCP9CON), 3
#define DC9B0_bit                      BANKMASK(CCP9CON), 4
#define DC9B1_bit                      BANKMASK(CCP9CON), 5
#ifndef _LIB_BUILD
#endif
CCPR10L                                equ 061Dh
CCPR10H                                equ 061Eh
CCP10CON                               equ 061Fh
#define CCP10M0_bit                    BANKMASK(CCP10CON), 0
#define CCP10M1_bit                    BANKMASK(CCP10CON), 1
#define CCP10M2_bit                    BANKMASK(CCP10CON), 2
#define CCP10M3_bit                    BANKMASK(CCP10CON), 3
#define DC10B0_bit                     BANKMASK(CCP10CON), 4
#define DC10B1_bit                     BANKMASK(CCP10CON), 5
#ifndef _LIB_BUILD
#endif
STATUS_SHAD                            equ 0FE4h
#define C_SHAD_bit                     BANKMASK(STATUS_SHAD), 0
#define DC_SHAD_bit                    BANKMASK(STATUS_SHAD), 1
#define Z_SHAD_bit                     BANKMASK(STATUS_SHAD), 2
#ifndef _LIB_BUILD
#endif
WREG_SHAD                              equ 0FE5h
BSR_SHAD                               equ 0FE6h
#ifndef _LIB_BUILD
#endif
PCLATH_SHAD                            equ 0FE7h
#ifndef _LIB_BUILD
#endif
FSR0L_SHAD                             equ 0FE8h
FSR0H_SHAD                             equ 0FE9h
FSR1L_SHAD                             equ 0FEAh
FSR1H_SHAD                             equ 0FEBh
STKPTR                                 equ 0FEDh
#ifndef _LIB_BUILD
#endif
TOSL                                   equ 0FEEh
TOSH                                   equ 0FEFh
#ifndef _LIB_BUILD
#endif

#endif
#endif

#ifndef _ASPIC_H_
#warning Header file as10f322.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS10F322_H_
#define _AS10F322_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define RP0                            BANKMASK(STATUS), 5
#define RP1                            BANKMASK(STATUS), 6
#define IRP                            BANKMASK(STATUS), 7
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define PORTA0                         BANKMASK(PORTA), 0
#define PORTA1                         BANKMASK(PORTA), 1
#define PORTA2                         BANKMASK(PORTA), 2
#define PORTA3                         BANKMASK(PORTA), 3
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 0006h
#ifndef _LIB_BUILD
#endif
LATA                                   equ 0007h
#define LATA0                          BANKMASK(LATA), 0
#define LATA1                          BANKMASK(LATA), 1
#define LATA2                          BANKMASK(LATA), 2
#ifndef _LIB_BUILD
#endif
ANSELA                                 equ 0008h
#define ANSA0                          BANKMASK(ANSELA), 0
#define ANSA1                          BANKMASK(ANSELA), 1
#define ANSA2                          BANKMASK(ANSELA), 2
#ifndef _LIB_BUILD
#endif
WPUA                                   equ 0009h
#define WPUA0                          BANKMASK(WPUA), 0
#define WPUA1                          BANKMASK(WPUA), 1
#define WPUA2                          BANKMASK(WPUA), 2
#define WPUA3                          BANKMASK(WPUA), 3
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#define PCLH0                          BANKMASK(PCLATH), 0
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define IOCIF                          BANKMASK(INTCON), 0
#define INTF                           BANKMASK(INTCON), 1
#define TMR0IF                         BANKMASK(INTCON), 2
#define IOCIE                          BANKMASK(INTCON), 3
#define INTE                           BANKMASK(INTCON), 4
#define TMR0IE                         BANKMASK(INTCON), 5
#define PEIE                           BANKMASK(INTCON), 6
#define GIE                            BANKMASK(INTCON), 7
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR2IF                         BANKMASK(PIR1), 1
#define CLC1IF                         BANKMASK(PIR1), 3
#define NCO1IF                         BANKMASK(PIR1), 4
#define ADIF                           BANKMASK(PIR1), 6
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 000Dh
#define TMR2IE                         BANKMASK(PIE1), 1
#define CLC1IE                         BANKMASK(PIE1), 3
#define NCO1IE                         BANKMASK(PIE1), 4
#define ADIE                           BANKMASK(PIE1), 6
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 000Eh
#define PSA                            BANKMASK(OPTION_REG), 3
#define T0SE                           BANKMASK(OPTION_REG), 4
#define T0CS                           BANKMASK(OPTION_REG), 5
#define INTEDG                         BANKMASK(OPTION_REG), 6
#define nWPUEN                         BANKMASK(OPTION_REG), 7
#define PS0                            BANKMASK(OPTION_REG), 0
#define PS1                            BANKMASK(OPTION_REG), 1
#define PS2                            BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
PCON                                   equ 000Fh
#define nBOR                           BANKMASK(PCON), 0
#define nPOR                           BANKMASK(PCON), 1
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 0010h
#define HFIOFS                         BANKMASK(OSCCON), 0
#define LFIOFR                         BANKMASK(OSCCON), 1
#define HFIOFR                         BANKMASK(OSCCON), 3
#define IRCF0                          BANKMASK(OSCCON), 4
#define IRCF1                          BANKMASK(OSCCON), 5
#define IRCF2                          BANKMASK(OSCCON), 6
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 0011h
PR2                                    equ 0012h
T2CON                                  equ 0013h
#define TMR2ON                         BANKMASK(T2CON), 2
#define T2CKPS0                        BANKMASK(T2CON), 0
#define T2CKPS1                        BANKMASK(T2CON), 1
#define TOUTPS0                        BANKMASK(T2CON), 3
#define TOUTPS1                        BANKMASK(T2CON), 4
#define TOUTPS2                        BANKMASK(T2CON), 5
#define TOUTPS3                        BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
IOCAP                                  equ 0014h
#define IOCAP0                         BANKMASK(IOCAP), 0
#define IOCAP1                         BANKMASK(IOCAP), 1
#define IOCAP2                         BANKMASK(IOCAP), 2
#define IOCAP3                         BANKMASK(IOCAP), 3
#ifndef _LIB_BUILD
#endif
IOCAN                                  equ 0015h
#define IOCAN0                         BANKMASK(IOCAN), 0
#define IOCAN1                         BANKMASK(IOCAN), 1
#define IOCAN2                         BANKMASK(IOCAN), 2
#define IOCAN3                         BANKMASK(IOCAN), 3
#ifndef _LIB_BUILD
#endif
IOCAF                                  equ 0016h
#define IOCAF0                         BANKMASK(IOCAF), 0
#define IOCAF1                         BANKMASK(IOCAF), 1
#define IOCAF2                         BANKMASK(IOCAF), 2
#define IOCAF3                         BANKMASK(IOCAF), 3
#ifndef _LIB_BUILD
#endif
FVRCON                                 equ 0017h
#define ADFVR0                         BANKMASK(FVRCON), 0
#define ADFVR1                         BANKMASK(FVRCON), 1
#define TSRNG                          BANKMASK(FVRCON), 4
#define TSEN                           BANKMASK(FVRCON), 5
#define FVRRDY                         BANKMASK(FVRCON), 6
#define FVREN                          BANKMASK(FVRCON), 7
#ifndef _LIB_BUILD
#endif
ADRES                                  equ 0018h
ADCON                                  equ 0019h
#define ADON                           BANKMASK(ADCON), 0
#define GO_nDONE                       BANKMASK(ADCON), 1
#define CHS0                           BANKMASK(ADCON), 2
#define CHS1                           BANKMASK(ADCON), 3
#define CHS2                           BANKMASK(ADCON), 4
#define ADCS0                          BANKMASK(ADCON), 5
#define ADCS1                          BANKMASK(ADCON), 6
#define ADCS2                          BANKMASK(ADCON), 7
#ifndef _LIB_BUILD
#endif
PMADRL                                 equ 001Ah
PMADRH                                 equ 001Bh
#define PMADR8                         BANKMASK(PMADRH), 0
#ifndef _LIB_BUILD
#endif
PMDATL                                 equ 001Ch
PMDATH                                 equ 001Dh
#ifndef _LIB_BUILD
#endif
PMCON1                                 equ 001Eh
#define RD                             BANKMASK(PMCON1), 0
#define WR                             BANKMASK(PMCON1), 1
#define WREN                           BANKMASK(PMCON1), 2
#define WRERR                          BANKMASK(PMCON1), 3
#define FREE                           BANKMASK(PMCON1), 4
#define LWLO                           BANKMASK(PMCON1), 5
#define CFGS                           BANKMASK(PMCON1), 6
#ifndef _LIB_BUILD
#endif
PMCON2                                 equ 001Fh
CLKRCON                                equ 0020h
#define CLKROE                         BANKMASK(CLKRCON), 6
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0022h
#define SWDTEN                         BANKMASK(WDTCON), 0
#define WDTPS0                         BANKMASK(WDTCON), 1
#define WDTPS1                         BANKMASK(WDTCON), 2
#define WDTPS2                         BANKMASK(WDTCON), 3
#define WDTPS3                         BANKMASK(WDTCON), 4
#define WDTPS4                         BANKMASK(WDTCON), 5
#ifndef _LIB_BUILD
#endif
VREGCON                                equ 0023h
#define VREGPM0                        BANKMASK(VREGCON), 0
#define VREGPM1                        BANKMASK(VREGCON), 1
#ifndef _LIB_BUILD
#endif
BORCON                                 equ 0024h
#define BORRDY                         BANKMASK(BORCON), 0
#define BORFS                          BANKMASK(BORCON), 6
#define SBOREN                         BANKMASK(BORCON), 7
#ifndef _LIB_BUILD
#endif

#endif
#endif

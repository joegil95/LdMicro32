#ifndef _CASPIC_H_
#warning Header file cas16f720.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS16F720_H_
#define _CAS16F720_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define IRP_bit                        BANKMASK(STATUS), 7
#define RP0_bit                        BANKMASK(STATUS), 5
#define RP1_bit                        BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define RA0_bit                        BANKMASK(PORTA), 0
#define RA1_bit                        BANKMASK(PORTA), 1
#define RA2_bit                        BANKMASK(PORTA), 2
#define RA3_bit                        BANKMASK(PORTA), 3
#define RA4_bit                        BANKMASK(PORTA), 4
#define RA5_bit                        BANKMASK(PORTA), 5
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 0006h
#define RB4_bit                        BANKMASK(PORTB), 4
#define RB5_bit                        BANKMASK(PORTB), 5
#define RB6_bit                        BANKMASK(PORTB), 6
#define RB7_bit                        BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 0007h
#define RC0_bit                        BANKMASK(PORTC), 0
#define RC1_bit                        BANKMASK(PORTC), 1
#define RC2_bit                        BANKMASK(PORTC), 2
#define RC3_bit                        BANKMASK(PORTC), 3
#define RC4_bit                        BANKMASK(PORTC), 4
#define RC5_bit                        BANKMASK(PORTC), 5
#define RC6_bit                        BANKMASK(PORTC), 6
#define RC7_bit                        BANKMASK(PORTC), 7
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define RABIF_bit                      BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define TMR0IF_bit                     BANKMASK(INTCON), 2
#define RABIE_bit                      BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define TMR0IE_bit                     BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF_bit                     BANKMASK(PIR1), 0
#define TMR2IF_bit                     BANKMASK(PIR1), 1
#define CCP1IF_bit                     BANKMASK(PIR1), 2
#define SSPIF_bit                      BANKMASK(PIR1), 3
#define TXIF_bit                       BANKMASK(PIR1), 4
#define RCIF_bit                       BANKMASK(PIR1), 5
#define ADIF_bit                       BANKMASK(PIR1), 6
#define TMR1GIF_bit                    BANKMASK(PIR1), 7
#define PSPIF_bit                      BANKMASK(PIR1), 7
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Eh
TMR1H                                  equ 000Fh
T1CON                                  equ 0010h
#define TMR1ON_bit                     BANKMASK(T1CON), 0
#define T1SYNC_bit                     BANKMASK(T1CON), 2
#define nT1SYNC_bit                    BANKMASK(T1CON), 2
#define T1CKPS0_bit                    BANKMASK(T1CON), 4
#define T1CKPS1_bit                    BANKMASK(T1CON), 5
#define TMR1CS0_bit                    BANKMASK(T1CON), 6
#define TMR1CS1_bit                    BANKMASK(T1CON), 7
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 0011h
T2CON                                  equ 0012h
#define TMR2ON_bit                     BANKMASK(T2CON), 2
#define T2CKPS0_bit                    BANKMASK(T2CON), 0
#define T2CKPS1_bit                    BANKMASK(T2CON), 1
#define TOUTPS0_bit                    BANKMASK(T2CON), 3
#define TOUTPS1_bit                    BANKMASK(T2CON), 4
#define TOUTPS2_bit                    BANKMASK(T2CON), 5
#define TOUTPS3_bit                    BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
SSPBUF                                 equ 0013h
SSPCON                                 equ 0014h
#define CKP_bit                        BANKMASK(SSPCON), 4
#define SSPEN_bit                      BANKMASK(SSPCON), 5
#define SSPOV_bit                      BANKMASK(SSPCON), 6
#define WCOL_bit                       BANKMASK(SSPCON), 7
#define SSPM0_bit                      BANKMASK(SSPCON), 0
#define SSPM1_bit                      BANKMASK(SSPCON), 1
#define SSPM2_bit                      BANKMASK(SSPCON), 2
#define SSPM3_bit                      BANKMASK(SSPCON), 3
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0015h
CCPR1H                                 equ 0016h
CCP1CON                                equ 0017h
#define B1_bit                         BANKMASK(CCP1CON), 4
#define DC1_bit                        BANKMASK(CCP1CON), 5
#define CCP1M0_bit                     BANKMASK(CCP1CON), 0
#define CCP1M1_bit                     BANKMASK(CCP1CON), 1
#define CCP1M2_bit                     BANKMASK(CCP1CON), 2
#define CCP1M3_bit                     BANKMASK(CCP1CON), 3
#define CCP1Y_bit                      BANKMASK(CCP1CON), 4
#define CCP1X_bit                      BANKMASK(CCP1CON), 5
#ifndef _LIB_BUILD
#endif
RCSTA                                  equ 0018h
#define RX9D_bit                       BANKMASK(RCSTA), 0
#define OERR_bit                       BANKMASK(RCSTA), 1
#define FERR_bit                       BANKMASK(RCSTA), 2
#define ADDEN_bit                      BANKMASK(RCSTA), 3
#define CREN_bit                       BANKMASK(RCSTA), 4
#define SREN_bit                       BANKMASK(RCSTA), 5
#define RX9_bit                        BANKMASK(RCSTA), 6
#define SPEN_bit                       BANKMASK(RCSTA), 7
#ifndef _LIB_BUILD
#endif
TXREG                                  equ 0019h
RCREG                                  equ 001Ah
ADRES                                  equ 001Eh
ADCON0                                 equ 001Fh
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 1
#define CHS0_bit                       BANKMASK(ADCON0), 2
#define CHS1_bit                       BANKMASK(ADCON0), 3
#define CHS2_bit                       BANKMASK(ADCON0), 4
#define CHS3_bit                       BANKMASK(ADCON0), 5
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nRABPU_bit                     BANKMASK(OPTION_REG), 7
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 0085h
#define TRISA0_bit                     BANKMASK(TRISA), 0
#define TRISA1_bit                     BANKMASK(TRISA), 1
#define TRISA2_bit                     BANKMASK(TRISA), 2
#define TRISA4_bit                     BANKMASK(TRISA), 4
#define TRISA5_bit                     BANKMASK(TRISA), 5
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 0086h
#define TRISB4_bit                     BANKMASK(TRISB), 4
#define TRISB5_bit                     BANKMASK(TRISB), 5
#define TRISB6_bit                     BANKMASK(TRISB), 6
#define TRISB7_bit                     BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
TRISC                                  equ 0087h
#define TRISC0_bit                     BANKMASK(TRISC), 0
#define TRISC1_bit                     BANKMASK(TRISC), 1
#define TRISC2_bit                     BANKMASK(TRISC), 2
#define TRISC3_bit                     BANKMASK(TRISC), 3
#define TRISC4_bit                     BANKMASK(TRISC), 4
#define TRISC5_bit                     BANKMASK(TRISC), 5
#define TRISC6_bit                     BANKMASK(TRISC), 6
#define TRISC7_bit                     BANKMASK(TRISC), 7
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE_bit                     BANKMASK(PIE1), 0
#define TMR2IE_bit                     BANKMASK(PIE1), 1
#define CCP1IE_bit                     BANKMASK(PIE1), 2
#define SSPIE_bit                      BANKMASK(PIE1), 3
#define TXIE_bit                       BANKMASK(PIE1), 4
#define RCIE_bit                       BANKMASK(PIE1), 5
#define ADIE_bit                       BANKMASK(PIE1), 6
#define TMR1GIE_bit                    BANKMASK(PIE1), 7
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOR_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#ifndef _LIB_BUILD
#endif
T1GCON                                 equ 008Fh
#define T1GVAL_bit                     BANKMASK(T1GCON), 2
#define T1GGO_DONE_bit                 BANKMASK(T1GCON), 3
#define T1GSPM_bit                     BANKMASK(T1GCON), 4
#define T1GTM_bit                      BANKMASK(T1GCON), 5
#define T1GPOL_bit                     BANKMASK(T1GCON), 6
#define TMR1GE_bit                     BANKMASK(T1GCON), 7
#define T1GSS0_bit                     BANKMASK(T1GCON), 0
#define T1GSS1_bit                     BANKMASK(T1GCON), 1
#define T1GGO_nDONE_bit                BANKMASK(T1GCON), 3
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 0090h
#define ICSS_bit                       BANKMASK(OSCCON), 2
#define ICSL_bit                       BANKMASK(OSCCON), 3
#define IRCF0_bit                      BANKMASK(OSCCON), 4
#define IRCF1_bit                      BANKMASK(OSCCON), 5
#ifndef _LIB_BUILD
#endif
OSCTUNE                                equ 0091h
#define TUN0_bit                       BANKMASK(OSCTUNE), 0
#define TUN1_bit                       BANKMASK(OSCTUNE), 1
#define TUN2_bit                       BANKMASK(OSCTUNE), 2
#define TUN3_bit                       BANKMASK(OSCTUNE), 3
#define TUN4_bit                       BANKMASK(OSCTUNE), 4
#define TUN5_bit                       BANKMASK(OSCTUNE), 5
#ifndef _LIB_BUILD
#endif
PR2                                    equ 0092h
SSPADD                                 equ 0093h
SSPMSK                                 equ 0093h
#define MSK0_bit                       BANKMASK(SSPMSK), 0
#define MSK1_bit                       BANKMASK(SSPMSK), 1
#define MSK2_bit                       BANKMASK(SSPMSK), 2
#define MSK3_bit                       BANKMASK(SSPMSK), 3
#define MSK4_bit                       BANKMASK(SSPMSK), 4
#define MSK5_bit                       BANKMASK(SSPMSK), 5
#define MSK6_bit                       BANKMASK(SSPMSK), 6
#define MSK7_bit                       BANKMASK(SSPMSK), 7
#ifndef _LIB_BUILD
#endif
SSPSTAT                                equ 0094h
#define BF_bit                         BANKMASK(SSPSTAT), 0
#define UA_bit                         BANKMASK(SSPSTAT), 1
#define R_nW_bit                       BANKMASK(SSPSTAT), 2
#define S_bit                          BANKMASK(SSPSTAT), 3
#define P_bit                          BANKMASK(SSPSTAT), 4
#define D_nA_bit                       BANKMASK(SSPSTAT), 5
#define CKE_bit                        BANKMASK(SSPSTAT), 6
#define SMP_bit                        BANKMASK(SSPSTAT), 7
#ifndef _LIB_BUILD
#endif
WPUA                                   equ 0095h
#define WPUA0_bit                      BANKMASK(WPUA), 0
#define WPUA1_bit                      BANKMASK(WPUA), 1
#define WPUA2_bit                      BANKMASK(WPUA), 2
#define WPUA3_bit                      BANKMASK(WPUA), 3
#define WPUA4_bit                      BANKMASK(WPUA), 4
#define WPUA5_bit                      BANKMASK(WPUA), 5
#ifndef _LIB_BUILD
#endif
IOCA                                   equ 0096h
#define IOCA0_bit                      BANKMASK(IOCA), 0
#define IOCA1_bit                      BANKMASK(IOCA), 1
#define IOCA2_bit                      BANKMASK(IOCA), 2
#define IOCA3_bit                      BANKMASK(IOCA), 3
#define IOCA4_bit                      BANKMASK(IOCA), 4
#define IOCA5_bit                      BANKMASK(IOCA), 5
#ifndef _LIB_BUILD
#endif
TXSTA                                  equ 0098h
#define TX9D_bit                       BANKMASK(TXSTA), 0
#define TRMT_bit                       BANKMASK(TXSTA), 1
#define BRGH_bit                       BANKMASK(TXSTA), 2
#define SYNC_bit                       BANKMASK(TXSTA), 4
#define TXEN_bit                       BANKMASK(TXSTA), 5
#define TX9_bit                        BANKMASK(TXSTA), 6
#define CSRC_bit                       BANKMASK(TXSTA), 7
#ifndef _LIB_BUILD
#endif
SPBRG                                  equ 0099h
FVRCON                                 equ 009Dh
#define ADFVR0_bit                     BANKMASK(FVRCON), 0
#define ADFVR1_bit                     BANKMASK(FVRCON), 1
#define TSRNG_bit                      BANKMASK(FVRCON), 4
#define TSEN_bit                       BANKMASK(FVRCON), 5
#define FVREN_bit                      BANKMASK(FVRCON), 6
#define FVRRDY_bit                     BANKMASK(FVRCON), 7
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 009Fh
#define ADCS0_bit                      BANKMASK(ADCON1), 4
#define ADCS1_bit                      BANKMASK(ADCON1), 5
#define ADCS2_bit                      BANKMASK(ADCON1), 6
#ifndef _LIB_BUILD
#endif
PMDATL                                 equ 010Ch
PMADRL                                 equ 010Dh
PMDATH                                 equ 010Eh
#ifndef _LIB_BUILD
#endif
PMADRH                                 equ 010Fh
#ifndef _LIB_BUILD
#endif
WPUB                                   equ 0115h
#define WPUB4_bit                      BANKMASK(WPUB), 4
#define WPUB5_bit                      BANKMASK(WPUB), 5
#define WPUB6_bit                      BANKMASK(WPUB), 6
#define WPUB7_bit                      BANKMASK(WPUB), 7
#ifndef _LIB_BUILD
#endif
IOCB                                   equ 0116h
#define IOCB4_bit                      BANKMASK(IOCB), 4
#define IOCB5_bit                      BANKMASK(IOCB), 5
#define IOCB6_bit                      BANKMASK(IOCB), 6
#define IOCB7_bit                      BANKMASK(IOCB), 7
#ifndef _LIB_BUILD
#endif
ANSELA                                 equ 0185h
#define ANSA0_bit                      BANKMASK(ANSELA), 0
#define ANSA1_bit                      BANKMASK(ANSELA), 1
#define ANSA2_bit                      BANKMASK(ANSELA), 2
#define ANSA4_bit                      BANKMASK(ANSELA), 4
#define ANSA5_bit                      BANKMASK(ANSELA), 5
#ifndef _LIB_BUILD
#endif
ANSELB                                 equ 0186h
#define ANSB4_bit                      BANKMASK(ANSELB), 4
#define ANSB5_bit                      BANKMASK(ANSELB), 5
#ifndef _LIB_BUILD
#endif
ANSELC                                 equ 0187h
#define ANSC0_bit                      BANKMASK(ANSELC), 0
#define ANSC1_bit                      BANKMASK(ANSELC), 1
#define ANSC2_bit                      BANKMASK(ANSELC), 2
#define ANSC3_bit                      BANKMASK(ANSELC), 3
#define ANSC6_bit                      BANKMASK(ANSELC), 6
#define ANSC7_bit                      BANKMASK(ANSELC), 7
#ifndef _LIB_BUILD
#endif
PMCON1                                 equ 018Ch
#define RD_bit                         BANKMASK(PMCON1), 0
#define WR_bit                         BANKMASK(PMCON1), 1
#define WREN_bit                       BANKMASK(PMCON1), 2
#define FREE_bit                       BANKMASK(PMCON1), 4
#define LWLO_bit                       BANKMASK(PMCON1), 5
#define CFGS_bit                       BANKMASK(PMCON1), 6
#ifndef _LIB_BUILD
#endif
PMCON2                                 equ 018Dh

#endif
#endif

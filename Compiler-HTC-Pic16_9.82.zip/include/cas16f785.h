#ifndef _CASPIC_H_
#warning Header file cas16f785.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS16F785_H_
#define _CAS16F785_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define IRP_bit                        BANKMASK(STATUS), 7
#define RP0_bit                        BANKMASK(STATUS), 5
#define RP1_bit                        BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define RA0_bit                        BANKMASK(PORTA), 0
#define RA1_bit                        BANKMASK(PORTA), 1
#define RA2_bit                        BANKMASK(PORTA), 2
#define RA3_bit                        BANKMASK(PORTA), 3
#define RA4_bit                        BANKMASK(PORTA), 4
#define RA5_bit                        BANKMASK(PORTA), 5
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 0006h
#define RB4_bit                        BANKMASK(PORTB), 4
#define RB5_bit                        BANKMASK(PORTB), 5
#define RB6_bit                        BANKMASK(PORTB), 6
#define RB7_bit                        BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 0007h
#define RC0_bit                        BANKMASK(PORTC), 0
#define RC1_bit                        BANKMASK(PORTC), 1
#define RC2_bit                        BANKMASK(PORTC), 2
#define RC3_bit                        BANKMASK(PORTC), 3
#define RC4_bit                        BANKMASK(PORTC), 4
#define RC5_bit                        BANKMASK(PORTC), 5
#define RC6_bit                        BANKMASK(PORTC), 6
#define RC7_bit                        BANKMASK(PORTC), 7
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define RAIF_bit                       BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define T0IF_bit                       BANKMASK(INTCON), 2
#define RAIE_bit                       BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define T0IE_bit                       BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#define TMR0IF_bit                     BANKMASK(INTCON), 2
#define TMR0IE_bit                     BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF_bit                     BANKMASK(PIR1), 0
#define TMR2IF_bit                     BANKMASK(PIR1), 1
#define OSFIF_bit                      BANKMASK(PIR1), 2
#define C1IF_bit                       BANKMASK(PIR1), 3
#define C2IF_bit                       BANKMASK(PIR1), 4
#define CCP1IF_bit                     BANKMASK(PIR1), 5
#define ADIF_bit                       BANKMASK(PIR1), 6
#define EEIF_bit                       BANKMASK(PIR1), 7
#define T1IF_bit                       BANKMASK(PIR1), 0
#define T2IF_bit                       BANKMASK(PIR1), 1
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Eh
TMR1H                                  equ 000Fh
T1CON                                  equ 0010h
#define TMR1ON_bit                     BANKMASK(T1CON), 0
#define TMR1CS_bit                     BANKMASK(T1CON), 1
#define nT1SYNC_bit                    BANKMASK(T1CON), 2
#define T1OSCEN_bit                    BANKMASK(T1CON), 3
#define TMR1GE_bit                     BANKMASK(T1CON), 6
#define T1GINV_bit                     BANKMASK(T1CON), 7
#define T1CKPS0_bit                    BANKMASK(T1CON), 4
#define T1CKPS1_bit                    BANKMASK(T1CON), 5
#define T1GE_bit                       BANKMASK(T1CON), 6
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 0011h
T2CON                                  equ 0012h
#define TMR2ON_bit                     BANKMASK(T2CON), 2
#define T2CKPS0_bit                    BANKMASK(T2CON), 0
#define T2CKPS1_bit                    BANKMASK(T2CON), 1
#define TOUTPS0_bit                    BANKMASK(T2CON), 3
#define TOUTPS1_bit                    BANKMASK(T2CON), 4
#define TOUTPS2_bit                    BANKMASK(T2CON), 5
#define TOUTPS3_bit                    BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0013h
CCPR1H                                 equ 0014h
CCP1CON                                equ 0015h
#define CCP1M0_bit                     BANKMASK(CCP1CON), 0
#define CCP1M1_bit                     BANKMASK(CCP1CON), 1
#define CCP1M2_bit                     BANKMASK(CCP1CON), 2
#define CCP1M3_bit                     BANKMASK(CCP1CON), 3
#define DC1B0_bit                      BANKMASK(CCP1CON), 4
#define DC1B1_bit                      BANKMASK(CCP1CON), 5
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0018h
#define SWDTEN_bit                     BANKMASK(WDTCON), 0
#define WDTPS0_bit                     BANKMASK(WDTCON), 1
#define WDTPS1_bit                     BANKMASK(WDTCON), 2
#define WDTPS2_bit                     BANKMASK(WDTCON), 3
#define WDTPS3_bit                     BANKMASK(WDTCON), 4
#ifndef _LIB_BUILD
#endif
ADRESH                                 equ 001Eh
ADCON0                                 equ 001Fh
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 1
#define VCFG_bit                       BANKMASK(ADCON0), 6
#define ADFM_bit                       BANKMASK(ADCON0), 7
#define GO_bit                         BANKMASK(ADCON0), 1
#define CHS0_bit                       BANKMASK(ADCON0), 2
#define CHS1_bit                       BANKMASK(ADCON0), 3
#define CHS2_bit                       BANKMASK(ADCON0), 4
#define CHS3_bit                       BANKMASK(ADCON0), 5
#define nDONE_bit                      BANKMASK(ADCON0), 1
#define GO_DONE_bit                    BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nRAPU_bit                      BANKMASK(OPTION_REG), 7
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 0085h
#define TRISA0_bit                     BANKMASK(TRISA), 0
#define TRISA1_bit                     BANKMASK(TRISA), 1
#define TRISA2_bit                     BANKMASK(TRISA), 2
#define TRISA3_bit                     BANKMASK(TRISA), 3
#define TRISA4_bit                     BANKMASK(TRISA), 4
#define TRISA5_bit                     BANKMASK(TRISA), 5
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 0086h
#define TRISB4_bit                     BANKMASK(TRISB), 4
#define TRISB5_bit                     BANKMASK(TRISB), 5
#define TRISB6_bit                     BANKMASK(TRISB), 6
#define TRISB7_bit                     BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
TRISC                                  equ 0087h
#define TRISC0_bit                     BANKMASK(TRISC), 0
#define TRISC1_bit                     BANKMASK(TRISC), 1
#define TRISC2_bit                     BANKMASK(TRISC), 2
#define TRISC3_bit                     BANKMASK(TRISC), 3
#define TRISC4_bit                     BANKMASK(TRISC), 4
#define TRISC5_bit                     BANKMASK(TRISC), 5
#define TRISC6_bit                     BANKMASK(TRISC), 6
#define TRISC7_bit                     BANKMASK(TRISC), 7
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE_bit                     BANKMASK(PIE1), 0
#define TMR2IE_bit                     BANKMASK(PIE1), 1
#define OSFIE_bit                      BANKMASK(PIE1), 2
#define C1IE_bit                       BANKMASK(PIE1), 3
#define C2IE_bit                       BANKMASK(PIE1), 4
#define CCP1IE_bit                     BANKMASK(PIE1), 5
#define ADIE_bit                       BANKMASK(PIE1), 6
#define EEIE_bit                       BANKMASK(PIE1), 7
#define T1IE_bit                       BANKMASK(PIE1), 0
#define T2IE_bit                       BANKMASK(PIE1), 1
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOR_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#define SBOREN_bit                     BANKMASK(PCON), 4
#define nBOD_bit                       BANKMASK(PCON), 0
#define SBODEN_bit                     BANKMASK(PCON), 4
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 008Fh
#define SCS_bit                        BANKMASK(OSCCON), 0
#define LTS_bit                        BANKMASK(OSCCON), 1
#define HTS_bit                        BANKMASK(OSCCON), 2
#define OSTS_bit                       BANKMASK(OSCCON), 3
#define IRCF0_bit                      BANKMASK(OSCCON), 4
#define IRCF1_bit                      BANKMASK(OSCCON), 5
#define IRCF2_bit                      BANKMASK(OSCCON), 6
#ifndef _LIB_BUILD
#endif
OSCTUNE                                equ 0090h
#define TUN0_bit                       BANKMASK(OSCTUNE), 0
#define TUN1_bit                       BANKMASK(OSCTUNE), 1
#define TUN2_bit                       BANKMASK(OSCTUNE), 2
#define TUN3_bit                       BANKMASK(OSCTUNE), 3
#define TUN4_bit                       BANKMASK(OSCTUNE), 4
#ifndef _LIB_BUILD
#endif
ANSEL0                                 equ 0091h
ANSEL                                  equ 0091h
#define ANS0_bit                       BANKMASK(ANSEL0), 0
#define ANS1_bit                       BANKMASK(ANSEL0), 1
#define ANS2_bit                       BANKMASK(ANSEL0), 2
#define ANS3_bit                       BANKMASK(ANSEL0), 3
#define ANS4_bit                       BANKMASK(ANSEL0), 4
#define ANS5_bit                       BANKMASK(ANSEL0), 5
#define ANS6_bit                       BANKMASK(ANSEL0), 6
#define ANS7_bit                       BANKMASK(ANSEL0), 7
#ifndef _LIB_BUILD
#endif
PR2                                    equ 0092h
ANSEL1                                 equ 0093h
#define ANS8_bit                       BANKMASK(ANSEL1), 0
#define ANS9_bit                       BANKMASK(ANSEL1), 1
#define ANS10_bit                      BANKMASK(ANSEL1), 2
#define ANS11_bit                      BANKMASK(ANSEL1), 3
#ifndef _LIB_BUILD
#endif
WPUA                                   equ 0095h
WPU                                    equ 0095h
#define WPUA0_bit                      BANKMASK(WPUA), 0
#define WPUA1_bit                      BANKMASK(WPUA), 1
#define WPUA2_bit                      BANKMASK(WPUA), 2
#define WPUA3_bit                      BANKMASK(WPUA), 3
#define WPUA4_bit                      BANKMASK(WPUA), 4
#define WPUA5_bit                      BANKMASK(WPUA), 5
#define WPU0_bit                       BANKMASK(WPUA), 0
#define WPU1_bit                       BANKMASK(WPUA), 1
#define WPU2_bit                       BANKMASK(WPUA), 2
#define WPU3_bit                       BANKMASK(WPUA), 3
#define WPU4_bit                       BANKMASK(WPUA), 4
#define WPU5_bit                       BANKMASK(WPUA), 5
#ifndef _LIB_BUILD
#endif
IOCA                                   equ 0096h
IOC                                    equ 0096h
#define IOCA0_bit                      BANKMASK(IOCA), 0
#define IOCA1_bit                      BANKMASK(IOCA), 1
#define IOCA2_bit                      BANKMASK(IOCA), 2
#define IOCA3_bit                      BANKMASK(IOCA), 3
#define IOCA4_bit                      BANKMASK(IOCA), 4
#define IOCA5_bit                      BANKMASK(IOCA), 5
#define IOC0_bit                       BANKMASK(IOCA), 0
#define IOC1_bit                       BANKMASK(IOCA), 1
#define IOC2_bit                       BANKMASK(IOCA), 2
#define IOC3_bit                       BANKMASK(IOCA), 3
#define IOC4_bit                       BANKMASK(IOCA), 4
#define IOC5_bit                       BANKMASK(IOCA), 5
#ifndef _LIB_BUILD
#endif
REFCON                                 equ 0098h
#define CVROE_bit                      BANKMASK(REFCON), 1
#define VROE_bit                       BANKMASK(REFCON), 2
#define VREN_bit                       BANKMASK(REFCON), 3
#define VRBB_bit                       BANKMASK(REFCON), 4
#define BGST_bit                       BANKMASK(REFCON), 5
#ifndef _LIB_BUILD
#endif
VRCON                                  equ 0099h
#define VR0_bit                        BANKMASK(VRCON), 0
#define VR1_bit                        BANKMASK(VRCON), 1
#define VR2_bit                        BANKMASK(VRCON), 2
#define VR3_bit                        BANKMASK(VRCON), 3
#define VRR_bit                        BANKMASK(VRCON), 5
#define C2VREN_bit                     BANKMASK(VRCON), 6
#define C1VREN_bit                     BANKMASK(VRCON), 7
#ifndef _LIB_BUILD
#endif
EEDATA                                 equ 009Ah
EEDAT                                  equ 009Ah
EEADR                                  equ 009Bh
EECON1                                 equ 009Ch
#define RD_bit                         BANKMASK(EECON1), 0
#define WR_bit                         BANKMASK(EECON1), 1
#define WREN_bit                       BANKMASK(EECON1), 2
#define WRERR_bit                      BANKMASK(EECON1), 3
#ifndef _LIB_BUILD
#endif
EECON2                                 equ 009Dh
ADRESL                                 equ 009Eh
ADCON1                                 equ 009Fh
#define ADCS0_bit                      BANKMASK(ADCON1), 4
#define ADCS1_bit                      BANKMASK(ADCON1), 5
#define ADCS2_bit                      BANKMASK(ADCON1), 6
#ifndef _LIB_BUILD
#endif
PWMCON1                                equ 0110h
#define OVRLP_bit                      BANKMASK(PWMCON1), 7
#define CMDLY0_bit                     BANKMASK(PWMCON1), 0
#define CMDLY1_bit                     BANKMASK(PWMCON1), 1
#define CMDLY2_bit                     BANKMASK(PWMCON1), 2
#define CMDLY3_bit                     BANKMASK(PWMCON1), 3
#define CMDLY4_bit                     BANKMASK(PWMCON1), 4
#define COMOD0_bit                     BANKMASK(PWMCON1), 5
#define COMOD1_bit                     BANKMASK(PWMCON1), 6
#ifndef _LIB_BUILD
#endif
PWMCON0                                equ 0111h
#define PH1EN_bit                      BANKMASK(PWMCON0), 0
#define PH2EN_bit                      BANKMASK(PWMCON0), 1
#define BLANK1_bit                     BANKMASK(PWMCON0), 4
#define BLANK2_bit                     BANKMASK(PWMCON0), 5
#define PASEN_bit                      BANKMASK(PWMCON0), 6
#define PRSEN_bit                      BANKMASK(PWMCON0), 7
#define SYNC0_bit                      BANKMASK(PWMCON0), 2
#define SYNC1_bit                      BANKMASK(PWMCON0), 3
#ifndef _LIB_BUILD
#endif
PWMCLK                                 equ 0112h
#define PWMASE_bit                     BANKMASK(PWMCLK), 7
#define PER0_bit                       BANKMASK(PWMCLK), 0
#define PER1_bit                       BANKMASK(PWMCLK), 1
#define PER2_bit                       BANKMASK(PWMCLK), 2
#define PER3_bit                       BANKMASK(PWMCLK), 3
#define PER4_bit                       BANKMASK(PWMCLK), 4
#define PWMP0_bit                      BANKMASK(PWMCLK), 5
#define PWMP1_bit                      BANKMASK(PWMCLK), 6
#ifndef _LIB_BUILD
#endif
PWMPH1                                 equ 0113h
#ifndef _LIB_BUILD
#endif
PWMPH2                                 equ 0114h
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 0119h
#define C1R_bit                        BANKMASK(CM1CON0), 2
#define C1SP_bit                       BANKMASK(CM1CON0), 3
#define C1POL_bit                      BANKMASK(CM1CON0), 4
#define C1OE_bit                       BANKMASK(CM1CON0), 5
#define C1OUT_bit                      BANKMASK(CM1CON0), 6
#define C1ON_bit                       BANKMASK(CM1CON0), 7
#define C1CH0_bit                      BANKMASK(CM1CON0), 0
#define C1CH1_bit                      BANKMASK(CM1CON0), 1
#ifndef _LIB_BUILD
#endif
CM2CON0                                equ 011Ah
#define C2R_bit                        BANKMASK(CM2CON0), 2
#define C2SP_bit                       BANKMASK(CM2CON0), 3
#define C2POL_bit                      BANKMASK(CM2CON0), 4
#define C2OE_bit                       BANKMASK(CM2CON0), 5
#define C2OUT_bit                      BANKMASK(CM2CON0), 6
#define C2ON_bit                       BANKMASK(CM2CON0), 7
#define C2CH0_bit                      BANKMASK(CM2CON0), 0
#define C2CH1_bit                      BANKMASK(CM2CON0), 1
#ifndef _LIB_BUILD
#endif
CM2CON1                                equ 011Bh
#define C2SYNC_bit                     BANKMASK(CM2CON1), 0
#define T1GSS_bit                      BANKMASK(CM2CON1), 1
#define MC2OUT_bit                     BANKMASK(CM2CON1), 6
#define MC1OUT_bit                     BANKMASK(CM2CON1), 7
#ifndef _LIB_BUILD
#endif
OPA1CON                                equ 011Ch
#ifndef _LIB_BUILD
#endif
OPA2CON                                equ 011Dh
#ifndef _LIB_BUILD
#endif

#endif
#endif

#ifndef _ASPIC_H_
#warning Header file as12f752.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS12F752_H_
#define _AS12F752_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define RP0                            BANKMASK(STATUS), 5
#define RP1                            BANKMASK(STATUS), 6
#define IRP                            BANKMASK(STATUS), 7
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define RA0                            BANKMASK(PORTA), 0
#define RA1                            BANKMASK(PORTA), 1
#define RA2                            BANKMASK(PORTA), 2
#define RA3                            BANKMASK(PORTA), 3
#define RA4                            BANKMASK(PORTA), 4
#define RA5                            BANKMASK(PORTA), 5
#ifndef _LIB_BUILD
#endif
IOCAF                                  equ 0008h
#define IOCAF0                         BANKMASK(IOCAF), 0
#define IOCAF1                         BANKMASK(IOCAF), 1
#define IOCAF2                         BANKMASK(IOCAF), 2
#define IOCAF3                         BANKMASK(IOCAF), 3
#define IOCAF4                         BANKMASK(IOCAF), 4
#define IOCAF5                         BANKMASK(IOCAF), 5
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define IOCIF                          BANKMASK(INTCON), 0
#define INTF                           BANKMASK(INTCON), 1
#define T0IF                           BANKMASK(INTCON), 2
#define IOCIE                          BANKMASK(INTCON), 3
#define INTE                           BANKMASK(INTCON), 4
#define T0IE                           BANKMASK(INTCON), 5
#define PEIE                           BANKMASK(INTCON), 6
#define GIE                            BANKMASK(INTCON), 7
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF                         BANKMASK(PIR1), 0
#define TMR2IF                         BANKMASK(PIR1), 1
#define HLTMR1IF                       BANKMASK(PIR1), 2
#define ADIF                           BANKMASK(PIR1), 6
#define TMR1GIF                        BANKMASK(PIR1), 7
#ifndef _LIB_BUILD
#endif
PIR2                                   equ 000Dh
#define CCP1IF                         BANKMASK(PIR2), 0
#define COG1IF                         BANKMASK(PIR2), 2
#define C1IF                           BANKMASK(PIR2), 4
#define C2IF                           BANKMASK(PIR2), 5
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Fh
TMR1H                                  equ 0010h
T1CON                                  equ 0011h
#define TMR1ON                         BANKMASK(T1CON), 0
#define nT1SYNC                        BANKMASK(T1CON), 2
#define T1CKPS0                        BANKMASK(T1CON), 4
#define T1CKPS1                        BANKMASK(T1CON), 5
#define TMR1CS0                        BANKMASK(T1CON), 6
#define TMR1CS1                        BANKMASK(T1CON), 7
#ifndef _LIB_BUILD
#endif
T1GCON                                 equ 0012h
#define T1GVAL                         BANKMASK(T1GCON), 2
#define T1GGO_nDONE                    BANKMASK(T1GCON), 3
#define T1GSPM                         BANKMASK(T1GCON), 4
#define T1GTM                          BANKMASK(T1GCON), 5
#define T1GPOL                         BANKMASK(T1GCON), 6
#define TMR1GE                         BANKMASK(T1GCON), 7
#define T1GSS0                         BANKMASK(T1GCON), 0
#define T1GSS1                         BANKMASK(T1GCON), 1
#define T1GGO                          BANKMASK(T1GCON), 3
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0013h
CCPR1H                                 equ 0014h
CCP1CON                                equ 0015h
#define CCP1M0                         BANKMASK(CCP1CON), 0
#define CCP1M1                         BANKMASK(CCP1CON), 1
#define CCP1M2                         BANKMASK(CCP1CON), 2
#define CCP1M3                         BANKMASK(CCP1CON), 3
#define DC1B0                          BANKMASK(CCP1CON), 4
#define DC1B1                          BANKMASK(CCP1CON), 5
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 001Ch
ADRESH                                 equ 001Dh
ADCON0                                 equ 001Eh
#define ADON                           BANKMASK(ADCON0), 0
#define GO_nDONE                       BANKMASK(ADCON0), 1
#define VCFG                           BANKMASK(ADCON0), 6
#define ADFM                           BANKMASK(ADCON0), 7
#define CHS0                           BANKMASK(ADCON0), 2
#define CHS1                           BANKMASK(ADCON0), 3
#define CHS2                           BANKMASK(ADCON0), 4
#define CHS3                           BANKMASK(ADCON0), 5
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 001Fh
#define ADCS0                          BANKMASK(ADCON1), 4
#define ADCS1                          BANKMASK(ADCON1), 5
#define ADCS2                          BANKMASK(ADCON1), 6
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA                            BANKMASK(OPTION_REG), 3
#define T0SE                           BANKMASK(OPTION_REG), 4
#define T0CS                           BANKMASK(OPTION_REG), 5
#define INTEDG                         BANKMASK(OPTION_REG), 6
#define nRAPU                          BANKMASK(OPTION_REG), 7
#define PS0                            BANKMASK(OPTION_REG), 0
#define PS1                            BANKMASK(OPTION_REG), 1
#define PS2                            BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 0085h
#define TRISA0                         BANKMASK(TRISA), 0
#define TRISA1                         BANKMASK(TRISA), 1
#define TRISA2                         BANKMASK(TRISA), 2
#define TRISA3                         BANKMASK(TRISA), 3
#define TRISA4                         BANKMASK(TRISA), 4
#define TRISA5                         BANKMASK(TRISA), 5
#ifndef _LIB_BUILD
#endif
IOCAP                                  equ 0088h
#define IOCAP0                         BANKMASK(IOCAP), 0
#define IOCAP1                         BANKMASK(IOCAP), 1
#define IOCAP2                         BANKMASK(IOCAP), 2
#define IOCAP3                         BANKMASK(IOCAP), 3
#define IOCAP4                         BANKMASK(IOCAP), 4
#define IOCAP5                         BANKMASK(IOCAP), 5
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE                         BANKMASK(PIE1), 0
#define TMR2IE                         BANKMASK(PIE1), 1
#define HLTMR1IE                       BANKMASK(PIE1), 2
#define ADIE                           BANKMASK(PIE1), 6
#define TMR1GIE                        BANKMASK(PIE1), 7
#ifndef _LIB_BUILD
#endif
PIE2                                   equ 008Dh
#define CCP1IE                         BANKMASK(PIE2), 0
#define COG1IE                         BANKMASK(PIE2), 2
#define C1IE                           BANKMASK(PIE2), 4
#define C2IE                           BANKMASK(PIE2), 5
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 008Fh
#define LTS                            BANKMASK(OSCCON), 1
#define HTS                            BANKMASK(OSCCON), 2
#define IRCF0                          BANKMASK(OSCCON), 4
#define IRCF1                          BANKMASK(OSCCON), 5
#ifndef _LIB_BUILD
#endif
FVRCON                                 equ 0090h
#define FVRBUFSS                       BANKMASK(FVRCON), 4
#define FVRBUFEN                       BANKMASK(FVRCON), 5
#define FVRRDY                         BANKMASK(FVRCON), 6
#define FVREN                          BANKMASK(FVRCON), 7
#ifndef _LIB_BUILD
#endif
DACCON0                                equ 0091h
#define DACPSS0                        BANKMASK(DACCON0), 2
#define DACOE                          BANKMASK(DACCON0), 5
#define DACRNG                         BANKMASK(DACCON0), 6
#define DACEN                          BANKMASK(DACCON0), 7
#ifndef _LIB_BUILD
#endif
DACCON1                                equ 0092h
#define DACR0                          BANKMASK(DACCON1), 0
#define DACR1                          BANKMASK(DACCON1), 1
#define DACR2                          BANKMASK(DACCON1), 2
#define DACR3                          BANKMASK(DACCON1), 3
#define DACR4                          BANKMASK(DACCON1), 4
#ifndef _LIB_BUILD
#endif
CM2CON0                                equ 009Bh
C2CON0                                 equ 009Bh
#define C2SYNC                         BANKMASK(CM2CON0), 0
#define C2HYS                          BANKMASK(CM2CON0), 1
#define C2SP                           BANKMASK(CM2CON0), 2
#define C2POL                          BANKMASK(CM2CON0), 4
#define C2OE                           BANKMASK(CM2CON0), 5
#define C2OUT                          BANKMASK(CM2CON0), 6
#define C2ON                           BANKMASK(CM2CON0), 7
#ifndef _LIB_BUILD
#endif
CM2CON1                                equ 009Ch
C2CON1                                 equ 009Ch
#define C2NCH0                         BANKMASK(CM2CON1), 0
#define C2INTN                         BANKMASK(CM2CON1), 6
#define C2INTP                         BANKMASK(CM2CON1), 7
#define C2PCH0                         BANKMASK(CM2CON1), 4
#define C2PCH1                         BANKMASK(CM2CON1), 5
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 009Dh
C1CON0                                 equ 009Dh
#define C1SYNC                         BANKMASK(CM1CON0), 0
#define C1HYS                          BANKMASK(CM1CON0), 1
#define C1SP                           BANKMASK(CM1CON0), 2
#define C1POL                          BANKMASK(CM1CON0), 4
#define C1OE                           BANKMASK(CM1CON0), 5
#define C1OUT                          BANKMASK(CM1CON0), 6
#define C1ON                           BANKMASK(CM1CON0), 7
#ifndef _LIB_BUILD
#endif
CM1CON1                                equ 009Eh
C1CON1                                 equ 009Eh
#define C1NCH0                         BANKMASK(CM1CON1), 0
#define C1INTN                         BANKMASK(CM1CON1), 6
#define C1INTP                         BANKMASK(CM1CON1), 7
#define C1PCH0                         BANKMASK(CM1CON1), 4
#define C1PCH1                         BANKMASK(CM1CON1), 5
#ifndef _LIB_BUILD
#endif
CMOUT                                  equ 009Fh
MCOUT                                  equ 009Fh
#define MCOUT1                         BANKMASK(CMOUT), 0
#define MCOUT2                         BANKMASK(CMOUT), 1
#ifndef _LIB_BUILD
#endif
LATA                                   equ 0105h
#define LATA0                          BANKMASK(LATA), 0
#define LATA1                          BANKMASK(LATA), 1
#define LATA2                          BANKMASK(LATA), 2
#define LATA4                          BANKMASK(LATA), 4
#define LATA5                          BANKMASK(LATA), 5
#ifndef _LIB_BUILD
#endif
IOCAN                                  equ 0108h
#define IOCAN0                         BANKMASK(IOCAN), 0
#define IOCAN1                         BANKMASK(IOCAN), 1
#define IOCAN2                         BANKMASK(IOCAN), 2
#define IOCAN3                         BANKMASK(IOCAN), 3
#define IOCAN4                         BANKMASK(IOCAN), 4
#define IOCAN5                         BANKMASK(IOCAN), 5
#ifndef _LIB_BUILD
#endif
WPUA                                   equ 010Ch
#define WPUA0                          BANKMASK(WPUA), 0
#define WPUA1                          BANKMASK(WPUA), 1
#define WPUA2                          BANKMASK(WPUA), 2
#define WPUA3                          BANKMASK(WPUA), 3
#define WPUA4                          BANKMASK(WPUA), 4
#define WPUA5                          BANKMASK(WPUA), 5
#ifndef _LIB_BUILD
#endif
PCON                                   equ 010Fh
#define nBOR                           BANKMASK(PCON), 0
#define nPOR                           BANKMASK(PCON), 1
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 0110h
PR2                                    equ 0111h
T2CON                                  equ 0112h
#define TMR2ON                         BANKMASK(T2CON), 2
#define T2CKPS0                        BANKMASK(T2CON), 0
#define T2CKPS1                        BANKMASK(T2CON), 1
#define T2OUTPS0                       BANKMASK(T2CON), 3
#define T2OUTPS1                       BANKMASK(T2CON), 4
#define T2OUTPS2                       BANKMASK(T2CON), 5
#define T2OUTPS3                       BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
HLTMR1                                 equ 0113h
HLTPR1                                 equ 0114h
HLT1CON0                               equ 0115h
#define H1ON                           BANKMASK(HLT1CON0), 2
#define H1CKPS0                        BANKMASK(HLT1CON0), 0
#define H1CKPS1                        BANKMASK(HLT1CON0), 1
#define H1OUTPS0                       BANKMASK(HLT1CON0), 3
#define H1OUTPS1                       BANKMASK(HLT1CON0), 4
#define H1OUTPS2                       BANKMASK(HLT1CON0), 5
#define H1OUTPS3                       BANKMASK(HLT1CON0), 6
#ifndef _LIB_BUILD
#endif
HLT1CON1                               equ 0116h
#define H1REREN                        BANKMASK(HLT1CON1), 0
#define H1FEREN                        BANKMASK(HLT1CON1), 1
#define H1ERS0                         BANKMASK(HLT1CON1), 2
#define H1ERS1                         BANKMASK(HLT1CON1), 3
#define H1ERS2                         BANKMASK(HLT1CON1), 4
#ifndef _LIB_BUILD
#endif
ANSELA                                 equ 0185h
#define ANSA0                          BANKMASK(ANSELA), 0
#define ANSA1                          BANKMASK(ANSELA), 1
#define ANSA2                          BANKMASK(ANSELA), 2
#define ANSA4                          BANKMASK(ANSELA), 4
#define ANSA5                          BANKMASK(ANSELA), 5
#ifndef _LIB_BUILD
#endif
APFCON                                 equ 0188h
#define COG1O0SEL                      BANKMASK(APFCON), 0
#define COG1O1SEL                      BANKMASK(APFCON), 1
#define COG1FSEL                       BANKMASK(APFCON), 2
#define T1GSEL                         BANKMASK(APFCON), 4
#ifndef _LIB_BUILD
#endif
OSCTUNE                                equ 0189h
#define TUN0                           BANKMASK(OSCTUNE), 0
#define TUN1                           BANKMASK(OSCTUNE), 1
#define TUN2                           BANKMASK(OSCTUNE), 2
#define TUN3                           BANKMASK(OSCTUNE), 3
#define TUN4                           BANKMASK(OSCTUNE), 4
#ifndef _LIB_BUILD
#endif
PMCON1                                 equ 018Ch
#define RD                             BANKMASK(PMCON1), 0
#define WR                             BANKMASK(PMCON1), 1
#define WREN                           BANKMASK(PMCON1), 2
#ifndef _LIB_BUILD
#endif
PMCON2                                 equ 018Dh
PMADRL                                 equ 018Eh
PMADRH                                 equ 018Fh
#ifndef _LIB_BUILD
#endif
PMDATL                                 equ 0190h
PMDATH                                 equ 0191h
#ifndef _LIB_BUILD
#endif
COG1PH                                 equ 0192h
#define G1PH0                          BANKMASK(COG1PH), 0
#define G1PH1                          BANKMASK(COG1PH), 1
#define G1PH2                          BANKMASK(COG1PH), 2
#define G1PH3                          BANKMASK(COG1PH), 3
#ifndef _LIB_BUILD
#endif
COG1BLK                                equ 0193h
#define G1BLKF0                        BANKMASK(COG1BLK), 0
#define G1BLKF1                        BANKMASK(COG1BLK), 1
#define G1BLKF2                        BANKMASK(COG1BLK), 2
#define G1BLKF3                        BANKMASK(COG1BLK), 3
#define G1BLKR0                        BANKMASK(COG1BLK), 4
#define G1BLKR1                        BANKMASK(COG1BLK), 5
#define G1BLKR2                        BANKMASK(COG1BLK), 6
#define G1BLKR3                        BANKMASK(COG1BLK), 7
#ifndef _LIB_BUILD
#endif
COG1DB                                 equ 0194h
#define G1DBF0                         BANKMASK(COG1DB), 0
#define G1DBF1                         BANKMASK(COG1DB), 1
#define G1DBF2                         BANKMASK(COG1DB), 2
#define G1DBF3                         BANKMASK(COG1DB), 3
#define G1BDR0                         BANKMASK(COG1DB), 4
#define G1BDR1                         BANKMASK(COG1DB), 5
#define G1BDR2                         BANKMASK(COG1DB), 6
#define G1BDR3                         BANKMASK(COG1DB), 7
#ifndef _LIB_BUILD
#endif
COG1CON0                               equ 0195h
#define G1LD                           BANKMASK(COG1CON0), 2
#define G1POL0                         BANKMASK(COG1CON0), 3
#define G1POL1                         BANKMASK(COG1CON0), 4
#define G1OE0                          BANKMASK(COG1CON0), 5
#define G1OE1                          BANKMASK(COG1CON0), 6
#define G1EN                           BANKMASK(COG1CON0), 7
#define G1CS0                          BANKMASK(COG1CON0), 0
#define G1CS1                          BANKMASK(COG1CON0), 1
#ifndef _LIB_BUILD
#endif
COG1CON1                               equ 0196h
#define G1RS0                          BANKMASK(COG1CON1), 0
#define G1RS1                          BANKMASK(COG1CON1), 1
#define G1RS2                          BANKMASK(COG1CON1), 2
#define G1FS0                          BANKMASK(COG1CON1), 3
#define G1FS1                          BANKMASK(COG1CON1), 4
#define G1FS2                          BANKMASK(COG1CON1), 5
#ifndef _LIB_BUILD
#endif
COG1ASD                                equ 0197h
#define G1ASDSFLT                      BANKMASK(COG1ASD), 0
#define G1ASDSC1                       BANKMASK(COG1ASD), 1
#define G1ASDSC2                       BANKMASK(COG1ASD), 2
#define G1ASDSHLT                      BANKMASK(COG1ASD), 3
#define G1ASDL0                        BANKMASK(COG1ASD), 4
#define G1ASDL1                        BANKMASK(COG1ASD), 5
#define G1ARSEN                        BANKMASK(COG1ASD), 6
#define G1ASDE                         BANKMASK(COG1ASD), 7
#ifndef _LIB_BUILD
#endif

#endif
#endif

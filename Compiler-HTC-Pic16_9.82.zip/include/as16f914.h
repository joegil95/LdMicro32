#ifndef _ASPIC_H_
#warning Header file as16f914.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS16F914_H_
#define _AS16F914_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define IRP                            BANKMASK(STATUS), 7
#define RP0                            BANKMASK(STATUS), 5
#define RP1                            BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define RA0                            BANKMASK(PORTA), 0
#define RA1                            BANKMASK(PORTA), 1
#define RA2                            BANKMASK(PORTA), 2
#define RA3                            BANKMASK(PORTA), 3
#define RA4                            BANKMASK(PORTA), 4
#define RA5                            BANKMASK(PORTA), 5
#define RA6                            BANKMASK(PORTA), 6
#define RA7                            BANKMASK(PORTA), 7
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 0006h
#define RB0                            BANKMASK(PORTB), 0
#define RB1                            BANKMASK(PORTB), 1
#define RB2                            BANKMASK(PORTB), 2
#define RB3                            BANKMASK(PORTB), 3
#define RB4                            BANKMASK(PORTB), 4
#define RB5                            BANKMASK(PORTB), 5
#define RB6                            BANKMASK(PORTB), 6
#define RB7                            BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 0007h
#define RC0                            BANKMASK(PORTC), 0
#define RC1                            BANKMASK(PORTC), 1
#define RC2                            BANKMASK(PORTC), 2
#define RC3                            BANKMASK(PORTC), 3
#define RC4                            BANKMASK(PORTC), 4
#define RC5                            BANKMASK(PORTC), 5
#define RC6                            BANKMASK(PORTC), 6
#define RC7                            BANKMASK(PORTC), 7
#ifndef _LIB_BUILD
#endif
PORTD                                  equ 0008h
#define RD0                            BANKMASK(PORTD), 0
#define RD1                            BANKMASK(PORTD), 1
#define RD2                            BANKMASK(PORTD), 2
#define RD3                            BANKMASK(PORTD), 3
#define RD4                            BANKMASK(PORTD), 4
#define RD5                            BANKMASK(PORTD), 5
#define RD6                            BANKMASK(PORTD), 6
#define RD7                            BANKMASK(PORTD), 7
#ifndef _LIB_BUILD
#endif
PORTE                                  equ 0009h
#define RE0                            BANKMASK(PORTE), 0
#define RE1                            BANKMASK(PORTE), 1
#define RE2                            BANKMASK(PORTE), 2
#define RE3                            BANKMASK(PORTE), 3
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define RBIF                           BANKMASK(INTCON), 0
#define INTF                           BANKMASK(INTCON), 1
#define TMR0IF                         BANKMASK(INTCON), 2
#define RBIE                           BANKMASK(INTCON), 3
#define INTE                           BANKMASK(INTCON), 4
#define TMR0IE                         BANKMASK(INTCON), 5
#define PEIE                           BANKMASK(INTCON), 6
#define GIE                            BANKMASK(INTCON), 7
#define T0IF                           BANKMASK(INTCON), 2
#define T0IE                           BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF                         BANKMASK(PIR1), 0
#define TMR2IF                         BANKMASK(PIR1), 1
#define CCP1IF                         BANKMASK(PIR1), 2
#define SSPIF                          BANKMASK(PIR1), 3
#define TXIF                           BANKMASK(PIR1), 4
#define RCIF                           BANKMASK(PIR1), 5
#define ADIF                           BANKMASK(PIR1), 6
#define EEIF                           BANKMASK(PIR1), 7
#ifndef _LIB_BUILD
#endif
PIR2                                   equ 000Dh
#define CCP2IF                         BANKMASK(PIR2), 0
#define LVDIF                          BANKMASK(PIR2), 2
#define LCDIF                          BANKMASK(PIR2), 4
#define C1IF                           BANKMASK(PIR2), 5
#define C2IF                           BANKMASK(PIR2), 6
#define OSFIF                          BANKMASK(PIR2), 7
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Eh
TMR1H                                  equ 000Fh
T1CON                                  equ 0010h
#define TMR1ON                         BANKMASK(T1CON), 0
#define TMR1CS                         BANKMASK(T1CON), 1
#define nT1SYNC                        BANKMASK(T1CON), 2
#define T1OSCEN                        BANKMASK(T1CON), 3
#define TMR1GE                         BANKMASK(T1CON), 6
#define T1GINV                         BANKMASK(T1CON), 7
#define T1SYNC                         BANKMASK(T1CON), 2
#define T1CKPS0                        BANKMASK(T1CON), 4
#define T1CKPS1                        BANKMASK(T1CON), 5
#define T1GE                           BANKMASK(T1CON), 6
#define T1INSYNC                       BANKMASK(T1CON), 2
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 0011h
T2CON                                  equ 0012h
#define TMR2ON                         BANKMASK(T2CON), 2
#define T2CKPS0                        BANKMASK(T2CON), 0
#define T2CKPS1                        BANKMASK(T2CON), 1
#define TOUTPS0                        BANKMASK(T2CON), 3
#define TOUTPS1                        BANKMASK(T2CON), 4
#define TOUTPS2                        BANKMASK(T2CON), 5
#define TOUTPS3                        BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
SSPBUF                                 equ 0013h
SSPCON                                 equ 0014h
#define CKP                            BANKMASK(SSPCON), 4
#define SSPEN                          BANKMASK(SSPCON), 5
#define SSPOV                          BANKMASK(SSPCON), 6
#define WCOL                           BANKMASK(SSPCON), 7
#define SSPM0                          BANKMASK(SSPCON), 0
#define SSPM1                          BANKMASK(SSPCON), 1
#define SSPM2                          BANKMASK(SSPCON), 2
#define SSPM3                          BANKMASK(SSPCON), 3
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0015h
CCPR1H                                 equ 0016h
CCP1CON                                equ 0017h
#define CCP1Y                          BANKMASK(CCP1CON), 4
#define CCP1X                          BANKMASK(CCP1CON), 5
#define CCP1M0                         BANKMASK(CCP1CON), 0
#define CCP1M1                         BANKMASK(CCP1CON), 1
#define CCP1M2                         BANKMASK(CCP1CON), 2
#define CCP1M3                         BANKMASK(CCP1CON), 3
#ifndef _LIB_BUILD
#endif
RCSTA                                  equ 0018h
#define RX9D                           BANKMASK(RCSTA), 0
#define OERR                           BANKMASK(RCSTA), 1
#define FERR                           BANKMASK(RCSTA), 2
#define ADDEN                          BANKMASK(RCSTA), 3
#define CREN                           BANKMASK(RCSTA), 4
#define SREN                           BANKMASK(RCSTA), 5
#define RX9                            BANKMASK(RCSTA), 6
#define SPEN                           BANKMASK(RCSTA), 7
#define RCD8                           BANKMASK(RCSTA), 0
#define RC9                            BANKMASK(RCSTA), 6
#define nRC8                           BANKMASK(RCSTA), 6
#define RC8_9                          BANKMASK(RCSTA), 6
#ifndef _LIB_BUILD
#endif
TXREG                                  equ 0019h
RCREG                                  equ 001Ah
CCPR2L                                 equ 001Bh
CCPR2H                                 equ 001Ch
CCP2CON                                equ 001Dh
#define CCP2Y                          BANKMASK(CCP2CON), 4
#define CCP2X                          BANKMASK(CCP2CON), 5
#define CCP2M0                         BANKMASK(CCP2CON), 0
#define CCP2M1                         BANKMASK(CCP2CON), 1
#define CCP2M2                         BANKMASK(CCP2CON), 2
#define CCP2M3                         BANKMASK(CCP2CON), 3
#ifndef _LIB_BUILD
#endif
ADRESH                                 equ 001Eh
ADCON0                                 equ 001Fh
#define ADON                           BANKMASK(ADCON0), 0
#define GO_nDONE                       BANKMASK(ADCON0), 1
#define ADFM                           BANKMASK(ADCON0), 7
#define nDONE                          BANKMASK(ADCON0), 1
#define CHS0                           BANKMASK(ADCON0), 2
#define CHS1                           BANKMASK(ADCON0), 3
#define CHS2                           BANKMASK(ADCON0), 4
#define VCFG0                          BANKMASK(ADCON0), 5
#define VCFG1                          BANKMASK(ADCON0), 6
#define GO_DONE                        BANKMASK(ADCON0), 1
#define GO                             BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA                            BANKMASK(OPTION_REG), 3
#define T0SE                           BANKMASK(OPTION_REG), 4
#define T0CS                           BANKMASK(OPTION_REG), 5
#define INTEDG                         BANKMASK(OPTION_REG), 6
#define nRBPU                          BANKMASK(OPTION_REG), 7
#define PS0                            BANKMASK(OPTION_REG), 0
#define PS1                            BANKMASK(OPTION_REG), 1
#define PS2                            BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 0085h
#define TRISA0                         BANKMASK(TRISA), 0
#define TRISA1                         BANKMASK(TRISA), 1
#define TRISA2                         BANKMASK(TRISA), 2
#define TRISA3                         BANKMASK(TRISA), 3
#define TRISA4                         BANKMASK(TRISA), 4
#define TRISA5                         BANKMASK(TRISA), 5
#define TRISA6                         BANKMASK(TRISA), 6
#define TRISA7                         BANKMASK(TRISA), 7
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 0086h
#define TRISB0                         BANKMASK(TRISB), 0
#define TRISB1                         BANKMASK(TRISB), 1
#define TRISB2                         BANKMASK(TRISB), 2
#define TRISB3                         BANKMASK(TRISB), 3
#define TRISB4                         BANKMASK(TRISB), 4
#define TRISB5                         BANKMASK(TRISB), 5
#define TRISB6                         BANKMASK(TRISB), 6
#define TRISB7                         BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
TRISC                                  equ 0087h
#define TRISC0                         BANKMASK(TRISC), 0
#define TRISC1                         BANKMASK(TRISC), 1
#define TRISC2                         BANKMASK(TRISC), 2
#define TRISC3                         BANKMASK(TRISC), 3
#define TRISC4                         BANKMASK(TRISC), 4
#define TRISC5                         BANKMASK(TRISC), 5
#define TRISC6                         BANKMASK(TRISC), 6
#define TRISC7                         BANKMASK(TRISC), 7
#ifndef _LIB_BUILD
#endif
TRISD                                  equ 0088h
#define TRISD0                         BANKMASK(TRISD), 0
#define TRISD1                         BANKMASK(TRISD), 1
#define TRISD2                         BANKMASK(TRISD), 2
#define TRISD3                         BANKMASK(TRISD), 3
#define TRISD4                         BANKMASK(TRISD), 4
#define TRISD5                         BANKMASK(TRISD), 5
#define TRISD6                         BANKMASK(TRISD), 6
#define TRISD7                         BANKMASK(TRISD), 7
#ifndef _LIB_BUILD
#endif
TRISE                                  equ 0089h
#define TRISE0                         BANKMASK(TRISE), 0
#define TRISE1                         BANKMASK(TRISE), 1
#define TRISE2                         BANKMASK(TRISE), 2
#define TRISE3                         BANKMASK(TRISE), 3
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE                         BANKMASK(PIE1), 0
#define TMR2IE                         BANKMASK(PIE1), 1
#define CCP1IE                         BANKMASK(PIE1), 2
#define SSPIE                          BANKMASK(PIE1), 3
#define TXIE                           BANKMASK(PIE1), 4
#define RCIE                           BANKMASK(PIE1), 5
#define ADIE                           BANKMASK(PIE1), 6
#define EEIE                           BANKMASK(PIE1), 7
#ifndef _LIB_BUILD
#endif
PIE2                                   equ 008Dh
#define CCP2IE                         BANKMASK(PIE2), 0
#define LVDIE                          BANKMASK(PIE2), 2
#define LCDIE                          BANKMASK(PIE2), 4
#define C1IE                           BANKMASK(PIE2), 5
#define C2IE                           BANKMASK(PIE2), 6
#define OSFIE                          BANKMASK(PIE2), 7
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOR                           BANKMASK(PCON), 0
#define nPOR                           BANKMASK(PCON), 1
#define SBOREN                         BANKMASK(PCON), 4
#define nBO                            BANKMASK(PCON), 0
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 008Fh
#define SCS                            BANKMASK(OSCCON), 0
#define LTS                            BANKMASK(OSCCON), 1
#define HTS                            BANKMASK(OSCCON), 2
#define OSTS                           BANKMASK(OSCCON), 3
#define IRCF0                          BANKMASK(OSCCON), 4
#define IRCF1                          BANKMASK(OSCCON), 5
#define IRCF2                          BANKMASK(OSCCON), 6
#ifndef _LIB_BUILD
#endif
OSCTUNE                                equ 0090h
#define TUN0                           BANKMASK(OSCTUNE), 0
#define TUN1                           BANKMASK(OSCTUNE), 1
#define TUN2                           BANKMASK(OSCTUNE), 2
#define TUN3                           BANKMASK(OSCTUNE), 3
#define TUN4                           BANKMASK(OSCTUNE), 4
#ifndef _LIB_BUILD
#endif
ANSEL                                  equ 0091h
#define ANS0                           BANKMASK(ANSEL), 0
#define ANS1                           BANKMASK(ANSEL), 1
#define ANS2                           BANKMASK(ANSEL), 2
#define ANS3                           BANKMASK(ANSEL), 3
#define ANS4                           BANKMASK(ANSEL), 4
#define ANS5                           BANKMASK(ANSEL), 5
#define ANS6                           BANKMASK(ANSEL), 6
#define ANS7                           BANKMASK(ANSEL), 7
#define AN0                            BANKMASK(ANSEL), 0
#define AN1                            BANKMASK(ANSEL), 1
#define AN2                            BANKMASK(ANSEL), 2
#define AN3                            BANKMASK(ANSEL), 3
#define AN4                            BANKMASK(ANSEL), 4
#define AN5                            BANKMASK(ANSEL), 5
#define AN6                            BANKMASK(ANSEL), 6
#define AN7                            BANKMASK(ANSEL), 7
#ifndef _LIB_BUILD
#endif
PR2                                    equ 0092h
SSPADD                                 equ 0093h
SSPSTAT                                equ 0094h
#define BF                             BANKMASK(SSPSTAT), 0
#define UA                             BANKMASK(SSPSTAT), 1
#define R_nW                           BANKMASK(SSPSTAT), 2
#define S                              BANKMASK(SSPSTAT), 3
#define P                              BANKMASK(SSPSTAT), 4
#define D_nA                           BANKMASK(SSPSTAT), 5
#define CKE                            BANKMASK(SSPSTAT), 6
#define SMP                            BANKMASK(SSPSTAT), 7
#define R                              BANKMASK(SSPSTAT), 2
#define D                              BANKMASK(SSPSTAT), 5
#define I2C_READ                       BANKMASK(SSPSTAT), 2
#define I2C_START                      BANKMASK(SSPSTAT), 3
#define I2C_STOP                       BANKMASK(SSPSTAT), 4
#define I2C_DATA                       BANKMASK(SSPSTAT), 5
#define nW                             BANKMASK(SSPSTAT), 2
#define nA                             BANKMASK(SSPSTAT), 5
#define nWRITE                         BANKMASK(SSPSTAT), 2
#define nADDRESS                       BANKMASK(SSPSTAT), 5
#define R_W                            BANKMASK(SSPSTAT), 2
#define D_A                            BANKMASK(SSPSTAT), 5
#define READ_WRITE                     BANKMASK(SSPSTAT), 2
#define DATA_ADDRESS                   BANKMASK(SSPSTAT), 5
#ifndef _LIB_BUILD
#endif
WPUB                                   equ 0095h
WPU                                    equ 0095h
#define WPUB0                          BANKMASK(WPUB), 0
#define WPUB1                          BANKMASK(WPUB), 1
#define WPUB2                          BANKMASK(WPUB), 2
#define WPUB3                          BANKMASK(WPUB), 3
#define WPUB4                          BANKMASK(WPUB), 4
#define WPUB5                          BANKMASK(WPUB), 5
#define WPUB6                          BANKMASK(WPUB), 6
#define WPUB7                          BANKMASK(WPUB), 7
#define WPU0                           BANKMASK(WPUB), 0
#define WPU1                           BANKMASK(WPUB), 1
#define WPU2                           BANKMASK(WPUB), 2
#define WPU3                           BANKMASK(WPUB), 3
#define WPU4                           BANKMASK(WPUB), 4
#define WPU5                           BANKMASK(WPUB), 5
#define WPU6                           BANKMASK(WPUB), 6
#define WPU7                           BANKMASK(WPUB), 7
#ifndef _LIB_BUILD
#endif
IOCB                                   equ 0096h
IOC                                    equ 0096h
#define IOCB4                          BANKMASK(IOCB), 4
#define IOCB5                          BANKMASK(IOCB), 5
#define IOCB6                          BANKMASK(IOCB), 6
#define IOCB7                          BANKMASK(IOCB), 7
#define IOC4                           BANKMASK(IOCB), 4
#define IOC5                           BANKMASK(IOCB), 5
#define IOC6                           BANKMASK(IOCB), 6
#define IOC7                           BANKMASK(IOCB), 7
#ifndef _LIB_BUILD
#endif
CMCON1                                 equ 0097h
#define C2SYNC                         BANKMASK(CMCON1), 0
#define T1GSS                          BANKMASK(CMCON1), 1
#ifndef _LIB_BUILD
#endif
TXSTA                                  equ 0098h
#define TX9D                           BANKMASK(TXSTA), 0
#define TRMT                           BANKMASK(TXSTA), 1
#define BRGH                           BANKMASK(TXSTA), 2
#define SYNC                           BANKMASK(TXSTA), 4
#define TXEN                           BANKMASK(TXSTA), 5
#define TX9                            BANKMASK(TXSTA), 6
#define CSRC                           BANKMASK(TXSTA), 7
#define TXD8                           BANKMASK(TXSTA), 0
#define nTX8                           BANKMASK(TXSTA), 6
#define TX8_9                          BANKMASK(TXSTA), 6
#ifndef _LIB_BUILD
#endif
SPBRG                                  equ 0099h
CMCON0                                 equ 009Ch
#define CIS                            BANKMASK(CMCON0), 3
#define C1INV                          BANKMASK(CMCON0), 4
#define C2INV                          BANKMASK(CMCON0), 5
#define C1OUT                          BANKMASK(CMCON0), 6
#define C2OUT                          BANKMASK(CMCON0), 7
#define CM0                            BANKMASK(CMCON0), 0
#define CM1                            BANKMASK(CMCON0), 1
#define CM2                            BANKMASK(CMCON0), 2
#ifndef _LIB_BUILD
#endif
VRCON                                  equ 009Dh
#define VRR                            BANKMASK(VRCON), 5
#define VREN                           BANKMASK(VRCON), 7
#define VR0                            BANKMASK(VRCON), 0
#define VR1                            BANKMASK(VRCON), 1
#define VR2                            BANKMASK(VRCON), 2
#define VR3                            BANKMASK(VRCON), 3
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 009Eh
ADCON1                                 equ 009Fh
#define ADCS0                          BANKMASK(ADCON1), 4
#define ADCS1                          BANKMASK(ADCON1), 5
#define ADCS2                          BANKMASK(ADCON1), 6
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0105h
#define SWDTEN                         BANKMASK(WDTCON), 0
#define SWDTE                          BANKMASK(WDTCON), 0
#define WDTPS0                         BANKMASK(WDTCON), 1
#define WDTPS1                         BANKMASK(WDTCON), 2
#define WDTPS2                         BANKMASK(WDTCON), 3
#define WDTPS3                         BANKMASK(WDTCON), 4
#ifndef _LIB_BUILD
#endif
LCDCON                                 equ 0107h
#define VLCDEN                         BANKMASK(LCDCON), 4
#define WERR                           BANKMASK(LCDCON), 5
#define SLPEN                          BANKMASK(LCDCON), 6
#define LCDEN                          BANKMASK(LCDCON), 7
#define LMUX0                          BANKMASK(LCDCON), 0
#define LMUX1                          BANKMASK(LCDCON), 1
#define CS0                            BANKMASK(LCDCON), 2
#define CS1                            BANKMASK(LCDCON), 3
#ifndef _LIB_BUILD
#endif
LCDPS                                  equ 0108h
#define WA                             BANKMASK(LCDPS), 4
#define LCDA                           BANKMASK(LCDPS), 5
#define BIASMD                         BANKMASK(LCDPS), 6
#define WFT                            BANKMASK(LCDPS), 7
#define LP0                            BANKMASK(LCDPS), 0
#define LP1                            BANKMASK(LCDPS), 1
#define LP2                            BANKMASK(LCDPS), 2
#define LP3                            BANKMASK(LCDPS), 3
#ifndef _LIB_BUILD
#endif
LVDCON                                 equ 0109h
#define LVDEN                          BANKMASK(LVDCON), 4
#define IRVST                          BANKMASK(LVDCON), 5
#define LVDL0                          BANKMASK(LVDCON), 0
#define LVDL1                          BANKMASK(LVDCON), 1
#define LVDL2                          BANKMASK(LVDCON), 2
#ifndef _LIB_BUILD
#endif
EEDATL                                 equ 010Ch
EEDATA                                 equ 010Ch
#define EEDATL0                        BANKMASK(EEDATL), 0
#define EEDATL1                        BANKMASK(EEDATL), 1
#define EEDATL2                        BANKMASK(EEDATL), 2
#define EEDATL3                        BANKMASK(EEDATL), 3
#define EEDATL4                        BANKMASK(EEDATL), 4
#define EEDATL5                        BANKMASK(EEDATL), 5
#define EEDATL6                        BANKMASK(EEDATL), 6
#define EEDATL7                        BANKMASK(EEDATL), 7
#ifndef _LIB_BUILD
#endif
EEADRL                                 equ 010Dh
EEADR                                  equ 010Dh
#define EEADRL0                        BANKMASK(EEADRL), 0
#define EEADRL1                        BANKMASK(EEADRL), 1
#define EEADRL2                        BANKMASK(EEADRL), 2
#define EEADRL3                        BANKMASK(EEADRL), 3
#define EEADRL4                        BANKMASK(EEADRL), 4
#define EEADRL5                        BANKMASK(EEADRL), 5
#define EEADRL6                        BANKMASK(EEADRL), 6
#define EEADRL7                        BANKMASK(EEADRL), 7
#ifndef _LIB_BUILD
#endif
EEDATH                                 equ 010Eh
#define EEDATH0                        BANKMASK(EEDATH), 0
#define EEDATH1                        BANKMASK(EEDATH), 1
#define EEDATH2                        BANKMASK(EEDATH), 2
#define EEDATH3                        BANKMASK(EEDATH), 3
#define EEDATH4                        BANKMASK(EEDATH), 4
#define EEDATH5                        BANKMASK(EEDATH), 5
#ifndef _LIB_BUILD
#endif
EEADRH                                 equ 010Fh
#define EEADRH0                        BANKMASK(EEADRH), 0
#define EEADRH1                        BANKMASK(EEADRH), 1
#define EEADRH2                        BANKMASK(EEADRH), 2
#define EEADRH3                        BANKMASK(EEADRH), 3
#define EEADRH4                        BANKMASK(EEADRH), 4
#ifndef _LIB_BUILD
#endif
LCDDATA0                               equ 0110h
#define SEG0COM0                       BANKMASK(LCDDATA0), 0
#define SEG1COM0                       BANKMASK(LCDDATA0), 1
#define SEG2COM0                       BANKMASK(LCDDATA0), 2
#define SEG3COM0                       BANKMASK(LCDDATA0), 3
#define SEG4COM0                       BANKMASK(LCDDATA0), 4
#define SEG5COM0                       BANKMASK(LCDDATA0), 5
#define SEG6COM0                       BANKMASK(LCDDATA0), 6
#define SEG7COM0                       BANKMASK(LCDDATA0), 7
#define S0C0                           BANKMASK(LCDDATA0), 0
#define S1C0                           BANKMASK(LCDDATA0), 1
#define S2C0                           BANKMASK(LCDDATA0), 2
#define S3C0                           BANKMASK(LCDDATA0), 3
#define S4C0                           BANKMASK(LCDDATA0), 4
#define S5C0                           BANKMASK(LCDDATA0), 5
#define S6C0                           BANKMASK(LCDDATA0), 6
#define S7C0                           BANKMASK(LCDDATA0), 7
#ifndef _LIB_BUILD
#endif
LCDDATA1                               equ 0111h
#define SEG8COM0                       BANKMASK(LCDDATA1), 0
#define SEG9COM0                       BANKMASK(LCDDATA1), 1
#define SEG10COM0                      BANKMASK(LCDDATA1), 2
#define SEG11COM0                      BANKMASK(LCDDATA1), 3
#define SEG12COM0                      BANKMASK(LCDDATA1), 4
#define SEG13COM0                      BANKMASK(LCDDATA1), 5
#define SEG14COM0                      BANKMASK(LCDDATA1), 6
#define SEG15COM0                      BANKMASK(LCDDATA1), 7
#define S8C0                           BANKMASK(LCDDATA1), 0
#define S9C0                           BANKMASK(LCDDATA1), 1
#define S10C0                          BANKMASK(LCDDATA1), 2
#define S11C0                          BANKMASK(LCDDATA1), 3
#define S12C0                          BANKMASK(LCDDATA1), 4
#define S13C0                          BANKMASK(LCDDATA1), 5
#define S14C0                          BANKMASK(LCDDATA1), 6
#define S15C0                          BANKMASK(LCDDATA1), 7
#ifndef _LIB_BUILD
#endif
LCDDATA2                               equ 0112h
#define SEG16COM0                      BANKMASK(LCDDATA2), 0
#define SEG17COM0                      BANKMASK(LCDDATA2), 1
#define SEG18COM0                      BANKMASK(LCDDATA2), 2
#define SEG19COM0                      BANKMASK(LCDDATA2), 3
#define SEG20COM0                      BANKMASK(LCDDATA2), 4
#define SEG21COM0                      BANKMASK(LCDDATA2), 5
#define SEG22COM0                      BANKMASK(LCDDATA2), 6
#define SEG23COM0                      BANKMASK(LCDDATA2), 7
#define S16C0                          BANKMASK(LCDDATA2), 0
#define S17C0                          BANKMASK(LCDDATA2), 1
#define S18C0                          BANKMASK(LCDDATA2), 2
#define S19C0                          BANKMASK(LCDDATA2), 3
#define S20C0                          BANKMASK(LCDDATA2), 4
#define S21C0                          BANKMASK(LCDDATA2), 5
#define S22C0                          BANKMASK(LCDDATA2), 6
#define S23C0                          BANKMASK(LCDDATA2), 7
#ifndef _LIB_BUILD
#endif
LCDDATA3                               equ 0113h
#define SEG0COM1                       BANKMASK(LCDDATA3), 0
#define SEG1COM1                       BANKMASK(LCDDATA3), 1
#define SEG2COM1                       BANKMASK(LCDDATA3), 2
#define SEG3COM1                       BANKMASK(LCDDATA3), 3
#define SEG4COM1                       BANKMASK(LCDDATA3), 4
#define SEG5COM1                       BANKMASK(LCDDATA3), 5
#define SEG6COM1                       BANKMASK(LCDDATA3), 6
#define SEG7COM1                       BANKMASK(LCDDATA3), 7
#define S0C1                           BANKMASK(LCDDATA3), 0
#define S1C1                           BANKMASK(LCDDATA3), 1
#define S2C1                           BANKMASK(LCDDATA3), 2
#define S3C1                           BANKMASK(LCDDATA3), 3
#define S4C1                           BANKMASK(LCDDATA3), 4
#define S5C1                           BANKMASK(LCDDATA3), 5
#define S6C1                           BANKMASK(LCDDATA3), 6
#define S7C1                           BANKMASK(LCDDATA3), 7
#ifndef _LIB_BUILD
#endif
LCDDATA4                               equ 0114h
#define SEG8COM1                       BANKMASK(LCDDATA4), 0
#define SEG9COM1                       BANKMASK(LCDDATA4), 1
#define SEG10COM1                      BANKMASK(LCDDATA4), 2
#define SEG11COM1                      BANKMASK(LCDDATA4), 3
#define SEG12COM1                      BANKMASK(LCDDATA4), 4
#define SEG13COM1                      BANKMASK(LCDDATA4), 5
#define SEG14COM1                      BANKMASK(LCDDATA4), 6
#define SEG15COM1                      BANKMASK(LCDDATA4), 7
#define S8C1                           BANKMASK(LCDDATA4), 0
#define S9C1                           BANKMASK(LCDDATA4), 1
#define S10C1                          BANKMASK(LCDDATA4), 2
#define S11C1                          BANKMASK(LCDDATA4), 3
#define S12C1                          BANKMASK(LCDDATA4), 4
#define S13C1                          BANKMASK(LCDDATA4), 5
#define S14C1                          BANKMASK(LCDDATA4), 6
#define S15C1                          BANKMASK(LCDDATA4), 7
#ifndef _LIB_BUILD
#endif
LCDDATA5                               equ 0115h
#define SEG16COM1                      BANKMASK(LCDDATA5), 0
#define SEG17COM1                      BANKMASK(LCDDATA5), 1
#define SEG18COM1                      BANKMASK(LCDDATA5), 2
#define SEG19COM1                      BANKMASK(LCDDATA5), 3
#define SEG20COM1                      BANKMASK(LCDDATA5), 4
#define SEG21COM1                      BANKMASK(LCDDATA5), 5
#define SEG22COM1                      BANKMASK(LCDDATA5), 6
#define SEG23COM1                      BANKMASK(LCDDATA5), 7
#define S16C1                          BANKMASK(LCDDATA5), 0
#define S17C1                          BANKMASK(LCDDATA5), 1
#define S18C1                          BANKMASK(LCDDATA5), 2
#define S19C1                          BANKMASK(LCDDATA5), 3
#define S20C1                          BANKMASK(LCDDATA5), 4
#define S21C1                          BANKMASK(LCDDATA5), 5
#define S22C1                          BANKMASK(LCDDATA5), 6
#define S23C1                          BANKMASK(LCDDATA5), 7
#ifndef _LIB_BUILD
#endif
LCDDATA6                               equ 0116h
#define SEG0COM2                       BANKMASK(LCDDATA6), 0
#define SEG1COM2                       BANKMASK(LCDDATA6), 1
#define SEG2COM2                       BANKMASK(LCDDATA6), 2
#define SEG3COM2                       BANKMASK(LCDDATA6), 3
#define SEG4COM2                       BANKMASK(LCDDATA6), 4
#define SEG5COM2                       BANKMASK(LCDDATA6), 5
#define SEG6COM2                       BANKMASK(LCDDATA6), 6
#define SEG7COM2                       BANKMASK(LCDDATA6), 7
#define S0C2                           BANKMASK(LCDDATA6), 0
#define S1C2                           BANKMASK(LCDDATA6), 1
#define S2C2                           BANKMASK(LCDDATA6), 2
#define S3C2                           BANKMASK(LCDDATA6), 3
#define S4C2                           BANKMASK(LCDDATA6), 4
#define S5C2                           BANKMASK(LCDDATA6), 5
#define S6C2                           BANKMASK(LCDDATA6), 6
#define S7C2                           BANKMASK(LCDDATA6), 7
#ifndef _LIB_BUILD
#endif
LCDDATA7                               equ 0117h
#define SEG8COM2                       BANKMASK(LCDDATA7), 0
#define SEG9COM2                       BANKMASK(LCDDATA7), 1
#define SEG10COM2                      BANKMASK(LCDDATA7), 2
#define SEG11COM2                      BANKMASK(LCDDATA7), 3
#define SEG12COM2                      BANKMASK(LCDDATA7), 4
#define SEG13COM2                      BANKMASK(LCDDATA7), 5
#define SEG14COM2                      BANKMASK(LCDDATA7), 6
#define SEG15COM2                      BANKMASK(LCDDATA7), 7
#define S8C2                           BANKMASK(LCDDATA7), 0
#define S9C2                           BANKMASK(LCDDATA7), 1
#define S10C2                          BANKMASK(LCDDATA7), 2
#define S11C2                          BANKMASK(LCDDATA7), 3
#define S12C2                          BANKMASK(LCDDATA7), 4
#define S13C2                          BANKMASK(LCDDATA7), 5
#define S14C2                          BANKMASK(LCDDATA7), 6
#define S15C2                          BANKMASK(LCDDATA7), 7
#ifndef _LIB_BUILD
#endif
LCDDATA8                               equ 0118h
#define SEG16COM2                      BANKMASK(LCDDATA8), 0
#define SEG17COM2                      BANKMASK(LCDDATA8), 1
#define SEG18COM2                      BANKMASK(LCDDATA8), 2
#define SEG19COM2                      BANKMASK(LCDDATA8), 3
#define SEG20COM2                      BANKMASK(LCDDATA8), 4
#define SEG21COM2                      BANKMASK(LCDDATA8), 5
#define SEG22COM2                      BANKMASK(LCDDATA8), 6
#define SEG23COM2                      BANKMASK(LCDDATA8), 7
#define S16C2                          BANKMASK(LCDDATA8), 0
#define S17C2                          BANKMASK(LCDDATA8), 1
#define S18C2                          BANKMASK(LCDDATA8), 2
#define S19C2                          BANKMASK(LCDDATA8), 3
#define S20C2                          BANKMASK(LCDDATA8), 4
#define S21C2                          BANKMASK(LCDDATA8), 5
#define S22C2                          BANKMASK(LCDDATA8), 6
#define S23C2                          BANKMASK(LCDDATA8), 7
#ifndef _LIB_BUILD
#endif
LCDDATA9                               equ 0119h
#define SEG0COM3                       BANKMASK(LCDDATA9), 0
#define SEG1COM3                       BANKMASK(LCDDATA9), 1
#define SEG2COM3                       BANKMASK(LCDDATA9), 2
#define SEG3COM3                       BANKMASK(LCDDATA9), 3
#define SEG4COM3                       BANKMASK(LCDDATA9), 4
#define SEG5COM3                       BANKMASK(LCDDATA9), 5
#define SEG6COM3                       BANKMASK(LCDDATA9), 6
#define SEG7COM3                       BANKMASK(LCDDATA9), 7
#define S0C3                           BANKMASK(LCDDATA9), 0
#define S1C3                           BANKMASK(LCDDATA9), 1
#define S2C3                           BANKMASK(LCDDATA9), 2
#define S3C3                           BANKMASK(LCDDATA9), 3
#define S4C3                           BANKMASK(LCDDATA9), 4
#define S5C3                           BANKMASK(LCDDATA9), 5
#define S6C3                           BANKMASK(LCDDATA9), 6
#define S7C3                           BANKMASK(LCDDATA9), 7
#ifndef _LIB_BUILD
#endif
LCDDATA10                              equ 011Ah
#define SEG8COM3                       BANKMASK(LCDDATA10), 0
#define SEG9COM3                       BANKMASK(LCDDATA10), 1
#define SEG10COM3                      BANKMASK(LCDDATA10), 2
#define SEG11COM3                      BANKMASK(LCDDATA10), 3
#define SEG12COM3                      BANKMASK(LCDDATA10), 4
#define SEG13COM3                      BANKMASK(LCDDATA10), 5
#define SEG14COM3                      BANKMASK(LCDDATA10), 6
#define SEG15COM3                      BANKMASK(LCDDATA10), 7
#define S8C3                           BANKMASK(LCDDATA10), 0
#define S9C3                           BANKMASK(LCDDATA10), 1
#define S10C3                          BANKMASK(LCDDATA10), 2
#define S11C3                          BANKMASK(LCDDATA10), 3
#define S12C3                          BANKMASK(LCDDATA10), 4
#define S13C3                          BANKMASK(LCDDATA10), 5
#define S14C3                          BANKMASK(LCDDATA10), 6
#define S15C3                          BANKMASK(LCDDATA10), 7
#ifndef _LIB_BUILD
#endif
LCDDATA11                              equ 011Bh
#define SEG16COM3                      BANKMASK(LCDDATA11), 0
#define SEG17COM3                      BANKMASK(LCDDATA11), 1
#define SEG18COM3                      BANKMASK(LCDDATA11), 2
#define SEG19COM3                      BANKMASK(LCDDATA11), 3
#define SEG20COM3                      BANKMASK(LCDDATA11), 4
#define SEG21COM3                      BANKMASK(LCDDATA11), 5
#define SEG22COM3                      BANKMASK(LCDDATA11), 6
#define SEG23COM3                      BANKMASK(LCDDATA11), 7
#define S16C3                          BANKMASK(LCDDATA11), 0
#define S17C3                          BANKMASK(LCDDATA11), 1
#define S18C3                          BANKMASK(LCDDATA11), 2
#define S19C3                          BANKMASK(LCDDATA11), 3
#define S20C3                          BANKMASK(LCDDATA11), 4
#define S21C3                          BANKMASK(LCDDATA11), 5
#define S22C3                          BANKMASK(LCDDATA11), 6
#define S23C3                          BANKMASK(LCDDATA11), 7
#ifndef _LIB_BUILD
#endif
LCDSE0                                 equ 011Ch
#define SE0                            BANKMASK(LCDSE0), 0
#define SE1                            BANKMASK(LCDSE0), 1
#define SE2                            BANKMASK(LCDSE0), 2
#define SE3                            BANKMASK(LCDSE0), 3
#define SE4                            BANKMASK(LCDSE0), 4
#define SE5                            BANKMASK(LCDSE0), 5
#define SE6                            BANKMASK(LCDSE0), 6
#define SE7                            BANKMASK(LCDSE0), 7
#define SEGEN0                         BANKMASK(LCDSE0), 0
#define SEGEN1                         BANKMASK(LCDSE0), 1
#define SEGEN2                         BANKMASK(LCDSE0), 2
#define SEGEN3                         BANKMASK(LCDSE0), 3
#define SEGEN4                         BANKMASK(LCDSE0), 4
#define SEGEN5                         BANKMASK(LCDSE0), 5
#define SEGEN6                         BANKMASK(LCDSE0), 6
#define SEGEN7                         BANKMASK(LCDSE0), 7
#ifndef _LIB_BUILD
#endif
LCDSE1                                 equ 011Dh
#define SE8                            BANKMASK(LCDSE1), 0
#define SE9                            BANKMASK(LCDSE1), 1
#define SE10                           BANKMASK(LCDSE1), 2
#define SE11                           BANKMASK(LCDSE1), 3
#define SE12                           BANKMASK(LCDSE1), 4
#define SE13                           BANKMASK(LCDSE1), 5
#define SE14                           BANKMASK(LCDSE1), 6
#define SE15                           BANKMASK(LCDSE1), 7
#define SEGEN8                         BANKMASK(LCDSE1), 0
#define SEGEN9                         BANKMASK(LCDSE1), 1
#define SEGEN10                        BANKMASK(LCDSE1), 2
#define SEGEN11                        BANKMASK(LCDSE1), 3
#define SEGEN12                        BANKMASK(LCDSE1), 4
#define SEGEN13                        BANKMASK(LCDSE1), 5
#define SEGEN14                        BANKMASK(LCDSE1), 6
#define SEGEN15                        BANKMASK(LCDSE1), 7
#ifndef _LIB_BUILD
#endif
LCDSE2                                 equ 011Eh
#define SE16                           BANKMASK(LCDSE2), 0
#define SE17                           BANKMASK(LCDSE2), 1
#define SE18                           BANKMASK(LCDSE2), 2
#define SE19                           BANKMASK(LCDSE2), 3
#define SE20                           BANKMASK(LCDSE2), 4
#define SE21                           BANKMASK(LCDSE2), 5
#define SE22                           BANKMASK(LCDSE2), 6
#define SE23                           BANKMASK(LCDSE2), 7
#define SEGEN16                        BANKMASK(LCDSE2), 0
#define SEGEN17                        BANKMASK(LCDSE2), 1
#define SEGEN18                        BANKMASK(LCDSE2), 2
#define SEGEN19                        BANKMASK(LCDSE2), 3
#define SEGEN20                        BANKMASK(LCDSE2), 4
#define SEGEN21                        BANKMASK(LCDSE2), 5
#define SEGEN22                        BANKMASK(LCDSE2), 6
#define SEGEN23                        BANKMASK(LCDSE2), 7
#ifndef _LIB_BUILD
#endif
EECON1                                 equ 018Ch
#define RD                             BANKMASK(EECON1), 0
#define WR                             BANKMASK(EECON1), 1
#define WREN                           BANKMASK(EECON1), 2
#define WRERR                          BANKMASK(EECON1), 3
#define EEPGD                          BANKMASK(EECON1), 7
#define EERD                           BANKMASK(EECON1), 0
#define EEWR                           BANKMASK(EECON1), 1
#ifndef _LIB_BUILD
#endif
EECON2                                 equ 018Dh

#endif
#endif

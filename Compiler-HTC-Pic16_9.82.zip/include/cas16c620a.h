#ifndef _CASPIC_H_
#warning Header file cas16c620a.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS16C620A_H_
#define _CAS16C620A_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define IRP_bit                        BANKMASK(STATUS), 7
#define RP0_bit                        BANKMASK(STATUS), 5
#define RP1_bit                        BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define RA0_bit                        BANKMASK(PORTA), 0
#define RA1_bit                        BANKMASK(PORTA), 1
#define RA2_bit                        BANKMASK(PORTA), 2
#define RA3_bit                        BANKMASK(PORTA), 3
#define RA4_bit                        BANKMASK(PORTA), 4
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 0006h
#define RB0_bit                        BANKMASK(PORTB), 0
#define RB1_bit                        BANKMASK(PORTB), 1
#define RB2_bit                        BANKMASK(PORTB), 2
#define RB3_bit                        BANKMASK(PORTB), 3
#define RB4_bit                        BANKMASK(PORTB), 4
#define RB5_bit                        BANKMASK(PORTB), 5
#define RB6_bit                        BANKMASK(PORTB), 6
#define RB7_bit                        BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define RBIF_bit                       BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define T0IF_bit                       BANKMASK(INTCON), 2
#define RBIE_bit                       BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define T0IE_bit                       BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#define TMR0IF_bit                     BANKMASK(INTCON), 2
#define TMR0IE_bit                     BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define CMIF_bit                       BANKMASK(PIR1), 6
#ifndef _LIB_BUILD
#endif
CMCON                                  equ 001Fh
#define CIS_bit                        BANKMASK(CMCON), 3
#define C1OUT_bit                      BANKMASK(CMCON), 6
#define C2OUT_bit                      BANKMASK(CMCON), 7
#define CM0_bit                        BANKMASK(CMCON), 0
#define CM1_bit                        BANKMASK(CMCON), 1
#define CM2_bit                        BANKMASK(CMCON), 2
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nRBPU_bit                      BANKMASK(OPTION_REG), 7
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 0085h
#define TRISA0_bit                     BANKMASK(TRISA), 0
#define TRISA1_bit                     BANKMASK(TRISA), 1
#define TRISA2_bit                     BANKMASK(TRISA), 2
#define TRISA3_bit                     BANKMASK(TRISA), 3
#define TRISA4_bit                     BANKMASK(TRISA), 4
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 0086h
#define TRISB0_bit                     BANKMASK(TRISB), 0
#define TRISB1_bit                     BANKMASK(TRISB), 1
#define TRISB2_bit                     BANKMASK(TRISB), 2
#define TRISB3_bit                     BANKMASK(TRISB), 3
#define TRISB4_bit                     BANKMASK(TRISB), 4
#define TRISB5_bit                     BANKMASK(TRISB), 5
#define TRISB6_bit                     BANKMASK(TRISB), 6
#define TRISB7_bit                     BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define CMIE_bit                       BANKMASK(PIE1), 6
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOR_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#define nBO_bit                        BANKMASK(PCON), 0
#ifndef _LIB_BUILD
#endif
VRCON                                  equ 009Fh
#define VRR_bit                        BANKMASK(VRCON), 5
#define VROE_bit                       BANKMASK(VRCON), 6
#define VREN_bit                       BANKMASK(VRCON), 7
#define VR0_bit                        BANKMASK(VRCON), 0
#define VR1_bit                        BANKMASK(VRCON), 1
#define VR2_bit                        BANKMASK(VRCON), 2
#define VR3_bit                        BANKMASK(VRCON), 3
#ifndef _LIB_BUILD
#endif

#endif
#endif

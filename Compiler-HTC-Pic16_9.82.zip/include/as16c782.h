#ifndef _ASPIC_H_
#warning Header file as16c782.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS16C782_H_
#define _AS16C782_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define IRP                            BANKMASK(STATUS), 7
#define RP0                            BANKMASK(STATUS), 5
#define RP1                            BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define RA0                            BANKMASK(PORTA), 0
#define RA1                            BANKMASK(PORTA), 1
#define RA2                            BANKMASK(PORTA), 2
#define RA3                            BANKMASK(PORTA), 3
#define RA4                            BANKMASK(PORTA), 4
#define RA5                            BANKMASK(PORTA), 5
#define RA6                            BANKMASK(PORTA), 6
#define RA7                            BANKMASK(PORTA), 7
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 0006h
#define RB0                            BANKMASK(PORTB), 0
#define RB1                            BANKMASK(PORTB), 1
#define RB2                            BANKMASK(PORTB), 2
#define RB3                            BANKMASK(PORTB), 3
#define RB4                            BANKMASK(PORTB), 4
#define RB5                            BANKMASK(PORTB), 5
#define RB6                            BANKMASK(PORTB), 6
#define RB7                            BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define RBIF                           BANKMASK(INTCON), 0
#define INTF                           BANKMASK(INTCON), 1
#define T0IF                           BANKMASK(INTCON), 2
#define RBIE                           BANKMASK(INTCON), 3
#define INTE                           BANKMASK(INTCON), 4
#define T0IE                           BANKMASK(INTCON), 5
#define PEIE                           BANKMASK(INTCON), 6
#define GIE                            BANKMASK(INTCON), 7
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF                         BANKMASK(PIR1), 0
#define C1IF                           BANKMASK(PIR1), 4
#define C2IF                           BANKMASK(PIR1), 5
#define ADIF                           BANKMASK(PIR1), 6
#define LVDIF                          BANKMASK(PIR1), 7
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Eh
TMR1H                                  equ 000Fh
T1CON                                  equ 0010h
#define TMR1ON                         BANKMASK(T1CON), 0
#define TMR1CS                         BANKMASK(T1CON), 1
#define nT1SYNC                        BANKMASK(T1CON), 2
#define T1OSCEN                        BANKMASK(T1CON), 3
#define TMR1GE                         BANKMASK(T1CON), 6
#define T1INSYNC                       BANKMASK(T1CON), 2
#define T1CKPS0                        BANKMASK(T1CON), 4
#define T1CKPS1                        BANKMASK(T1CON), 5
#ifndef _LIB_BUILD
#endif
ADRES                                  equ 001Eh
ADCON0                                 equ 001Fh
#define ADON                           BANKMASK(ADCON0), 0
#define CHS3                           BANKMASK(ADCON0), 1
#define GO_nDONE                       BANKMASK(ADCON0), 2
#define GO                             BANKMASK(ADCON0), 2
#define CHS0                           BANKMASK(ADCON0), 3
#define CHS1                           BANKMASK(ADCON0), 4
#define CHS2                           BANKMASK(ADCON0), 5
#define ADCS0                          BANKMASK(ADCON0), 6
#define ADCS1                          BANKMASK(ADCON0), 7
#define nDONE                          BANKMASK(ADCON0), 2
#define GO_DONE                        BANKMASK(ADCON0), 2
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA                            BANKMASK(OPTION_REG), 3
#define T0SE                           BANKMASK(OPTION_REG), 4
#define T0CS                           BANKMASK(OPTION_REG), 5
#define INTEDG                         BANKMASK(OPTION_REG), 6
#define nRBPU                          BANKMASK(OPTION_REG), 7
#define PS0                            BANKMASK(OPTION_REG), 0
#define PS1                            BANKMASK(OPTION_REG), 1
#define PS2                            BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 0085h
#define TRISA0                         BANKMASK(TRISA), 0
#define TRISA1                         BANKMASK(TRISA), 1
#define TRISA2                         BANKMASK(TRISA), 2
#define TRISA3                         BANKMASK(TRISA), 3
#define TRISA4                         BANKMASK(TRISA), 4
#define TRISA5                         BANKMASK(TRISA), 5
#define TRISA6                         BANKMASK(TRISA), 6
#define TRISA7                         BANKMASK(TRISA), 7
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 0086h
#define TRISB0                         BANKMASK(TRISB), 0
#define TRISB1                         BANKMASK(TRISB), 1
#define TRISB2                         BANKMASK(TRISB), 2
#define TRISB3                         BANKMASK(TRISB), 3
#define TRISB4                         BANKMASK(TRISB), 4
#define TRISB5                         BANKMASK(TRISB), 5
#define TRISB6                         BANKMASK(TRISB), 6
#define TRISB7                         BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE                         BANKMASK(PIE1), 0
#define C1IE                           BANKMASK(PIE1), 4
#define C2IE                           BANKMASK(PIE1), 5
#define ADIE                           BANKMASK(PIE1), 6
#define LVDIE                          BANKMASK(PIE1), 7
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOR                           BANKMASK(PCON), 0
#define nPOR                           BANKMASK(PCON), 1
#define OSCF                           BANKMASK(PCON), 3
#define WDTON                          BANKMASK(PCON), 4
#define nBO                            BANKMASK(PCON), 0
#ifndef _LIB_BUILD
#endif
WPUB                                   equ 0095h
#define WPUB0                          BANKMASK(WPUB), 0
#define WPUB1                          BANKMASK(WPUB), 1
#define WPUB2                          BANKMASK(WPUB), 2
#define WPUB3                          BANKMASK(WPUB), 3
#define WPUB4                          BANKMASK(WPUB), 4
#define WPUB5                          BANKMASK(WPUB), 5
#define WPUB6                          BANKMASK(WPUB), 6
#define WPUB7                          BANKMASK(WPUB), 7
#ifndef _LIB_BUILD
#endif
IOCB                                   equ 0096h
#define IOCB0                          BANKMASK(IOCB), 0
#define IOCB1                          BANKMASK(IOCB), 1
#define IOCB2                          BANKMASK(IOCB), 2
#define IOCB3                          BANKMASK(IOCB), 3
#define IOCB4                          BANKMASK(IOCB), 4
#define IOCB5                          BANKMASK(IOCB), 5
#define IOCB6                          BANKMASK(IOCB), 6
#define IOCB7                          BANKMASK(IOCB), 7
#ifndef _LIB_BUILD
#endif
REFCON                                 equ 009Bh
#define VROE                           BANKMASK(REFCON), 2
#define VREN                           BANKMASK(REFCON), 3
#define VREFOE                         BANKMASK(REFCON), 2
#define VREFEN                         BANKMASK(REFCON), 3
#ifndef _LIB_BUILD
#endif
LVDCON                                 equ 009Ch
#define LVDEN                          BANKMASK(LVDCON), 4
#define BGST                           BANKMASK(LVDCON), 5
#define LV0                            BANKMASK(LVDCON), 0
#define LV1                            BANKMASK(LVDCON), 1
#define LV2                            BANKMASK(LVDCON), 2
#define LV3                            BANKMASK(LVDCON), 3
#ifndef _LIB_BUILD
#endif
ANSEL                                  equ 009Dh
#define ANS0                           BANKMASK(ANSEL), 0
#define ANS1                           BANKMASK(ANSEL), 1
#define ANS2                           BANKMASK(ANSEL), 2
#define ANS3                           BANKMASK(ANSEL), 3
#define ANS4                           BANKMASK(ANSEL), 4
#define ANS5                           BANKMASK(ANSEL), 5
#define ANS6                           BANKMASK(ANSEL), 6
#define ANS7                           BANKMASK(ANSEL), 7
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 009Fh
#define VCFG0                          BANKMASK(ADCON1), 4
#define VCFG1                          BANKMASK(ADCON1), 5
#ifndef _LIB_BUILD
#endif
PMDATL                                 equ 010Ch
PMADRL                                 equ 010Dh
PMDATH                                 equ 010Eh
#ifndef _LIB_BUILD
#endif
PMADRH                                 equ 010Fh
#ifndef _LIB_BUILD
#endif
CALCON                                 equ 0110h
#define CALREF                         BANKMASK(CALCON), 5
#define CALERR                         BANKMASK(CALCON), 6
#define CAL                            BANKMASK(CALCON), 7
#ifndef _LIB_BUILD
#endif
PSMCCON0                               equ 0111h
#define DC0                            BANKMASK(PSMCCON0), 0
#define DC1                            BANKMASK(PSMCCON0), 1
#define MAXDC0                         BANKMASK(PSMCCON0), 2
#define MAXDC1                         BANKMASK(PSMCCON0), 3
#define MINDC0                         BANKMASK(PSMCCON0), 4
#define MINDC1                         BANKMASK(PSMCCON0), 5
#define SMCCL0                         BANKMASK(PSMCCON0), 6
#define SMCCL1                         BANKMASK(PSMCCON0), 7
#ifndef _LIB_BUILD
#endif
PSMCCON1                               equ 0112h
#define SMCCS                          BANKMASK(PSMCCON1), 0
#define PWM_nPSM                       BANKMASK(PSMCCON1), 1
#define SMCOM                          BANKMASK(PSMCCON1), 2
#define SCEN                           BANKMASK(PSMCCON1), 3
#define S1BPOL                         BANKMASK(PSMCCON1), 5
#define S1APOL                         BANKMASK(PSMCCON1), 6
#define SMCON                          BANKMASK(PSMCCON1), 7
#define PWM                            BANKMASK(PSMCCON1), 1
#define PSM                            BANKMASK(PSMCCON1), 1
#define nPSM                           BANKMASK(PSMCCON1), 1
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 0119h
#define C1R                            BANKMASK(CM1CON0), 2
#define C1SP                           BANKMASK(CM1CON0), 3
#define C1POL                          BANKMASK(CM1CON0), 4
#define C1OE                           BANKMASK(CM1CON0), 5
#define C1OUT                          BANKMASK(CM1CON0), 6
#define C1ON                           BANKMASK(CM1CON0), 7
#define C1CH0                          BANKMASK(CM1CON0), 0
#define C1CH1                          BANKMASK(CM1CON0), 1
#ifndef _LIB_BUILD
#endif
CM2CON0                                equ 011Ah
#define C2R                            BANKMASK(CM2CON0), 2
#define C2SP                           BANKMASK(CM2CON0), 3
#define C2POL                          BANKMASK(CM2CON0), 4
#define C2OE                           BANKMASK(CM2CON0), 5
#define C2OUT                          BANKMASK(CM2CON0), 6
#define C2ON                           BANKMASK(CM2CON0), 7
#define C2CH0                          BANKMASK(CM2CON0), 0
#define C2CH1                          BANKMASK(CM2CON0), 1
#ifndef _LIB_BUILD
#endif
CM2CON1                                equ 011Bh
#define C2SYNC                         BANKMASK(CM2CON1), 0
#define MC2OUT                         BANKMASK(CM2CON1), 6
#define MC1OUT                         BANKMASK(CM2CON1), 7
#ifndef _LIB_BUILD
#endif
OPACON                                 equ 011Ch
#define GBWP                           BANKMASK(OPACON), 0
#define CMPEN                          BANKMASK(OPACON), 6
#define OPAON                          BANKMASK(OPACON), 7
#ifndef _LIB_BUILD
#endif
DAC                                    equ 011Eh
#define DA0                            BANKMASK(DAC), 0
#define DA1                            BANKMASK(DAC), 1
#define DA2                            BANKMASK(DAC), 2
#define DA3                            BANKMASK(DAC), 3
#define DA4                            BANKMASK(DAC), 4
#define DA5                            BANKMASK(DAC), 5
#define DA6                            BANKMASK(DAC), 6
#define DA7                            BANKMASK(DAC), 7
#ifndef _LIB_BUILD
#endif
DACON0                                 equ 011Fh
#define DAOE                           BANKMASK(DACON0), 6
#define DAON                           BANKMASK(DACON0), 7
#define DARS0                          BANKMASK(DACON0), 0
#define DARS1                          BANKMASK(DACON0), 1
#ifndef _LIB_BUILD
#endif
PMCON1                                 equ 018Ch
#define RD                             BANKMASK(PMCON1), 0
#ifndef _LIB_BUILD
#endif

#endif
#endif

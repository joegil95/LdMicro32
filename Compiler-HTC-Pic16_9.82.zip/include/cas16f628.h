#ifndef _CASPIC_H_
#warning Header file cas16f628.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS16F628_H_
#define _CAS16F628_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#define IRP_bit                        BANKMASK(STATUS), 7
#define RP0_bit                        BANKMASK(STATUS), 5
#define RP1_bit                        BANKMASK(STATUS), 6
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
PORTA                                  equ 0005h
#define RA0_bit                        BANKMASK(PORTA), 0
#define RA1_bit                        BANKMASK(PORTA), 1
#define RA2_bit                        BANKMASK(PORTA), 2
#define RA3_bit                        BANKMASK(PORTA), 3
#define RA4_bit                        BANKMASK(PORTA), 4
#define RA5_bit                        BANKMASK(PORTA), 5
#define RA6_bit                        BANKMASK(PORTA), 6
#define RA7_bit                        BANKMASK(PORTA), 7
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 0006h
#define RB0_bit                        BANKMASK(PORTB), 0
#define RB1_bit                        BANKMASK(PORTB), 1
#define RB2_bit                        BANKMASK(PORTB), 2
#define RB3_bit                        BANKMASK(PORTB), 3
#define RB4_bit                        BANKMASK(PORTB), 4
#define RB5_bit                        BANKMASK(PORTB), 5
#define RB6_bit                        BANKMASK(PORTB), 6
#define RB7_bit                        BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define RBIF_bit                       BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define T0IF_bit                       BANKMASK(INTCON), 2
#define RBIE_bit                       BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define T0IE_bit                       BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#define TMR0IF_bit                     BANKMASK(INTCON), 2
#define TMR0IE_bit                     BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 000Ch
#define TMR1IF_bit                     BANKMASK(PIR1), 0
#define TMR2IF_bit                     BANKMASK(PIR1), 1
#define CCP1IF_bit                     BANKMASK(PIR1), 2
#define TXIF_bit                       BANKMASK(PIR1), 4
#define RCIF_bit                       BANKMASK(PIR1), 5
#define CMIF_bit                       BANKMASK(PIR1), 6
#define EEIF_bit                       BANKMASK(PIR1), 7
#ifndef _LIB_BUILD
#endif
TMR1L                                  equ 000Eh
TMR1H                                  equ 000Fh
T1CON                                  equ 0010h
#define TMR1ON_bit                     BANKMASK(T1CON), 0
#define TMR1CS_bit                     BANKMASK(T1CON), 1
#define nT1SYNC_bit                    BANKMASK(T1CON), 2
#define T1OSCEN_bit                    BANKMASK(T1CON), 3
#define T1CKPS0_bit                    BANKMASK(T1CON), 4
#define T1CKPS1_bit                    BANKMASK(T1CON), 5
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 0011h
T2CON                                  equ 0012h
#define TMR2ON_bit                     BANKMASK(T2CON), 2
#define T2CKPS0_bit                    BANKMASK(T2CON), 0
#define T2CKPS1_bit                    BANKMASK(T2CON), 1
#define TOUTPS0_bit                    BANKMASK(T2CON), 3
#define TOUTPS1_bit                    BANKMASK(T2CON), 4
#define TOUTPS2_bit                    BANKMASK(T2CON), 5
#define TOUTPS3_bit                    BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0015h
CCPR1H                                 equ 0016h
CCP1CON                                equ 0017h
#define CCP1Y_bit                      BANKMASK(CCP1CON), 4
#define CCP1X_bit                      BANKMASK(CCP1CON), 5
#define CCP1M0_bit                     BANKMASK(CCP1CON), 0
#define CCP1M1_bit                     BANKMASK(CCP1CON), 1
#define CCP1M2_bit                     BANKMASK(CCP1CON), 2
#define CCP1M3_bit                     BANKMASK(CCP1CON), 3
#ifndef _LIB_BUILD
#endif
RCSTA                                  equ 0018h
#define RX9D_bit                       BANKMASK(RCSTA), 0
#define OERR_bit                       BANKMASK(RCSTA), 1
#define FERR_bit                       BANKMASK(RCSTA), 2
#define ADEN_bit                       BANKMASK(RCSTA), 3
#define CREN_bit                       BANKMASK(RCSTA), 4
#define SREN_bit                       BANKMASK(RCSTA), 5
#define RX9_bit                        BANKMASK(RCSTA), 6
#define SPEN_bit                       BANKMASK(RCSTA), 7
#define ADDEN_bit                      BANKMASK(RCSTA), 3
#ifndef _LIB_BUILD
#endif
TXREG                                  equ 0019h
RCREG                                  equ 001Ah
CMCON                                  equ 001Fh
#define CIS_bit                        BANKMASK(CMCON), 3
#define C1INV_bit                      BANKMASK(CMCON), 4
#define C2INV_bit                      BANKMASK(CMCON), 5
#define C1OUT_bit                      BANKMASK(CMCON), 6
#define C2OUT_bit                      BANKMASK(CMCON), 7
#define CM0_bit                        BANKMASK(CMCON), 0
#define CM1_bit                        BANKMASK(CMCON), 1
#define CM2_bit                        BANKMASK(CMCON), 2
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0081h
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nRBPU_bit                      BANKMASK(OPTION_REG), 7
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 0085h
#define TRISA0_bit                     BANKMASK(TRISA), 0
#define TRISA1_bit                     BANKMASK(TRISA), 1
#define TRISA2_bit                     BANKMASK(TRISA), 2
#define TRISA3_bit                     BANKMASK(TRISA), 3
#define TRISA4_bit                     BANKMASK(TRISA), 4
#define TRISA5_bit                     BANKMASK(TRISA), 5
#define TRISA6_bit                     BANKMASK(TRISA), 6
#define TRISA7_bit                     BANKMASK(TRISA), 7
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 0086h
#define TRISB0_bit                     BANKMASK(TRISB), 0
#define TRISB1_bit                     BANKMASK(TRISB), 1
#define TRISB2_bit                     BANKMASK(TRISB), 2
#define TRISB3_bit                     BANKMASK(TRISB), 3
#define TRISB4_bit                     BANKMASK(TRISB), 4
#define TRISB5_bit                     BANKMASK(TRISB), 5
#define TRISB6_bit                     BANKMASK(TRISB), 6
#define TRISB7_bit                     BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 008Ch
#define TMR1IE_bit                     BANKMASK(PIE1), 0
#define TMR2IE_bit                     BANKMASK(PIE1), 1
#define CCP1IE_bit                     BANKMASK(PIE1), 2
#define TXIE_bit                       BANKMASK(PIE1), 4
#define RCIE_bit                       BANKMASK(PIE1), 5
#define CMIE_bit                       BANKMASK(PIE1), 6
#define EEIE_bit                       BANKMASK(PIE1), 7
#ifndef _LIB_BUILD
#endif
PCON                                   equ 008Eh
#define nBOR_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#define OSCF_bit                       BANKMASK(PCON), 3
#define nBO_bit                        BANKMASK(PCON), 0
#define nBOD_bit                       BANKMASK(PCON), 0
#ifndef _LIB_BUILD
#endif
PR2                                    equ 0092h
TXSTA                                  equ 0098h
#define TX9D_bit                       BANKMASK(TXSTA), 0
#define TRMT_bit                       BANKMASK(TXSTA), 1
#define BRGH_bit                       BANKMASK(TXSTA), 2
#define SYNC_bit                       BANKMASK(TXSTA), 4
#define TXEN_bit                       BANKMASK(TXSTA), 5
#define TX9_bit                        BANKMASK(TXSTA), 6
#define CSRC_bit                       BANKMASK(TXSTA), 7
#ifndef _LIB_BUILD
#endif
SPBRG                                  equ 0099h
EEDATA                                 equ 009Ah
EEADR                                  equ 009Bh
EECON1                                 equ 009Ch
#define RD_bit                         BANKMASK(EECON1), 0
#define WR_bit                         BANKMASK(EECON1), 1
#define WREN_bit                       BANKMASK(EECON1), 2
#define WRERR_bit                      BANKMASK(EECON1), 3
#ifndef _LIB_BUILD
#endif
EECON2                                 equ 009Dh
VRCON                                  equ 009Fh
#define VRR_bit                        BANKMASK(VRCON), 5
#define VROE_bit                       BANKMASK(VRCON), 6
#define VREN_bit                       BANKMASK(VRCON), 7
#define VR0_bit                        BANKMASK(VRCON), 0
#define VR1_bit                        BANKMASK(VRCON), 1
#define VR2_bit                        BANKMASK(VRCON), 2
#define VR3_bit                        BANKMASK(VRCON), 3
#ifndef _LIB_BUILD
#endif

#endif
#endif

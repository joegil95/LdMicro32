#ifndef _ASPIC_H_
#warning Header file as16c505.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS16C505_H_
#define _AS16C505_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define PA0                            BANKMASK(STATUS), 5
#define RBWUF                          BANKMASK(STATUS), 7
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
OSCCAL                                 equ 0005h
#define CAL0                           BANKMASK(OSCCAL), 2
#define CAL1                           BANKMASK(OSCCAL), 3
#define CAL2                           BANKMASK(OSCCAL), 4
#define CAL3                           BANKMASK(OSCCAL), 5
#define CAL4                           BANKMASK(OSCCAL), 6
#define CAL5                           BANKMASK(OSCCAL), 7
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 0006h
#define RB0                            BANKMASK(PORTB), 0
#define RB1                            BANKMASK(PORTB), 1
#define RB2                            BANKMASK(PORTB), 2
#define RB3                            BANKMASK(PORTB), 3
#define RB4                            BANKMASK(PORTB), 4
#define RB5                            BANKMASK(PORTB), 5
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 0007h
#define RC0                            BANKMASK(PORTC), 0
#define RC1                            BANKMASK(PORTC), 1
#define RC2                            BANKMASK(PORTC), 2
#define RC3                            BANKMASK(PORTC), 3
#define RC4                            BANKMASK(PORTC), 4
#define RC5                            BANKMASK(PORTC), 5
#ifndef _LIB_BUILD
#endif

#endif
#endif

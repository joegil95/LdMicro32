#ifndef _ASPIC_H_
#warning Header file as12f509.h included directly. Including <aspic.h> instead
#include <aspic.h>
#else
#ifndef _AS12F509_H_
#define _AS12F509_H_

INDF                                   equ 0000h
TMR0                                   equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY                          BANKMASK(STATUS), 0
#define DC                             BANKMASK(STATUS), 1
#define ZERO                           BANKMASK(STATUS), 2
#define nPD                            BANKMASK(STATUS), 3
#define nTO                            BANKMASK(STATUS), 4
#define PA0                            BANKMASK(STATUS), 5
#define GPWUF                          BANKMASK(STATUS), 7
#ifndef _LIB_BUILD
#endif
FSR                                    equ 0004h
OSCCAL                                 equ 0005h
#define CAL0                           BANKMASK(OSCCAL), 1
#define CAL1                           BANKMASK(OSCCAL), 2
#define CAL2                           BANKMASK(OSCCAL), 3
#define CAL3                           BANKMASK(OSCCAL), 4
#define CAL4                           BANKMASK(OSCCAL), 5
#define CAL5                           BANKMASK(OSCCAL), 6
#define CAL6                           BANKMASK(OSCCAL), 7
#ifndef _LIB_BUILD
#endif
GPIO                                   equ 0006h
#define GP0                            BANKMASK(GPIO), 0
#define GP1                            BANKMASK(GPIO), 1
#define GP2                            BANKMASK(GPIO), 2
#define GP3                            BANKMASK(GPIO), 3
#define GP4                            BANKMASK(GPIO), 4
#define GP5                            BANKMASK(GPIO), 5
#ifndef _LIB_BUILD
#endif

#endif
#endif

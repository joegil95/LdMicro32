#ifndef _CASPIC_H_
#warning Header file cas16f1783.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS16F1783_H_
#define _CAS16F1783_H_

INDF0                                  equ 0000h
INDF1                                  equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#ifndef _LIB_BUILD
#endif
FSR0L                                  equ 0004h
FSR0H                                  equ 0005h
FSR1L                                  equ 0006h
FSR1H                                  equ 0007h
BSR                                    equ 0008h
#define BSR0_bit                       BANKMASK(BSR), 0
#define BSR1_bit                       BANKMASK(BSR), 1
#define BSR2_bit                       BANKMASK(BSR), 2
#define BSR3_bit                       BANKMASK(BSR), 3
#define BSR4_bit                       BANKMASK(BSR), 4
#ifndef _LIB_BUILD
#endif
WREG                                   equ 0009h
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define IOCIF_bit                      BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define TMR0IF_bit                     BANKMASK(INTCON), 2
#define IOCIE_bit                      BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define TMR0IE_bit                     BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#define T0IF_bit                       BANKMASK(INTCON), 2
#define T0IE_bit                       BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PORTA                                  equ 000Ch
#define RA0_bit                        BANKMASK(PORTA), 0
#define RA1_bit                        BANKMASK(PORTA), 1
#define RA2_bit                        BANKMASK(PORTA), 2
#define RA3_bit                        BANKMASK(PORTA), 3
#define RA4_bit                        BANKMASK(PORTA), 4
#define RA5_bit                        BANKMASK(PORTA), 5
#define RA6_bit                        BANKMASK(PORTA), 6
#define RA7_bit                        BANKMASK(PORTA), 7
#ifndef _LIB_BUILD
#endif
PORTB                                  equ 000Dh
#define RB0_bit                        BANKMASK(PORTB), 0
#define RB1_bit                        BANKMASK(PORTB), 1
#define RB2_bit                        BANKMASK(PORTB), 2
#define RB3_bit                        BANKMASK(PORTB), 3
#define RB4_bit                        BANKMASK(PORTB), 4
#define RB5_bit                        BANKMASK(PORTB), 5
#define RB6_bit                        BANKMASK(PORTB), 6
#define RB7_bit                        BANKMASK(PORTB), 7
#ifndef _LIB_BUILD
#endif
PORTC                                  equ 000Eh
#define RC0_bit                        BANKMASK(PORTC), 0
#define RC1_bit                        BANKMASK(PORTC), 1
#define RC2_bit                        BANKMASK(PORTC), 2
#define RC3_bit                        BANKMASK(PORTC), 3
#define RC4_bit                        BANKMASK(PORTC), 4
#define RC5_bit                        BANKMASK(PORTC), 5
#define RC6_bit                        BANKMASK(PORTC), 6
#define RC7_bit                        BANKMASK(PORTC), 7
#ifndef _LIB_BUILD
#endif
PORTE                                  equ 0010h
#define RE3_bit                        BANKMASK(PORTE), 3
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 0011h
#define TMR1IF_bit                     BANKMASK(PIR1), 0
#define TMR2IF_bit                     BANKMASK(PIR1), 1
#define CCP1IF_bit                     BANKMASK(PIR1), 2
#define SSP1IF_bit                     BANKMASK(PIR1), 3
#define TXIF_bit                       BANKMASK(PIR1), 4
#define RCIF_bit                       BANKMASK(PIR1), 5
#define ADIF_bit                       BANKMASK(PIR1), 6
#define TMR1GIF_bit                    BANKMASK(PIR1), 7
#ifndef _LIB_BUILD
#endif
PIR2                                   equ 0012h
#define CCP2IF_bit                     BANKMASK(PIR2), 0
#define C3IF_bit                       BANKMASK(PIR2), 1
#define BCL1IF_bit                     BANKMASK(PIR2), 3
#define EEIF_bit                       BANKMASK(PIR2), 4
#define C1IF_bit                       BANKMASK(PIR2), 5
#define C2IF_bit                       BANKMASK(PIR2), 6
#define OSFIF_bit                      BANKMASK(PIR2), 7
#ifndef _LIB_BUILD
#endif
PIR4                                   equ 0014h
#define PSMC1SIF_bit                   BANKMASK(PIR4), 0
#define PSMC2SIF_bit                   BANKMASK(PIR4), 1
#define PSMC1TIF_bit                   BANKMASK(PIR4), 4
#define PSMC2TIF_bit                   BANKMASK(PIR4), 5
#ifndef _LIB_BUILD
#endif
TMR0                                   equ 0015h
TMR1L                                  equ 0016h
TMR1H                                  equ 0017h
T1CON                                  equ 0018h
#define TMR1ON_bit                     BANKMASK(T1CON), 0
#define nT1SYNC_bit                    BANKMASK(T1CON), 2
#define T1OSCEN_bit                    BANKMASK(T1CON), 3
#define T1CKPS0_bit                    BANKMASK(T1CON), 4
#define T1CKPS1_bit                    BANKMASK(T1CON), 5
#define TMR1CS0_bit                    BANKMASK(T1CON), 6
#define TMR1CS1_bit                    BANKMASK(T1CON), 7
#ifndef _LIB_BUILD
#endif
T1GCON                                 equ 0019h
#define T1GSS0_bit                     BANKMASK(T1GCON), 0
#define T1GSS1_bit                     BANKMASK(T1GCON), 1
#define T1GVAL_bit                     BANKMASK(T1GCON), 2
#define T1GGO_bit                      BANKMASK(T1GCON), 3
#define T1GSPM_bit                     BANKMASK(T1GCON), 4
#define T1GTM_bit                      BANKMASK(T1GCON), 5
#define T1GPOL_bit                     BANKMASK(T1GCON), 6
#define TMR1GE_bit                     BANKMASK(T1GCON), 7
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 001Ah
PR2                                    equ 001Bh
T2CON                                  equ 001Ch
#define T2CKPS0_bit                    BANKMASK(T2CON), 0
#define T2CKPS1_bit                    BANKMASK(T2CON), 1
#define TMR2ON_bit                     BANKMASK(T2CON), 2
#define T2OUTPS0_bit                   BANKMASK(T2CON), 3
#define T2OUTPS1_bit                   BANKMASK(T2CON), 4
#define T2OUTPS2_bit                   BANKMASK(T2CON), 5
#define T2OUTPS3_bit                   BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 008Ch
#define TRISA0_bit                     BANKMASK(TRISA), 0
#define TRISA1_bit                     BANKMASK(TRISA), 1
#define TRISA2_bit                     BANKMASK(TRISA), 2
#define TRISA3_bit                     BANKMASK(TRISA), 3
#define TRISA4_bit                     BANKMASK(TRISA), 4
#define TRISA5_bit                     BANKMASK(TRISA), 5
#define TRISA6_bit                     BANKMASK(TRISA), 6
#define TRISA7_bit                     BANKMASK(TRISA), 7
#ifndef _LIB_BUILD
#endif
TRISB                                  equ 008Dh
#define TRISB0_bit                     BANKMASK(TRISB), 0
#define TRISB1_bit                     BANKMASK(TRISB), 1
#define TRISB2_bit                     BANKMASK(TRISB), 2
#define TRISB3_bit                     BANKMASK(TRISB), 3
#define TRISB4_bit                     BANKMASK(TRISB), 4
#define TRISB5_bit                     BANKMASK(TRISB), 5
#define TRISB6_bit                     BANKMASK(TRISB), 6
#define TRISB7_bit                     BANKMASK(TRISB), 7
#ifndef _LIB_BUILD
#endif
TRISC                                  equ 008Eh
#define TRISC0_bit                     BANKMASK(TRISC), 0
#define TRISC1_bit                     BANKMASK(TRISC), 1
#define TRISC2_bit                     BANKMASK(TRISC), 2
#define TRISC3_bit                     BANKMASK(TRISC), 3
#define TRISC4_bit                     BANKMASK(TRISC), 4
#define TRISC5_bit                     BANKMASK(TRISC), 5
#define TRISC6_bit                     BANKMASK(TRISC), 6
#define TRISC7_bit                     BANKMASK(TRISC), 7
#ifndef _LIB_BUILD
#endif
TRISE                                  equ 0090h
#define TRISE3_bit                     BANKMASK(TRISE), 3
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 0091h
#define TMR1IE_bit                     BANKMASK(PIE1), 0
#define TMR2IE_bit                     BANKMASK(PIE1), 1
#define CCP1IE_bit                     BANKMASK(PIE1), 2
#define SSP1IE_bit                     BANKMASK(PIE1), 3
#define TXIE_bit                       BANKMASK(PIE1), 4
#define RCIE_bit                       BANKMASK(PIE1), 5
#define ADIE_bit                       BANKMASK(PIE1), 6
#define TMR1GIE_bit                    BANKMASK(PIE1), 7
#ifndef _LIB_BUILD
#endif
PIE2                                   equ 0092h
#define CCP2IE_bit                     BANKMASK(PIE2), 0
#define C3IE_bit                       BANKMASK(PIE2), 1
#define BCL1IE_bit                     BANKMASK(PIE2), 3
#define EEIE_bit                       BANKMASK(PIE2), 4
#define C1IE_bit                       BANKMASK(PIE2), 5
#define C2IE_bit                       BANKMASK(PIE2), 6
#define OSFIE_bit                      BANKMASK(PIE2), 7
#ifndef _LIB_BUILD
#endif
PIE4                                   equ 0094h
#define PSMC1SIE_bit                   BANKMASK(PIE4), 0
#define PSMC2SIE_bit                   BANKMASK(PIE4), 1
#define PSMC1TIE_bit                   BANKMASK(PIE4), 4
#define PSMC2TIE_bit                   BANKMASK(PIE4), 5
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0095h
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define TMR0SE_bit                     BANKMASK(OPTION_REG), 4
#define TMR0CS_bit                     BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nWPUEN_bit                     BANKMASK(OPTION_REG), 7
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#ifndef _LIB_BUILD
#endif
PCON                                   equ 0096h
#define nBOR_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#define nRI_bit                        BANKMASK(PCON), 2
#define nRMCLR_bit                     BANKMASK(PCON), 3
#define nRWDT_bit                      BANKMASK(PCON), 4
#define STKUNF_bit                     BANKMASK(PCON), 6
#define STKOVF_bit                     BANKMASK(PCON), 7
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0097h
#define SWDTEN_bit                     BANKMASK(WDTCON), 0
#define WDTPS0_bit                     BANKMASK(WDTCON), 1
#define WDTPS1_bit                     BANKMASK(WDTCON), 2
#define WDTPS2_bit                     BANKMASK(WDTCON), 3
#define WDTPS3_bit                     BANKMASK(WDTCON), 4
#define WDTPS4_bit                     BANKMASK(WDTCON), 5
#ifndef _LIB_BUILD
#endif
OSCTUNE                                equ 0098h
#define TUN0_bit                       BANKMASK(OSCTUNE), 0
#define TUN1_bit                       BANKMASK(OSCTUNE), 1
#define TUN2_bit                       BANKMASK(OSCTUNE), 2
#define TUN3_bit                       BANKMASK(OSCTUNE), 3
#define TUN4_bit                       BANKMASK(OSCTUNE), 4
#define TUN5_bit                       BANKMASK(OSCTUNE), 5
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 0099h
#define SCS0_bit                       BANKMASK(OSCCON), 0
#define SCS1_bit                       BANKMASK(OSCCON), 1
#define IRCF0_bit                      BANKMASK(OSCCON), 3
#define IRCF1_bit                      BANKMASK(OSCCON), 4
#define IRCF2_bit                      BANKMASK(OSCCON), 5
#define IRCF3_bit                      BANKMASK(OSCCON), 6
#define SPLLEN_bit                     BANKMASK(OSCCON), 7
#ifndef _LIB_BUILD
#endif
OSCSTAT                                equ 009Ah
#define HFIOFS_bit                     BANKMASK(OSCSTAT), 0
#define LFIOFR_bit                     BANKMASK(OSCSTAT), 1
#define MFIOFR_bit                     BANKMASK(OSCSTAT), 2
#define HFIOFL_bit                     BANKMASK(OSCSTAT), 3
#define HFIOFR_bit                     BANKMASK(OSCSTAT), 4
#define OSTS_bit                       BANKMASK(OSCSTAT), 5
#define PLLR_bit                       BANKMASK(OSCSTAT), 6
#define T1OSCR_bit                     BANKMASK(OSCSTAT), 7
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 009Bh
ADRESH                                 equ 009Ch
ADCON0                                 equ 009Dh
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 1
#define CHS0_bit                       BANKMASK(ADCON0), 2
#define CHS1_bit                       BANKMASK(ADCON0), 3
#define CHS2_bit                       BANKMASK(ADCON0), 4
#define CHS3_bit                       BANKMASK(ADCON0), 5
#define CHS4_bit                       BANKMASK(ADCON0), 6
#define ADGO_bit                       BANKMASK(ADCON0), 1
#define GO_bit                         BANKMASK(ADCON0), 1
#define DONE_bit                       BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 009Eh
#define ADPREF0_bit                    BANKMASK(ADCON1), 0
#define ADPREF1_bit                    BANKMASK(ADCON1), 1
#define ADNREF_bit                     BANKMASK(ADCON1), 2
#define ADCS0_bit                      BANKMASK(ADCON1), 4
#define ADCS1_bit                      BANKMASK(ADCON1), 5
#define ADCS2_bit                      BANKMASK(ADCON1), 6
#define ADFM_bit                       BANKMASK(ADCON1), 7
#ifndef _LIB_BUILD
#endif
ADCON2                                 equ 009Fh
#define CHSN0_bit                      BANKMASK(ADCON2), 0
#define CHSN1_bit                      BANKMASK(ADCON2), 1
#define CHSN2_bit                      BANKMASK(ADCON2), 2
#define CHSN3_bit                      BANKMASK(ADCON2), 3
#define TRIGSEL0_bit                   BANKMASK(ADCON2), 4
#define TRIGSEL1_bit                   BANKMASK(ADCON2), 5
#define TRIGSEL2_bit                   BANKMASK(ADCON2), 6
#define TRIGSEL3_bit                   BANKMASK(ADCON2), 7
#ifndef _LIB_BUILD
#endif
LATA                                   equ 010Ch
#define LATA0_bit                      BANKMASK(LATA), 0
#define LATA1_bit                      BANKMASK(LATA), 1
#define LATA2_bit                      BANKMASK(LATA), 2
#define LATA3_bit                      BANKMASK(LATA), 3
#define LATA4_bit                      BANKMASK(LATA), 4
#define LATA5_bit                      BANKMASK(LATA), 5
#define LATA6_bit                      BANKMASK(LATA), 6
#define LATA7_bit                      BANKMASK(LATA), 7
#ifndef _LIB_BUILD
#endif
LATB                                   equ 010Dh
#define LATB0_bit                      BANKMASK(LATB), 0
#define LATB1_bit                      BANKMASK(LATB), 1
#define LATB2_bit                      BANKMASK(LATB), 2
#define LATB3_bit                      BANKMASK(LATB), 3
#define LATB4_bit                      BANKMASK(LATB), 4
#define LATB5_bit                      BANKMASK(LATB), 5
#define LATB6_bit                      BANKMASK(LATB), 6
#define LATB7_bit                      BANKMASK(LATB), 7
#ifndef _LIB_BUILD
#endif
LATC                                   equ 010Eh
#define LATC0_bit                      BANKMASK(LATC), 0
#define LATC1_bit                      BANKMASK(LATC), 1
#define LATC2_bit                      BANKMASK(LATC), 2
#define LATC3_bit                      BANKMASK(LATC), 3
#define LATC4_bit                      BANKMASK(LATC), 4
#define LATC5_bit                      BANKMASK(LATC), 5
#define LATC6_bit                      BANKMASK(LATC), 6
#define LATC7_bit                      BANKMASK(LATC), 7
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 0111h
#define C1SYNC_bit                     BANKMASK(CM1CON0), 0
#define C1HYS_bit                      BANKMASK(CM1CON0), 1
#define C1SP_bit                       BANKMASK(CM1CON0), 2
#define C1POL_bit                      BANKMASK(CM1CON0), 4
#define C1OE_bit                       BANKMASK(CM1CON0), 5
#define C1OUT_bit                      BANKMASK(CM1CON0), 6
#define C1ON_bit                       BANKMASK(CM1CON0), 7
#ifndef _LIB_BUILD
#endif
CM1CON1                                equ 0112h
#define C1NCH0_bit                     BANKMASK(CM1CON1), 0
#define C1NCH1_bit                     BANKMASK(CM1CON1), 1
#define C1NCH2_bit                     BANKMASK(CM1CON1), 2
#define C1PCH0_bit                     BANKMASK(CM1CON1), 3
#define C1PCH1_bit                     BANKMASK(CM1CON1), 4
#define C1PCH2_bit                     BANKMASK(CM1CON1), 5
#define C1INTN_bit                     BANKMASK(CM1CON1), 6
#define C1INTP_bit                     BANKMASK(CM1CON1), 7
#ifndef _LIB_BUILD
#endif
CM2CON0                                equ 0113h
#define C2SYNC_bit                     BANKMASK(CM2CON0), 0
#define C2HYS_bit                      BANKMASK(CM2CON0), 1
#define C2SP_bit                       BANKMASK(CM2CON0), 2
#define C2POL_bit                      BANKMASK(CM2CON0), 4
#define C2OE_bit                       BANKMASK(CM2CON0), 5
#define C2OUT_bit                      BANKMASK(CM2CON0), 6
#define C2ON_bit                       BANKMASK(CM2CON0), 7
#ifndef _LIB_BUILD
#endif
CM2CON1                                equ 0114h
#define C2NCH0_bit                     BANKMASK(CM2CON1), 0
#define C2NCH1_bit                     BANKMASK(CM2CON1), 1
#define C2NCH2_bit                     BANKMASK(CM2CON1), 2
#define C2PCH0_bit                     BANKMASK(CM2CON1), 3
#define C2PCH1_bit                     BANKMASK(CM2CON1), 4
#define C2PCH2_bit                     BANKMASK(CM2CON1), 5
#define C2INTN_bit                     BANKMASK(CM2CON1), 6
#define C2INTP_bit                     BANKMASK(CM2CON1), 7
#ifndef _LIB_BUILD
#endif
CMOUT                                  equ 0115h
#define MC1OUT_bit                     BANKMASK(CMOUT), 0
#define MC2OUT_bit                     BANKMASK(CMOUT), 1
#define MC3OUT_bit                     BANKMASK(CMOUT), 2
#ifndef _LIB_BUILD
#endif
BORCON                                 equ 0116h
#define BORRDY_bit                     BANKMASK(BORCON), 0
#define BORFS_bit                      BANKMASK(BORCON), 6
#define SBOREN_bit                     BANKMASK(BORCON), 7
#ifndef _LIB_BUILD
#endif
FVRCON                                 equ 0117h
#define ADFVR0_bit                     BANKMASK(FVRCON), 0
#define ADFVR1_bit                     BANKMASK(FVRCON), 1
#define CDAFVR0_bit                    BANKMASK(FVRCON), 2
#define CDAFVR1_bit                    BANKMASK(FVRCON), 3
#define FVRRDY_bit                     BANKMASK(FVRCON), 6
#define FVREN_bit                      BANKMASK(FVRCON), 7
#ifndef _LIB_BUILD
#endif
DACCON0                                equ 0118h
#define DACNSS_bit                     BANKMASK(DACCON0), 0
#define DACPSS0_bit                    BANKMASK(DACCON0), 2
#define DACPSS1_bit                    BANKMASK(DACCON0), 3
#define DACOE2_bit                     BANKMASK(DACCON0), 4
#define DACOE1_bit                     BANKMASK(DACCON0), 5
#define DACEN_bit                      BANKMASK(DACCON0), 7
#ifndef _LIB_BUILD
#endif
DACCON1                                equ 0119h
#define DACR0_bit                      BANKMASK(DACCON1), 0
#define DACR1_bit                      BANKMASK(DACCON1), 1
#define DACR2_bit                      BANKMASK(DACCON1), 2
#define DACR3_bit                      BANKMASK(DACCON1), 3
#define DACR4_bit                      BANKMASK(DACCON1), 4
#define DACR5_bit                      BANKMASK(DACCON1), 5
#define DACR6_bit                      BANKMASK(DACCON1), 6
#define DACR7_bit                      BANKMASK(DACCON1), 7
#ifndef _LIB_BUILD
#endif
APFCON                                 equ 011Dh
APFCON0                                equ 011Dh
#define CCP2SEL_bit                    BANKMASK(APFCON), 0
#define RXSEL_bit                      BANKMASK(APFCON), 1
#define TXSEL_bit                      BANKMASK(APFCON), 2
#define SDISEL_bit                     BANKMASK(APFCON), 3
#define SCKSEL_bit                     BANKMASK(APFCON), 4
#define SDOSEL_bit                     BANKMASK(APFCON), 5
#define CCP1SEL_bit                    BANKMASK(APFCON), 6
#define C2OUTSEL_bit                   BANKMASK(APFCON), 7
#ifndef _LIB_BUILD
#endif
CM3CON0                                equ 011Eh
#define C3SYNC_bit                     BANKMASK(CM3CON0), 0
#define C3HYS_bit                      BANKMASK(CM3CON0), 1
#define C3SP_bit                       BANKMASK(CM3CON0), 2
#define C3POL_bit                      BANKMASK(CM3CON0), 4
#define C3OE_bit                       BANKMASK(CM3CON0), 5
#define C3OUT_bit                      BANKMASK(CM3CON0), 6
#define C3ON_bit                       BANKMASK(CM3CON0), 7
#ifndef _LIB_BUILD
#endif
CM3CON1                                equ 011Fh
#define C3NCH0_bit                     BANKMASK(CM3CON1), 0
#define C3NCH1_bit                     BANKMASK(CM3CON1), 1
#define C3NCH2_bit                     BANKMASK(CM3CON1), 2
#define C3PCH0_bit                     BANKMASK(CM3CON1), 3
#define C3PCH1_bit                     BANKMASK(CM3CON1), 4
#define C3PCH2_bit                     BANKMASK(CM3CON1), 5
#define C3INTN_bit                     BANKMASK(CM3CON1), 6
#define C3INTP_bit                     BANKMASK(CM3CON1), 7
#ifndef _LIB_BUILD
#endif
ANSELA                                 equ 018Ch
#define ANSA0_bit                      BANKMASK(ANSELA), 0
#define ANSA1_bit                      BANKMASK(ANSELA), 1
#define ANSA2_bit                      BANKMASK(ANSELA), 2
#define ANSA3_bit                      BANKMASK(ANSELA), 3
#define ANSA4_bit                      BANKMASK(ANSELA), 4
#define ANSA5_bit                      BANKMASK(ANSELA), 5
#define ANSA7_bit                      BANKMASK(ANSELA), 7
#ifndef _LIB_BUILD
#endif
ANSELB                                 equ 018Dh
#define ANSB0_bit                      BANKMASK(ANSELB), 0
#define ANSB1_bit                      BANKMASK(ANSELB), 1
#define ANSB2_bit                      BANKMASK(ANSELB), 2
#define ANSB3_bit                      BANKMASK(ANSELB), 3
#define ANSB4_bit                      BANKMASK(ANSELB), 4
#define ANSB5_bit                      BANKMASK(ANSELB), 5
#ifndef _LIB_BUILD
#endif
EEADRL                                 equ 0191h
EEADRH                                 equ 0192h
#ifndef _LIB_BUILD
#endif
EEDATL                                 equ 0193h
EEDATA                                 equ 0193h
EEDATH                                 equ 0194h
#ifndef _LIB_BUILD
#endif
EECON1                                 equ 0195h
#define RD_bit                         BANKMASK(EECON1), 0
#define WR_bit                         BANKMASK(EECON1), 1
#define WREN_bit                       BANKMASK(EECON1), 2
#define WRERR_bit                      BANKMASK(EECON1), 3
#define FREE_bit                       BANKMASK(EECON1), 4
#define LWLO_bit                       BANKMASK(EECON1), 5
#define CFGS_bit                       BANKMASK(EECON1), 6
#define EEPGD_bit                      BANKMASK(EECON1), 7
#ifndef _LIB_BUILD
#endif
EECON2                                 equ 0196h
VREGCON                                equ 0197h
#define VREGPM0_bit                    BANKMASK(VREGCON), 0
#define VREGPM1_bit                    BANKMASK(VREGCON), 1
#ifndef _LIB_BUILD
#endif
WPUA                                   equ 020Ch
#define WPUA0_bit                      BANKMASK(WPUA), 0
#define WPUA1_bit                      BANKMASK(WPUA), 1
#define WPUA2_bit                      BANKMASK(WPUA), 2
#define WPUA3_bit                      BANKMASK(WPUA), 3
#define WPUA4_bit                      BANKMASK(WPUA), 4
#define WPUA5_bit                      BANKMASK(WPUA), 5
#define WPUA6_bit                      BANKMASK(WPUA), 6
#define WPUA7_bit                      BANKMASK(WPUA), 7
#ifndef _LIB_BUILD
#endif
WPUB                                   equ 020Dh
#define WPUB0_bit                      BANKMASK(WPUB), 0
#define WPUB1_bit                      BANKMASK(WPUB), 1
#define WPUB2_bit                      BANKMASK(WPUB), 2
#define WPUB3_bit                      BANKMASK(WPUB), 3
#define WPUB4_bit                      BANKMASK(WPUB), 4
#define WPUB5_bit                      BANKMASK(WPUB), 5
#define WPUB6_bit                      BANKMASK(WPUB), 6
#define WPUB7_bit                      BANKMASK(WPUB), 7
#ifndef _LIB_BUILD
#endif
WPUC                                   equ 020Eh
#define WPUC0_bit                      BANKMASK(WPUC), 0
#define WPUC1_bit                      BANKMASK(WPUC), 1
#define WPUC2_bit                      BANKMASK(WPUC), 2
#define WPUC3_bit                      BANKMASK(WPUC), 3
#define WPUC4_bit                      BANKMASK(WPUC), 4
#define WPUC5_bit                      BANKMASK(WPUC), 5
#define WPUC6_bit                      BANKMASK(WPUC), 6
#define WPUC7_bit                      BANKMASK(WPUC), 7
#ifndef _LIB_BUILD
#endif
WPUE                                   equ 0210h
#define WPUE3_bit                      BANKMASK(WPUE), 3
#ifndef _LIB_BUILD
#endif
SSPBUF                                 equ 0211h
SSP1BUF                                equ 0211h
SSPADD                                 equ 0212h
SSP1ADD                                equ 0212h
SSPMSK                                 equ 0213h
SSP1MSK                                equ 0213h
SSPSTAT                                equ 0214h
SSP1STAT                               equ 0214h
#define BF_bit                         BANKMASK(SSPSTAT), 0
#define UA_bit                         BANKMASK(SSPSTAT), 1
#define R_nW_bit                       BANKMASK(SSPSTAT), 2
#define S_bit                          BANKMASK(SSPSTAT), 3
#define P_bit                          BANKMASK(SSPSTAT), 4
#define D_nA_bit                       BANKMASK(SSPSTAT), 5
#define CKE_bit                        BANKMASK(SSPSTAT), 6
#define SMP_bit                        BANKMASK(SSPSTAT), 7
#ifndef _LIB_BUILD
#endif
SSPCON1                                equ 0215h
SSP1CON                                equ 0215h
SSPCON                                 equ 0215h
#define SSPM0_bit                      BANKMASK(SSPCON1), 0
#define SSPM1_bit                      BANKMASK(SSPCON1), 1
#define SSPM2_bit                      BANKMASK(SSPCON1), 2
#define SSPM3_bit                      BANKMASK(SSPCON1), 3
#define CKP_bit                        BANKMASK(SSPCON1), 4
#define SSPEN_bit                      BANKMASK(SSPCON1), 5
#define SSPOV_bit                      BANKMASK(SSPCON1), 6
#define WCOL_bit                       BANKMASK(SSPCON1), 7
#ifndef _LIB_BUILD
#endif
SSPCON2                                equ 0216h
SSP1CON2                               equ 0216h
#define SEN_bit                        BANKMASK(SSPCON2), 0
#define RSEN_bit                       BANKMASK(SSPCON2), 1
#define PEN_bit                        BANKMASK(SSPCON2), 2
#define RCEN_bit                       BANKMASK(SSPCON2), 3
#define ACKEN_bit                      BANKMASK(SSPCON2), 4
#define ACKDT_bit                      BANKMASK(SSPCON2), 5
#define ACKSTAT_bit                    BANKMASK(SSPCON2), 6
#define GCEN_bit                       BANKMASK(SSPCON2), 7
#ifndef _LIB_BUILD
#endif
SSPCON3                                equ 0217h
SSP1CON3                               equ 0217h
#define DHEN_bit                       BANKMASK(SSPCON3), 0
#define AHEN_bit                       BANKMASK(SSPCON3), 1
#define SBCDE_bit                      BANKMASK(SSPCON3), 2
#define SDAHT_bit                      BANKMASK(SSPCON3), 3
#define BOEN_bit                       BANKMASK(SSPCON3), 4
#define SCIE_bit                       BANKMASK(SSPCON3), 5
#define PCIE_bit                       BANKMASK(SSPCON3), 6
#define ACKTIM_bit                     BANKMASK(SSPCON3), 7
#ifndef _LIB_BUILD
#endif
ODCONA                                 equ 028Ch
#define ODCONA0_bit                    BANKMASK(ODCONA), 0
#define ODCONA1_bit                    BANKMASK(ODCONA), 1
#define ODCONA2_bit                    BANKMASK(ODCONA), 2
#define ODCONA3_bit                    BANKMASK(ODCONA), 3
#define ODCONA4_bit                    BANKMASK(ODCONA), 4
#define ODCONA5_bit                    BANKMASK(ODCONA), 5
#define ODCONA6_bit                    BANKMASK(ODCONA), 6
#define ODCONA7_bit                    BANKMASK(ODCONA), 7
#ifndef _LIB_BUILD
#endif
ODCONB                                 equ 028Dh
#define ODCONB0_bit                    BANKMASK(ODCONB), 0
#define ODCONB1_bit                    BANKMASK(ODCONB), 1
#define ODCONB2_bit                    BANKMASK(ODCONB), 2
#define ODCONB3_bit                    BANKMASK(ODCONB), 3
#define ODCONB4_bit                    BANKMASK(ODCONB), 4
#define ODCONB5_bit                    BANKMASK(ODCONB), 5
#define ODCONB6_bit                    BANKMASK(ODCONB), 6
#define ODCONB7_bit                    BANKMASK(ODCONB), 7
#ifndef _LIB_BUILD
#endif
ODCONC                                 equ 028Eh
#define ODCONC0_bit                    BANKMASK(ODCONC), 0
#define ODCONC1_bit                    BANKMASK(ODCONC), 1
#define ODCONC2_bit                    BANKMASK(ODCONC), 2
#define ODCONC3_bit                    BANKMASK(ODCONC), 3
#define ODCONC4_bit                    BANKMASK(ODCONC), 4
#define ODCONC5_bit                    BANKMASK(ODCONC), 5
#define ODCONC6_bit                    BANKMASK(ODCONC), 6
#define ODCONC7_bit                    BANKMASK(ODCONC), 7
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0291h
CCPR1H                                 equ 0292h
CCP1CON                                equ 0293h
#define CCP1M0_bit                     BANKMASK(CCP1CON), 0
#define CCP1M1_bit                     BANKMASK(CCP1CON), 1
#define CCP1M2_bit                     BANKMASK(CCP1CON), 2
#define CCP1M3_bit                     BANKMASK(CCP1CON), 3
#define DC1B0_bit                      BANKMASK(CCP1CON), 4
#define DC1B1_bit                      BANKMASK(CCP1CON), 5
#define P1M0_bit                       BANKMASK(CCP1CON), 6
#define P1M1_bit                       BANKMASK(CCP1CON), 7
#ifndef _LIB_BUILD
#endif
CCPR2L                                 equ 0298h
CCPR2H                                 equ 0299h
CCP2CON                                equ 029Ah
#define CCP2M0_bit                     BANKMASK(CCP2CON), 0
#define CCP2M1_bit                     BANKMASK(CCP2CON), 1
#define CCP2M2_bit                     BANKMASK(CCP2CON), 2
#define CCP2M3_bit                     BANKMASK(CCP2CON), 3
#define DC2B0_bit                      BANKMASK(CCP2CON), 4
#define DC2B1_bit                      BANKMASK(CCP2CON), 5
#define P2M0_bit                       BANKMASK(CCP2CON), 6
#define P2M1_bit                       BANKMASK(CCP2CON), 7
#ifndef _LIB_BUILD
#endif
SLRCONA                                equ 030Ch
#define SLRCONA0_bit                   BANKMASK(SLRCONA), 0
#define SLRCONA1_bit                   BANKMASK(SLRCONA), 1
#define SLRCONA2_bit                   BANKMASK(SLRCONA), 2
#define SLRCONA3_bit                   BANKMASK(SLRCONA), 3
#define SLRCONA4_bit                   BANKMASK(SLRCONA), 4
#define SLRCONA5_bit                   BANKMASK(SLRCONA), 5
#define SLRCONA6_bit                   BANKMASK(SLRCONA), 6
#define SLRCONA7_bit                   BANKMASK(SLRCONA), 7
#ifndef _LIB_BUILD
#endif
SLRCONB                                equ 030Dh
#define SLRCONB0_bit                   BANKMASK(SLRCONB), 0
#define SLRCONB1_bit                   BANKMASK(SLRCONB), 1
#define SLRCONB2_bit                   BANKMASK(SLRCONB), 2
#define SLRCONB3_bit                   BANKMASK(SLRCONB), 3
#define SLRCONB4_bit                   BANKMASK(SLRCONB), 4
#define SLRCONB5_bit                   BANKMASK(SLRCONB), 5
#define SLRCONB6_bit                   BANKMASK(SLRCONB), 6
#define SLRCONB7_bit                   BANKMASK(SLRCONB), 7
#ifndef _LIB_BUILD
#endif
SLRCONC                                equ 030Eh
#define SLRCONC0_bit                   BANKMASK(SLRCONC), 0
#define SLRCONC1_bit                   BANKMASK(SLRCONC), 1
#define SLRCONC2_bit                   BANKMASK(SLRCONC), 2
#define SLRCONC3_bit                   BANKMASK(SLRCONC), 3
#define SLRCONC4_bit                   BANKMASK(SLRCONC), 4
#define SLRCONC5_bit                   BANKMASK(SLRCONC), 5
#define SLRCONC6_bit                   BANKMASK(SLRCONC), 6
#define SLRCONC7_bit                   BANKMASK(SLRCONC), 7
#ifndef _LIB_BUILD
#endif
INLVLA                                 equ 038Ch
#define INLVLA0_bit                    BANKMASK(INLVLA), 0
#define INLVLA1_bit                    BANKMASK(INLVLA), 1
#define INLVLA2_bit                    BANKMASK(INLVLA), 2
#define INLVLA3_bit                    BANKMASK(INLVLA), 3
#define INLVLA4_bit                    BANKMASK(INLVLA), 4
#define INLVLA5_bit                    BANKMASK(INLVLA), 5
#define INLVLA6_bit                    BANKMASK(INLVLA), 6
#define INLVLA7_bit                    BANKMASK(INLVLA), 7
#ifndef _LIB_BUILD
#endif
INLVLB                                 equ 038Dh
#define INLVLB0_bit                    BANKMASK(INLVLB), 0
#define INLVLB1_bit                    BANKMASK(INLVLB), 1
#define INLVLB2_bit                    BANKMASK(INLVLB), 2
#define INLVLB3_bit                    BANKMASK(INLVLB), 3
#define INLVLB4_bit                    BANKMASK(INLVLB), 4
#define INLVLB5_bit                    BANKMASK(INLVLB), 5
#define INLVLB6_bit                    BANKMASK(INLVLB), 6
#define INLVLB7_bit                    BANKMASK(INLVLB), 7
#ifndef _LIB_BUILD
#endif
INLVLC                                 equ 038Eh
#define INLVLC0_bit                    BANKMASK(INLVLC), 0
#define INLVLC1_bit                    BANKMASK(INLVLC), 1
#define INLVLC2_bit                    BANKMASK(INLVLC), 2
#define INLVLC3_bit                    BANKMASK(INLVLC), 3
#define INLVLC4_bit                    BANKMASK(INLVLC), 4
#define INLVLC5_bit                    BANKMASK(INLVLC), 5
#define INLVLC6_bit                    BANKMASK(INLVLC), 6
#define INLVLC7_bit                    BANKMASK(INLVLC), 7
#ifndef _LIB_BUILD
#endif
INLVLE                                 equ 0390h
#define INLVLE3_bit                    BANKMASK(INLVLE), 3
#ifndef _LIB_BUILD
#endif
IOCAP                                  equ 0391h
#define IOCAP0_bit                     BANKMASK(IOCAP), 0
#define IOCAP1_bit                     BANKMASK(IOCAP), 1
#define IOCAP2_bit                     BANKMASK(IOCAP), 2
#define IOCAP3_bit                     BANKMASK(IOCAP), 3
#define IOCAP4_bit                     BANKMASK(IOCAP), 4
#define IOCAP5_bit                     BANKMASK(IOCAP), 5
#define IOCAP6_bit                     BANKMASK(IOCAP), 6
#define IOCAP7_bit                     BANKMASK(IOCAP), 7
#ifndef _LIB_BUILD
#endif
IOCAN                                  equ 0392h
#define IOCAN0_bit                     BANKMASK(IOCAN), 0
#define IOCAN1_bit                     BANKMASK(IOCAN), 1
#define IOCAN2_bit                     BANKMASK(IOCAN), 2
#define IOCAN3_bit                     BANKMASK(IOCAN), 3
#define IOCAN4_bit                     BANKMASK(IOCAN), 4
#define IOCAN5_bit                     BANKMASK(IOCAN), 5
#define IOCAN6_bit                     BANKMASK(IOCAN), 6
#define IOCAN7_bit                     BANKMASK(IOCAN), 7
#ifndef _LIB_BUILD
#endif
IOCAF                                  equ 0393h
#define IOCAF0_bit                     BANKMASK(IOCAF), 0
#define IOCAF1_bit                     BANKMASK(IOCAF), 1
#define IOCAF2_bit                     BANKMASK(IOCAF), 2
#define IOCAF3_bit                     BANKMASK(IOCAF), 3
#define IOCAF4_bit                     BANKMASK(IOCAF), 4
#define IOCAF5_bit                     BANKMASK(IOCAF), 5
#define IOCAF6_bit                     BANKMASK(IOCAF), 6
#define IOCAF7_bit                     BANKMASK(IOCAF), 7
#ifndef _LIB_BUILD
#endif
IOCBP                                  equ 0394h
#define IOCBP0_bit                     BANKMASK(IOCBP), 0
#define IOCBP1_bit                     BANKMASK(IOCBP), 1
#define IOCBP2_bit                     BANKMASK(IOCBP), 2
#define IOCBP3_bit                     BANKMASK(IOCBP), 3
#define IOCBP4_bit                     BANKMASK(IOCBP), 4
#define IOCBP5_bit                     BANKMASK(IOCBP), 5
#define IOCBP6_bit                     BANKMASK(IOCBP), 6
#define IOCBP7_bit                     BANKMASK(IOCBP), 7
#ifndef _LIB_BUILD
#endif
IOCBN                                  equ 0395h
#define IOCBN0_bit                     BANKMASK(IOCBN), 0
#define IOCBN1_bit                     BANKMASK(IOCBN), 1
#define IOCBN2_bit                     BANKMASK(IOCBN), 2
#define IOCBN3_bit                     BANKMASK(IOCBN), 3
#define IOCBN4_bit                     BANKMASK(IOCBN), 4
#define IOCBN5_bit                     BANKMASK(IOCBN), 5
#define IOCBN6_bit                     BANKMASK(IOCBN), 6
#define IOCBN7_bit                     BANKMASK(IOCBN), 7
#ifndef _LIB_BUILD
#endif
IOCBF                                  equ 0396h
#define IOCBF0_bit                     BANKMASK(IOCBF), 0
#define IOCBF1_bit                     BANKMASK(IOCBF), 1
#define IOCBF2_bit                     BANKMASK(IOCBF), 2
#define IOCBF3_bit                     BANKMASK(IOCBF), 3
#define IOCBF4_bit                     BANKMASK(IOCBF), 4
#define IOCBF5_bit                     BANKMASK(IOCBF), 5
#define IOCBF6_bit                     BANKMASK(IOCBF), 6
#define IOCBF7_bit                     BANKMASK(IOCBF), 7
#ifndef _LIB_BUILD
#endif
IOCCP                                  equ 0397h
#define IOCCP0_bit                     BANKMASK(IOCCP), 0
#define IOCCP1_bit                     BANKMASK(IOCCP), 1
#define IOCCP2_bit                     BANKMASK(IOCCP), 2
#define IOCCP3_bit                     BANKMASK(IOCCP), 3
#define IOCCP4_bit                     BANKMASK(IOCCP), 4
#define IOCCP5_bit                     BANKMASK(IOCCP), 5
#define IOCCP6_bit                     BANKMASK(IOCCP), 6
#define IOCCP7_bit                     BANKMASK(IOCCP), 7
#ifndef _LIB_BUILD
#endif
IOCCN                                  equ 0398h
#define IOCCN0_bit                     BANKMASK(IOCCN), 0
#define IOCCN1_bit                     BANKMASK(IOCCN), 1
#define IOCCN2_bit                     BANKMASK(IOCCN), 2
#define IOCCN3_bit                     BANKMASK(IOCCN), 3
#define IOCCN4_bit                     BANKMASK(IOCCN), 4
#define IOCCN5_bit                     BANKMASK(IOCCN), 5
#define IOCCN6_bit                     BANKMASK(IOCCN), 6
#define IOCCN7_bit                     BANKMASK(IOCCN), 7
#ifndef _LIB_BUILD
#endif
IOCCF                                  equ 0399h
#define IOCCF0_bit                     BANKMASK(IOCCF), 0
#define IOCCF1_bit                     BANKMASK(IOCCF), 1
#define IOCCF2_bit                     BANKMASK(IOCCF), 2
#define IOCCF3_bit                     BANKMASK(IOCCF), 3
#define IOCCF4_bit                     BANKMASK(IOCCF), 4
#define IOCCF5_bit                     BANKMASK(IOCCF), 5
#define IOCCF6_bit                     BANKMASK(IOCCF), 6
#define IOCCF7_bit                     BANKMASK(IOCCF), 7
#ifndef _LIB_BUILD
#endif
IOCEP                                  equ 039Dh
#define IOCEP3_bit                     BANKMASK(IOCEP), 3
#ifndef _LIB_BUILD
#endif
IOCEN                                  equ 039Eh
#define IOCEN3_bit                     BANKMASK(IOCEN), 3
#ifndef _LIB_BUILD
#endif
IOCEF                                  equ 039Fh
#define IOCEF3_bit                     BANKMASK(IOCEF), 3
#ifndef _LIB_BUILD
#endif
OPA1CON                                equ 0511h
#define OPA1CH0_bit                    BANKMASK(OPA1CON), 0
#define OPA1CH1_bit                    BANKMASK(OPA1CON), 1
#define OPA1SP_bit                     BANKMASK(OPA1CON), 6
#define OPA1EN_bit                     BANKMASK(OPA1CON), 7
#ifndef _LIB_BUILD
#endif
OPA2CON                                equ 0513h
#define OPA2CH0_bit                    BANKMASK(OPA2CON), 0
#define OPA2CH1_bit                    BANKMASK(OPA2CON), 1
#define OPA2SP_bit                     BANKMASK(OPA2CON), 6
#define OPA2EN_bit                     BANKMASK(OPA2CON), 7
#ifndef _LIB_BUILD
#endif
CLKRCON                                equ 051Ah
#define CLKRDIV0_bit                   BANKMASK(CLKRCON), 0
#define CLKRDIV1_bit                   BANKMASK(CLKRCON), 1
#define CLKRDIV2_bit                   BANKMASK(CLKRCON), 2
#define CLKRDC0_bit                    BANKMASK(CLKRCON), 3
#define CLKRDC1_bit                    BANKMASK(CLKRCON), 4
#define CLKRSLR_bit                    BANKMASK(CLKRCON), 5
#define CLKROE_bit                     BANKMASK(CLKRCON), 6
#define CLKREN_bit                     BANKMASK(CLKRCON), 7
#ifndef _LIB_BUILD
#endif
STATUS_SHAD                            equ 0FE4h
#define C_SHAD_bit                     BANKMASK(STATUS_SHAD), 0
#define DC_SHAD_bit                    BANKMASK(STATUS_SHAD), 1
#define Z_SHAD_bit                     BANKMASK(STATUS_SHAD), 2
#ifndef _LIB_BUILD
#endif
WREG_SHAD                              equ 0FE5h
BSR_SHAD                               equ 0FE6h
#ifndef _LIB_BUILD
#endif
PCLATH_SHAD                            equ 0FE7h
#ifndef _LIB_BUILD
#endif
FSR0L_SHAD                             equ 0FE8h
FSR0H_SHAD                             equ 0FE9h
FSR1L_SHAD                             equ 0FEAh
FSR1H_SHAD                             equ 0FEBh
STKPTR                                 equ 0FEDh
#ifndef _LIB_BUILD
#endif
TOSL                                   equ 0FEEh
TOSH                                   equ 0FEFh
#ifndef _LIB_BUILD
#endif

#endif
#endif

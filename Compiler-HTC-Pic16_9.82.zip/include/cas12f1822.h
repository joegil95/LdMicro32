#ifndef _CASPIC_H_
#warning Header file cas12f1822.h included directly. Including <caspic.h> instead
#include <caspic.h>
#else
#ifndef _CAS12F1822_H_
#define _CAS12F1822_H_

INDF0                                  equ 0000h
INDF1                                  equ 0001h
PCL                                    equ 0002h
STATUS                                 equ 0003h
#define CARRY_bit                      BANKMASK(STATUS), 0
#define DC_bit                         BANKMASK(STATUS), 1
#define ZERO_bit                       BANKMASK(STATUS), 2
#define nPD_bit                        BANKMASK(STATUS), 3
#define nTO_bit                        BANKMASK(STATUS), 4
#ifndef _LIB_BUILD
#endif
FSR0L                                  equ 0004h
FSR0H                                  equ 0005h
FSR1L                                  equ 0006h
FSR1H                                  equ 0007h
BSR                                    equ 0008h
#define BSR0_bit                       BANKMASK(BSR), 0
#define BSR1_bit                       BANKMASK(BSR), 1
#define BSR2_bit                       BANKMASK(BSR), 2
#define BSR3_bit                       BANKMASK(BSR), 3
#define BSR4_bit                       BANKMASK(BSR), 4
#ifndef _LIB_BUILD
#endif
WREG                                   equ 0009h
PCLATH                                 equ 000Ah
#ifndef _LIB_BUILD
#endif
INTCON                                 equ 000Bh
#define IOCIF_bit                      BANKMASK(INTCON), 0
#define INTF_bit                       BANKMASK(INTCON), 1
#define TMR0IF_bit                     BANKMASK(INTCON), 2
#define IOCIE_bit                      BANKMASK(INTCON), 3
#define INTE_bit                       BANKMASK(INTCON), 4
#define TMR0IE_bit                     BANKMASK(INTCON), 5
#define PEIE_bit                       BANKMASK(INTCON), 6
#define GIE_bit                        BANKMASK(INTCON), 7
#define T0IF_bit                       BANKMASK(INTCON), 2
#define T0IE_bit                       BANKMASK(INTCON), 5
#ifndef _LIB_BUILD
#endif
PORTA                                  equ 000Ch
#define RA0_bit                        BANKMASK(PORTA), 0
#define RA1_bit                        BANKMASK(PORTA), 1
#define RA2_bit                        BANKMASK(PORTA), 2
#define RA3_bit                        BANKMASK(PORTA), 3
#define RA4_bit                        BANKMASK(PORTA), 4
#define RA5_bit                        BANKMASK(PORTA), 5
#define AN0_bit                        BANKMASK(PORTA), 0
#define AN1_bit                        BANKMASK(PORTA), 1
#define AN2_bit                        BANKMASK(PORTA), 2
#define AN3_bit                        BANKMASK(PORTA), 4
#define CPS0_bit                       BANKMASK(PORTA), 0
#define CPS1_bit                       BANKMASK(PORTA), 1
#define CPS2_bit                       BANKMASK(PORTA), 2
#define CPS3_bit                       BANKMASK(PORTA), 4
#define C1INP_bit                      BANKMASK(PORTA), 0
#define C1IN0N_bit                     BANKMASK(PORTA), 1
#define C1IN1N_bit                     BANKMASK(PORTA), 4
#define DACOUT_bit                     BANKMASK(PORTA), 0
#define SRI_bit                        BANKMASK(PORTA), 1
#define SRQ_bit                        BANKMASK(PORTA), 2
#define SRNQ_bit                       BANKMASK(PORTA), 5
#define SCK_bit                        BANKMASK(PORTA), 1
#define T0CKI_bit                      BANKMASK(PORTA), 2
#define T1OSO_bit                      BANKMASK(PORTA), 4
#define T1CKI_bit                      BANKMASK(PORTA), 5
#define SCL_bit                        BANKMASK(PORTA), 1
#define SDA_bit                        BANKMASK(PORTA), 2
#define nMCLR_bit                      BANKMASK(PORTA), 3
#define CLKR_bit                       BANKMASK(PORTA), 4
#define T1OSI_bit                      BANKMASK(PORTA), 5
#define MDMIN_bit                      BANKMASK(PORTA), 1
#define MDCIN1_bit                     BANKMASK(PORTA), 2
#define MDCIN2_bit                     BANKMASK(PORTA), 4
#define SDI_bit                        BANKMASK(PORTA), 2
#define OSC2_bit                       BANKMASK(PORTA), 4
#define OSC1_bit                       BANKMASK(PORTA), 5
#define FLT0_bit                       BANKMASK(PORTA), 2
#define CLKOUT_bit                     BANKMASK(PORTA), 4
#define CLKIN_bit                      BANKMASK(PORTA), 5
#ifndef _LIB_BUILD
#endif
PIR1                                   equ 0011h
#define TMR1IF_bit                     BANKMASK(PIR1), 0
#define TMR2IF_bit                     BANKMASK(PIR1), 1
#define CCP1IF_bit                     BANKMASK(PIR1), 2
#define SSP1IF_bit                     BANKMASK(PIR1), 3
#define TXIF_bit                       BANKMASK(PIR1), 4
#define RCIF_bit                       BANKMASK(PIR1), 5
#define ADIF_bit                       BANKMASK(PIR1), 6
#define TMR1GIF_bit                    BANKMASK(PIR1), 7
#ifndef _LIB_BUILD
#endif
PIR2                                   equ 0012h
#define BCL1IF_bit                     BANKMASK(PIR2), 3
#define EEIF_bit                       BANKMASK(PIR2), 4
#define C1IF_bit                       BANKMASK(PIR2), 5
#define OSFIF_bit                      BANKMASK(PIR2), 7
#ifndef _LIB_BUILD
#endif
TMR0                                   equ 0015h
TMR1L                                  equ 0016h
TMR1H                                  equ 0017h
T1CON                                  equ 0018h
#define TMR1ON_bit                     BANKMASK(T1CON), 0
#define nT1SYNC_bit                    BANKMASK(T1CON), 2
#define T1OSCEN_bit                    BANKMASK(T1CON), 3
#define T1CKPS0_bit                    BANKMASK(T1CON), 4
#define T1CKPS1_bit                    BANKMASK(T1CON), 5
#define TMR1CS0_bit                    BANKMASK(T1CON), 6
#define TMR1CS1_bit                    BANKMASK(T1CON), 7
#ifndef _LIB_BUILD
#endif
T1GCON                                 equ 0019h
#define T1GSS0_bit                     BANKMASK(T1GCON), 0
#define T1GSS1_bit                     BANKMASK(T1GCON), 1
#define T1GVAL_bit                     BANKMASK(T1GCON), 2
#define T1GGO_nDONE_bit                BANKMASK(T1GCON), 3
#define T1GSPM_bit                     BANKMASK(T1GCON), 4
#define T1GTM_bit                      BANKMASK(T1GCON), 5
#define T1GPOL_bit                     BANKMASK(T1GCON), 6
#define TMR1GE_bit                     BANKMASK(T1GCON), 7
#define T1GGO_bit                      BANKMASK(T1GCON), 3
#ifndef _LIB_BUILD
#endif
TMR2                                   equ 001Ah
PR2                                    equ 001Bh
T2CON                                  equ 001Ch
#define T2CKPS0_bit                    BANKMASK(T2CON), 0
#define T2CKPS1_bit                    BANKMASK(T2CON), 1
#define TMR2ON_bit                     BANKMASK(T2CON), 2
#define T2OUTPS0_bit                   BANKMASK(T2CON), 3
#define T2OUTPS1_bit                   BANKMASK(T2CON), 4
#define T2OUTPS2_bit                   BANKMASK(T2CON), 5
#define T2OUTPS3_bit                   BANKMASK(T2CON), 6
#ifndef _LIB_BUILD
#endif
CPSCON0                                equ 001Eh
#define T0XCS_bit                      BANKMASK(CPSCON0), 0
#define CPSOUT_bit                     BANKMASK(CPSCON0), 1
#define CPSRNG0_bit                    BANKMASK(CPSCON0), 2
#define CPSRNG1_bit                    BANKMASK(CPSCON0), 3
#define CPSRM_bit                      BANKMASK(CPSCON0), 6
#define CPSON_bit                      BANKMASK(CPSCON0), 7
#ifndef _LIB_BUILD
#endif
CPSCON1                                equ 001Fh
#define CPSCH0_bit                     BANKMASK(CPSCON1), 0
#define CPSCH1_bit                     BANKMASK(CPSCON1), 1
#ifndef _LIB_BUILD
#endif
TRISA                                  equ 008Ch
#define TRISA0_bit                     BANKMASK(TRISA), 0
#define TRISA1_bit                     BANKMASK(TRISA), 1
#define TRISA2_bit                     BANKMASK(TRISA), 2
#define TRISA3_bit                     BANKMASK(TRISA), 3
#define TRISA4_bit                     BANKMASK(TRISA), 4
#define TRISA5_bit                     BANKMASK(TRISA), 5
#ifndef _LIB_BUILD
#endif
PIE1                                   equ 0091h
#define TMR1IE_bit                     BANKMASK(PIE1), 0
#define TMR2IE_bit                     BANKMASK(PIE1), 1
#define CCP1IE_bit                     BANKMASK(PIE1), 2
#define SSP1IE_bit                     BANKMASK(PIE1), 3
#define TXIE_bit                       BANKMASK(PIE1), 4
#define RCIE_bit                       BANKMASK(PIE1), 5
#define ADIE_bit                       BANKMASK(PIE1), 6
#define TMR1GIE_bit                    BANKMASK(PIE1), 7
#ifndef _LIB_BUILD
#endif
PIE2                                   equ 0092h
#define BCL1IE_bit                     BANKMASK(PIE2), 3
#define EEIE_bit                       BANKMASK(PIE2), 4
#define C1IE_bit                       BANKMASK(PIE2), 5
#define OSFIE_bit                      BANKMASK(PIE2), 7
#ifndef _LIB_BUILD
#endif
OPTION_REG                             equ 0095h
#define PS0_bit                        BANKMASK(OPTION_REG), 0
#define PS1_bit                        BANKMASK(OPTION_REG), 1
#define PS2_bit                        BANKMASK(OPTION_REG), 2
#define PSA_bit                        BANKMASK(OPTION_REG), 3
#define TMR0SE_bit                     BANKMASK(OPTION_REG), 4
#define TMR0CS_bit                     BANKMASK(OPTION_REG), 5
#define INTEDG_bit                     BANKMASK(OPTION_REG), 6
#define nWPUEN_bit                     BANKMASK(OPTION_REG), 7
#define T0SE_bit                       BANKMASK(OPTION_REG), 4
#define T0CS_bit                       BANKMASK(OPTION_REG), 5
#ifndef _LIB_BUILD
#endif
PCON                                   equ 0096h
#define nBOR_bit                       BANKMASK(PCON), 0
#define nPOR_bit                       BANKMASK(PCON), 1
#define nRI_bit                        BANKMASK(PCON), 2
#define nRMCLR_bit                     BANKMASK(PCON), 3
#define STKUNF_bit                     BANKMASK(PCON), 6
#define STKOVF_bit                     BANKMASK(PCON), 7
#ifndef _LIB_BUILD
#endif
WDTCON                                 equ 0097h
#define SWDTEN_bit                     BANKMASK(WDTCON), 0
#define WDTPS0_bit                     BANKMASK(WDTCON), 1
#define WDTPS1_bit                     BANKMASK(WDTCON), 2
#define WDTPS2_bit                     BANKMASK(WDTCON), 3
#define WDTPS3_bit                     BANKMASK(WDTCON), 4
#define WDTPS4_bit                     BANKMASK(WDTCON), 5
#ifndef _LIB_BUILD
#endif
OSCTUNE                                equ 0098h
#define TUN0_bit                       BANKMASK(OSCTUNE), 0
#define TUN1_bit                       BANKMASK(OSCTUNE), 1
#define TUN2_bit                       BANKMASK(OSCTUNE), 2
#define TUN3_bit                       BANKMASK(OSCTUNE), 3
#define TUN4_bit                       BANKMASK(OSCTUNE), 4
#define TUN5_bit                       BANKMASK(OSCTUNE), 5
#ifndef _LIB_BUILD
#endif
OSCCON                                 equ 0099h
#define SCS0_bit                       BANKMASK(OSCCON), 0
#define SCS1_bit                       BANKMASK(OSCCON), 1
#define IRCF0_bit                      BANKMASK(OSCCON), 3
#define IRCF1_bit                      BANKMASK(OSCCON), 4
#define IRCF2_bit                      BANKMASK(OSCCON), 5
#define IRCF3_bit                      BANKMASK(OSCCON), 6
#define SPLLEN_bit                     BANKMASK(OSCCON), 7
#ifndef _LIB_BUILD
#endif
OSCSTAT                                equ 009Ah
#define HFIOFS_bit                     BANKMASK(OSCSTAT), 0
#define LFIOFR_bit                     BANKMASK(OSCSTAT), 1
#define MFIOFR_bit                     BANKMASK(OSCSTAT), 2
#define HFIOFL_bit                     BANKMASK(OSCSTAT), 3
#define HFIOFR_bit                     BANKMASK(OSCSTAT), 4
#define OSTS_bit                       BANKMASK(OSCSTAT), 5
#define PLLR_bit                       BANKMASK(OSCSTAT), 6
#define T1OSCR_bit                     BANKMASK(OSCSTAT), 7
#ifndef _LIB_BUILD
#endif
ADRESL                                 equ 009Bh
ADRESH                                 equ 009Ch
ADCON0                                 equ 009Dh
#define ADON_bit                       BANKMASK(ADCON0), 0
#define GO_nDONE_bit                   BANKMASK(ADCON0), 1
#define CHS0_bit                       BANKMASK(ADCON0), 2
#define CHS1_bit                       BANKMASK(ADCON0), 3
#define CHS2_bit                       BANKMASK(ADCON0), 4
#define CHS3_bit                       BANKMASK(ADCON0), 5
#define CHS4_bit                       BANKMASK(ADCON0), 6
#define ADGO_bit                       BANKMASK(ADCON0), 1
#define GO_bit                         BANKMASK(ADCON0), 1
#define nDONE_bit                      BANKMASK(ADCON0), 1
#ifndef _LIB_BUILD
#endif
ADCON1                                 equ 009Eh
#define ADPREF0_bit                    BANKMASK(ADCON1), 0
#define ADPREF1_bit                    BANKMASK(ADCON1), 1
#define ADCS0_bit                      BANKMASK(ADCON1), 4
#define ADCS1_bit                      BANKMASK(ADCON1), 5
#define ADCS2_bit                      BANKMASK(ADCON1), 6
#define ADFM_bit                       BANKMASK(ADCON1), 7
#ifndef _LIB_BUILD
#endif
LATA                                   equ 010Ch
#define LATA0_bit                      BANKMASK(LATA), 0
#define LATA1_bit                      BANKMASK(LATA), 1
#define LATA2_bit                      BANKMASK(LATA), 2
#define LATA4_bit                      BANKMASK(LATA), 4
#define LATA5_bit                      BANKMASK(LATA), 5
#ifndef _LIB_BUILD
#endif
CM1CON0                                equ 0111h
#define C1SYNC_bit                     BANKMASK(CM1CON0), 0
#define C1HYS_bit                      BANKMASK(CM1CON0), 1
#define C1SP_bit                       BANKMASK(CM1CON0), 2
#define C1POL_bit                      BANKMASK(CM1CON0), 4
#define C1OE_bit                       BANKMASK(CM1CON0), 5
#define C1ON_bit                       BANKMASK(CM1CON0), 7
#ifndef _LIB_BUILD
#endif
CM1CON1                                equ 0112h
#define C1NCH0_bit                     BANKMASK(CM1CON1), 0
#define C1PCH0_bit                     BANKMASK(CM1CON1), 4
#define C1PCH1_bit                     BANKMASK(CM1CON1), 5
#define C1INTN_bit                     BANKMASK(CM1CON1), 6
#define C1INTP_bit                     BANKMASK(CM1CON1), 7
#ifndef _LIB_BUILD
#endif
CMOUT                                  equ 0115h
#define MC1OUT_bit                     BANKMASK(CMOUT), 0
#ifndef _LIB_BUILD
#endif
BORCON                                 equ 0116h
#define BORRDY_bit                     BANKMASK(BORCON), 0
#define SBOREN_bit                     BANKMASK(BORCON), 7
#ifndef _LIB_BUILD
#endif
FVRCON                                 equ 0117h
#define ADFVR0_bit                     BANKMASK(FVRCON), 0
#define ADFVR1_bit                     BANKMASK(FVRCON), 1
#define CDAFVR0_bit                    BANKMASK(FVRCON), 2
#define CDAFVR1_bit                    BANKMASK(FVRCON), 3
#define TSRNG_bit                      BANKMASK(FVRCON), 4
#define TSEN_bit                       BANKMASK(FVRCON), 5
#define FVRRDY_bit                     BANKMASK(FVRCON), 6
#define FVREN_bit                      BANKMASK(FVRCON), 7
#ifndef _LIB_BUILD
#endif
DACCON0                                equ 0118h
#define DACPSS0_bit                    BANKMASK(DACCON0), 2
#define DACPSS1_bit                    BANKMASK(DACCON0), 3
#define DACOE_bit                      BANKMASK(DACCON0), 5
#define DACLPS_bit                     BANKMASK(DACCON0), 6
#define DACEN_bit                      BANKMASK(DACCON0), 7
#ifndef _LIB_BUILD
#endif
DACCON1                                equ 0119h
#define DACR0_bit                      BANKMASK(DACCON1), 0
#define DACR1_bit                      BANKMASK(DACCON1), 1
#define DACR2_bit                      BANKMASK(DACCON1), 2
#define DACR3_bit                      BANKMASK(DACCON1), 3
#define DACR4_bit                      BANKMASK(DACCON1), 4
#ifndef _LIB_BUILD
#endif
SRCON0                                 equ 011Ah
#define SRPR_bit                       BANKMASK(SRCON0), 0
#define SRPS_bit                       BANKMASK(SRCON0), 1
#define SRNQEN_bit                     BANKMASK(SRCON0), 2
#define SRQEN_bit                      BANKMASK(SRCON0), 3
#define SRCLK0_bit                     BANKMASK(SRCON0), 4
#define SRCLK1_bit                     BANKMASK(SRCON0), 5
#define SRCLK2_bit                     BANKMASK(SRCON0), 6
#define SRLEN_bit                      BANKMASK(SRCON0), 7
#ifndef _LIB_BUILD
#endif
SRCON1                                 equ 011Bh
#define SRRC1E_bit                     BANKMASK(SRCON1), 0
#define SRRCKE_bit                     BANKMASK(SRCON1), 2
#define SRRPE_bit                      BANKMASK(SRCON1), 3
#define SRSC1E_bit                     BANKMASK(SRCON1), 4
#define SRSCKE_bit                     BANKMASK(SRCON1), 6
#define SRSPE_bit                      BANKMASK(SRCON1), 7
#ifndef _LIB_BUILD
#endif
APFCON                                 equ 011Dh
APFCON0                                equ 011Dh
#define CCP1SEL_bit                    BANKMASK(APFCON), 0
#define P1BSEL_bit                     BANKMASK(APFCON), 1
#define TXCKSEL_bit                    BANKMASK(APFCON), 2
#define T1GSEL_bit                     BANKMASK(APFCON), 3
#define SSSEL_bit                      BANKMASK(APFCON), 5
#define SDOSEL_bit                     BANKMASK(APFCON), 6
#define RXDTSEL_bit                    BANKMASK(APFCON), 7
#define SS1SEL_bit                     BANKMASK(APFCON), 5
#define SDO1SEL_bit                    BANKMASK(APFCON), 6
#ifndef _LIB_BUILD
#endif
ANSELA                                 equ 018Ch
#define ANSA0_bit                      BANKMASK(ANSELA), 0
#define ANSA1_bit                      BANKMASK(ANSELA), 1
#define ANSA2_bit                      BANKMASK(ANSELA), 2
#define ANSA4_bit                      BANKMASK(ANSELA), 4
#ifndef _LIB_BUILD
#endif
EEADRL                                 equ 0191h
EEADRH                                 equ 0192h
#ifndef _LIB_BUILD
#endif
EEDATL                                 equ 0193h
EEDATA                                 equ 0193h
EEDATH                                 equ 0194h
#ifndef _LIB_BUILD
#endif
EECON1                                 equ 0195h
#define RD_bit                         BANKMASK(EECON1), 0
#define WR_bit                         BANKMASK(EECON1), 1
#define WREN_bit                       BANKMASK(EECON1), 2
#define WRERR_bit                      BANKMASK(EECON1), 3
#define FREE_bit                       BANKMASK(EECON1), 4
#define LWLO_bit                       BANKMASK(EECON1), 5
#define CFGS_bit                       BANKMASK(EECON1), 6
#define EEPGD_bit                      BANKMASK(EECON1), 7
#ifndef _LIB_BUILD
#endif
EECON2                                 equ 0196h
RCREG                                  equ 0199h
TXREG                                  equ 019Ah
SPBRGL                                 equ 019Bh
SPBRG                                  equ 019Bh
SPBRGH                                 equ 019Ch
RCSTA                                  equ 019Dh
#define RX9D_bit                       BANKMASK(RCSTA), 0
#define OERR_bit                       BANKMASK(RCSTA), 1
#define FERR_bit                       BANKMASK(RCSTA), 2
#define ADDEN_bit                      BANKMASK(RCSTA), 3
#define CREN_bit                       BANKMASK(RCSTA), 4
#define SREN_bit                       BANKMASK(RCSTA), 5
#define RX9_bit                        BANKMASK(RCSTA), 6
#define SPEN_bit                       BANKMASK(RCSTA), 7
#ifndef _LIB_BUILD
#endif
TXSTA                                  equ 019Eh
#define TX9D_bit                       BANKMASK(TXSTA), 0
#define TRMT_bit                       BANKMASK(TXSTA), 1
#define BRGH_bit                       BANKMASK(TXSTA), 2
#define SENDB_bit                      BANKMASK(TXSTA), 3
#define SYNC_bit                       BANKMASK(TXSTA), 4
#define TXEN_bit                       BANKMASK(TXSTA), 5
#define TX9_bit                        BANKMASK(TXSTA), 6
#define CSRC_bit                       BANKMASK(TXSTA), 7
#ifndef _LIB_BUILD
#endif
BAUDCON                                equ 019Fh
#define ABDEN_bit                      BANKMASK(BAUDCON), 0
#define WUE_bit                        BANKMASK(BAUDCON), 1
#define BRG16_bit                      BANKMASK(BAUDCON), 3
#define SCKP_bit                       BANKMASK(BAUDCON), 4
#define RCIDL_bit                      BANKMASK(BAUDCON), 6
#define ABDOVF_bit                     BANKMASK(BAUDCON), 7
#ifndef _LIB_BUILD
#endif
WPUA                                   equ 020Ch
#define WPUA0_bit                      BANKMASK(WPUA), 0
#define WPUA1_bit                      BANKMASK(WPUA), 1
#define WPUA2_bit                      BANKMASK(WPUA), 2
#define WPUA3_bit                      BANKMASK(WPUA), 3
#define WPUA4_bit                      BANKMASK(WPUA), 4
#define WPUA5_bit                      BANKMASK(WPUA), 5
#ifndef _LIB_BUILD
#endif
SSP1BUF                                equ 0211h
SSPBUF                                 equ 0211h
SSP1ADD                                equ 0212h
SSPADD                                 equ 0212h
SSP1MSK                                equ 0213h
SSPMSK                                 equ 0213h
SSP1STAT                               equ 0214h
SSPSTAT                                equ 0214h
#define BF_bit                         BANKMASK(SSP1STAT), 0
#define UA_bit                         BANKMASK(SSP1STAT), 1
#define R_nW_bit                       BANKMASK(SSP1STAT), 2
#define S_bit                          BANKMASK(SSP1STAT), 3
#define P_bit                          BANKMASK(SSP1STAT), 4
#define D_nA_bit                       BANKMASK(SSP1STAT), 5
#define CKE_bit                        BANKMASK(SSP1STAT), 6
#define SMP_bit                        BANKMASK(SSP1STAT), 7
#ifndef _LIB_BUILD
#endif
SSP1CON1                               equ 0215h
SSPCON1                                equ 0215h
SSPCON                                 equ 0215h
#define SSPM0_bit                      BANKMASK(SSP1CON1), 0
#define SSPM1_bit                      BANKMASK(SSP1CON1), 1
#define SSPM2_bit                      BANKMASK(SSP1CON1), 2
#define SSPM3_bit                      BANKMASK(SSP1CON1), 3
#define CKP_bit                        BANKMASK(SSP1CON1), 4
#define SSPEN_bit                      BANKMASK(SSP1CON1), 5
#define SSPOV_bit                      BANKMASK(SSP1CON1), 6
#define WCOL_bit                       BANKMASK(SSP1CON1), 7
#ifndef _LIB_BUILD
#endif
SSP1CON2                               equ 0216h
SSPCON2                                equ 0216h
#define SEN_bit                        BANKMASK(SSP1CON2), 0
#define RSEN_bit                       BANKMASK(SSP1CON2), 1
#define PEN_bit                        BANKMASK(SSP1CON2), 2
#define RCEN_bit                       BANKMASK(SSP1CON2), 3
#define ACKEN_bit                      BANKMASK(SSP1CON2), 4
#define ACKDT_bit                      BANKMASK(SSP1CON2), 5
#define ACKSTAT_bit                    BANKMASK(SSP1CON2), 6
#define GCEN_bit                       BANKMASK(SSP1CON2), 7
#ifndef _LIB_BUILD
#endif
SSP1CON3                               equ 0217h
SSPCON3                                equ 0217h
#define DHEN_bit                       BANKMASK(SSP1CON3), 0
#define AHEN_bit                       BANKMASK(SSP1CON3), 1
#define SBCDE_bit                      BANKMASK(SSP1CON3), 2
#define SDAHT_bit                      BANKMASK(SSP1CON3), 3
#define BOEN_bit                       BANKMASK(SSP1CON3), 4
#define SCIE_bit                       BANKMASK(SSP1CON3), 5
#define PCIE_bit                       BANKMASK(SSP1CON3), 6
#define ACKTIM_bit                     BANKMASK(SSP1CON3), 7
#ifndef _LIB_BUILD
#endif
CCPR1L                                 equ 0291h
CCPR1H                                 equ 0292h
CCP1CON                                equ 0293h
#define CCP1M0_bit                     BANKMASK(CCP1CON), 0
#define CCP1M1_bit                     BANKMASK(CCP1CON), 1
#define CCP1M2_bit                     BANKMASK(CCP1CON), 2
#define CCP1M3_bit                     BANKMASK(CCP1CON), 3
#define DC1B0_bit                      BANKMASK(CCP1CON), 4
#define DC1B1_bit                      BANKMASK(CCP1CON), 5
#define P1M0_bit                       BANKMASK(CCP1CON), 6
#define P1M1_bit                       BANKMASK(CCP1CON), 7
#ifndef _LIB_BUILD
#endif
PWM1CON                                equ 0294h
#define P1DC0_bit                      BANKMASK(PWM1CON), 0
#define P1DC1_bit                      BANKMASK(PWM1CON), 1
#define P1DC2_bit                      BANKMASK(PWM1CON), 2
#define P1DC3_bit                      BANKMASK(PWM1CON), 3
#define P1DC4_bit                      BANKMASK(PWM1CON), 4
#define P1DC5_bit                      BANKMASK(PWM1CON), 5
#define P1DC6_bit                      BANKMASK(PWM1CON), 6
#define P1RSEN_bit                     BANKMASK(PWM1CON), 7
#ifndef _LIB_BUILD
#endif
CCP1AS                                 equ 0295h
ECCP1AS                                equ 0295h
#define PSS1BD0_bit                    BANKMASK(CCP1AS), 0
#define PSS1BD1_bit                    BANKMASK(CCP1AS), 1
#define PSS1AC0_bit                    BANKMASK(CCP1AS), 2
#define PSS1AC1_bit                    BANKMASK(CCP1AS), 3
#define CCP1AS0_bit                    BANKMASK(CCP1AS), 4
#define CCP1AS1_bit                    BANKMASK(CCP1AS), 5
#define CCP1AS2_bit                    BANKMASK(CCP1AS), 6
#define CCP1ASE_bit                    BANKMASK(CCP1AS), 7
#ifndef _LIB_BUILD
#endif
PSTR1CON                               equ 0296h
#define STR1A_bit                      BANKMASK(PSTR1CON), 0
#define STR1B_bit                      BANKMASK(PSTR1CON), 1
#define STR1C_bit                      BANKMASK(PSTR1CON), 2
#define STR1D_bit                      BANKMASK(PSTR1CON), 3
#define STR1SYNC_bit                   BANKMASK(PSTR1CON), 4
#ifndef _LIB_BUILD
#endif
IOCAP                                  equ 0391h
#define IOCAP0_bit                     BANKMASK(IOCAP), 0
#define IOCAP1_bit                     BANKMASK(IOCAP), 1
#define IOCAP2_bit                     BANKMASK(IOCAP), 2
#define IOCAP3_bit                     BANKMASK(IOCAP), 3
#define IOCAP4_bit                     BANKMASK(IOCAP), 4
#define IOCAP5_bit                     BANKMASK(IOCAP), 5
#ifndef _LIB_BUILD
#endif
IOCAN                                  equ 0392h
#define IOCAN0_bit                     BANKMASK(IOCAN), 0
#define IOCAN1_bit                     BANKMASK(IOCAN), 1
#define IOCAN2_bit                     BANKMASK(IOCAN), 2
#define IOCAN3_bit                     BANKMASK(IOCAN), 3
#define IOCAN4_bit                     BANKMASK(IOCAN), 4
#define IOCAN5_bit                     BANKMASK(IOCAN), 5
#ifndef _LIB_BUILD
#endif
IOCAF                                  equ 0393h
#define IOCAF0_bit                     BANKMASK(IOCAF), 0
#define IOCAF1_bit                     BANKMASK(IOCAF), 1
#define IOCAF2_bit                     BANKMASK(IOCAF), 2
#define IOCAF3_bit                     BANKMASK(IOCAF), 3
#define IOCAF4_bit                     BANKMASK(IOCAF), 4
#define IOCAF5_bit                     BANKMASK(IOCAF), 5
#ifndef _LIB_BUILD
#endif
CLKRCON                                equ 039Ah
#define CLKRDIV0_bit                   BANKMASK(CLKRCON), 0
#define CLKRDIV1_bit                   BANKMASK(CLKRCON), 1
#define CLKRDIV2_bit                   BANKMASK(CLKRCON), 2
#define CLKRDC0_bit                    BANKMASK(CLKRCON), 3
#define CLKRDC1_bit                    BANKMASK(CLKRCON), 4
#define CLKRSLR_bit                    BANKMASK(CLKRCON), 5
#define CLKROE_bit                     BANKMASK(CLKRCON), 6
#define CLKREN_bit                     BANKMASK(CLKRCON), 7
#ifndef _LIB_BUILD
#endif
MDCON                                  equ 039Ch
#define MDBIT_bit                      BANKMASK(MDCON), 0
#define MDOPOL_bit                     BANKMASK(MDCON), 4
#define MDSLR_bit                      BANKMASK(MDCON), 5
#define MDOE_bit                       BANKMASK(MDCON), 6
#define MDEN_bit                       BANKMASK(MDCON), 7
#ifndef _LIB_BUILD
#endif
MDSRC                                  equ 039Dh
#define MDMS0_bit                      BANKMASK(MDSRC), 0
#define MDMS1_bit                      BANKMASK(MDSRC), 1
#define MDMS2_bit                      BANKMASK(MDSRC), 2
#define MDMS3_bit                      BANKMASK(MDSRC), 3
#define MDMSODIS_bit                   BANKMASK(MDSRC), 7
#ifndef _LIB_BUILD
#endif
MDCARL                                 equ 039Eh
#define MDCL0_bit                      BANKMASK(MDCARL), 0
#define MDCL1_bit                      BANKMASK(MDCARL), 1
#define MDCL2_bit                      BANKMASK(MDCARL), 2
#define MDCL3_bit                      BANKMASK(MDCARL), 3
#define MDCLSYNC_bit                   BANKMASK(MDCARL), 5
#define MDCLPOL_bit                    BANKMASK(MDCARL), 6
#define MDCLODIS_bit                   BANKMASK(MDCARL), 7
#ifndef _LIB_BUILD
#endif
MDCARH                                 equ 039Fh
#define MDCH0_bit                      BANKMASK(MDCARH), 0
#define MDCH1_bit                      BANKMASK(MDCARH), 1
#define MDCH2_bit                      BANKMASK(MDCARH), 2
#define MDCH3_bit                      BANKMASK(MDCARH), 3
#define MDCHSYNC_bit                   BANKMASK(MDCARH), 5
#define MDCHPOL_bit                    BANKMASK(MDCARH), 6
#define MDCHODIS_bit                   BANKMASK(MDCARH), 7
#ifndef _LIB_BUILD
#endif
STATUS_SHAD                            equ 0FE4h
#define C_SHAD_bit                     BANKMASK(STATUS_SHAD), 0
#define DC_SHAD_bit                    BANKMASK(STATUS_SHAD), 1
#define Z_SHAD_bit                     BANKMASK(STATUS_SHAD), 2
#ifndef _LIB_BUILD
#endif
WREG_SHAD                              equ 0FE5h
BSR_SHAD                               equ 0FE6h
#ifndef _LIB_BUILD
#endif
PCLATH_SHAD                            equ 0FE7h
#ifndef _LIB_BUILD
#endif
FSR0L_SHAD                             equ 0FE8h
FSR0H_SHAD                             equ 0FE9h
FSR1L_SHAD                             equ 0FEAh
FSR1H_SHAD                             equ 0FEBh
STKPTR                                 equ 0FEDh
#ifndef _LIB_BUILD
#endif
TOSL                                   equ 0FEEh
TOSH                                   equ 0FEFh
#ifndef _LIB_BUILD
#endif

#endif
#endif

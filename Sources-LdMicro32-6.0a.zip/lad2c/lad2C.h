//-----------------------------------------------------------------------------
// Copyright 2021 Jos� GILLES
//
// This file is part of LDmicro32.
//
// LDmicro32 is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// LDmicro32 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

#include <stdio.h>
#include <conio.h>
#include <string.h>

#include <iostream >
#include <windows.h>


#include "common.h"


int str_find(char * chaine, char * maillon);
int str_back(char * chaine, char chr);
int str_begin(char * str, char * beg);
int str_equal(char * str1, char * str2);
void fputabs(FILE * f, int n);
void lad2c_error(String s);
void lad2c_warning(String s);
bool CheckSaveUserCancels();

void readtLdConfig(FILE * ldfile);
int readLdInfo(FILE * f, int mode);
int readtLdVarlist(FILE * ldfile, int mode);
int convertLadder(char * fname, char * pname, char * hname, int mcuisa, int mode);
int configTimer(int mcuisa, char * hname);
int createCProg(char * pname, char * hname, int mcuisa);
int Lad2C(char * ldname, char * progname, char * headname);		// Declaration is duplicated in ldmicro.h

int getVarfromList(char * vname);
int getIOfromList(char * ioname);
int getInfofromMcu(int Mcu, char * info, char * response);
unsigned short getPortfromPin(char * mcu, int pin);
void createVarforParam(char * s, char * type, int state);
int searchContact(char * fname, char * str);

int EnableContacts(char * contype);
int Configure_Reset(int mcuisa, FILE * ffuncdef);
int Configure_Adc(int mcuisa, char * ioname, char * refs, FILE * fhead, FILE * ffuncdef, FILE * finit, char * lptr);
int Configure_Pwm(int mcuisa, char * ioname, long freq, FILE * fhead, FILE * ffuncdef, FILE * finit, char * lptr);
int Configure_Uart(int mcuisa, long bauds, FILE * fhead, FILE * ffuncdef, FILE * finit, char * lptr);
int Configure_I2c(int mcuisa, char * i2cname, long speed, FILE * fhead, FILE * ffuncdef, FILE * finit, char * lptr);
int Configure_Spi(int mcuisa, char * spiname, long rate, FILE * fhead, FILE * ffuncdef, FILE * finit, char * lptr);

void Push(char c);
char Pop(void);
char Pop_Push(void);


typedef struct GlobalVar
	{
	int varsize;
	String vartype;
	String varname;
	}
GlobalVar;


typedef struct GlobalIO
	{
	int iopin;				// Keep int
	String ioname;
	}
GlobalIO;



#define MakeCharVariable(name) \
	{	\
	int i= getVarfromList(name);	\
	if ((i >= 0) && (VarStat[i] == 0))	\
		{	\
		VarStat[i]= 1;	\
		fprintf(fvardef, "char %s= 0;\n", name);	\
		if (! str_equal(VarList[i].vartype, "char"))	\
			{	\
			sprintf(errormsg, "Variable <%s> converted to char", name);	\
			lad2c_warning(errormsg);	\
			strcpy(VarList[i].vartype, "char");	\
			VarList[i].varsize= 1;	\
			}	\
		}	\
	if (i == -1)	\
		{	\
		createVarforParam(name, "char");	\
		fprintf(fvardef, "char %s= 0;\n", name);	\
		}	\
	}	\

#define MakeShortVariable(name) \
	{	\
	int i= getVarfromList(name);	\
	if ((i >= 0) && (VarStat[i] == 0))	\
		{	\
		VarStat[i]= 1;	\
		fprintf(fvardef, "short %s= 0;\n", name);	\
		if (! str_equal(VarList[i].vartype, "short"))	\
			{	\
			sprintf(errormsg, "Variable <%s> converted to short", name);	\
			lad2c_warning(errormsg);	\
			strcpy(VarList[i].vartype, "short");	\
			VarList[i].varsize= 2;	\
			}	\
		}	\
	if (i == -1)	\
		{	\
		createVarforParam(name, "short");	\
		fprintf(fvardef, "short %s= 0;\n", name);	\
		}	\
	}	\

#define MakeMediumVariable(name) \
	{	\
	int i= getVarfromList(name);	\
	if ((i >= 0) && (VarStat[i] == 0))	\
		{	\
		VarStat[i]= 1;	\
		fprintf(fvardef, "long %s= 0;\n", name);	\
		if (! str_equal(VarList[i].vartype, "medium"))	\
			{	\
			sprintf(errormsg, "Variable <%s> converted to medium", name);	\
			lad2c_warning(errormsg);	\
			strcpy(VarList[i].vartype, "medium");	\
			VarList[i].varsize= 3;	\
			}	\
		}	\
	if (i == -1)	\
		{	\
		createVarforParam(name, "medium");	\
		fprintf(fvardef, "long %s= 0;\n", name);	\
		}	\
	}	\

#define MakeLongVariable(name) \
	{	\
	int i= getVarfromList(name);	\
	if ((i >= 0) && (VarStat[i] == 0))	\
		{	\
		VarStat[i]= 1;	\
		fprintf(fvardef, "long %s= 0;\n", name);	\
		if (! str_equal(VarList[i].vartype, "long"))	\
			{	\
			sprintf(errormsg, "Variable <%s> converted to long", name);	\
			lad2c_warning(errormsg);	\
			strcpy(VarList[i].vartype, "long");	\
			VarList[i].varsize= 4;	\
			}	\
		}	\
	if (i == -1)	\
		{	\
		createVarforParam(name, "long");	\
		fprintf(fvardef, "long %s= 0;\n", name);	\
		}	\
	}	\

#define MakeIntegerVariable(name) \
	{	\
	int i= getVarfromList(name);	\
	if ((i >= 0) && (VarStat[i] == 0))	\
		{	\
		VarStat[i]= 1;	\
		fprintf(fvardef, "integer %s= 0;\n", name);	\
		if ((str_equal(VarList[i].vartype, "char")) || (str_equal(VarList[i].vartype, "medium")))	\
			{ \
			sprintf(errormsg, "Variable <%s> converted to integer", name); \
			lad2c_warning(errormsg); \
			} \
		strcpy(VarList[i].vartype, "integer"); \
		VarList[i].varsize= 4; \
		}	\
	if (i == -1)	\
		{	\
		createVarforParam(name, "integer");	\
		fprintf(fvardef, "integer %s= 0;\n", name);	\
		}	\
	}	\

#define DefineVariable(name) \
	{	\
	fprintf(fhead, "#define %s %s\n\n", name, name+1);	\
	}	\
	 


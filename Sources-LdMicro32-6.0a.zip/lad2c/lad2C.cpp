//-----------------------------------------------------------------------------
// Copyright 2021 Jos� GILLES
//
// This file is part of LDmicro32.
//
// LDmicro32 is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// LDmicro32 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

#include "ldmicro.h"

#include "lad2c.h"

#include <direct.h>

using namespace std;

extern char ExePath[];
extern char CurrentLdPath[];

static String Version= "", Micro= "", Compiler= "";
static unsigned long Crystal= 0, Cycle= 0, Baud= 0, Rate= 0, Speed= 0, CfgWords= 0;
static int Mcu= 0, Timer= 0, Duty= 0;

#define MAX_PORTS	16			// Should be equal or less than MAX_IO_PORTS (cf ldconfig.h)
int Port_inp[MAX_PORTS];
int Port_out[MAX_PORTS];
int Port_pup[MAX_PORTS];

static int NbVars= 0;
GlobalVar * VarList;
static int * VarStat;			// 0= not created, 1= created as variable or relay, 2= created as coil, 3= created as relay & Coil

static int * IOStat;			// 0= not created, 1= created
static int NbIOs= 0;
GlobalIO * IOList;

static int NbRung= 0;
static int NbPara= 0;

static char * piletab;			// Stack to allocate for Parallel branches
static int pileptr= 0;

static char errormsg[200]= "";

int InternalException= 0;

#define MAX_ADC_C 256
int ADC_USED= 0; 
int ADC_Used[MAX_ADC_C];		// used ADC #

#define MAX_PWM_C 256
int PWM_USED= 0; 
int PWM_Used[MAX_PWM_C];		// used PWM #

int UART_USED= 0;
int I2C_USED= 0;
int SPI_USED= 0;

int RST_USED= 0;

int TEMPO_USED= 0;
int OSC_USED= 0;
int COUNT_USED= 0;
int TIME_USED= 0;
int QUADENCOD_USED= 0;
int PULSE_USED= 0;
int STEP_USED= 0;
int STRING_USED= 0;
int SHIFTREG_USED= 0;
int PLTAB_USED= 0;
int LUTAB_USED= 0;
int PERSIST_USED= 0;
int MODBUS_USED= 0;
int BITOPS_USED= 0;
int BCDOPS_USED= 0;
int DISPLAY_USED= 0;

int LONG_USED= 0;


// Reads Global config in ld file
void readLdConfig(FILE * f)
	{
	Line line;

	while (fgets(line, sizeof(line)-1, f) != NULL)
		{
		int len= strlen(line);
		if (len == 0) continue;

		while ((line[len-1] == '\r') || (line[len-1] == '\n') || (line[len-1] == '\t') || (line[len-1] == ' '))
			{
			line[len-1]= NUL;
			len--;
			}

		if (len == 0) break;						// Empty line before other fields

		if (str_begin(line, "LDmicro"))
			strcpy(Version, line+7);

		if (str_begin(line, "MICRO="))
			{
			strcpy(Micro, line+6);

			if (str_equal(Micro, "St ARM STM32F40X 144-LQFP")) Mcu= STM32F40X_LQFP_144;
			if (str_equal(Micro, "St ARM STM32F10X 48-LQFP / Bluepill")) Mcu= STM32F10X_LQFP_48;

			if (str_equal(Micro, "Atmel AVR AT90USB647 64-TQFP")) Mcu= AT90USB647_TQFP_64;
			if (str_equal(Micro, "Atmel AVR ATmega8 28-PDIP")) Mcu= ATMEGA8_PDIP_28;
			if (str_equal(Micro, "Atmel AVR ATmega8 32-Pin packages")) Mcu= ATMEGA8_TQFP_32;
			if (str_equal(Micro, "Atmel AVR ATmega16 40-PDIP")) Mcu= ATMEGA16_PDIP_40;
			if (str_equal(Micro, "Atmel AVR ATmega16 44-Pin packages")) Mcu= ATMEGA16_TQFP_44;
			if (str_equal(Micro, "Atmel AVR ATmega16U4 44-Pin packages")) Mcu= ATMEGA16U4_TQFP_44;
			if (str_equal(Micro, "Atmel AVR ATmega32 40-PDIP")) Mcu= ATMEGA32_PDIP_40;
			if (str_equal(Micro, "Atmel AVR ATmega32 44-Pin packages")) Mcu= ATMEGA32_TQFP_44;
			if (str_equal(Micro, "Atmel AVR ATmega32U4 44-Pin packages")) Mcu= ATMEGA32U4_TQFP_44;
			if (str_equal(Micro, "Atmel AVR ATmega48 28-PDIP")) Mcu= ATMEGA48_PDIP_28;
			if (str_equal(Micro, "Atmel AVR ATmega64 64-TQFP")) Mcu= ATMEGA64_TQFP_64;
			if (str_equal(Micro, "Atmel AVR ATmega88 28-PDIP")) Mcu= ATMEGA88_PDIP_28;
			if (str_equal(Micro, "Atmel AVR ATmega128 64-TQFP")) Mcu= ATMEGA128_TQFT_64;	
			if (str_equal(Micro, "Atmel AVR ATmega162 40-PDIP")) Mcu= ATMEGA162_PDIP_40;
			if (str_equal(Micro, "Atmel AVR ATmega164 40-PDIP")) Mcu= ATMEGA164_PDIP_40;
			if (str_equal(Micro, "Atmel AVR ATmega168 28-PDIP")) Mcu= ATMEGA168_PDIP_28;
			if (str_equal(Micro, "Atmel AVR ATmega324 40-PDIP")) Mcu= ATMEGA324_PDIP_40;
			if (str_equal(Micro, "Atmel AVR ATmega328 28-PDIP")) Mcu= ATMEGA328_PDIP_28;
			if (str_equal(Micro, "Atmel AVR ATmega328 32-Pin packages")) Mcu= ATMEGA328_TQFP_32;
			if (str_equal(Micro, "Atmel AVR ATmega640 100-TQFP")) Mcu= ATMEGA640_TQFP_100;
			if (str_equal(Micro, "Atmel AVR ATmega644 40-PDIP")) Mcu= ATMEGA644_PDIP_40;
			if (str_equal(Micro, "Atmel AVR ATmega1280 100-TQFP")) Mcu= ATMEGA1280_TQFP_100;
			if (str_equal(Micro, "Atmel AVR ATmega1284 40-PDIP")) Mcu= ATMEGA1284_PDIP_40;
			if (str_equal(Micro, "Atmel AVR ATmega2560 100-TQFP")) Mcu= ATMEGA2560_TQFP_100;
			if (str_equal(Micro, "Atmel AVR ATtiny10 6-Pin packages")) Mcu= ATTINY10_SOT_6;
			if (str_equal(Micro, "Atmel AVR ATtiny85 8-Pin packages")) Mcu= ATTINY85_PDIP_8;
			if (str_equal(Micro, "Atmel AVR ATtiny85 20-Pin packages")) Mcu= ATTINY85_QFN_20;

			if (str_equal(Micro, "Microchip PIC16F72 28-Pin PDIP, SOIC, SSOP")) Mcu= PIC16F72_PDIP_28;
			if (str_equal(Micro, "Microchip PIC16F88 18-PDIP or 18-SOIC")) Mcu= PIC16F88_PDIP_18;
			if (str_equal(Micro, "Microchip PIC16F628 18-PDIP or 18-SOIC")) Mcu= PIC16F628PDIP_18;
			if (str_equal(Micro, "Microchip PIC16F819 18-PDIP or 18-SOIC")) Mcu= PIC16F819PDIP_18;
			if (str_equal(Micro, "Microchip PIC16F876 28-PDIP or 28-SOIC")) Mcu= PIC16F876_PDIP_28;
			if (str_equal(Micro, "Microchip PIC16F877 40-PDIP")) Mcu= PIC16F877_PDIP_40;
			if (str_equal(Micro, "Microchip PIC16F886 28-PDIP or 28-SOIC")) Mcu= PIC16F886_PDIP_28;
			if (str_equal(Micro, "Microchip PIC16F887 40-PDIP")) Mcu= PIC16F887_PDIP_40;
			if (str_equal(Micro, "Microchip PIC16F887 44-TQFP")) Mcu= PIC16F887_TQFP_44;
			if (str_equal(Micro, "Microchip PIC16F1512 28-Pin SPDIP, SOIC, SSOP"));
			if (str_equal(Micro, "Microchip PIC16F1516 28-Pin SPDIP, SOIC, SSOP")) Mcu= PIC16F1516_PDIP_28;
			if (str_equal(Micro, "Microchip PIC16F1527 64-Pin packages")) Mcu= PIC16F1527_TQF_64;	
			if (str_equal(Micro, "Microchip PIC16F1824 14-Pin PDIP, SOIC, TSSOP")) Mcu= PIC16F1824_PDIP_14;
			if (str_equal(Micro, "Microchip PIC16F1827 18-Pin PDIP, SOIC")) Mcu= PIC16F1827_PDIP_28;

			if (str_equal(Micro, "Microchip PIC18F458 40-PDIP")) Mcu= PIC18F458_PDIP_40;
			if (str_equal(Micro, "Microchip PIC18F4520 40-PDIP")) Mcu= PIC18F4520_PDIP_40;
			if (str_equal(Micro, "Microchip PIC18F4550 40-PDIP")) Mcu= PIC18F4550_PDIP_40;
			}

		if (str_begin(line, "COMPILER="))
			strcpy(Compiler, line+9);

		if (str_begin(line, "CRYSTAL="))			// Max 2 GHz
			Crystal= atol(line+8);

		if (str_begin(line, "CYCLE="))
			{
			Cycle= atol(line+6);				// Cycle time in �s

			int p= str_find(line, "Timer");
			if (p != -1) Timer= atoi(line+p+5);
			else Timer= 0;

			p= str_find(line, "YPlcCycleDuty:");
			if (p != -1) Duty= atoi(line+p+14);
			else Duty= 0;

			p= str_find(line, "ConfigurationWord(s):");
			if (p != -1) sscanf(line+p+14, "%lX", &CfgWords);
			else CfgWords= 0;
			}

		if (str_begin(line, "BAUD="))
			{
			Baud= atol(line+5);				// UART Baud rate (Hz)

			int p= str_find(line, "RATE=");
			if (p != -1) Rate= atoi(line+p+5);		// SPI rate (Hz)
			else Rate= 0;

			p= str_find(line, "SPEED=");
			if (p != -1) Speed= atoi(line+p+6);		// I2C rate (Hz)
			else Speed= 0;
			}
		}

	printf("Version=%s\n", Version);
	printf("Micro=%s\n", Micro);
	printf("Cycle=%lu us at Timer%d, Duty:%d, CgfWords:0x%lX\n", Cycle, Timer, Duty, CfgWords);
	printf("Crystal=%lu Hz\n", Crystal);
	printf("Baud=%lu Hz, Rate=%lu Hz, Speed=%lu Hz\n", Baud, Rate, Speed);
	printf("Compiler=%s\n", Compiler);
	puts("");
	}


// Reads Var list in ld file
// Creates Global variables (if mode > 0)
// Returns number of variables
int readLdVarlist(FILE * f, int mode)
	{
	Line line;
	char * lineptr= line;
	String vname= "", s= "";
	int found= 0;
	int nbvars= 0;
	long p= 0;

	LONG_USED= 0;

	while (fgets(line, sizeof(line)-1, f) != NULL)
		{
		int len= strlen(line);
		if (len == 0) continue;

		// remove useless chars at end
		while ((line[len-1] == '\r') || (line[len-1] == '\n') || (line[len-1] == '\t') || (line[len-1] == ' '))
			{
			line[len-1]= NUL;
			len--;
			}

		// remove useless chars at beginning
		lineptr= line;
		while ((lineptr[0] == '\t') || (lineptr[0] == ' '))
			{
			lineptr++;
			}

		if (str_equal(lineptr, "VAR LIST"))						// Begin of Var List
			{
			found= 1;
			if (mode > 0) printf("Variable list:\n");
			continue;
			}
	
		if ((found == 1) && (str_equal(lineptr, "END")))			// End of Var List
			{
			found= 0;
			continue;
			}

		if (str_equal(lineptr, "PROGRAM"))						// Begin of Program
			{
			found= 2;
			if (mode > 0) printf("Extra variables:\n");
			continue;
			}

		if (found == 1)				// Var List
			{
			if (mode > 0)
				{
				// if (str_find(lineptr, "!") != -1) continue;		// Unused variable ??? => Not reliable

				sscanf(lineptr, "%d bytes %s", &VarList[nbvars].varsize, VarList[nbvars].varname);
				VarStat[nbvars]= 0;

				// Ldmicro variables can be 1, 2, 3 or 4 bytes long
				if (VarList[nbvars].varsize == 1) strcpy(VarList[nbvars].vartype, "char");
				else if (VarList[nbvars].varsize == 2) strcpy(VarList[nbvars].vartype, "short");
				else if (VarList[nbvars].varsize == 3) 
					{
					strcpy(VarList[nbvars].vartype, "medium");
					LONG_USED= 1;
					}					
				else if (VarList[nbvars].varsize == 4)
					{
					strcpy(VarList[nbvars].vartype, "long");
					LONG_USED= 1;
					}
				else strcpy(VarList[nbvars].vartype, "byte[]");	

				printf("\t%d bytes (%s) %s\n", VarList[nbvars].varsize, VarList[nbvars].vartype, VarList[nbvars].varname);
				}

			nbvars++;					// Count number of variables
			}

		if (found == 2)				// Extra Variables for R-Relays, R-Coils and other Contacts
			{
			if ((str_begin(lineptr, "CONTACTS ")) || (str_begin(lineptr, "COIL ")))
				{
				if (mode > 0)
					{
					sscanf(lineptr, "%s %s", vname, vname);
					if (getVarfromList(vname) == -1)		// variable does not exist yet
						{
						strcpy(VarList[nbvars].varname, vname);
						VarList[nbvars].varsize= 1;
						strcpy(VarList[nbvars].vartype, "char");
						VarStat[nbvars]= 0;

						printf("\t%d bytes (%s) %s\n", VarList[nbvars].varsize, VarList[nbvars].vartype, VarList[nbvars].varname);
						}
					else				// don't store the same variable twice
						{
						nbvars--;
						}
					}

				nbvars++;				
				}

			if (mode == 0)
				{
				if (str_begin(lineptr, "TON ")) nbvars+= 2;		// Contacts may require Param variables
				if (str_begin(lineptr, "TOF ")) nbvars+= 2;
				if (str_equal(lineptr, "OSR")) nbvars+= 0;
				if (str_equal(lineptr, "OSF")) nbvars+= 0;
				if (str_equal(lineptr, "OSL")) nbvars+= 0;
				if (str_equal(lineptr, "OSC")) nbvars+= 0;

				if (str_begin(lineptr, "CTU ")) nbvars+= 3;
				if (str_begin(lineptr, "CTD ")) nbvars+= 3;
				if (str_begin(lineptr, "CTC ")) nbvars+= 3;

				if (str_begin(lineptr, "THI ")) nbvars+= 2;
				if (str_begin(lineptr, "TLO ")) nbvars+= 2;
				if (str_begin(lineptr, "RTO ")) nbvars+= 2;
				if (str_begin(lineptr, "RTL ")) nbvars+= 2;
				if (str_begin(lineptr, "TCY ")) nbvars+= 2;
				if (str_begin(lineptr, "TIME2COUNT ")) nbvars+= 2;

				if (str_begin(lineptr, "RES ")) nbvars+= 0;

				if (str_begin(lineptr, "EQU ")) nbvars+= 2;
				if (str_begin(lineptr, "NEQ ")) nbvars+= 2;
				if (str_begin(lineptr, "GRT ")) nbvars+= 2;
				if (str_begin(lineptr, "GEQ ")) nbvars+= 2;
				if (str_begin(lineptr, "LES ")) nbvars+= 2;
				if (str_begin(lineptr, "LEQ ")) nbvars+= 2;
				if (str_begin(lineptr, "IS_BIT_SET ")) nbvars+= 2;
				if (str_begin(lineptr, "IS_BIT_CLEAR ")) nbvars+= 2;

				if (str_begin(lineptr, "MOVE ")) nbvars+= 2;
				if (str_begin(lineptr, "NEG ")) nbvars+= 2;
				if (str_begin(lineptr, "NOT ")) nbvars+= 2;

				if (str_begin(lineptr, "ADD ")) nbvars+= 3;
				if (str_begin(lineptr, "SUB ")) nbvars+= 3;
				if (str_begin(lineptr, "MUL ")) nbvars+= 3;
				if (str_begin(lineptr, "DIV ")) nbvars+= 3;
				if (str_begin(lineptr, "MOD ")) nbvars+= 3;

				if (str_begin(lineptr, "AND ")) nbvars+= 3;
				if (str_begin(lineptr, "OR ")) nbvars+= 3;
				if (str_begin(lineptr, "XOR ")) nbvars+= 3;
				if (str_begin(lineptr, "SHL ")) nbvars+= 3;
				if (str_begin(lineptr, "SHR ")) nbvars+= 3;
				if (str_begin(lineptr, "SR0 ")) nbvars+= 3;
				if (str_begin(lineptr, "ROL ")) nbvars+= 3;
				if (str_begin(lineptr, "ROR ")) nbvars+= 3;

				if (str_begin(lineptr, "SET_BIT ")) nbvars+= 2;
				if (str_begin(lineptr, "CLEAR_BIT ")) nbvars+= 2;
				if (str_begin(lineptr, "OPPOSITE ")) nbvars+= 2;
				if (str_begin(lineptr, "SWAP ")) nbvars+= 2;

				if (str_begin(lineptr, "RANDOM ")) nbvars+= 1;
				if (str_begin(lineptr, "SEED_RANDOM ")) nbvars+= 1;

				if (str_begin(lineptr, "DELAY ")) nbvars+= 1;
				if (str_begin(lineptr, "PERSIST ")) nbvars+= 2;
				if (str_begin(lineptr, "QUAD_ENCOD ")) nbvars+= 10;
				if (str_begin(lineptr, "PULSER ")) nbvars+= 10;
				if (str_begin(lineptr, "STEPPER ")) nbvars+= 10;

				if (str_begin(lineptr, "SHIFT_REGISTER "))
					{
					sscanf(lineptr, "SHIFT_REGISTER %s %ld", s, &p);
					nbvars+= p;
					}

				if (str_begin(lineptr, "STRING")) nbvars+= 4;

				if (str_begin(lineptr, "PIECEWISE_LINEAR ")) nbvars+= 2;
				if (str_begin(lineptr, "LOOK_UP_TABLE ")) nbvars+= 3;

				if (str_begin(lineptr, "MODBUS ")) nbvars+= 2;

				if (str_begin(lineptr, "7SEGMENTS ")) nbvars+= 2;
				if (str_begin(lineptr, "9SEGMENTS ")) nbvars+= 2;				
				if (str_begin(lineptr, "14SEGMENTS ")) nbvars+= 2;		
				if (str_begin(lineptr, "16SEGMENTS ")) nbvars+= 2;

				if (str_begin(lineptr, "READ_ADC ")) nbvars+= 2;
				if (str_begin(lineptr, "SET_PWM ")) nbvars+= 4;
				if (str_begin(lineptr, "UART")) nbvars+= 3;
				if (str_begin(lineptr, "I2C")) nbvars+= 4;
				if (str_begin(lineptr, "SPI")) nbvars+= 4;
				

				////////////////// A VOIR et A COMPLETER

				}
			}		
		}

	if (mode == 0) 
		{
		VarList= new GlobalVar[nbvars];		// Create Var List
		VarStat= new int[nbvars];			// Create Var Status List:
		}

	if (mode > 0) printf("End (%d)\n\n", nbvars);		// Param variables not displayed / counted

	return nbvars;
	}


// Reads IO list in ld file
// Creates IO variables (if mode > 0)
// Returns number of IOs in use
int readLdIOlist(FILE * f, int mode)
	{
	Line line;
	char * lineptr= line;
	int found= false;
	int nbios= 0;

	while (fgets(line, sizeof(line)-1, f) != NULL)
		{
		int len= strlen(line);
		if (len == 0) continue;

		// remove useless chars at end
		while ((line[len-1] == '\r') || (line[len-1] == '\n') || (line[len-1] == '\t') || (line[len-1] == ' '))
			{
			line[len-1]= NUL;
			len--;
			}

		// remove useless chars at beginning
		lineptr= line;
		while ((lineptr[0] == '\t') || (lineptr[0] == ' '))
			{
			lineptr++;
			}

		if (str_equal(lineptr, "IO LIST"))						// Begin of IO List
			{
			found= true;
			if (mode > 0) printf("IO list:\n");
			continue;
			}
		if ((found) && (str_equal(lineptr, "END")))				// End of IO List
			{
			if (mode > 0) printf("End (%d)\n\n", nbios);
			break;
			}

		if (found) 
			{
			if (mode > 0)
				{
				sscanf(lineptr, "%s at %d", IOList[nbios].ioname, &IOList[nbios].iopin);
				IOStat[nbios]= 0;

				printf("\t%s at %d\n", IOList[nbios].ioname, IOList[nbios].iopin);
				}

			nbios++;					// Count number of variables
			}
		}

	if (mode == 0) 
		{
		IOList= new GlobalIO[nbios];		// Create IO List
		IOStat= new int[nbios];				// Create IO Status List
		}

	return nbios;
	}


// Reads number of Rungs, of Parallel branches 
// Mode 1 = Rungs, 2= Parallel 
int readLdInfo(FILE * f, int mode)
	{
	Line line;
	char * lineptr= line;
	int found= false, n= 0, nb= 0;

	while (fgets(line, sizeof(line)-1, f) != NULL)
		{
		int len= strlen(line);
		if (len == 0) continue;

		// remove useless chars at beginning
		lineptr= line;
		while ((lineptr[0] == '\t') || (lineptr[0] == ' '))
			{
			lineptr++;
			}

		if (str_begin(lineptr, "PROGRAM"))			// Begin of Program
			{
			found= true;
			continue;
			}

		if (found)
			{
			if (mode == 1) 
				if (str_begin(lineptr, "RUNG ")) nb++;

			if (mode == 2)			// Count max Parallel branches per Rung (for stack's size)
				{
				if (str_begin(lineptr, "RUNG ")) n= 0;					
				if (str_begin(lineptr, "PARALLEL")) n++;
				if (n > nb) nb= n;
				}
			}
		}

	return nb;
	}


// Search for variable in VarList
// Returns index or -1 if not found
int getVarfromList(char * vname)
	{
	for (int i= 0 ; i < NbVars ; i++)
		if (str_equal(VarList[i].varname, vname)) return i;

	return -1;
	}


// Search for IO in IOList
// Returns index or -1 if not found
int getIOfromList(char * ioname)
	{
	for (int i= 0 ; i < NbIOs ; i++)
		if (str_equal(IOList[i].ioname, ioname)) return i;

	return -1;
	}


// Search for Information in mcu descriptor
// Returns 1 if found (in response) or 0 if not found
int getInfofromMcu(char * info, char * response)
	{
	FILE * fmcu= NULL;
	Name fname="";
	Line line;

	sprintf(fname, "Mcus/%s.txt", Prog.mcu()->packName);
	fmcu= fopen(fname, "rt");
	if (fmcu == NULL) 
		{
		lad2c_error("Error opening mcu file");
		return 0;
		}

	while (fgets(line, sizeof(line)-1, fmcu) != NULL)
		{
		int len= strlen(line);
		if (len == 0) continue;

		// remove useless chars at end
		while ((line[len-1] == '\r') || (line[len-1] == '\n') || (line[len-1] == '\t') || (line[len-1] == ' '))
			{
			line[len-1]= NUL;
			len--;
			}

		len= strlen(line);
		if (len == 0) continue;				// Empty line
		if (line[0] == '/') continue;		// Comment

		if (str_begin(line, info))
			{
			strcpy(response, line+strlen(info)+1);

			fclose(fmcu);
			return 1;
			}
		}

	fclose(fmcu);
	return 0;
	}


// Search for Port associated to pin in mcu descriptor
// Returns Port letter in high byte + Port pin in low byte
unsigned short getPortfromPin(int pin)
	{
	String list= "", port= "", resp= "";
	int p= 0, nb= 0, go= 0;

	if (getInfofromMcu("mcu.port.list", list))
		go++;

	if (getInfofromMcu("mcu.port.bits", resp))
		{
		nb= atoi(resp);
		go++;
		}

	if (go == 2)
		{
		for (int i= 0 ; i < strlen(list) ; i++)
			{
			if (list[i] != ',')
			for (int j= 0 ; j < nb ; j++)
				{
				sprintf(port, "mcu.port%c.pin%d=", list[i], j);
				if (getInfofromMcu(port, resp)) 
					{
					int pos= str_find(resp, "/");
					if (pos == -1) continue;
					else p= atoi(resp+pos+1);

					if (pin == p)
						return (list[i] << 8) + j;
					}
				}
			}
		}

	return 0;
	}


// Check if value or variable
int isValue(char * str)
	{
	if (str[0] == '+') return 1;		// for signed values
	if (str[0] == '-') return 1;
	if (str[0] == '\'') return 1;					// for ASCII values 'X'
	if ((str[0] >= '0') && (str[0] <= '9')) return 1;		// for decimal or hexadecimal values

	return 0;
	}


void createVarforParam(char * s, char * type, int state= 1)
	{
	strcpy(VarList[NbVars].varname, s);
	if (str_equal(type, "char"))
		VarList[NbVars].varsize= 1;					// char
	if (str_equal(type, "short"))
		VarList[NbVars].varsize= 2;					// short
	if (str_equal(type, "medium"))
		VarList[NbVars].varsize= 3;					// medium
	if (str_equal(type, "long"))
		VarList[NbVars].varsize= 4;					// long
	if (str_equal(type, "integer"))
		VarList[NbVars].varsize= 4;					// short or long

	strcpy(VarList[NbVars].vartype, type);
	VarStat[NbVars]= state;

	NbVars++;
	}


// Search forward for a contact definition in an opened file
// Returns 1 if contact found, 0 if not
int searchContact(char * fname, char * str)
	{
	FILE * f;
	Line line;
	char * lineptr= line;
	long fpos= 0;
	int found= false;

	f= fopen(fname, "rt");
	if (f == NULL) 
		{
		lad2c_error("Error opening file");
		return 0;
		}

	while (fgets(line, sizeof(line)-1, f) != NULL)
		{
		int len= strlen(line);
		if (len == 0) continue;

		// remove useless chars at end
		while ((line[len-1] == '\r') || (line[len-1] == '\n') || (line[len-1] == '\t') || (line[len-1] == ' '))
			{
			line[len-1]= NUL;
			len--;
			}

		// remove useless chars at beginning
		lineptr= line;
		while ((lineptr[0] == '\t') || (lineptr[0] == ' '))
			{
			lineptr++;
			}

		if (str_equal(lineptr, "PROGRAM"))				// Beginning of program
			found= true;

		if (!found) continue;

		if (str_begin(lineptr, str))			// Contact Found
			return 1;
		}

	fclose(f);

	return 0;
	}


// Functions to manage Parallel branches stack
void Push(char c)
	{
	piletab[pileptr]= c;
	pileptr++;
	}

char Pop(void)
	{
	pileptr--;
	return piletab[pileptr];
	}

char Pop_Push(void)		// Equivalent to Pop + Push the same value
	{
	return piletab[pileptr-1];
	}


// Converts ladder program to C program
int convertLadder(char * fname, char * pname, char * hname, int mcuisa, int mode)
	{
	FILE * f= NULL, *fintro= NULL, * fhead= NULL, * fvardef= NULL, * ffuncdef= NULL, * fvarinit= NULL;
	FILE * finit= NULL, * fdevice= NULL, * ftime= NULL, * fmain= NULL, * fsub= NULL, * ftmp= NULL;
	Line line, tmpline, insline, newline;
	Name name= "";
	char * lineptr;
	int linenum= 0, insert= 0, insdone= 0;
	int pulsenum= 0;
	int eepromadr= 0;
	int retcode= 1;
	int pullup= false, found= false, create= false, addend= false, done= false;
	int rung= 0, pin1= 0, pin2= 0, pin3= 0, pin4= 0, tabs= 0, pins= 0;
	String target= "", cmd= "", s= "", s1= "", s2= "", s3= "", s4= "", s5= "", s6= "";
	long p= 0, p1= 0, p2= 0, p3= 0, p4= 0, q1= 0, q2= 0, q3= 0, q4= 0;
	char c1, c2;
	char lastbr= 0;
	int Lib_rom= 0, Lib_adc= 0, Lib_spi= 0, Lib_i2c= 0, Lib_uart= 0, Lib_pwm= 0, Lib_modbus= 0;

	f= fopen(fname, "rt");
	if (f == NULL) 
		{
		lad2c_error("Error opening ld file");
		retcode= 0;
		goto closeall;
		}

	fintro= fopen("Output/plcintro.h", "w+t");
	if (fintro == NULL) 
		{
		lad2c_error("Error creating plcintro H file");
		retcode= 0;
		goto closeall;
		}

	fhead= fopen(hname, "w+t");
	if (fhead == NULL) 
		{
		lad2c_error("Error creating program H file");
		retcode= 0;
		goto closeall;
		}

	fvardef= fopen("Output/plcvardef.c", "w+t");
	if (fvardef == NULL) 
		{
		lad2c_error("Error creating plcvardef C file");
		retcode= 0;
		goto closeall;
		}

	ffuncdef= fopen("Output/plcfuncdef.c", "w+t");
	if (ffuncdef == NULL) 
		{
		lad2c_error("Error creating plcfunc C file");
		retcode= 0;
		goto closeall;
		}

	fvarinit= fopen("Output/plcvarinit.c", "w+t");
	if (fvarinit == NULL) 
		{
		lad2c_error("Error creating plcvarinit C file");
		retcode= 0;
		goto closeall;
		}

	fdevice= fopen("Output/plcdevinit.c", "w+t");
	if (fdevice == NULL) 
		{
		lad2c_error("Error creating devinit C file");
		retcode= 0;
		goto closeall;
		}

	finit= fopen("Output/plcinit.c", "w+t");
	if (finit == NULL) 
		{
		lad2c_error("Error creating plcinit C file");
		retcode= 0;
		goto closeall;
		}

	ftime= fopen("Output/plctimer.c", "w+t");
	if (ftime == NULL) 
		{
		lad2c_error("Error creating plctimer C file");
		retcode= 0;
		goto closeall;
		}

	fmain= fopen("Output/plcmain.c", "w+t");
	if (fmain == NULL) 
		{
		lad2c_error("Error creating plcmain C file");
		retcode= 0;
		goto closeall;
		}

	fsub= fopen("Output/plcsub.c", "w+t");
	if (fsub == NULL) 
		{
		lad2c_error("Error creating plcsub C file");
		retcode= 0;
		goto closeall;
		}

	// plcintro.h
	fprintf(fintro, "/*\n");
	fprintf(fintro, "Source: Ld file version %s\n", Version);
	fprintf(fintro, "Target: %s\n", Micro);
	fprintf(fintro, "*/\n\n");

	fputs("#include <stdio.h>\n", fintro);
	fputs("#include <stdlib.h>\n", fintro);				// For random
	fputs("#include <string.h>\n\n", fintro);			// For strings

	fputs("#include \"ladder.h\"\n", fintro);
	fputs("#include \"contacts.h\"\n\n", fintro);

	//
	SetExt(name, pname, "h");
	int pos= str_back(name, '\\');
	fprintf(fintro, "#include \"%s\"\n\n", name+pos+1);
	//

	if (mcuisa == ISA_ARM)
		{
		if (Mcu == STM32F40X_LQFP_144)
			{
			fputs("#include \"stm32f4xx.h\"\n", fhead);
			fputs("#include \"stm32f4xx_gpio.h\"\n", fhead);
			fputs("#include \"stm32f4xx_rcc.h\"\n\n", fhead);
			fputs("#include \"Lib_gpio.h\"\n\n", fhead);

			fprintf(fhead, "#define LDTARGET_stm32f40x\n\n");

			fputs("#include \"Lib_usr.h\"\n\n", fhead);
			}
		else if (Mcu == STM32F10X_LQFP_48)
			{
			fputs("#include \"stm32f10x.h\"\n", fhead);
			fputs("#include \"stm32f10x_gpio.h\"\n", fhead);
			fputs("#include \"stm32f10x_rcc.h\"\n\n", fhead);
			fputs("#include \"Lib_gpio.h\"\n\n", fhead);

			fprintf(fhead, "#define LDTARGET_stm32f10x\n\n");

			fputs("#include \"Lib_usr.h\"\n\n", fhead);	
			}
		}

	if (mcuisa == ISA_AVR)
		{
		fputs("#include <avr\\io.h>\n", fhead);
		fputs("#include <stdio.h>\n\n", fhead);

		strcpy(target, Prog.mcu()->deviceName);
		strlwr(target);
		fprintf(fhead, "#define LDTARGET_%s\n\n", target);

		fputs("#include \"UsrLib.h\"\n\n", fhead);
		}
	
	if (mcuisa == ISA_PIC16)
		{
		fputs("#include <htc.h>\n", fhead);
		fputs("#include <stdio.h>\n\n", fhead);

		strcpy(target, Prog.mcu()->deviceName);
		strlwr(target);
		fprintf(fhead, "#define LDTARGET_%s\n\n", target);

		fputs("#include \"UsrLib.h\"\n\n", fhead);

		// Don't put config word in .h because causes an error in HTC
		fprintf(fintro, "__CONFIG(0x%4.4X);\n", (WORD) Prog.configurationWord & 0xFFFF);		// 16 bit config word
		if(Prog.configurationWord & 0xFFFF0000)
			fprintf(fintro, "__CONFIG(0x%4.4X);\n", (WORD) (Prog.configurationWord >> 16) & 0xFFFF);	// 32 bit config word
		}

	if (mcuisa == ISA_PIC18)
		{
		fputs("#include <htc.h>\n", fhead);
		fputs("#include <stdio.h>\n\n", fhead);

		strcpy(target, Prog.mcu()->deviceName);
		strlwr(target);
		fprintf(fhead, "#define LDTARGET_%s\n\n", target);

		fputs("#include \"UsrLib.h\"\n\n", fhead);

		// Beware that __PROG_CONFIG may not work (HITECH-C 18 release notes)
		if (str_equal(target, "pic18f458"))
			{
			fprintf(fintro,
				"__PROG_CONFIG(1, 0x%4.4X);\n"
				"__CONFIG(2, WDTDIS & PWRTEN & BORDIS);\n"				// No Wtdog, No Brown out, Pwrup timer
																		// Config 3 does not exist
				"__CONFIG(4, DEBUGDIS & LVPDIS & STVREN);\n\n",			// No Debug, No LVP, Stack overflow
				(WORD) Prog.configurationWord & 0xFFFF);				// Config words 5, 6, 7 are left to default
			}
		else
			{
			fprintf(fintro,
			"__PROG_CONFIG(1, 0x%4.4X);\n"
			"__CONFIG(2, WDTDIS & PWRTEN & BORDIS);\n"					// No Wtdog, No Brown out, Pwrup timer
			"__CONFIG(3, MCLREN & PBDIGITAL);\n"						// Mclr, PortB digital
			"__CONFIG(4, DEBUGDIS & XINSTDIS & LVPDIS & STVREN);\n\n",	// No Debug, No Extended set, No LVP, Stack overflow
			(WORD) Prog.configurationWord & 0xFFFF);					// Config words 5, 6, 7 are left to default
			}
		}

	while (1)
		{
		if (insert == 0)				// Normal behaviour
			{
			lineptr= fgets(line, sizeof(line)-1, f);
			if (lineptr == NULL) break;
			}
		else if (insert == 1)			// To insert a required Relay or Coil or String
			{
			strcpy(tmpline, line);
			strcpy(line, insline);
			insert= 2;						// For next loop
			}
		else if (insert == 2)			// To finish the job by processing the initial line
			{
			strcpy(line, tmpline);			
			insert= 0;				
			}

		int len= strlen(line);
		if (len == 0) continue;

		// remove useless chars at end
		while ((line[len-1] == '\r') || (line[len-1] == '\n') || (line[len-1] == '\t') || (line[len-1] == ' '))
			{
			line[len-1]= NUL;
			len--;
			}

		// remove useless chars at beginning
		lineptr= line;
		while ((lineptr[0] == '\t') || (lineptr[0] == ' '))
			{
			lineptr++;
			}

		if (str_equal(lineptr, "PULL-UP LIST"))				// Beginning of Pull-Up list
			{
			pullup= true;			
			continue;
			}
		if (pullup && str_equal(lineptr, "END"))			// End of Pull-Up list
			{
			pullup= false;
			continue;
			}
		if (pullup)
			{
			if ((mcuisa == ISA_PIC16) || (mcuisa == ISA_PIC18))
				sscanf(lineptr, "R%c: 0x%lX", &c1, &p1);
			else
				sscanf(lineptr, "P%c: 0x%lX", &c1, &p1);
			Port_pup[c1-'A']= p1;
			continue;
			}

		if (str_equal(lineptr, "PROGRAM"))				// Beginning of program
			{
			found= true;

			// Stacks for PARALLEL / SERIES branches
			fputs("#define RungStart(in) {pile1ptr= 0; pile2ptr= 0; out= in;}\n\n", fvardef);
			fprintf(fvardef, "char pile1[%d];\t\t// Parallel stack 1\n", NbPara+1);
			fprintf(fvardef, "char pile2[%d];\t\t// Parallel stack 2\n", NbPara+1);
			fprintf(fvardef, "short pile1ptr= 0;\n");
			fprintf(fvardef, "short pile2ptr= 0;\n\n");
			fprintf(fvardef, "char master= 1;\t\t// Master control\n\n");

			continue;
			}

		if (!found) continue;			// Waiting for program beginning

		done= false;
		if ((insert == 0) && (insdone == 0)) linenum++;	 // Program line number used to index some contacts

		if (str_begin(lineptr, "RUNG "))
			{
			sscanf(lineptr, "RUNG %d", &rung);			// Get rung number

			if (rung > 1) fprintf(fmain, "}\n");
			fprintf(fvardef, "\n// Rung: %d\n", rung);
			fprintf(fvarinit, "\n// Rung: %d\n", rung);
			fprintf(fmain, "\nRung_%d:\t// Rung: %d\n", rung, rung);

			if ((rung == 1) && (Duty))		// Activate PlcCycleDuty ouput
				{
				int i= getIOfromList("YPlcCycleDuty");
				if (i >= 0)
					{
					pin1= IOList[i].iopin;
					unsigned short port= getPortfromPin(pin1);
					if (port != 0)
						{
						// Initialize port
						Port_out[(port >> 8)-'A'] |= (1 << (port & 0xFF));
						
						// Create port function						
						fprintf(ffuncdef, "void YPlcCycleDuty_writebit(char b)\n");
						fprintf(ffuncdef, "\t{\n");
						fprintf(ffuncdef, "\tif (b) Gpio_setoutputs('%c', (1 << %d));\n", (char) (port >> 8), port & 0xFF);
						fprintf(ffuncdef, "\telse Gpio_resetoutputs('%c', (1 << %d));\n", (char) (port >> 8), port & 0xFF);
						fprintf(ffuncdef, "\t}\n\n");						
						}
					else
						{
						lad2c_error("Port does not exist !");
						retcode= 0;
						goto closeall;
						}

					fputabs(fmain, tabs);
					fprintf(fmain, "YPlcCycleDuty_writebit(1);\n");
					}
				else
					{
					lad2c_error("PlcCycleDuty I/O not defined !");
					retcode= 0;
					goto closeall;
					}
				}

			fprintf(fmain, "RungStart(master)\n");
			fprintf(fmain, "{\n");

			continue;
			}

		if (str_equal(lineptr, "PARALLEL"))				// Parallel sub branches (Or)
			{
			fputabs(fmain, tabs); fprintf(fmain, "// PARALLEL\n");
			tabs= (pileptr/2)+1;
			fputabs(fmain, tabs); fprintf(fmain, "Push(1, out);\n");
			fputabs(fmain, tabs); fprintf(fmain, "Push(2, 0);\n");
			Push('P');

			continue;
			}

		if (str_equal(lineptr, "SERIES"))				// Series sub branch
			{
			fputabs(fmain, tabs); fprintf(fmain, "// SERIES\n");
			fputabs(fmain, tabs); fprintf(fmain, "out= Pop_Push(1);\n"); 
			Push('S');

			continue;
			}

		if (str_equal(lineptr, "END"))			
			{
			if (pileptr == 0) continue;			// To skip END of Rung
			
			if (Pop() == 'S')							// End of  Series branch
				{
				fputabs(fmain, tabs); fprintf(fmain, "// END SERIES\n");
				fputabs(fmain, tabs); fprintf(fmain, "out= out | Pop(2);\n");
				fputabs(fmain, tabs); fprintf(fmain, "Push(2, out);\n");
				}
			else										// End of Parallel branch
				{
				tabs= (pileptr/2); 
				fputabs(fmain, tabs); fprintf(fmain, "// END PARALLEL\n");
				fputabs(fmain, tabs); fprintf(fmain, "Pop(1);\n");
				fputabs(fmain, tabs); fprintf(fmain, "Pop(2);\n");			
				}

			continue;
			}

		if (Pop_Push() == 'P')			// A Parallel is followed by a "virtual" Series branch (1 contact only)
			{
			fputabs(fmain, tabs); fprintf(fmain, "// SERIES_1\n");
			fputabs(fmain, tabs); fprintf(fmain, "out= Pop_Push(1);\n"); 
			Push('S');
			addend= true;
			}

		fputabs(fmain, tabs);			// For next Contact

		////////////////////////////////////////////////////////////////////////////////////////
		if (str_begin(lineptr, "COMMENT "))					// Comment contact
			{
			// Example:	COMMENT Comment or Comment1\r\nComment2

			int pos1, pos2;
			lineptr+= 8;

			fprintf(fmain, "// Comment:\n");
			do
				{
				pos1= str_find(lineptr, "\\n");
				if (pos1 >= 0) 
					{
					lineptr[pos1]= NUL;
					pos2= str_find(lineptr, "\\r");
					if (pos2 >= 0) lineptr[pos2]= NUL;
					}
				fprintf(fmain, "// %s\n", lineptr);
				lineptr+= pos1+2;
				}
			while (pos1 != -1);
			
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "CONTACTS "))				// Relay contact
			{
			// Example:	CONTACTS Xbutton 1 1
			sscanf(lineptr, "CONTACTS %s %ld %ld", name, &p1, &p2);
			if (p1) c1= 'I'; else c1= 'N';
			
			int i= getIOfromList(name);
			if (i >= 0)					// External Relay 'X' or 'Y'
				{
				c2= name[0];							
				pin1= IOList[i].iopin;

				// Check if Relay has been created yet
				if (IOStat[i] == 0)
					{
					create= true;
					IOStat[i]= 1;
					}
				else
					create= false;

				if (create)
					{
					fprintf(fvardef, "Relay R%s;\t\t// (%ld, %ld)\n", name, p1, p2);

					// Check if variable has been created yet
					int j= getVarfromList(name);
					if (j == -1) 
						{
						createVarforParam(name, "char");
						fprintf(fvardef, "char %s= 0;\n", name);
						j= getVarfromList(name);
						}

					if (VarStat[j] == 0) fprintf(fvardef, "char %s= 0;\n", name);	
					VarStat[j] |= 1;

					unsigned short port= getPortfromPin(pin1);
					if (port != 0)
						{
						// Initialize port
						if (c2 == 'X')
							Port_inp[(port >> 8)-'A'] |= (1 << (port & 0xFF));
						else
							Port_out[(port >> 8)-'A'] |= (1 << (port & 0xFF));
						
						// Create port function
						if (c2 == 'X')
							fprintf(ffuncdef, "char R%s_readinput()\n", name);			// 'X'
						else
							fprintf(ffuncdef, "char R%s_readoutput()\n", name);			// 'Y'
						fprintf(ffuncdef, "\t{\n");

						if (c2 == 'X')
							{
							fprintf(ffuncdef, "\tint b= Gpio_readinput('%c', (1 << %d));\n", (char) (port >> 8), port & 0xFF); 
							fprintf(ffuncdef, "\tif (b) return 1; else return 0;\n");
							}
						else
							{
							fprintf(ffuncdef, "\tint b= Gpio_readoutput('%c', (1 << %d));\n", (char) (port >> 8), port & 0xFF); 
							fprintf(ffuncdef, "\tif (b) return 1; else return 0;\n");									
							}

						fprintf(ffuncdef, "\t}\n\n");

						fprintf(fvarinit, "Relay_Init(&R%s, '%c', '%c', %d, &%s);\t\t// %s\n", name, c1, c2, pin1, name, lineptr);

						if (c2 == 'X')
							fprintf(fmain, "*(R%s.bitptr)= R%s_readinput();\n", name, name);		// 'X'
						else
							fprintf(fmain, "*(R%s.bitptr)= R%s_readoutput();\n", name, name);		// 'Y'
						fputabs(fmain, tabs);
						}
					else
						{
						lad2c_error("Port does not exist !");
						retcode= 0;
						goto closeall;
						}
					}
				}
			else							// Internal Relay 'R'
				{
				c2= 'R';

				// Check if Relay (or Coil) has been created yet
				int i= getVarfromList(name);
				if ((i >= 0) && ((VarStat[i] & 1) == 0)) 
					create= true;
				else 
					create= false;

				if (create)
					{
					fprintf(fvardef, "Relay R%s;\t\t// (%ld, %ld)\n", name, p1, p2);
					if (VarStat[i] == 0) fprintf(fvardef, "char %s= 0;\n", name);
					VarStat[i] |= 1;

					fprintf(fvarinit, "Relay_Init(&R%s, '%c', '%c', 0, &%s);\t\t// %s\n", name, c1, c2, name, lineptr);
					}
				}

			if (insert == 0)
				fprintf(fmain, "out= Relay_Transfer(&R%s, '%c', out);\t\t// %s\n", name, c1, lineptr);
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "COIL "))					// Coil contact (Terminal instruction only)
			{
			// Example:	COIL Yled 0 0 0 0
			sscanf(lineptr, "COIL %s %ld %ld %ld %ld", name, &p1, &p2, &p3, &p4);
			if (p1) c1= 'I'; else if (p2) c1= 'S'; else if (p3) c1= 'R'; else if (p4) c1= 'T';
			else c1= 'N';

			if (insert == 0)
				fprintf(fmain, "out= Coil_Transfer(&C%s, '%c', out);\t\t// %s\n", name, c1, lineptr);

			int i= getIOfromList(name);
			if (i >= 0)					// External Coil 'Y'
				{
				c2= 'Y';				
				pin1= IOList[i].iopin;

				// Check if Relay has been created yet
				if (IOStat[i] == 0)
					{
					create= true;
					IOStat[i]= 1;
					}
				else
					create= false;

				if (create)
					{
					fprintf(fvardef, "Coil C%s;\t\t// (%ld, %ld, %ld, %ld)\n", name, p1, p2, p3, p4);

					// Check if variable has been created yet
					int j= getVarfromList(name);
					if (j == -1)
						{
						createVarforParam(name, "char");
						fprintf(fvardef, "char %s= 0;\n", name);
						j= getVarfromList(name);
						}

					if (VarStat[j] == 0) fprintf(fvardef, "char %s= 0;\n", name);
					VarStat[j] |= 2;

					fprintf(fvarinit, "Coil_Init(&C%s, '%c', '%c', %d, &%s);\t\t// %s\n", name, c1, c2, pin1, name, lineptr);

					unsigned short port= getPortfromPin(pin1);
					if (port != 0)
						{
						// Initialize port
						Port_out[(port >> 8)-'A'] |= (1 << (port & 0xFF));
						
						// Create port function						
						fprintf(ffuncdef, "void C%s_writebit(char b)\n", name);
						fprintf(ffuncdef, "\t{\n");
						fprintf(ffuncdef, "\tif (b) Gpio_setoutputs('%c', (1 << %d));\n", (char) (port >> 8), port & 0xFF);
						fprintf(ffuncdef, "\telse Gpio_resetoutputs('%c', (1 << %d));\n", (char) (port >> 8), port & 0xFF);
						fprintf(ffuncdef, "\t}\n\n");						
						}
					else
						{
						lad2c_error("Port does not exist !");
						retcode= 0;
						goto closeall;
						}
					
					if (insert == 0)
						{
						fputabs(fmain, tabs);
						fprintf(fmain, "C%s_writebit(out);\n", name);
						}
					}
				else
					{
					if (insert == 0)
						{
						fputabs(fmain, tabs);
						fprintf(fmain, "C%s_writebit(out);\n", name);
						}
					}
				}
			else						// Internal Coil 'R'
				{
				c2= 'R';		
				// Check if Coil (or Relay) has been created yet
				int i= getVarfromList(name);
				if ((i >= 0) && ((VarStat[i] & 2) == 0)) 
					create= true;
				else 
					create= false;

				if (create)
					{
					fprintf(fvardef, "Coil C%s;\t\t// (%ld, %ld, %ld, %ld)\n", name, p1, p2, p3, p4);
					if (VarStat[i] == 0) fprintf(fvardef, "char %s= 0;\n", name);			
					VarStat[i] |= 2;

					fprintf(fvarinit, "Coil_Init(&C%s, '%c', '%c', 0, &%s);\t\t// %s\n", name, c1, c2, name, lineptr);							
					}						
				}
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		// Most Contacts' parameters can be Values or Variables (Not starting with a digit)

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_equal(lineptr, "MASTER_RELAY"))					// Master Relay (Terminal only)
			{
			// Example:	Master_Relay

			fprintf(fmain, "master= Master_Relay(master, out);\t\t// %s\n", lineptr);
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_equal(lineptr, "PLACEHOLDER"))					// Empty line
			{
			// Example:	Placeholder

			fprintf(fmain, "// PlaceHolder (Empty line) //\n");
			done= true;
			}


		////////////////////////////////////////////////////////////////////////////////////////

		if (str_equal(lineptr, "SHORT"))					// Short Circuit
			{
			// Example:	Short

			fprintf(fmain, "out= ShortCircuit(out);\t\t// %s\n", lineptr);
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_equal(lineptr, "OPEN"))						// Open Circuit
			{
			// Example:	Open

			fprintf(fmain, "out= 0;\t\t// Open wire\n");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "TON "))					// Ton contact
			{
			// Example:	TON Tosc_on var 0
			sscanf(lineptr, "TON %s %s %s", name, s1, s2);					// s1= Tempo, s2= Adjustment (value)

			fprintf(fvardef, "Ton %s_tn;\t\t// (%s, %s)\n", name, s1, s2);

			// Test if variables created yet because sharable
			int i= getVarfromList(name);
			if ((i >= 0) && (VarStat[i] == 0)) 
				{
				VarStat[i]= 1;
				fprintf(fvardef, "integer %s= 0;\n", name);
				}

			if (isValue(s2))
				{
				p2= atol(s2);
				}
			else
				{
				lad2c_error("Ton / Tof adjustment must be a value");
				p2= 0;
				}
			if (isValue(s1))
				{
				p1= atol(s1)/Cycle;
				sprintf(s1, "%ld", p1);
				}
			else
				{
				MakeIntegerVariable(s1);
				}

			fprintf(fvarinit, "Ton_Init(&%s_tn, &%s, %s+(%ld));\t\t// %s\n", name, name, s1, p2, lineptr);
			fprintf(fmain, "out= Ton_Transfer(&%s_tn, out);\t\t// %s\n", name, lineptr);

			EnableContacts("TEMPO");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "TOF "))					// Tof contact
			{
			// Example:	TOF Tosc_off 2500 0
			sscanf(lineptr, "TOF %s %s %s", name, s1, s2);					// s1= tempo, adjustment s2 is ignored

			fprintf(fvardef, "Tof %s_tf;\t\t// (%s, %s)\n", name, s1, s2);
			
			// Test if variables created yet because sharable
			int i= getVarfromList(name);
			if ((i >= 0) && (VarStat[i] == 0))
				{
				VarStat[i]= 1;
				fprintf(fvardef, "integer %s= 0;\n", name);
				}

			if (isValue(s2))
				{
				p2= atol(s2);
				}
			else
				{
				lad2c_error("Ton / Tof adjustment must be a value");
				p2= 0;
				}
			if (isValue(s1))
				{
				p1= atol(s1)/Cycle;
				sprintf(s1, "%ld", p1);
				}
			else
				{
				MakeIntegerVariable(s1);
				}

			fprintf(fvarinit, "Tof_Init(&%s_tf, &%s, %s+(%ld));\t\t// %s\n", name, name, s1, p2, lineptr);
			fprintf(fmain, "out= Tof_Transfer(&%s_tf, out);\t\t// %s\n", name, lineptr);

			EnableContacts("TEMPO");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if ((str_equal(lineptr, "OSR"))	||				// Osr, Osf, Osl contact
			(str_equal(lineptr, "OSF")) ||
			(str_equal(lineptr, "OSL")))
			{
			// Example:	OSR

			c1= lineptr[2];
			fprintf(fvardef, "OneShot Os%c_%d;\n", tolower(c1), linenum);
			
			fprintf(fvarinit, "OneShot_Init(&Os%c_%d, '%c');\t\t// %s\n", tolower(c1), linenum, c1, lineptr);
			fprintf(fmain, "out= OneShot_Transfer(&Os%c_%d, out);\t\t// %s\n", tolower(c1), linenum, lineptr);

			EnableContacts("OSC");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_equal(lineptr, "OSC"))					// Oscillator contact
			{
			// Example:	OSR

			fprintf(fvardef, "Oscillator Osc_%d;\n", linenum);
			
			fprintf(fvarinit, "Oscillator_Init(&Osc_%d);\t\t// %s\n", linenum, lineptr);
			fprintf(fmain, "out= Oscillator_Transfer(&Osc_%d, out);\t\t// %s\n", linenum, lineptr);

			EnableContacts("OSC");
			done= true;
			}


		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "CTU "))					// Count-Up contact
			{
			// Example:	CTU Cup 100 10
			sscanf(lineptr, "CTU %s %s %s %s", name, s1, s2, s3);			// s1= Max, s2= Begin, s3= Mode

			fprintf(fvardef, "Count %s_up;\t\t// (%s, %s, %s)\n", name, s1, s2, s3);

			// Test if variables created yet because sharable
			int i= getVarfromList(name);
			if ((i >= 0) && (VarStat[i] == 0)) 
				{
				VarStat[i]= 1;
				fprintf(fvardef, "integer %s= 0;\n", name);
				}

			if (isValue(s1))
				{
				p1= atol(s1);
				strcpy(s1, name); strcat(s1, "_lim");
				createVarforParam(s1, "integer");
				fprintf(fvardef, "integer %s= %ld;\n", s1, p1);
				}				
			else
				{
				MakeIntegerVariable(s1);
				}
			if (isValue(s2))
				{
				p2= atol(s2);
				strcpy(s2, name); strcat(s2, "_beg");
				createVarforParam(s2, "integer");
				fprintf(fvardef, "integer %s= %ld;\n", s2, p2);
				}
			else
				{
				MakeIntegerVariable(s2);
				}							

			fprintf(fvarinit, "Count_Init(&%s_up, 'U', '%s', &%s, &%s, &%s);\t\t// %s\n", name, s3, s2, s1, name, lineptr);			
			fprintf(fmain, "out= Count_Transfer(&%s_up, out);\t\t// %s\n", name, lineptr);

			EnableContacts("COUNT");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "CTD "))					// Count-Dn contact
			{
			// Example:	CTU Cdn 10 100
			sscanf(lineptr, "CTD %s %s %s %s", name, s1, s2, s3);			// s1= Max, s2= Begin, s3= Mode

			fprintf(fvardef, "Count %s_dn;\t\t// (%s, %s, %s)\n", name, s1, s2, s3);

			// Test if variables created yet because sharable
			int i= getVarfromList(name);
			if ((i >= 0) && (VarStat[i] == 0)) 
				{
				VarStat[i]= 1;
				fprintf(fvardef, "integer %s= 0;\n", name);
				}

			if (isValue(s1))
				{
				p1= atol(s1);
				strcpy(s1, name); strcat(s1, "_lim");
				createVarforParam(s1, "integer");
				fprintf(fvardef, "integer %s= %ld;\n", s1, p1);
				}				
			else
				{
				MakeIntegerVariable(s1);
				}
			if (isValue(s2))
				{
				p2= atol(s2);
				strcpy(s2, name); strcat(s2, "_beg");
				createVarforParam(s2, "integer");
				fprintf(fvardef, "integer %s= %ld;\n", s2, p2);
				}				
			else
				{
				MakeIntegerVariable(s2);
				}
			
			fprintf(fvarinit, "Count_Init(&%s_dn, 'D', '%s', &%s, &%s, &%s);\t\t// %s\n", name, s3, s2, s1, name, lineptr);			
			fprintf(fmain, "out= Count_Transfer(&%s_dn, out);\t\t// %s\n", name, lineptr);

			EnableContacts("COUNT");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if ((str_begin(lineptr, "CTC ")) ||					// Count-Cc or Count-Cr contact
			(str_begin(lineptr, "CTR ")))
			{
			// Example:	CTC Ctc 100 10
			if (lineptr[2] == 'C')
				{
				sscanf(lineptr, "CTC %s %s %s %s", name, s1, s2, s3);			// s1= Max, s2= Begin, s3= Mode
				fprintf(fvardef, "Count %s_cc;\t\t// (%s, %s, %s)\n", name, s1, s2, s3);
				}
			else
				{
				sscanf(lineptr, "CTR %s %s %s %s", name, s1, s2, s3);			// s1= Min, s2= Begin, s3= Mode
				fprintf(fvardef, "Count %s_cr;\t\t// (%s, %s, %s)\n", name, s1, s2, s3);
				}

			// Test if variables created yet because sharable
			int i= getVarfromList(name);
			if ((i >= 0) && (VarStat[i] == 0)) 
				{
				VarStat[i]= 1;
				fprintf(fvardef, "integer %s= 0;\n", name);
				}

			if (isValue(s1))
				{
				p1= atol(s1);
				strcpy(s1, name); strcat(s1, "_lim");
				createVarforParam(s1, "integer");
				fprintf(fvardef, "integer %s= %ld;\n", s1, p1);
				}				
			else
				{
				MakeIntegerVariable(s1);
				}
			if (isValue(s2))
				{
				p2= atol(s2);
				strcpy(s2, name); strcat(s2, "_beg");
				createVarforParam(s2, "integer");
				fprintf(fvardef, "integer %s= %ld;\n", s2, p2);
				}				
			else
				{
				MakeIntegerVariable(s2);
				}
			
			if (lineptr[2] == 'C')
				{
				fprintf(fvarinit, "Count_Init(&%s_cc, 'C', '%s', &%s, &%s, &%s);\t\t// %s\n", name, s3, s2, s1, name, lineptr);					
				fprintf(fmain, "out= Count_Transfer(&%s_cc, out);\t\t// %s\n", name, lineptr);
				}
			else
				{
				fprintf(fvarinit, "Count_Init(&%s_cr, 'R', '%s', &%s, &%s, &%s);\t\t// %s\n", name, s3, s2, s1, name, lineptr);					
				fprintf(fmain, "out= Count_Transfer(&%s_cr, out);\t\t// %s\n", name, lineptr);
				}

			EnableContacts("COUNT");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "TIME2COUNT "))					// Time to Count converter
			{
			// Example:	TIME2COUNT Tconv var 0
			sscanf(lineptr, "TIME2COUNT %s %s", name, s1);			// s1= time in ms

			// Test if variables created yet because sharable
			int i= getVarfromList(name);
			if ((i >= 0) && (VarStat[i] == 0)) 
				{
				VarStat[i]= 1;
				fprintf(fvardef, "integer %s= 0;\n", name);
				}

			if (!isValue(s1))
				{
				MakeIntegerVariable(s1);
				}

			fprintf(fmain, "if (out) %s= (%s / %ld);\t\t// %s\n", name, s1, Cycle, lineptr);

			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if ((str_begin(lineptr, "THI ")) ||					// Thi contact
			(str_begin(lineptr, "TLO ")) ||					// Tlo contact
			(str_begin(lineptr, "RTO ")) ||					// Rto contact
			(str_begin(lineptr, "RTL ")) ||					// Rtl contact
			(str_begin(lineptr, "TCY ")))					// Tcy contact
			{
			// Example:	THI Ton var 0
																				// cmd= THI / TLO / RTO / RTL / TCY"
			sscanf(lineptr, "%s %s %s %s", cmd, name, s1, s2);					// s1= Tempo, s2= Adjustment (value)

			fprintf(fvardef, "Timer %s_ti;\t\t// (%s, %s)\n", name, s1, s2);

			// Test if variables created yet because sharable (with RES only in fact)
			int i= getVarfromList(name);
			if ((i >= 0) && (VarStat[i] == 0)) 
				{
				VarStat[i]= 1;
				fprintf(fvardef, "integer %s= 0;\n", name);
				}

			if (isValue(s2))
				{
				p2= atol(s2);
				}
			else
				{
				lad2c_error("Timer adjustment must be a value");
				p2= 0;
				}
			if (isValue(s1))
				{
				p1= atol(s1)/Cycle;
				strcpy(s1, name); strcat(s1, "_lim");
				createVarforParam(s1, "integer");
				fprintf(fvardef, "integer %s= %ld;\n", s1, p1+p2);
				}
			else
				{
				MakeIntegerVariable(s1);
				}

			if(str_equal(cmd, "THI")) c1= 'H';
			if(str_equal(cmd, "TLO")) c1= 'L';
			if(str_equal(cmd, "RTO")) c1= 'U';
			if(str_equal(cmd, "RTL")) c1= 'D';
			if(str_equal(cmd, "TCY")) c1= 'C';

			fprintf(fvarinit, "Timer_Init(&%s_ti, '%c', &%s, &%s);\t\t// %s\n", name, c1, s1, name, lineptr);
			fprintf(fmain, "out= Timer_Transfer(&%s_ti, out);\t\t// %s\n", name, lineptr);

			EnableContacts("TIME");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "RES "))					// Reset contact (Counter, Timer, Pwm)
			{
			// Example:	Res Ctc
			// Example: Res Tim
			// Example: Res Pwm
			sscanf(lineptr, "RES %s", name);

			if (name[0] == 'T')
				{
				fprintf(fmain, "out= Timer_Reset(&%s, out);\t\t// %s\n", name, lineptr);

				EnableContacts("TIME");
				}
			else if (name[0] == 'C')												
				{
				if (str_begin(name, "CTU"))
					fprintf(fmain, "out= Count_Reset(&%s_up, out);\t\t// %s\n", name, lineptr);
				if (str_begin(name, "CTD"))
					fprintf(fmain, "out= Count_Reset(&%s_dn, out);\t\t// %s\n", name, lineptr);
				if (str_begin(name, "CTC"))
					fprintf(fmain, "out= Count_Reset(&%s_cc, out);\t\t// %s\n", name, lineptr);
				if (str_begin(name, "CTR"))
					fprintf(fmain, "out= Count_Reset(&%s_cr, out);\t\t// %s\n", name, lineptr);

				EnableContacts("COUNT");
				}
			else if (name[0] == 'P')
				{
				// This PWM must exist somewhere in the ladder...
				fprintf(fmain, "if (out) Pwm_%s_Stop();\t\t// %s\n", name, lineptr);
				}

			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if ((str_begin(lineptr, "EQU ")) || (str_begin(lineptr, "NEQ ")) ||(str_begin(lineptr, "GRT ")) ||
			(str_begin(lineptr, "GEQ ")) ||(str_begin(lineptr, "LES ")) ||(str_begin(lineptr, "LEQ ")))				
			{
			// Example:	EQU var val						// Equ contact
			// Example:	NEQ Cstate 20					// Neq contact
			// Example:	GRT var val						// Grt contact
			// Example:	GEQ var val						// Geq contact
			// Example:	LES var val						// Les contact
			// Example:	LEQ var val						// Leq contact
			sscanf(lineptr, "%s %s %s", cmd, s1, s2);					// s1 compared to s2
		
			// Test if variables exists yet because sharable
			if (isValue(s1))
				{
				strcpy(s3, s1);
				}				
			else
				{
				MakeIntegerVariable(s1);
				strcpy(s3, s1);
				}				
			if (isValue(s2))
				{	
				strcpy(s4, s2);
				}				
			else
				{
				MakeIntegerVariable(s2);
				strcpy(s4, s2);
				}

			if (str_equal(cmd, "EQU"))
				fprintf(fmain, "if (out && (%s == %s)) out= 1; else out= 0;\t\t// %s\n", s3, s4, lineptr);
			if (str_equal(cmd, "NEQ"))
				fprintf(fmain, "if (out && (%s != %s)) out= 1; else out= 0;\t\t// %s\n", s3, s4, lineptr);
			if (str_equal(cmd, "GRT"))
				fprintf(fmain, "if (out && (%s > %s)) out= 1; else out= 0;\t\t// %s\n", s3, s4, lineptr);
			if (str_equal(cmd, "GEQ"))
				fprintf(fmain, "if (out && (%s >= %s)) out= 1; else out= 0;\t\t// %s\n", s3, s4, lineptr);
			if (str_equal(cmd, "LES"))
				fprintf(fmain, "if (out && (%s < %s)) out= 1; else out= 0;\t\t// %s\n", s3, s4, lineptr);
			if (str_equal(cmd, "LEQ"))
				fprintf(fmain, "if (out && (%s <= %s)) out= 1; else out= 0;\t\t// %s\n", s3, s4, lineptr);
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if ((str_begin(lineptr, "IF_BIT_SET ")) || (str_begin(lineptr, "IF_BIT_CLEAR ")))					
			{
			// Example:	IF_BIT_SET var bit									// Bt0 contact
			// Example:	IF_BIT_CLEAR var bit								// Bt1 contact
			sscanf(lineptr, "%s %s %s", cmd, s1, s2);		// test bit s2 in s1

			// Test if variables exists yet because sharable
			if (isValue(s1))
				{
				strcpy(s3, s1);
				}				
			else
				{
				MakeIntegerVariable(s1);
				strcpy(s3, s1);
				}				
			if (isValue(s2))
				{	
				strcpy(s4, s2);
				}				
			else
				{
				MakeIntegerVariable(s2);
				strcpy(s4, s2);
				}

			if (str_equal(cmd, "IF_BIT_SET"))
				fprintf(fmain, "if (out && (%s & (1 << %s))) out= 1; else out= 0;\t\t// %s\n", s3, s4, lineptr);
			if (str_equal(cmd, "IF_BIT_CLEAR"))
				fprintf(fmain, "if (out && (~%s & (1 << %s))) out= 1; else out= 0;\t\t// %s\n", s3, s4, lineptr);
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "MOVE ")) 				// Move instruction (Terminal only)
			{
			// Example:	MOVE destvar srcevar			// supports arrays[] as srce or dest
																	// cmd = MOVE
			sscanf(lineptr, "%s %s %s", cmd, s1, s2);				// s1= dest, s2= srce

			// Test if variables exist yet because sharable
			if (isValue(s1))
				{
				lad2c_error("Move 1st parameter must be a variable");
				strcpy(s3, s1);
				}				
			else if (s1[0] == '#')			// case of Register #PORTx, #PINx, #DDRx ...
				{
				if (mcuisa == ISA_ARM)
					{
					strcpy(s3, s1);
					if (str_begin(s1, "#PORT")) sprintf(s3, "GPIO%c->ODR", s1[5]);
					}
				else
					{
					s1[0]= '_';				// Replace # with _ for compiler
					DefineVariable(s1);
					strcpy(s3, s1);
					}
				}
			else if (str_find(s1, "[") != -1)			// case of array[] (preexisting)
				{
				strcpy(s3, s1);
				}			
			else
				{
				MakeIntegerVariable(s1);
				strcpy(s3, s1);
				}

			if (s2[0] == '#')				// case of Register #PORTx, #PINx, #DDRx ...
				{
				if (mcuisa == ISA_ARM)
					{
					strcpy(s4, s2);
					// #DDRx not supported for ARMs
					if (str_begin(s2, "#PIN")) sprintf(s4, "GPIO%c->IDR", s2[4]);
					if (str_begin(s2, "#PORT")) sprintf(s4, "GPIO%c->ODR)", s2[5]);
					}
				else
					{
					s2[0]= '_';				// Replace # with _ for compiler
					DefineVariable(s2);
					strcpy(s4, s2);
					}
				}
			else if ((isValue(s2)) || (str_find(s2, "[") != -1))
				{	
				strcpy(s4, s2);
				}				
			else
				{
				MakeIntegerVariable(s2);
				strcpy(s4, s2);
				}	

			fprintf(fmain, "if (out) Move(%s, %s);\t\t// %s\n", s3, s4, lineptr);
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if ((str_begin(lineptr, "NEG ")) ||						// Neg instruction
			(str_begin(lineptr, "NOT ")))						// Not instruction
			{
			// Example:	NEG destvar srcevar
			// Example:	NOT destvar srcevar
																	// cmd = NEG / NOT
			sscanf(lineptr, "%s %s %s", cmd, s1, s2);				// s1= dest, s2= srce

			// Test if variables exist yet because sharable
			if (isValue(s1))
				{
				lad2c_error("Neg / Not 1st parameter must be a variable");
				}				
			else
				{
				MakeIntegerVariable(s1);
				}
			if (isValue(s2))
				{	
				strcpy(s4, s2);
				}				
			else
				{
				MakeIntegerVariable(s2);
				strcpy(s4, s2);
				}	

			if (str_equal(cmd, "NEG"))
				fprintf(fmain, "if (out) Nega(%s, %s);\t\t// %s\n", s1, s4, lineptr);
			if (str_equal(cmd, "NOT"))
				fprintf(fmain, "if (out) Not(%s, %s);\t\t// %s\n", s1, s4, lineptr);
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if ((str_begin(lineptr, "ADD ")) ||				// Arithmetical instructions (Terminal only)
			(str_begin(lineptr, "SUB ")) ||
			(str_begin(lineptr, "MUL ")) ||
			(str_begin(lineptr, "DIV ")) ||
			(str_begin(lineptr, "MOD ")))
			{
			// Example:	ADD destvar op1 op2		
																			// cmd= ADD / SUB / MUL / DIV / MOD
			sscanf(lineptr, "%s %s %s %s", cmd, s1, s2, s3);				// s1= dest, s2= op1, s3= op2

			// Test if variables exist yet because sharable
			if (isValue(s1))
				{
				lad2c_error("Arithmetical instruction 1st parameter must be a variable");
				}				
			else
				{
				MakeIntegerVariable(s1);
				}
			if (isValue(s2))
				{	
				strcpy(s4, s2);
				}				
			else
				{
				MakeIntegerVariable(s2);
				strcpy(s4, s2);
				}	
			if (isValue(s3))
				{	
				strcpy(s5, s3);
				}				
			else
				{
				MakeIntegerVariable(s3);
				strcpy(s5, s3);
				}	

			if (str_equal(cmd, "ADD"))
				fprintf(fmain, "if (out) %s= Add(%s, %s);\t\t// %s\n", s1, s4, s5, lineptr);
			if (str_equal(cmd, "SUB"))
				fprintf(fmain, "if (out) %s= Sub(%s, %s);\t\t// %s\n", s1, s4, s5, lineptr);
			if (str_equal(cmd, "MUL"))
				fprintf(fmain, "if (out) %s= Mul(%s, %s);\t\t// %s\n", s1, s4, s5, lineptr);
			if (str_equal(cmd, "DIV"))
				fprintf(fmain, "if (out) %s= Div(%s, %s);\t\t// %s\n", s1, s4, s5, lineptr);
			if (str_equal(cmd, "MOD"))
				fprintf(fmain, "if (out) %s= Mod(%s, %s);\t\t// %s\n", s1, s4, s5, lineptr);
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "RANDOM "))					// Random value contact
			{
			// Example:	RANDOM var
			sscanf(lineptr, "RANDOM %s", s1);					// s1= variable
			
			// Test if variables exist yet because sharable
			if (isValue(s1))
				{
				lad2c_error("Random parameter must be a variable");
				}				
			else
				{
				MakeIntegerVariable(s1);
				}

			fprintf(fmain, "if (out) %s= rand();\t\t// %s\n", s1), lineptr;
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "SEED_RANDOM "))					// Random init contact
			{													// Attached var is ignored
			// Example:	SEED_RANDOM var 100
			sscanf(lineptr, "SEED_RANDOM %s %s", s1, s2);					// s1= ignored variable, s2= init
			
			// Test if variables exist yet because sharable
			if (isValue(s2))
				{
				strcpy(s4, s2);
				}				
			else
				{
				MakeIntegerVariable(s2);
				strcpy(s4, s2);
				}

			fprintf(fmain, "if (out) srand(%s);\t\t// %s\n", s4, lineptr);
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if ((str_begin(lineptr, "AND ")) ||				// Binary instructions (Terminal only)
			(str_begin(lineptr, "OR ")) ||
			(str_begin(lineptr, "XOR ")) ||
			(str_begin(lineptr, "SHL ")) ||
			(str_begin(lineptr, "SHR ")) ||				// This is not a classic Shr
			(str_begin(lineptr, "SR0 ")) ||				// This is the classic Shr
			(str_begin(lineptr, "ROL ")) ||
			(str_begin(lineptr, "ROR ")))
			{
			// Example:	ADD destvar op1 op2
																	// cmd= AND / OR / XOR / SHL / SHR / SR0 / ROL / ROR
			sscanf(lineptr, "%s %s %s %s", cmd, s1, s2, s3);		// s1= dest, s2= op1, s3= op2

			// Test if variables exist yet because sharable
			if (isValue(s1))
				{
				lad2c_error("Binary instruction 1st parameter must be a variable");
				}
			else
				{
				MakeIntegerVariable(s1);
				}
			if (isValue(s2))
				{
				strcpy(s4, s2);
				}
			else
				{
				MakeIntegerVariable(s2);
				strcpy(s4, s2);
				}
			if (isValue(s3))
				{	
				strcpy(s5, s3);
				}
			else
				{
				MakeIntegerVariable(s3);
				strcpy(s5, s3);
				}

			if (str_equal(cmd, "AND"))
				fprintf(fmain, "if (out) %s= And(%s, %s);\t\t// %s\n", s1, s4, s5, lineptr);
			if (str_equal(cmd, "OR"))
				fprintf(fmain, "if (out) %s= Or(%s, %s);\t\t// %s\n", s1, s4, s5, lineptr);
			if (str_equal(cmd, "XOR"))
				fprintf(fmain, "if (out) %s= Xor(%s, %s);\t\t// %s\n", s1, s4, s5, lineptr);
			if (str_equal(cmd, "SHL"))
				fprintf(fmain, "if (out) %s= Shl(%s, (int) %s);\t\t// %s\n", s1, s4, s5, lineptr);
			if (str_equal(cmd, "SHR"))
				fprintf(fmain, "if (out) %s= Ssr(%s, (int) %s, 8*sizeof(%s));\t\t// %s\n", s1, s4, s5, s1, lineptr);
			if (str_equal(cmd, "SR0"))
				fprintf(fmain, "if (out) %s= Shr(%s, (int) %s);\t\t// %s\n", s1, s4, s5, lineptr);
			if (str_equal(cmd, "ROL"))
				fprintf(fmain, "if (out) %s= Rol(%s, (int) %s, 8*sizeof(%s));\t\t// %s\n", s1, s4, s5, s1, lineptr);
			if (str_equal(cmd, "ROR"))
				fprintf(fmain, "if (out) %s= Ror(%s, (int) %s, 8*sizeof(%s));\t\t// %s\n", s1, s4, s5, s1, lineptr);

			EnableContacts("BITOPS");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if ((str_begin(lineptr, "SET_BIT ")) ||				// Bit or Bcd instructions
			(str_begin(lineptr, "CLEAR_BIT ")) ||
			(str_begin(lineptr, "OPPOSITE ")) ||
			(str_begin(lineptr, "SWAP ")) ||
			(str_begin(lineptr, "BIN2BCD ")) ||
			(str_begin(lineptr, "BCD2BIN ")))
			{
			// Example:	SET_BIT var bit
			// Example: OPPOSITE dest srce
			// Example: SWAP dest srce
			// Example: BIN2BCD dest srce
																	// cmd= SET_BIT / CLEAR_BIT / OPPOSITE / SWAP
			sscanf(lineptr, "%s %s %s", cmd, s1, s2);				// s1= variable, s2= bit position

			// Test if variables exist yet because sharable
			if (isValue(s1))
				{
				lad2c_error("Bit / Bcd instruction 1st parameter must be a variable");
				}				
			else
				{
				MakeIntegerVariable(s1);
				}
			if (isValue(s2))
				{	
				strcpy(s4, s2);
				}				
			else
				{
				MakeIntegerVariable(s2);
				strcpy(s4, s2);
				}	

			if (str_equal(cmd, "SET_BIT"))
				fprintf(fmain, "if (out) SetBit(%s, (int) %s);\t\t// %s\n", s1, s4, lineptr);
			if (str_equal(cmd, "CLEAR_BIT"))
				fprintf(fmain, "if (out) ClrBit(%s, (int) %s);\t\t// %s\n", s1, s4, lineptr);
			if (str_equal(cmd, "OPPOSITE"))
				{
				fprintf(fmain, "if (out) %s= RevBits(%s, 8*sizeof(%s));\t\t// %s\n", s1, s4, s1, lineptr);
				EnableContacts("BITOPS");
				}
			if (str_equal(cmd, "SWAP"))
				{
				fprintf(fmain, "if (out) %s= SwapBits(%s, 8*sizeof(%s));\t\t// %s\n", s1, s4, s1, lineptr);
				EnableContacts("BITOPS");
				}
			if (str_equal(cmd, "BIN2BCD"))
				{
				fprintf(fmain, "if (out) %s= Bin2Bcd(%s);\t\t// %s\n", s1, s4, lineptr);
				EnableContacts("BCDOPS");
				}
			if (str_equal(cmd, "BCD2BIN"))
				{
				fprintf(fmain, "if (out) %s= Bcd2Bin(%s);\t\t// %s\n", s1, s4, lineptr);
				EnableContacts("BCDOPS");
				}
			
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "BUS "))				// Bus Tracer instruction
			{
			// Example:	BUS dest src 7 6 5 4 0 1 2 3

			sscanf(lineptr, "BUS %s %s %ld %ld %ld %ld %ld %ld %ld %ld", s1, s2, &p1, &p2, &p3, &p4, &q1, &q2, &q3, &q4);
			int bits[]= {p1, p2, p3, p4, q1, q2, q3, q4};

			// Test if variables exist yet because sharable
			if (isValue(s1))
				{
				lad2c_error("Bus tracer instruction destination parameter must be a variable");
				}				
			else
				{
				MakeIntegerVariable(s1);
				}
			if (isValue(s2))
				{	
				lad2c_error("Bus tracer instruction source parameter must be a variable");
				}				
			else
				{
				MakeIntegerVariable(s2);
				}	

			long swap= 0;
			for (int i= 0 ; i < 8 ; i++)
				{
				swap |= (bits[i] & 0x0F);
				if (i < 7) swap = swap << 4;
				}

			fprintf(fmain, "if (out) %s= BusTracer(%s, 0x%8.8lX);\t\t// %s\n", s1, s2, swap, lineptr);

			EnableContacts("BITOPS");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		// Warning:		Inserting Labels in parallel branches may cause a crash

		if (str_begin(lineptr, "LABEL "))					// Label in code
			{
			// Example:	LABEL label1
			sscanf(lineptr, "LABEL %s", s1);					// s1= label name

			fprintf(fmain, "Label_%s:\t// Label\n\n", s1);
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "GOTO "))					// Goto in code (Terminal instruction only)
			{
			// Example:	GOTO label1 
			// Example: GOTO 3
			sscanf(lineptr, "GOTO %s", s1);					// s1= label name / rung number

			if (str_equal(s1, "?")) lad2c_error("Invalid label");
			if (isValue(s1))		// GOTO rung
				{
				p1= atol(s1);
				if (p1 > NbRung) p1= 1;				// Rung number too high => Rung_1
				if (p1 == 0) p1= 0;					// Rung_0 means PlcInit()
				
				sprintf(s3, "Rung_%ld", p1);
				}				
			else					// GOTO label
				{
				sprintf(s3, "Label_%s", s1);
				}

			if (p1 >= 0)
				fprintf(fmain, "if (out) goto %s;\t// Goto\n", s3);
			else
				{
				if (!Configure_Reset(mcuisa, ffuncdef))			// Rung < 0 mean Reset()
					{
					lad2c_error("Reset configuration error !");
					retcode= 0;
					goto closeall;
					}

				fprintf(fmain, "if (out) Reset_Mcu();\t// Reset\n", s3);
				}
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		// Warning:		SubProg should be the only instruction on a rung

		if (str_begin(lineptr, "SUBPROG "))					// Subprogram declaration in code
			{
			// Example:	Subprog sub1
			sscanf(lineptr, "SUBPROG %s", s1);					// s1= subprog name

			if (str_equal(s1, "?")) lad2c_error("Invalid subprog name");

			fprintf(fmain, "// Cf Subprog_%s()\n", s1);

			ftmp= fmain;
			fmain= fsub;

			fprintf(fmain, "\nvoid Subprog_%s()\t// Subprog\n", s1);
			fprintf(fmain, "{\n");
			fprintf(fmain, "char out;\n");
			fprintf(fmain, "{\n");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		// Warning:		EndSub should be the only instruction on a rung

		if (str_begin(lineptr, "ENDSUB "))					// End of Subprogram declaration in code
			{												// Implies an implicit Return
			// Example:	Endsub sub1
			sscanf(lineptr, "ENDSUB %s", s1);					// s1= subprog name

			if (str_equal(s1, "?")) lad2c_error("Invalid subprogram end");

			fprintf(fmain, "return;\n");
			fprintf(fmain, "}\n");
			fprintf(fmain, "}\t// End of Subprog\n\n");

			fmain= ftmp;

			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_equal(lineptr, "RETURN"))					// Return of Subprogram in code (Terminal only)
			{
			// Example:	Return

 			fprintf(fmain, "if (out) return;\t// Return\n\n");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "GOSUB "))					// Call of Subprogram in code (Terminal only)
			{
			// Example:	Gosub sub1
			sscanf(lineptr, "GOSUB %s", s1);					// s1= subprog name

			if (str_equal(s1, "?")) lad2c_error("Invalid subprog call");

			fprintf(fmain, "if (out) Subprog_%s();\t// Call\n\n", s1);
			done= true;
			}


		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "DELAY "))					// Delay in �s
			{												
			// Example:	Delay time
			sscanf(lineptr, "DELAY %s", s1);					// s1= delay variable / value

			// Test if variables exist yet because sharable
			if (isValue(s1))
				{
				strcpy(s3, s1);
				}
			else
				{
				MakeIntegerVariable(s1);
				}

			fprintf(fmain, "if (out) delay_us(%s);\t\t// %s\n", s1, lineptr);
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "TIME2DELAY "))					// Convert value into variable
			{													// Not supported : use Move instead
			fprintf(fmain, "// T2Dly() : not supported\n");
			lad2c_error("Time to Delay instruction not supported !");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_equal(lineptr, "LOCK"))					// Lock �C in an infinite loop (Terminal only)
			{
			// Example: Lock

			fprintf(fmain, "Lock_%d: if (out) goto Lock_%d;\t// Lock\n\n", linenum, linenum);

			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "SLEEP"))					// Put �C in Sleep mode (Terminal only)
			{
			fprintf(fmain, "// Sleep() : not supported\n");
			lad2c_error("Sleep instruction not supported !");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_equal(lineptr, "CLRWDT"))					// Reset WatchDog (Terminal only)
			{
			fprintf(fmain, "// ClrWdt() : not supported\n");
			lad2c_error("Clear Watchdog instruction not supported !");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "PERSIST "))					// Save variable to EEprom if changed (Terminal only)
			{												// Variable is automatically loaded from EEprom at start time
			// Example:	Persist var
			sscanf(lineptr, "PERSIST %s", name);

			// Test if variables exist yet because sharable an multiply usable 
			if (isValue(s1))
				{
				lad2c_error("Persist instruction parameter must be a variable");
				}
			else
				{
				MakeIntegerVariable(name);
				}

			strcpy(s1, name); strcat(s1, "_old");
			int i= getVarfromList(s1);
			if (i == -1)
				{
				fprintf(fvardef, "Persist %s_rom;\n", name);
				fprintf(fvarinit, "Persist_Init(&%s_rom, &%s, %ld);\t\t// %s\n", name, name, eepromadr, lineptr);

				createVarforParam(s1, "integer");
				fprintf(fvardef, "integer %s= 0;\n", s1);
				eepromadr+= 4;								// For next persistant variable
				}
			
			p2= 0;
			int info= getInfofromMcu("mcu.desc.eeprom", s2);
			if (info != -1)
				{
				sscanf(s2, "%ld%c", &p2, &c2);		// Example 512B or 10K or 1M
				if (c2 == 'K') p2 *= 1024;
				if (c2 == 'M') p2 *= 1024*1024;
				}

			if ((p2 == 0) || (p2 < eepromadr))
				lad2c_error("EEPROM missing or insufficient");
	
			if (!Lib_rom)
				{
				fprintf(fintro, "#include \"Lib_rom.h\"\n");
				Lib_rom= 1;
				}

			fprintf(fmain, "out= Persist_Transfer(&%s_rom, out);\t\t// %s\n", name, lineptr);

			EnableContacts("PERSIST");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "QUAD_ENCOD "))				// Quadratic Encoder
			{												
			// Example:	QUAD_ENCOD qCount 0 XqA XqB XqZ Rqdir / 0	
			// Example:	QUAD_ENCOD qCount 0 XqA XqB XqZ Yqdir - 25	
			// Example:	QUAD_ENCOD qCount 0 XqA XqB (none) Rqdir / 0	
			// Example:	QUAD_ENCOD qCount 0 XqA XqB (none) (none) / 0	
			// Example:	QUAD_ENCOD qCount 0 XqA XqB XqZ (none) \ 100

			sscanf(lineptr, "QUAD_ENCOD %s %ld %s %s %s %s %c %ld", name, &p1, s1, s2, s3, s4, &c1, &p2);		
			// p1= 0 (ignored), s1= Io_A, s2= Io_B, s3= Io_Z, s4= dir relay, c1= Z mode, p2= revolution	

			// Test if variables created yet because sharable
			int i= getVarfromList(name);
			if ((i >= 0) && (VarStat[i] == 0)) 
				{
				VarStat[i]= 1;				
				fprintf(fvardef, "integer %s= 0;\n", name);
				q1= 1; q2= 1; q3= 1; q4= 1;
				}

			i= getIOfromList(s1);
			if (i >= 0)					// External Relay 'X' for input A
				{
				if (s1[0] != 'X') lad2c_error("Quad Encoder inputs must be X Relays");

				// Check if Relay has been created yet or exists forwardly
				if (IOStat[i] == 0)
					{
					q1= 1;
					sprintf(s5, "CONTACTS %s ", s1);
					int exist= searchContact(fname, s5);
					if (!exist)								// Insert a new Contact if need be
						{						
						createVarforParam(s1, "char", 0);

						strcat(s5, "0 0");
						strcpy(insline, s5);
						insert= 1;
						q1= 0;
						continue;
						}
					}
				}	

			i= getIOfromList(s2);
			if (i >= 0)					// External Relay 'X' for input B
				{
				if (s2[0] != 'X') lad2c_error("Quad Encoder inputs must be X Relays");

				// Check if Relay has been created yet or exists forwardly
				if (IOStat[i] == 0)
					{
					q2= 1;
					sprintf(s5, "CONTACTS %s ", s2);
					int exist= searchContact(fname, s5);
					if (!exist)								// Insert a new Contact if need be
						{						
						createVarforParam(s2, "char", 0);

						strcat(s5, "0 0");
						strcpy(insline, s5);
						insert= 1;
						q2= 0;
						continue;
						}			
					}
				}
		
			if (!str_equal(s3, "(none)"))			// Z input is used
				{
				i= getIOfromList(s3);
				if (i >= 0)					// External Relay 'X'
					{
					if (s3[0] != 'X') lad2c_error("Quad Encoder inputs must be X Relays");

					// Check if Relay has been created yet or exists forwardly
					if (IOStat[i] == 0)
						{
						q3= 1;
						sprintf(s5, "CONTACTS %s ", s3);
						int exist= searchContact(fname, s5);
						if (!exist)								// Insert a new Contact if need be
							{						
							createVarforParam(s3, "char", 0);

							strcat(s5, "0 0");
							strcpy(insline, s5);
							insert= 1;
							q3= 0;
							continue;
							}				
						}
					}
				}
			else q3= 0;			// Z input not used at all

			if (!str_equal(s4, "(none)"))			// Dir output is used
				{
				if (s4[0] == 'Y')						// External Coil 'Y'
					{
					i= getIOfromList(s4);
					if (i >= 0)	
						{					
						// Check if Coil has been created yet or exists forwardly
						if (IOStat[i] == 0)
							{
							sprintf(s5, "COIL %s ", s4);
							int exist= searchContact(fname, s5);
							if (!exist)								// Insert a new Coil if need be
								{						
								createVarforParam(s4, "char", 0);

								strcat(s5, "0 0 0 0");
								strcpy(insline, s5);
								insert= 1;
								continue;
								}				
							}
						}
					}
				else if(s4[0] == 'R')					// Internal Coil 'R'
					{
					// Check if Internal Coil has been created yet
					int i= getVarfromList(s4);
					if ((i >= 0) && ((VarStat[i] & 2) == 0))
						{
						fprintf(fvardef, "Coil C%s;\t\t// (Quad_encod %s dir output)\n", s4, name);
						if (VarStat[i] == 0) fprintf(fvardef, "char %s= 0;\n", s4);
						VarStat[i] |= 2;

						fprintf(fvarinit, "Coil_Init(&C%s, 'N', 'R', 0, &%s);\n", s4, s4);
						}
					if (i == -1)
						{
						createVarforParam(s4, "byte", 2);			// 2 means Coil

						fprintf(fvardef, "Coil C%s;\t\t// (Quad_encod %s output dir)\n", s4, name);
						fprintf(fvardef, "char %s= 0;\n", s4);
				
						fprintf(fvarinit, "Coil_Init(&C%s, 'N', 'R', 0, &%s);\n", s4, s4);
						}
					}
				else lad2c_error("Quad Encoder output dir must be Y or R Relay");
				}
			else q4= 0;		// Dir output not used
			
			fprintf(fvardef, "QuadEncoder %s_quad;\n", name);		// Leave after inserts

			if (s3[0] == 'X')
				{
				if (q4)
					fprintf(fvarinit, "QuadEncoder_Init(&%s_quad, &%s, &%s, &%s, '%c', %ld, &%s, &C%s);\t\t// %s\n", name, s1, s2, s3, c1, p2, name, s4, lineptr);						
				else
					fprintf(fvarinit, "QuadEncoder_Init(&%s_quad, &%s, &%s, &%s, '%c', %ld, &%s, NULL);\t\t// %s\n", name, s1, s2, s3, c1, p2, name, lineptr);					
				}
			else
				{
				if (q4)
					fprintf(fvarinit, "QuadEncoder_Init(&%s_quad, &%s, &%s, NULL, '%c', %ld, &%s, &C%s);\t\t// %s\n", name, s1, s2, c1, p2, name, s4, lineptr);
				else										
					fprintf(fvarinit, "QuadEncoder_Init(&%s_quad, &%s, &%s, NULL, '%c', %ld, &%s, NULL);\t\t// %s\n", name, s1, s2, c1, p2, name, lineptr);
				}
			
			if (q1)		// Automatic if Relay created localy by insertion
				fprintf(fmain, "*(R%s.bitptr)= R%s_readinput();\n", s1, s1);	// Read input A
			if (q2)		// Automatic if Relay created localy by insertion
				fprintf(fmain, "*(R%s.bitptr)= R%s_readinput();\n", s2, s2);	// Read input B
			if (q3)		// Automatic if Relay created localy by insertion
				fprintf(fmain, "*(R%s.bitptr)= R%s_readinput();\n", s3, s3);	// Read input Z

			fprintf(fmain, "out= QuadEncoder_Transfer(&%s_quad, out);\t\t// %s\n", name, lineptr);

			if (s4[0] == 'Y')
				fprintf(fmain, "C%s_writebit(*(C%s.bitptr));\n", s4, s4);		// Set output dir pin

			EnableContacts("QUADENCOD");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "PULSER "))				// Pulser
			{							
			// Example:	PULSER 3 1 2 counter Ypulse
			// Example:	PULSER d1 d0 mul c10 Ypulse

			sscanf(lineptr, "PULSER %s %s %s %s %s", s1, s2, s3, s4, s5);
			// s1= 1 duration, s2= 0 duration, s3= multiplier, s4= repeat count, S5= output coil

			int i= getIOfromList(s5);
			if (i >= 0)					// External Coil 'Y' for output
				{
				if (s5[0] != 'Y') lad2c_error("Pulser output must be Y Relay");

				// Check if Relay has been created yet or exists forwardly
				if (IOStat[i] == 0)
					{
					sprintf(s6, "COIL %s ", s5);
					int exist= searchContact(fname, s6);
					if (!exist)								// Insert a new Contact if need be
						{						
						createVarforParam(name, "char", 0);

						strcat(s6, "0 0");
						strcpy(insline, s6);
						insert= 1;
						continue;
						}
					}
				}	

			pulsenum++;
			sprintf(name, "pulser_%d", pulsenum);
			fprintf(fvardef, "Pulser %s;\n", name);		// Leave after inserts

			// Test if variables created yet because sharable
			if (isValue(s1))
				{
				p1= atol(s1);
				strcpy(s1, name); strcat(s1, "_d1");
				createVarforParam(s1, "integer");
				fprintf(fvardef, "integer %s= %ld;\n", s1, p1);
				}				
			else
				{
				MakeIntegerVariable(s1);
				}
			if (isValue(s2))
				{
				p2= atol(s2);
				strcpy(s2, name); strcat(s2, "_d0");
				createVarforParam(s2, "integer");
				fprintf(fvardef, "integer %s= %ld;\n", s2, p2);
				}				
			else
				{
				MakeIntegerVariable(s2);
				}
			if (isValue(s3))
				{
				p3= atol(s3);
				strcpy(s3, name); strcat(s3, "_mul");
				createVarforParam(s3, "integer");
				fprintf(fvardef, "integer %s= %ld;\n", s3, p3);
				}				
			else
				{
				MakeIntegerVariable(s4);
				}
			if (isValue(s4))
				{
				p4= atol(s4);
				strcpy(s4, name); strcat(s4, "_cnt");
				createVarforParam(s4, "integer");
				fprintf(fvardef, "integer %s= %ld;\n", s4, p4);
				}				
			else
				{
				MakeIntegerVariable(s4);
				}
	
			fprintf(fvarinit, "Pulser_Init(&pulser_%d, &%s, &%s, &%s, &%s, &%s);\t\t// %s\n", pulsenum, s1, s2, s3, s4, s5, lineptr);
			
			fprintf(fmain, "out= Pulser_Transfer(&%s, out);\t\t// %s\n", name, lineptr);
			if (s5[0] == 'Y')
				fprintf(fmain, "C%s_writebit(%s);\n", s5, s5);		// Set output

			EnableContacts("PULSE");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

/*
		if (str_begin(lineptr, "STEPPER "))				// Stepper		CONTACT + DOC A VOIR
			{							
			// Example:	STEPPER name steps Ystep Ydir

			sscanf(lineptr, "STEPPER %s %s %s %s", name, s1, s2, s3);
			// s1= steps (< 0, 0, > 0), s2= step output, s3= dir output

			int i= getIOfromList(s2);
			if (i >= 0)					// External Coil 'Y' for output
				{
				if (s2[0] != 'Y') lad2c_error("Stepper outputs must be Y Relays");

				// Check if Relay has been created yet or exists forwardly
				if (IOStat[i] == 0)
					{
					sprintf(s4, "COIL %s ", s2);
					int exist= searchContact(fname, s4);
					if (!exist)								// Insert a new Contact if need be
						{						
						createVarforParam(name, "char", 0);

						strcat(s4, "0 0");
						strcpy(insline, s4);
						insert= 1;
						continue;
						}
					}
				}	

			i= getIOfromList(s3);
			if (i >= 0)					// External Coil 'Y' for output
				{
				if (s3[0] != 'Y') lad2c_error("Stepper outputs must be Y Relays");

				// Check if Relay has been created yet or exists forwardly
				if (IOStat[i] == 0)
					{
					sprintf(s5, "COIL %s ", s3);
					int exist= searchContact(fname, s5);
					if (!exist)								// Insert a new Contact if need be
						{						
						createVarforParam(name, "char", 0);

						strcat(s5, "0 0");
						strcpy(insline, s5);
						insert= 1;
						continue;
						}
					}
				}	

			fprintf(fvardef, "Stepper %s_stp;\n", name);		// Leave after inserts

			// Test if variables created yet because sharable
			if (isValue(s1))
				{
				p1= atol(s1);
				strcpy(s1, name); strcat(s1, "_val");
				createVarforParam(s1, "integer");
				fprintf(fvardef, "integer %s= %ld;\n", s1, p1);
				}				
			else
				{
				MakeIntegerVariable(s1);
				}
	
			fprintf(fvarinit, "Stepper_Init(&%s_stp, &%s, &%s, &%s);\t\t// %s\n", name, s1, s2, s3);

			fprintf(fmain, "out= Stepper_Transfer(&%s_stp, out);\t\t// %s\n", name, lineptr);
			fprintf(fmain, "C%s_writebit(%s);\n", s2, s2);		// Set step output
			fprintf(fmain, "C%s_writebit(%s);\n", s3, s3);		// Set dir output

			EnableContacts("STEP");
			done= true;
			}
*/

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "STRING "))				// Formatted (or not) string
			{							
			// Example:	STRING dest var format
			// Example: STRING dest var "X= %d\n"		// String will receive "X= <var>\n"

			sscanf(lineptr, "STRING %s %s ", s1, s2);
			// s1= next char in string, s2= srce var or value, name= formatted string (like printf)
			// Beware: last string may contain spaces !
			sprintf(s3, "STRING %s %s ", s1, s2);
			p3= strlen(s3);
			strcpy(name, lineptr+p3);
			// Use name instead of s3 because bigger capacity !
			
			// Test if variables created yet because sharable
			if (isValue(s1))
				{
				lad2c_error("String destination parameter must be a variable");
				}				
			else
				{
				MakeCharVariable(s1);

				// Final string size= string size + integer size (6 / 12 digits max)
				fprintf(fvardef, "unsigned char %s_stg[%d]= \"\";\n", s1, strlen(name) + 3*sizeof(integer));
				}

			if (isValue(s2))
				{
				p2= atol(s2);
				strcpy(s2, s1); strcat(s2, "_var");
				createVarforParam(s2, "integer");
				fprintf(fvardef, "integer %s= %ld;\n", s2, p2);			
				}
			else if (str_equal(s2, "(none)"))			// No parameter to substitute
				{
				strcpy(s2, "NULL");
				}
			else
				{
				MakeIntegerVariable(s2);
				}
			if (isValue(name))		// Type is array => convert to string
				{
				sscanf(name, "%s ", s3);
				p3= atol(s3);
				p= strlen(s3)+1;

				for (long i= 0 ; i < p3 ; i++)
					{
					sscanf(name+p, "%s ", s4);
					p+= strlen(s4)+1;
					p4= atol(s4);
					newline[i]= (char) p4;
					}
				newline[p3]= NUL;

				strcpy(name, newline);
				}			

			// Process string if formatted with %				
			int j= 0;
			for (int i= 0 ; i <= strlen(name) ; i++)	// <= on purpose !
				{
				if (name[i] == '%')						// '%' in name mustn't be interpreted by compiler => '%%'
					{
					newline[j]= '%'; newline[j+1]= '%';
					j+= 2;
					}
				else if (name[i] == '\\')				// '\' are duplicated by ldmicro => '\'
					{
					newline[j]= '\\';
					if (name[i+1] == '\\') i++;
					j++;
					}
				else
					{
					newline[j]= name[i];
					j++;
					}
				}				

			fprintf(fvardef, "unsigned char %s_fmt[]= \"%s\";\n", s1, newline);
			fprintf(fvardef, "FormatString fmtstg_%d;\n", linenum);

			strcpy(lineptr, s3);		// To replace lineptr because of % interpretation by compiler
			strcat(lineptr, newline);

			if (str_equal(s2, "NULL"))
				fprintf(fvarinit, "FormatString_Init(&fmtstg_%d, %s_fmt, %s_stg, NULL, &%s);\t\t// %s\n", linenum, s1, s1, s1, lineptr);
			else
				fprintf(fvarinit, "FormatString_Init(&fmtstg_%d, %s_fmt, %s_stg, &%s, &%s);\t\t// %s\n", linenum, s1, s1, s2, s1, lineptr);
			
			fprintf(fmain, "if (out) out= FormatString_Transfer(&fmtstg_%d, out);\t\t// %s\n", linenum, lineptr);

			EnableContacts("STRING");
			done= true;
			}


		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "SHIFT_REGISTER "))				// Shift Register Array (Terminal only)
			{												
			// Example:	SHIFT_REGISTER reg 8

			sscanf(lineptr, "SHIFT_REGISTER %s %ld", name, &p1);
			// p1= array size

			if (isValue(name))			// Possible in ldmicro !
				{
				lad2c_error("Shift register 1st parameter must be a variable");
				}				
			else
				{
				for (long k= 0 ; k < p1 ; k++)
					{
					sprintf(s1, "%s%ld", name, k);		// Array is reg0, ... , reg7

					MakeIntegerVariable(s1);
					}

				fprintf(fvardef, "integer * %s_shr[]= {", name);
				for (long k= 0 ; k < p1 ; k++)
					{
					if (k+1 < p1) fprintf(fvardef, "&%s%d, ", name, k);
					else fprintf(fvardef, "&%s%d", name, k);
					}
				fprintf(fvardef, "};\n");

				fprintf(fvardef, "ShiftRegister %s_shr;\n", name);
				}	

			fprintf(fvarinit, "ShiftRegister_Init(&%s_shr, %ld, %s_shr);\t\t// %s\n", name, p1, name, lineptr);

			fprintf(fmain, "out= ShiftRegister_Transfer(&%s_shr, out);\t\t// %s\n", name, lineptr);

			EnableContacts("SHIFTREG");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "PIECEWISE_LINEAR "))				// Piecewide linear table (Terminal only)
			{												
			// Example:	PIECEWISE_LINEAR dest srce 3 0 0 1 1 2 2

			sscanf(lineptr, "PIECEWISE_LINEAR %s %s %ld ", s1, s2, &p1);
			// s1= dest value, s2= srce value (cte or variable), p1= nb of (X,Y) couples to follow

			int p= str_back(lineptr, ' ');		// Name is stupidely at the end
			strcpy(name, lineptr+p+1);

			fprintf(fvardef, "PiecewiseLinear %s_pwl;\n", name);

			p= strlen(s1)+strlen(s2)+19;		// Position of p1 parameter
			sscanf(lineptr+p, "%s", s3);
			p+= strlen(s3)+1;					// Position of first X value

			fprintf(fvardef, "integer %s_x[%ld]= {", name, p1);		// Create X values table
			for (int i= 0 ; i < p1 ; i++)
				{
				sscanf(lineptr+p, "%s %s", s3, s4);
				p+= strlen(s3)+strlen(s4)+2;

				fprintf(fvardef, "%s", s3);				// X value
				if (i+1 < p1) fprintf(fvardef, ",");
				}
			fprintf(fvardef, "};\n");

			p= strlen(s1)+strlen(s2)+19;		// Position of p1 parameter
			sscanf(lineptr+p, "%s", s3);
			p+= strlen(s3)+1;					// Position of first X value

			fprintf(fvardef, "integer %s_y[%ld]= {", name, p1);		// Create Y values table
			for (int i= 0 ; i < p1 ; i++)
				{
				sscanf(lineptr+p, "%s %s", s3, s4);
				p+= strlen(s3)+strlen(s4)+2;

				fprintf(fvardef, "%s", s4);				// Y value
				if (i+1 < p1) fprintf(fvardef, ",");
				}
			fprintf(fvardef, "};\n");

			if (isValue(s1))
				{
				lad2c_error("Piecewise Linear destination parameter must be a variable");
				}				
			else
				{
				MakeIntegerVariable(s1);
				}	
			if (isValue(s2))
				{
				p2= atol(s2);
				strcpy(s2, name); strcat(s2, "_src");
				createVarforParam(s2, "integer");
				fprintf(fvardef, "integer %s= %ld;\n", s2, p2);
				}				
			else
				{
				MakeIntegerVariable(s2);
				}	

			fprintf(fvarinit, "PiecewiseLinear_Init(&%s_pwl, %ld, &%s, &%s, %s_x, %s_y);\t\t// %s\n", name, p1, s1, s2, name, name, lineptr);

			fprintf(fmain, "out= PiecewiseLinear_Transfer(&%s_pwl, out);\t\t// %s\n", name, lineptr);

			EnableContacts("PLTAB");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "LOOK_UP_TABLE "))				// Look Up table = Array (Terminal only)
			{												
			// Example:	LOOK_UP_TABLE dest index 5 0 1 3 5 7 9 table

			sscanf(lineptr, "LOOK_UP_TABLE %s %s %ld %ld ", s1, s2, &p1, &p2);
			// s1= dest value, s2= index (cte or variable), p1= array size, p2= type

			int p= str_back(lineptr, ' ');		// Name is stupidely at the end
			strcpy(name, lineptr+p+1);

			fprintf(fvardef, "LookUp %s_lut;\n", name);

			p= strlen(s1)+strlen(s2)+16;				// Position of p1 parameter
			sscanf(lineptr+p, "%s %s ", s3, s4);
			p+= strlen(s3)+strlen(s4)+2;				// Position of first value

			if (p2 == 0)		// Type is Array
				{
				fprintf(fvardef, "integer %s[%ld]= {", name, p1);		// Create integer values table
				for (int i= 0 ; i < p1 ; i++)
					{
					sscanf(lineptr+p, "%s ", s3);
					p+= strlen(s3)+1;

					fprintf(fvardef, "%s", s3);				// value
					if (i+1 < p1) fprintf(fvardef, ",");
					}
				fprintf(fvardef, "};\n");

				c1= 'L';
				}
			if (p2 == 1)		// Type is String
				{
				fprintf(fvardef, "char %s[%ld]= {", name, p1);		// Create char String
				for (int i= 0 ; i < p1 ; i++)
					{
					sscanf(lineptr+p, "%s ", s3);
					p+= strlen(s3)+1;

					fprintf(fvardef, "%s", s3);				// value
					if (i+1 < p1) fprintf(fvardef, ",");
					}
				fprintf(fvardef, "};\n");

				c1= 'C';
				}

			if (isValue(s1))
				{
				lad2c_error("Look Up table destination parameter must be a variable");
				}				
			else
				{
				MakeIntegerVariable(s1);
				}	
			if (isValue(s2))
				{
				p2= atol(s2);
				strcpy(s2, name); strcat(s2, "_ind");
				createVarforParam(s2, "integer");
				fprintf(fvardef, "integer %s= %ld;\n", s2, p2);
				}				
			else
				{
				MakeIntegerVariable(s2);
				}	

			fprintf(fvarinit, "LookUp_Init(&%s_lut, '%c', %ld, &%s, &%s, %s);\t\t// %s\n", name, c1, p1, s1, s2, name, lineptr);

			fprintf(fmain, "out= LookUp_Transfer(&%s_lut, out);\t\t// %s\n", name, lineptr);

			EnableContacts("LUTAB");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "MODBUS "))				// Modbus (Communication with PLC)
			{												
			// Example:	MODBUS name uart speed timout mode pdata count 
			// Example: MODBUS Plc1 1 9600 0 S pdata cnt

			sscanf(lineptr, "MODBUS %s %ld %ld %ld %c %s %s", name, &p1, &p2, &p3, &c1, s1, s2);
			// p1= uart (1 ...)
			// p2= uart speed (9600 ...)
			// p3= timout on receive value (0 to use default value)
			// c1= mode ('S', 'R', 'E', 'D')
			// s1= data (Look Up table))
			// s2= data size variable
			
			if (isValue(s1))		// data to send / receive
				{
				if ((c1 == 'S') || (c1 == 'R'))
					lad2c_error("Modbus data parameter must be a LUT destination variable");
				}	
			else
				{
				fprintf(fvardef, "char %s[sizeof(%s)/sizeof(integer)]= \"\";\n", name, s1);		// Create char String to receive integer table			
				}

			if (isValue(s2))
				{
				if ((c1 == 'S') || (c1 == 'R'))
					lad2c_error("Modbus count parameter must be a variable");		// Modified when sent / received
				}				
			else
				{
				MakeIntegerVariable(s2);
				}	

			if (!Lib_modbus)
				{
				fprintf(fintro, "#include \"Lib_modbus.h\"\n");

				ftmp= fopen("Input/modbus_stm32f4.c", "r+t");
				if (ftmp == NULL) 
					{
					lad2c_error("Error accessing modbus handler C file");
					retcode= 0;
					goto closeall;
					}
				else		// Create modbus uart interrupt handler
					{
					while (fgets(newline, sizeof(newline)-1, ftmp) != NULL)
						{
						fprintf(ftime, newline, (int) p1, (int) p1);
						}

					fclose(ftmp);
					}

				Lib_modbus= 1;
				}

			fprintf(fvardef, "Modbus %s_mdb;\n", name);

			fprintf(fvarinit, "Modbus_Init(&%s_mdb, %ld, %ld, %ld);\t\t// %s\n", name, p1, p2, p3, lineptr);

			if ((c1 == 'S')	|| (c1 == 'R'))	// data to send / receive must be a LUT variable
				fprintf(fmain, "out= Modbus_Transfer(&%s_mdb, &%s_lut, '%c', %s, &%s, out);\t\t// %s\n", name, s1, c1, name, s2, lineptr);
			if ((c1 == 'E') || (c1 == 'D'))
				fprintf(fmain, "out= Modbus_Transfer(&%s_mdb, &%s_lut, '%c', NULL, NULL, out);\t\t// %s\n", name, s1, c1, lineptr);

			EnableContacts("MODBUS");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		if ((str_begin(lineptr, "7SEGMENTS ")) ||				// 7 Segt display
			(str_begin(lineptr, "9SEGMENTS ")) ||				// 9 Segt display
			(str_begin(lineptr, "14SEGMENTS ")) ||				// 14 Segt display
			(str_begin(lineptr, "16SEGMENTS ")))				// 16 Segt display
			{												 
			// Example:	7SEGMENTS dest index A
			// Example:	9SEGMENTS dest index C
			// Example:	14SEGMENTS dest index A
			// Example:	16SEGMENTS dest index C
				 
			sscanf(lineptr, "%ld%s %s %s %c", &p1, name, s1, s2, &c1);
			// s1= dest value, s2= index (cte or variable), c1= common 'A' or 'C'

			if (p1 == 7)
			fprintf(fvardef, 
				"char Codes7Seg[129]= {0x3F, 0x6, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x7, 0x7F, 0x6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71, 0xBF, 0x86, 0xDB,\n \
				0xCF, 0xE6, 0xED, 0xFD, 0x87, 0xFF, 0xEF, 0xF7, 0xFC, 0xB9, 0xDE, 0xF9, 0xF1, 0x0, 0xB0, 0x22, 0x4E, 0x6D, 0xD2, 0xDA, 0x20, 0x39,\n \
				0xF, 0x72, 0x70, 0xC, 0x40, 0x80, 0x52, 0x3F, 0x6, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x7, 0x7F, 0x6F, 0x9, 0xD, 0x61, 0x41, 0x43, 0xD3,\n \
				0x9F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71, 0x3D, 0x74, 0x30, 0x1E, 0x75, 0x38, 0x55, 0x54, 0x5C, 0x73, 0x67, 0x33, 0x6D, 0x78, 0x3E,\n \
				0x1C, 0x6A, 0x76, 0x6E, 0x5B, 0x39, 0x64, 0xF, 0x23, 0x8, 0x20, 0x5F, 0x7C, 0x58, 0x5E, 0x7B, 0x71, 0x6F, 0x74, 0x10, 0xE, 0x75,\n \
				0x18, 0x55, 0x54, 0x5C, 0x73, 0x67, 0x50, 0x6D, 0x78, 0x3E, 0x1C, 0x6A, 0x76, 0x6E, 0x5B, 0x39, 0x30, 0xF, 0x1, 0x0, 0x63};\n\n");

			if (p1 == 9)
			fprintf(fvardef, 
				"short Codes9Seg[129]= {0x33F, 0x106, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x7, 0x7F, 0x6F, 0x77, 0x17D, 0x39, 0x5E, 0x79, 0x71, 0x3BF, 0x186, 0xDB,\n \
				0xCF, 0xE6, 0xED, 0xFD, 0x87, 0xFF, 0xEF, 0xF7, 0x1FD, 0xB9, 0xDE, 0xF9, 0xF1, 0x0, 0xB0, 0x120, 0x404E, 0x6D, 0xD2, 0xDA, 0x100, 0x39,\n \
				0xF, 0x72, 0x340, 0x200, 0x40, 0x80, 0x300, 0x33F, 0x106, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x7, 0x7F, 0x6F, 0x9, 0x201, 0x61, 0x41, 0x43,\n \
				0xD3, 0x9F, 0x77, 0x17D, 0x39, 0x5E, 0x79, 0x71, 0x3D, 0x74, 0x30, 0x1E, 0x75, 0x38, 0x55, 0x54, 0x3F, 0x73, 0x67, 0x33, 0x6D, 0x78,\n \
				0x3E, 0x330, 0x6A, 0x4364, 0x6E, 0x4349, 0x39, 0x64, 0xF, 0x102, 0x8, 0x20, 0x5F, 0x7C, 0x58, 0x5E, 0x7B, 0x171, 0x6F, 0x74, 0x10, 0xE,\n \
				0x75, 0x18, 0x55, 0x54, 0x5C, 0x73, 0x67, 0x50, 0x6D, 0x78, 0x3E, 0x210, 0x6A, 0x4364, 0x6E, 0x309, 0x39, 0x30, 0xF, 0x1, 0x0, 0x63};\n\n");

			if (p1 == 14)
			fprintf(fvardef, 
				"short Codes14Seg[129]= {0x33F, 0x106, 0x405B, 0x404F, 0x4066, 0x406D, 0x407D, 0x7, 0x407F, 0x406F, 0x4077, 0x680F, 0x39, 0x280F, 0x79, 0x71,\n \
				0x3BF,0x186, 0x40DB, 0x40CF, 0x40E6, 0x40ED, 0x40FD, 0x87, 0x40FF, 0x40EF, 0x40F7, 0x688F, 0xB9, 0x288F, 0xF9, 0xF1, 0x0, 0x2880, 0x820,\n \
				0x684E, 0x686D, 0x5764, 0x5459, 0x100, 0x1100, 0x600, 0x7F40, 0x6840, 0x200, 0x4040, 0x80, 0x300, 0x33F, 0x106, 0x405B, 0x404F, 0x4066,\n \
				0x406D, 0x407D, 0x7, 0x407F, 0x406F, 0x9, 0x201, 0x4061, 0x4041, 0x4043, 0x6083, 0x205F, 0x4077, 0x417D, 0x39, 0x280F, 0x79, 0x71, 0x403D,\n \
				0x4076, 0x2809, 0x1E, 0x1170, 0x38, 0x536, 0x1436, 0x3F, 0x4073, 0x103F, 0x5073, 0x406D, 0x2801, 0x3E, 0x330, 0x1236, 0x1700, 0x2500, 0x4349,\n \
				0x39, 0x1400, 0xF, 0x102, 0x8, 0x400, 0xA058, 0x1078, 0x4058, 0x420E, 0x258, 0x4171, 0x440F, 0x4074, 0x10, 0xE, 0x5070, 0x18, 0x6054, 0x1050,\n \
				0x405C, 0x171, 0x4407, 0x4050, 0x5008, 0x78, 0x1C, 0x210, 0x1214, 0x5240, 0x440E, 0x248, 0x1140, 0x2800, 0x4600, 0x1, 0x0, 0x63};\n\n");

			if (p1 == 16)
			fprintf(fvardef, 
				"integer Codes16Seg[129]= {0x1833F, 0x106, 0x1C05B, 0x1C04F, 0x4066, 0x1C06D, 0x1C07D, 0x10007, 0x1C07F, 0x1C06F, 0x4077, 0x680F, 0x39, 0x280F, 0x79,\n \
				0x71, 0x183BF, 0x186, 0x1C0DB, 0x1C0CF, 0x40E6, 0x1C0ED, 0x1C0FD, 0x10087, 0x1C0FF, 0x1C0EF, 0x40F7, 0x688F, 0xB9, 0x288F, 0xF9, 0xF1, 0x0, 0x2880,\n \
				0x820, 0xE84E, 0x1E86D, 0x5764, 0x1D459, 0x100, 0x1100, 0x600, 0x7F40, 0x6840, 0x200, 0x4040, 0x80, 0x300, 0x1833F, 0x106, 0x1C05B, 0x1C04F, 0x4066,\n \
				0x1C06D, 0x1C07D, 0x10007, 0x1C07F, 0x1C06F, 0x9, 0x201, 0x14061, 0x14041, 0x14043, 0x16083, 0x1A05F, 0x14077, 0x1C17D, 0x18039, 0x1A80F, 0x18079, 0x10071,\n \
				0x1C03D, 0x4076, 0x1A809, 0x801E, 0x1170, 0x8038, 0x536, 0x1436, 0x1803F, 0x14073, 0x1903F, 0x15073, 0x1C06D, 0x12801, 0x803E, 0x330, 0x1236, 0x1700, 0x2500,\n \
				0x1C349, 0x1A800, 0x1400, 0x2809, 0x102, 0x8008, 0x400, 0xA058, 0x9078, 0xC058, 0xC20E, 0x8258, 0x16840, 0x1C40F, 0x4074, 0x10, 0xA006, 0x5070, 0x8018, 0x6054,\n \
				0x1050, 0xC05C, 0x10171, 0x14407, 0x4050, 0xD008, 0xE840, 0x801C, 0x210, 0x1214, 0x5240, 0xC40E, 0x8248, 0x1A840, 0x2800, 0x6809, 0x10001, 0x0, 0x63};\n\n");

			if (isValue(s1))
				{
				lad2c_error("Segment display converter destination parameter must be a variable");
				}				
			else
				{
				MakeIntegerVariable(s1);
				}	
			if (!isValue(s2))
				{
				MakeIntegerVariable(s2);
				}	

			fprintf(fmain, "out= Seg%ld_Convert(Codes%ldSeg, &%s, %s, '%c', out);\t\t// %s\n", p1, p1, s1, s2, c1, lineptr);

			EnableContacts("DISPLAY");
			done= true;
			}

		////////////////////////////////////////////////////////////////////////////////////////

		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "READ_ADC "))					// ADC
			{												
			// Example:	Read_Adc Ain refs
			sscanf(lineptr, "READ_ADC %s %s", s1, s2);			// s1= dest variable, s2= refs (for PICs)

			// Adc input is declared as an IO to determine pin, not as a variable
			if (isValue(s1))
				{
				lad2c_error("ADC destination parameter must be a variable");
				}				
			else
				{
				MakeIntegerVariable(s1);
				}
			if (!isValue(s2))
				{
				lad2c_error("ADC refs parameter must be a value");
				strcpy(s2, "0");
				}

			if (!Configure_Adc(mcuisa, s1, s2, fhead, ffuncdef, fdevice, lineptr))
				{
				lad2c_error("ADC configuration error !");
				retcode= 0;
				goto closeall;
				}

			fprintf(fmain, "if (out) %s= Read_%s();\t\t// %s\n", s1, s1, lineptr);
			done= true;
			}


		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "SET_PWM "))					// PWM
			{												
			// Example:	Set_Pwm duty frequency name resolution
			sscanf(lineptr, "SET_PWM %s %s %s %s", s1, s2, s3, s4);		// s1= duty, s2= frequency, s3= name, s4= resolution

			// Pwm output (name) is declared as an IO to determine pin
			if (isValue(s1))
				{
				p1= atol(s1);
				}				
			else
				{
				MakeIntegerVariable(s1);
				}
			if (isValue(s2))
				{
				p2= atoi(s2);
				}
			else
				{
				lad2c_error("PWM frequency must be a value");
				}

			if (!Configure_Pwm(mcuisa, s3, p2, fhead, ffuncdef, fdevice, lineptr))
				{
				lad2c_error("PWM configuration error !");
				retcode= 0;
				goto closeall;
				}

			fprintf(fmain, "if (out) Pwm_%s(%ld, %s);\t\t// %s\n", s3, p2, s1, lineptr);
			done= true;
			}


		////////////////////////////////////////////////////////////////////////////////////////

		if ((str_begin(lineptr, "UART_SEND"))  || (str_begin(lineptr, "UART_RECV")))		// UART Send / Receive
			{																				// UART Send_Ready / Receive_avail
			// Example:	Uart_Send value nb wait
			// Example:	Uart_Recv var nb wait
			// Example:	Uart_Send_Ready
			// Example:	Uart_Recv_Avail

			char uart_func= 0;
			if (str_begin(lineptr, "UART_SEND ")) uart_func= 'S';
			if (str_begin(lineptr, "UART_RECV ")) uart_func= 'R';
			if (str_begin(lineptr, "UART_SEND_READY")) uart_func= 'Y';
			if (str_begin(lineptr, "UART_RECV_AVAIL")) uart_func= 'A';

			strcpy(s1, "0"); strcpy(s2, "0"); strcpy(s3, "0"); 
			sscanf(lineptr+9, "%s %s %s", s1, s2, s3);	
			// s1= variable, s2= nb octets (1 to 4), s3= wait or not (0 or 1)

			if (isValue(s1))
				{
				if (uart_func == 'R')
					lad2c_error("UART_RECV destination parameter must be a variable");
				}				
			else
				{
				if ((uart_func == 'S') || (uart_func == 'R'))
					MakeIntegerVariable(s1);
				}
			if (isValue(s2))
				{
				p2= atol(s2);
				}
			else
				{
				if ((uart_func == 'R') || (uart_func == 'S'))
					lad2c_error("UART_RECV / SEND byte count must be a value");			// Must be 1 to 4
				}
			if (isValue(s3))
				{
				p3= atol(s3);
				}
			else
				{
				if ((uart_func == 'R') || (uart_func == 'S'))
					lad2c_error("UART_RECV / SEND wait status must be a value");		// Must be 0 or 1
				}

			if (!Configure_Uart(mcuisa, Baud, fhead, ffuncdef, fdevice, lineptr))
				{
				lad2c_error("UART configuration error !");
				retcode= 0;
				goto closeall;
				}

			if (uart_func == 'S')		// Send 1 to 4 bytes
				{
				if (p2 >= 1)
					{
					if (p3) fprintf(fmain, "if (out) while (!Uart_Transmit_Ready());\n");
					fprintf(fmain, "if (out) Uart_Transmit(%s);\t\t// %s\n", s1, lineptr);					
					}
				if (p2 >= 2)
					{					
					if (p3) fprintf(fmain, "if (out) while (!Uart_Transmit_Ready());\n");
					fprintf(fmain, "if (out) Uart_Transmit(%s >> 8);\n", s1);
					}

				if (p2 >= 3)
					{
					if (p3) fprintf(fmain, "if (out) while (!Uart_Transmit_Ready());\n");
					fprintf(fmain, "if (out) Uart_Transmit(%s >> 16);\n", s1);
					}
				if (p2 >= 4)
					{					
					if (p3) fprintf(fmain, "if (out) while (!Uart_Transmit_Ready());\n");
					fprintf(fmain, "if (out) Uart_Transmit(%s >> 24);\n", s1);
					}
				}
			if (uart_func == 'R')		// Receive 1 to 4 bytes
				{
				if (p2 >= 1)
					{					
					if (p3) fprintf(fmain, "if (out) %s= Uart_Receive();\t\t// %s\n", s1, lineptr);
					else fprintf(fmain, "if (out && Uart_Receive_Avail()) %s= Uart_Receive();\t\t// %s\n", s1, lineptr);
					fprintf(fmain, "else out= 0;\n");
					}
				if (p2 >= 2)
					{					
					if (p3) fprintf(fmain, "if (out) %s |= Uart_Receive() << 8;\n");
					else fprintf(fmain, "if (out && Uart_Receive_Avail()) %s |= Uart_Receive() << 8;\n", s1);
					fprintf(fmain, "else out= 0;\n");
					}
				if (p2 >= 3)
					{					
					if (p3) fprintf(fmain, "if (out) %s |= Uart_Receive() << 16;\n");
					else fprintf(fmain, "if (out && Uart_Receive_Avail()) %s |= Uart_Receive() << 16;\n", s1);
					fprintf(fmain, "else out= 0;\n");
					}
				if (p2 >= 4)
					{					
					if (p3) fprintf(fmain, "if (out) %s |= Uart_Receive() << 24;\n");
					else fprintf(fmain, "if (out && Uart_Receive_Avail()) %s |= Uart_Receive() << 24;\n", s1);
					fprintf(fmain, "else out= 0;\n");
					}
				}
			if (uart_func == 'Y')
				fprintf(fmain, "if (out) out= Uart_Transmit_Ready();\t\t// %s\n", lineptr);
			if (uart_func == 'A')
				fprintf(fmain, "if (out) out= Uart_Receive_Avail();\t\t// %s\n", lineptr);

			done= true;
			}


		////////////////////////////////////////////////////////////////////////////////////////

		if (str_begin(lineptr, "FORMATTED_STRING "))		// FORMATTED_STRING over UART
			{												
			// Example:	Formatted_String var string		
			// Example:	Formatted_String (none) string		// String without variable parameter
			// Sends 1 byte per cycle using a String

			sscanf(lineptr, "FORMATTED_STRING %s %s", s1, s2);
			// s1= variable, s2= formatted string (like printf + \v special format)
			// Beware: string may contain spaces !

			if ((insert == 0) && (!insdone))
				{
				if ((!isValue(s1)) && (!str_equal(s1, "(none)")))
					{
					MakeIntegerVariable(s1);
					}

				fprintf(fmain, "if (Uart_Transmit_Ready())\n");
				fprintf(fmain, "\t{\n\t");

				sprintf(s, "FORMATTED_STRING %s ", s1);
				pos= strlen(s);
				strcpy(s2, lineptr+pos);			// Get s2 with spaces
				// Manage \v special ldmicro format (like \3 or \-4)
				// Only one occurrence in a String
				int k= 0;
				strcpy(s3, s2);			
				for (p= 0 ; p < strlen(s2) ; p++)
					{
					if ((s2[p] == '\\') && (s2[p+1] == '\\'))		// These '\' are duplicated by ldmicro
						{
						if (s2[p+2] == '-') k= 1;
						if (sscanf(s2+p+k+2, "%ld", &p2) > 0)
							{
							s3[p]= '%';						// Replace \\3 with %3d for printf
							s3[p+1]= '0'+ (char) p2;		// %ld not supported by HTC compiler
							s3[p+2]= 'd';
							strcpy(s3+p+3, s2+p+k+3);
							break;						
							}
						}			
					}

				// Insert a String
				sprintf(s4, "STRING Uart_%d %s %s", linenum, s1, s3);
				strcpy(insline, s4);
				insert= 1;
				insdone= 1;
				continue;
				}

			if (!Configure_Uart(mcuisa, Baud, fhead, ffuncdef, fdevice, s))
				{
				lad2c_error("UART configuration error !");
				retcode= 0;
				goto closeall;
				}
			
			fprintf(fmain, "\tif (out) Uart_Transmit(Uart_%d);\t\t// %s\n", linenum, lineptr);
			fprintf(fmain, "\t}\n");

			insdone= 0;
			done= true;
			}


		////////////////////////////////////////////////////////////////////////////////////////

		if ((str_begin(lineptr, "I2C_RD"))  || (str_begin(lineptr, "I2C_WR")))		// I2C Read / Write
			{
			// Example:	I2c_Rd I2C - recvvar Master 0x68 0 MSB 100000
			// Example:	I2c_Rd I2C1 sendvar - Master 0x68 0 MSB -
		
			char i2c_func= 0;
			if (str_begin(lineptr, "I2C_RD ")) i2c_func= 'R';
			if (str_begin(lineptr, "I2C_WR ")) i2c_func= 'W';

			sscanf(lineptr+7, "%s %s %s %s %s %s %s", name, s1, s2, s3, s4, s5, s6);
			// name= I2C, s1= send variable, s2= receive variable, s3= mode Master (only) 
			// s4= I2C address, s5= I2C register, s6= MSB first (only), 
			// s7= I2C speed is ignored (old format)

			if (!isValue(s1))
				{
				MakeIntegerVariable(s1);
				}
			if (isValue(s2))
				{
				if (i2c_func == 'R')
					lad2c_error("I2C_RD receive parameter must be a variable");
				}				
			else if (!str_equal(s2, "-"))
				{
				MakeIntegerVariable(s2);
				}
			if (!isValue(s4))
				{
				MakeIntegerVariable(s4);
				}
			if (!isValue(s5))
				{
				MakeIntegerVariable(s5);				
				}

			if (!Configure_I2c(mcuisa, name, Speed, fhead, ffuncdef, fdevice, lineptr))
				{
				lad2c_error("I2C configuration error !");
				retcode= 0;
				goto closeall;
				}

			if (i2c_func == 'R')		// Read 1 byte
				fprintf(fmain, "if (out) %s= I2C_Recv(%s, %s);\t\t// %s\n", s2, s4, s5, lineptr);	
			if (i2c_func == 'W')		// Write 1 byte
				fprintf(fmain, "if (out) I2C_Send(%s, %s, %s);\t\t// %s\n", s4, s5, s1, lineptr);
			done= true;
			}


		////////////////////////////////////////////////////////////////////////////////////////

/*
		if (str_begin(lineptr, "FORMAT_STRING_I2C "))		// FORMATTED_STRING over I2C
			{												
			// Example:	Format_String_I2c I2C Master 0x68 0 MSB var string 
			// Example:	Format_String_I2c I2C Master 0x68 0 MSB (none) string // String without variable parameter
			// Sends 1 byte per cycle using a String

			sscanf(lineptr, "FORMAT_STRING_I2C %s %s %s %s %s %s %s", name, s1, s2, s3, s4, s5, s6);
			// name= I2C, s1= mode Master (only), s2= I2C address, s3= I2C register, 
			// s4= MSB first (only), s5= variable, s6= formatted string
			// Beware: string may contain spaces !
			sprintf(s, "FORMAT_STRING_I2C %s %s %s %s %s %s ", name, s1, s2, s3, s4, s5);
			p= strlen(s);
			strcpy(s6, lineptr+p);

			if ((insert == 0) && (!insdone))
				{
				if ((!isValue(s5)) && (!str_equal(s5, "(none)")))
					{
					MakeIntegerVariable(s5);
					}

				// Insert a String
				sprintf(s, "STRING I2c_%d %s %s", linenum, s5, s6);
				strcpy(insline, s);
				insert= 1;
				insdone= 1;
				continue;
				}

			if (!Configure_I2c(mcuisa, name, Speed, fhead, ffuncdef, fdevice, lineptr))
				{
				lad2c_error("I2C configuration error !");
				retcode= 0;
				goto closeall;
				}
			
			fprintf(fmain, "if (out) I2C_Send(%s, %s, I2c_%d);\t\t// %s\n", s2, s3, linenum, lineptr);

			insdone= 0;
			done= true;
			}
*/

		////////////////////////////////////////////////////////////////////////////////////////

		if ((str_begin(lineptr, "SPI "))  || (str_begin(lineptr, "SPI_WR ")))		// SPI Read / Write
			{
			// Example:	Spi SPI sendvar recvvar Master 0 8 MSB -
			// Example:	Spi_Wr SPI2 string - Master 0 8 MSB 100000
		
			char spi_func= 0;
			if (str_begin(lineptr, "SPI ")) 
				{
				spi_func= 'M';

				sscanf(lineptr, "SPI %s %s %s %s %s %s %s", name, s1, s2, s3, s4, s5, s6);
				// name= I2C, s1= send variable, s2= receive variable, s3= Master (only)
				// s4= SPI mode (ignored), s5= data bits (8 only), s6= MSB first (only)
				// s7= SPI speed is ignored (old format)

				if (!isValue(s1))
					{
					MakeIntegerVariable(s1);
					}			
				if (isValue(s2))
					{
					lad2c_error("SPI receive parameter must be a variable");
					}
				else
					{
					MakeIntegerVariable(s2);
					}
				}

			if (str_begin(lineptr, "SPI_WR "))	// Beware that string to send may contain spaces !
				{
				spi_func= 'W';
				
				sscanf(lineptr, "SPI_WR %s ", name);
				// name= I2C, s1= formatted string, s2= variable, s3= Master (only)
				// s4= SPI mode (ignored), s5= data bits (8 only), s6= MSB first (only)
				// Beware: string may contain spaces !			
				strcpy(tmpline, lineptr);
				p= str_back(tmpline, ' ');					
				if ((isValue(tmpline+p+1)) || (str_equal(tmpline+p+1, "-")))
					tmpline[p]= 0;							// Ignore bitrate if any (old format)
				p= str_back(tmpline, ' ');
				tmpline[p]= 0;								// Other params igored
				p= str_back(tmpline, ' ');
				tmpline[p]= 0;
				p= str_back(tmpline, ' ');
				tmpline[p]= 0;
				p= str_back(tmpline, ' ');
				tmpline[p]= 0;
				p= str_back(tmpline, ' ');
				tmpline[p]= 0;
				strcpy(s1, tmpline+strlen(name)+8);			// s1= string
				}

			if (!Configure_Spi(mcuisa, name, Rate, fhead, ffuncdef, fdevice, lineptr))
				{
				lad2c_error("SPI configuration error !");
				retcode= 0;
				goto closeall;
				}

			if (spi_func == 'M')		// Read / Write 1 byte
				fprintf(fmain, "if (out) %s= SPI_SendRecv(%s);\t\t// %s\n", s2, s1, lineptr);	
			if (spi_func == 'W')		// Write next byte
				fprintf(fmain, "if (out) SPI_Write(\"%s\");\t\t// %s\n", s1, lineptr);

			done= true;
			}


		////////////////////////////////////////////////////////////////////////////////////////
/*
		if (str_begin(lineptr, "FORMAT_STRING_SPI"))		// FORMATTED STRING over SPI
			{
			// Example:	Format_String_Spi SPI2 Master 0 8 MSB var string
			// Example:	Format_String_Spi SPI2 Master 0 8 MSB (none) string
			// Sends 1 byte per cycle using a String
		
			sscanf(lineptr, "FORMAT_STRING_SPI %s %s %s %s %s %s %s", name, s1, s2, s3, s4, s5, s6);
			// name= SPI, s1= mode Master (only), s2= SPI mode (ignored), s3= data bits (8 only), 
			// s4= MSB first (only)n s5= variable, s6= formatted string
			// Beware: string may contain spaces !
			sprintf(s, "FORMAT_STRING_SPI %s %s %s %s %s %s ", name, s1, s2, s3, s4, s5);
			p= strlen(s);
			strcpy(s6, lineptr+p);
			
			if ((insert == 0) && (!insdone))
				{
				if (!isValue(s2))
					{
					MakeIntegerVariable(s2);
					}

				// Insert a String
				sprintf(s, "STRING Spi_%d %s %s", linenum, s2, s1);
				strcpy(insline, s);
				insert= 1;
				insdone= 1;
				continue;
				}

			if (!Configure_Spi(mcuisa, name, Rate, fhead, ffuncdef, fdevice, lineptr))
				{
				lad2c_error("SPI configuration error !");
				retcode= 0;
				goto closeall;
				}

			fprintf(fmain, "if (out) SPI_SendRecv(Spi_%d);\t\t// %s\n", linenum, lineptr);

			insdone= 0;
			done= true;
			}
*/

		////////////////////////////////////////////////////////////////////////////////////////

		if (!done) 
			{
			sscanf(lineptr, "%s", s1);
			lad2c_error("Unknown contact in ladder !!!");
			fprintf(fmain, "// UNKNOWN CONTACT %s\n", s1);
//			retcode= 0;
//			goto closeall;
			}

		if (addend)
			{
			if (Pop() == 'S')							// End of "virtual" Series branch
				{
				fputabs(fmain, tabs); fprintf(fmain, "// END SERIES_1\n");
				fputabs(fmain, tabs); fprintf(fmain, "out= out | Pop(2);\n");
				fputabs(fmain, tabs); fprintf(fmain, "Push(2, out);\n");
				}
			addend= false;
			}
		}

	// Initialize ports
	for (char i= 0 ; i < MAX_PORTS ; i++)		// Port A to P max
		{
		if (Prog.mcu()->inputRegs[i] == 0) continue;		// Unexisting port

		if (Port_inp[i] != 0)			// 'A' -> 0 etc
			{
			pins= Port_inp[i] & Port_pup[i];		// Inputs with Pull-up
			if (pins != 0)						
				{
				if (mcuisa == ISA_ARM)
					fprintf(finit, "Gpio_conf('%c', 0x%4.4X, MODE_PUP);\n", 'A'+i, pins);
				else
					fprintf(finit, "Gpio_conf('%c', 0x%2.2X, MODE_PUP);\n", 'A'+i, pins);

				if ((mcuisa == ISA_PIC16) || (mcuisa == ISA_PIC18))
					{
					// Pull-Ups only on Port B or PortD of PIC16F1527
					if ((i != 1) && ((Mcu != PIC16F1527_TQF_64) || (i != 3)))
						{
						lad2c_error("Invalid pull-Ups !");
						}
					}
				}

			pins= Port_inp[i] & ~Port_pup[i];		// Inputs without Pull-up
			if (pins != 0)			
				{
				if (mcuisa == ISA_ARM)
					fprintf(finit, "Gpio_conf('%c', 0x%4.4X, MODE_INP);\n", 'A'+i, pins);
				else
					fprintf(finit, "Gpio_conf('%c', 0x%2.2X, MODE_INP);\n", 'A'+i, pins);
				}
			}

		if (Port_out[i] != 0)				// Outputs
			{
			if (mcuisa == ISA_ARM)
				{
				fprintf(finit, "Gpio_conf('%c', 0x%4.4X, MODE_OUT);\n", 'A'+i, Port_out[i]);
				fprintf(finit, "Gpio_resetoutputs('%c', 0x%4.4X);\n", 'A'+i, Port_out[i]);
				}
			else
				{
				fprintf(finit, "Gpio_conf('%c', 0x%2.2X, MODE_OUT);\n", 'A'+i, Port_out[i]);
				fprintf(finit, "Gpio_resetoutputs('%c', 0x%2.2X);\n", 'A'+i, Port_out[i]);
				}
			}

		int unused= ~(Port_inp[i] | Port_out[i]);
		if (mcuisa == ISA_ARM) unused &= 0xFFFF;
		else unused &= 0xFF;

		if (unused != 0)					// Fix unused pins as inputs with or without Pull-ups
			{
			if (mcuisa == ISA_ARM)
				{
				if (unused & ~Port_pup[i])
					fprintf(finit, "Gpio_conf('%c', 0x%4.4X, MODE_INP);\n", 'A'+i, unused & ~Port_pup[i]);
				if (unused & Port_pup[i])
					fprintf(finit, "Gpio_conf('%c', 0x%4.4X, MODE_PUP);\n", 'A'+i, unused & Port_pup[i]);
				}
			else
				{
				if (unused & ~Port_pup[i])
					fprintf(finit, "Gpio_conf('%c', 0x%2.2X, MODE_INP);\n", 'A'+i, unused & ~Port_pup[i]);
				if (unused & Port_pup[i])
					fprintf(finit, "Gpio_conf('%c', 0x%2.2X, MODE_PUP);\n", 'A'+i, unused & Port_pup[i]);					
				}
			}
		}

	fprintf(finit, "\n");
	fprintf(fmain, "}\n");

	if (Duty)
		{
		fputabs(fmain, tabs);
		fprintf(fmain, "YPlcCycleDuty_writebit(0);\n");
		}

closeall:
	fclose(fsub);
	fclose(fmain);
	fclose(ftime);
	fclose(finit);
	fclose(fdevice);
	fclose(fvarinit);
	fclose(ffuncdef);
	fclose(fvardef);
	fclose(fhead);
	fclose(fintro);
	fclose(f);

	return retcode;
	}


// Creates C file for timing config
int configTimer(int mcuisa, char * hname)
	{
	FILE * fhead= NULL, * fdev= NULL, * ftime= NULL, * fsrce= NULL;
	Name fname= "";
	String stg= "";
	Line line;
	int step= 0;
	int retcode= 1;
	unsigned long period= 0;
	double fperiod = (double)(Crystal);

	fhead= fopen(hname, "a+t");
	if (fhead == NULL) 
		{
		lad2c_error("Error accessing program H file");
		retcode= 0;
		goto closeall;
		}

	fdev= fopen("Output/plcdevinit.c", "a+t");
	if (fdev == NULL) 
		{
		lad2c_error("Error accessing devinit C file");
		retcode= 0;
		goto closeall;
		}

	ftime= fopen("Output/plctimer.c", "a+t");		// mode append
	if (ftime == NULL) 
		{
		lad2c_error("Error accessing plctimer C file");
		retcode= 0;
		goto closeall;
		}


	// Compute timer frequency according to desired Cycle time
	if (mcuisa == ISA_ARM)
		{
		if (Mcu == STM32F40X_LQFP_144) 
			{			
			strcpy(fname, "Input/timer_stm32f4.c");
			fperiod /= 2000000;									// STM32F40X	f= (F/4)/[(prediv)*(period)]				
			fperiod = (fperiod * Cycle) / 1000;
			period = (unsigned long) fperiod;			
			}

		if (Mcu == STM32F10X_LQFP_48) 
			{			
			strcpy(fname, "Input/timer_stm32f1.c");
			fperiod /= 1000000;									// Bluepill
			fperiod = (fperiod * Cycle) / 1000;
			period = (unsigned long) fperiod;
			}

		if (period == 0) period = 1;
		if (period > 65535) period = 65535;						// Securities

		fprintf(fhead, "#define F_CPU\t\t %ldL\n\n", Crystal);		
		}

	if (mcuisa == ISA_AVR)
		{
		strcpy(fname, "Input/timer_avr8.c");

		if (!CalcAvrPlcCycle(Prog.cycleTime, AvrProgLdLen))
			{
			lad2c_error("Error in timing computation");
			retcode= 0;
			goto closeall;
			}
		
		fprintf(fhead, "#define TIMER%d\n", Timer);

		int counter= plcTmr.tmr - 1;
		if (Timer == 0)			// 8 bits
			{			
			if (counter < 0) counter= 0;
			if(counter > 255) counter= 255;					// Securities

			fprintf(fhead, "#define TIM_SOFTDIV\t %ld\n", plcTmr.softDivisor);
			fprintf(fhead, "#define TIM_CS\t\t %d\n", plcTmr.cs & 0xFF);
			fprintf(fhead, "#define TIM_CNT\t\t %d\n\n", counter & 0xFF);
			}

		if (Timer == 1)			// 16 bits
			{
			fprintf(fhead, "#define TIM_SOFTDIV %ld\n", plcTmr.softDivisor);
			fprintf(fhead, "#define TIM_CS %d\n", plcTmr.cs);
			fprintf(fhead, "#define TIM_CNT %d\n\n", counter);
			}

		fprintf(fhead, "#define F_CPU\t\t %ldL\n\n", Crystal);
		}

	if (mcuisa == ISA_PIC16)
		{
		strcpy(fname, "Input/timer_pic16.c");

		if (!CalcPicPlcCycle(Prog.cycleTime, PicProgLdLen))
			{
			lad2c_error("Error in timing computation");
			retcode= 0;
			goto closeall;
			}
		
		fprintf(fhead, "#define TIMER%d\n", Timer);

		if (Timer == 0)			// 8 bits
			{			
			int counter= 256 - plcTmr.tmr + 1;

			if (counter < 0) counter= 0;
			if(counter > 255) counter= 255;					// Securities

			fprintf(fhead, "#define TIM_SOFTDIV\t %ld\n", plcTmr.softDivisor);
			fprintf(fhead, "#define TIM_PS\t\t %d\n", plcTmr.ps & 0xFF);
			fprintf(fhead, "#define TIM_CNT\t\t %d\n", counter & 0xFF);
			fprintf(fhead, "#define TIM_PSA\t\t %d\n\n", plcTmr.prescaler == 1 ? 1 : 0);
			}

		if (Timer == 1)			// 16 bits
			{
			int counter= plcTmr.tmr;

			fprintf(fhead, "#define TIM_SOFTDIV %ld\n", plcTmr.softDivisor);
			fprintf(fhead, "#define TIM_PS %d\n", plcTmr.ps);
			fprintf(fhead, "#define TIM_CNT %d\n\n", counter);
			}

		fprintf(fhead, "#define F_CPU\t\t %ldL\n\n", Crystal);
		}


	if (mcuisa == ISA_PIC18)
		{
		strcpy(fname, "Input/timer_pic18.c");

		if (!CalcPicPlcCycle(Prog.cycleTime, PicProgLdLen))
			{
			lad2c_error("Error in timing computation");
			retcode= 0;
			goto closeall;
			}
		
		fprintf(fhead, "#define TIMER%d\n", Timer);

		if (Timer == 0)			// 16 bits but used as 8 bits
			{		
			int counter= 256 - plcTmr.tmr + 1;

			if (counter < 0) counter= 0;
			if(counter > 255) counter= 255;					// Securities

			fprintf(fhead, "#define TIM_SOFTDIV\t %ld\n", plcTmr.softDivisor);
			fprintf(fhead, "#define TIM_PS\t\t %d\n", plcTmr.ps & 0xFF);
			fprintf(fhead, "#define TIM_CNT\t\t %d\n", counter & 0xFF);
			fprintf(fhead, "#define TIM_PSA\t\t %d\n\n", plcTmr.prescaler == 1 ? 1 : 0);
			}

		if (Timer == 1)			// 16 bits
			{
			int counter= plcTmr.tmr;

			fprintf(fhead, "#define TIM_SOFTDIV %ld\n", plcTmr.softDivisor);
			fprintf(fhead, "#define TIM_PS %d\n", plcTmr.ps);
			fprintf(fhead, "#define TIM_CNT %d\n\n", counter);
			}

		fprintf(fhead, "#define F_CPU\t\t %ldL\n\n", Crystal);
		}

	fsrce= fopen(fname, "rt");
	if (fsrce == NULL) 
		{
		lad2c_error("Error opening timer source C file");
		retcode= 0;
		goto closeall;
		}

	while (fgets(line, sizeof(line)-1, fsrce) != NULL)
		{
		if (str_begin(line, "// Timer includes")) 
			{
			step= 1; 
			continue;
			}

		if (str_begin(line, "// Init Timer")) 
			{  
			step= 2; 
			continue;
			}

		if (str_begin(line, "// Timer function")) 
			{
			step= 3; 
			continue;
			}

		if (mcuisa == ISA_ARM)
			{
			if (step == 1) fprintf(fhead, line, Timer);
			if (step == 2) fprintf(fdev, line, Timer, period);
			if (step == 3) fprintf(ftime, line, Timer);
			}

		if ((mcuisa == ISA_AVR) || (mcuisa == ISA_PIC16) || (mcuisa == ISA_PIC18))
			{
			if (step == 1) fprintf(fhead, line);
			if (step == 2) fprintf(fdev, line);
			if (step == 3) fprintf(ftime, line);
			}
		}

closeall:
	fclose(ftime);
	fclose(fdev);
	fclose(fhead);
	fclose(fsrce);

	return retcode;
	}


// Melts generated H and C files into C program
int createCProg(char * pname, char * hname, int mcuisa)
	{
	FILE * fbase= NULL, * finsert= NULL, * fprog= NULL, * flad= NULL;
	Name fname, bname, lname;
	Line line;
	int tabs= 0;
	int retcode= 1;

	if (mcuisa == ISA_ARM) strcpy(bname, "Input/plcbase_arm32.c");
	if (mcuisa == ISA_AVR) strcpy(bname, "Input/plcbase_avr8.c");
	if (mcuisa == ISA_PIC16) strcpy(bname, "Input/plcbase_pic16.c");
	if (mcuisa == ISA_PIC18) strcpy(bname, "Input/plcbase_pic18.c");

	// Update ladder.h for libraries
	strcpy(lname, CurrentCompilePath);
	strcat(lname, "\\ladder.h");
	flad= fopen(lname, "a+t");
	if (flad == NULL) 
		{
		lad2c_error("Error creating ladder H file");
		return 0;
		}

	if (mcuisa == ISA_AVR) 
		{
		int pos= str_back(hname, '\\');
		fprintf(flad, "\n#include \"%s\"\n\n", hname+pos+1);
		}

	if ((mcuisa == ISA_PIC16) || (mcuisa == ISA_PIC18))
		{
		int pos= str_back(hname, '\\');
		fprintf(flad, "\n#include \"%s\"\n\n", hname+pos+1);

		fprintf(flad, "#define _XTAL_FREQ	F_CPU\n\n");
		fprintf(flad, "#define CFG_WORD 0x%lX\n\n", Prog.configurationWord);

		if (LONG_USED)
			fprintf(flad, "#define USE_LONGS\n\n");
		else
			fprintf(flad, "#define USE_SHORTS\n\n");

		for (char i= 0 ; i < MAX_PORTS ; i++)		// Port A to P max
			{
			if ((Port_inp[i] != 0)|| (Port_out[i] != 0))
				fprintf(flad, "#define USING_PORT%c\n", 'A'+i);
			}
		fprintf(flad, "\n");
	}
	fclose(flad);

	// Create c file
	fbase= fopen(bname, "rt");
	if (fbase == NULL) 
		{
		lad2c_error("Error opening base C file");
		retcode= 0;
		goto closeall;
		}

	fprog= fopen(pname, "w+t");
	if (fprog == NULL) 
		{
		lad2c_error("Error creating program C file");
		retcode= 0;
		goto closeall;
		}

	while (fgets(line, sizeof(line)-1, fbase) != NULL)
		{
		if (str_begin(line, "#insert "))			// Insert file					
			{
			strcpy(fname, "Output/");
			sscanf(line+8, "%d,%s", &tabs, fname+strlen(fname));

			finsert= fopen(fname, "rt");
			if (finsert == NULL) 
				{
				lad2c_error("Error opening inserted H / C file");
				retcode= 0;
				goto closeall;
				}

			while (fgets(line, sizeof(line)-1, finsert) != NULL)
				{
				if (str_begin(line, "void Subprog_"))
					for (int t= 0 ; t < tabs-1 ; t++) fwrite("\t", 1, 1, fprog);
				else
					for (int t= 0 ; t < tabs ; t++) fwrite("\t", 1, 1, fprog);
				fprintf(fprog, line);
				}

			fclose(finsert);
			}
		else							// Copy full line
			{
			fprintf(fprog, line);
			}
		}

closeall:
	fclose(fbase);
	fclose(fprog);

	return retcode;
	}


int Lad2C(char * ldname, char * progname, char * headname)
	{
	FILE * ldfile= NULL;
	int mcuisa= 0;
	Line lname= "";

	InternalException= 0;

	if (!Prog.mcu())
		{
		lad2c_error("Select target before compiling");
		return 0;
		}
	else
		mcuisa= Prog.mcu()->whichIsa;

	CheckSaveUserCancels();

	strcpy(lname, CurrentCompilePath);
	strcat(lname, "\\ladder.h");
	remove(lname);

	ldfile= fopen(ldname, "rt");
	if (ldfile == NULL)
		{
		lad2c_error("Input ld file not found");
		return 0;
		}

	readLdConfig(ldfile);

	if (str_equal(Version, "0.1"))
		{
		lad2c_error("C Compiling requires ld file version >= 0.2");
		return 0;
		}

	NbVars= readLdVarlist(ldfile, 0);		// Temporary value of NbVars
	rewind(ldfile);
	NbVars= readLdVarlist(ldfile, 1);		// Final value of NbVars
	rewind(ldfile);

	NbIOs= readLdIOlist(ldfile, 0);
	rewind(ldfile);
	readLdIOlist(ldfile, 1);
	rewind(ldfile);

	NbRung= readLdInfo(ldfile, 1);
	rewind(ldfile);
	printf("%d Rungs\n", NbRung);

	NbPara= readLdInfo(ldfile, 2);
	rewind(ldfile);
	printf("%d Parallel branches max\n", NbPara);
	piletab= new char[2*NbPara+1];

	chdir(ExePath);

	ADC_USED= 0; 
	for (int a= 0 ; a < MAX_ADC_C ; a ++) 
		ADC_Used[a]= 0;

	PWM_USED= 0; 
	for (int p= 0 ; p < MAX_PWM_C ; p ++) 
		PWM_Used[p]= 0;

	UART_USED= 0;
	I2C_USED= 0;
	SPI_USED= 0;
	RST_USED= 0;

	TEMPO_USED= 0;
	OSC_USED= 0;
	COUNT_USED= 0;
	TIME_USED= 0;
	QUADENCOD_USED= 0;
	PULSE_USED= 0;
	STEP_USED= 0;
	STRING_USED= 0;
	SHIFTREG_USED= 0;
	PLTAB_USED= 0;
	LUTAB_USED= 0;
	PERSIST_USED= 0;
	MODBUS_USED= 0;
	BITOPS_USED= 0;
	BCDOPS_USED= 0;
	DISPLAY_USED= 0;

	for (char i= 0 ; i < MAX_PORTS ; i++)
		{
		Port_inp[i]= 0;
		Port_out[i]= 0;
		Port_pup[i]= 0;
		}

	if (! convertLadder(ldname, progname, headname, mcuisa, 1)) return 0;
	if (! configTimer(mcuisa, headname)) return 0;
	if (! createCProg(progname, headname, mcuisa)) return 0;

	chdir(CurrentLdPath);

	delete[] piletab;
	delete[] IOList;
	delete[] IOStat;
	delete[] VarList;
	delete[] VarStat;

	fclose(ldfile);

	return 1;
	}


void lad2c_error(String s)
	{
	Error(_(s));

	puts(s);
	getch();
	}

void lad2c_warning(String s)
	{
	Warning(_(s));

	puts(s);
	getch();
	}



// Insert n tabs in a file
void fputabs(FILE * f, int n)
	{
	for (int i= 0 ; i < n ; i++)
		fprintf(f, "\t");
	}



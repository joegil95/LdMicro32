//-----------------------------------------------------------------------------
// Copyright 2021 Jos� GILLES
//
// This file is part of LDmicro32.
//
// LDmicro32 is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// LDmicro32 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

/*
This code is used by Lad2C
*/

#include "ladder.h"
#include "contacts.h"
#include "fakelibs.h"

#include <string.h>


/*
char Codes7Seg[129]= {0x3F, 0x6, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x7, 0x7F, 0x6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71, 0xBF, 0x86, 0xDB,
	0xCF, 0xE6, 0xED, 0xFD, 0x87, 0xFF, 0xEF, 0xF7, 0xFC, 0xB9, 0xDE, 0xF9, 0xF1, 0x0, 0xB0, 0x22, 0x4E, 0x6D, 0xD2, 0xDA, 0x20, 0x39,
	0xF, 0x72, 0x70, 0xC, 0x40, 0x80, 0x52, 0x3F, 0x6, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x7, 0x7F, 0x6F, 0x9, 0xD, 0x61, 0x41, 0x43, 0xD3,
	0x9F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71, 0x3D, 0x74, 0x30, 0x1E, 0x75, 0x38, 0x55, 0x54, 0x5C, 0x73, 0x67, 0x33, 0x6D, 0x78, 0x3E,
	0x1C, 0x6A, 0x76, 0x6E, 0x5B, 0x39, 0x64, 0xF, 0x23, 0x8, 0x20, 0x5F, 0x7C, 0x58, 0x5E, 0x7B, 0x71, 0x6F, 0x74, 0x10, 0xE, 0x75,
	0x18, 0x55, 0x54, 0x5C, 0x73, 0x67, 0x50, 0x6D, 0x78, 0x3E, 0x1C, 0x6A, 0x76, 0x6E, 0x5B, 0x39, 0x30, 0xF, 0x1, 0x0, 0x63};

integer Codes9Seg[129]= {0x33F, 0x106, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x7, 0x7F, 0x6F, 0x77, 0x17D, 0x39, 0x5E, 0x79, 0x71, 0x3BF, 0x186, 0xDB,
	0xCF, 0xE6, 0xED, 0xFD, 0x87, 0xFF, 0xEF, 0xF7, 0x1FD, 0xB9, 0xDE, 0xF9, 0xF1, 0x0, 0xB0, 0x120, 0x404E, 0x6D, 0xD2, 0xDA, 0x100, 0x39,
	0xF, 0x72, 0x340, 0x200, 0x40, 0x80, 0x300, 0x33F, 0x106, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x7, 0x7F, 0x6F, 0x9, 0x201, 0x61, 0x41, 0x43,
	0xD3, 0x9F, 0x77, 0x17D, 0x39, 0x5E, 0x79, 0x71, 0x3D, 0x74, 0x30, 0x1E, 0x75, 0x38, 0x55, 0x54, 0x3F, 0x73, 0x67, 0x33, 0x6D, 0x78,
	0x3E, 0x330, 0x6A, 0x4364, 0x6E, 0x4349, 0x39, 0x64, 0xF, 0x102, 0x8, 0x20, 0x5F, 0x7C, 0x58, 0x5E, 0x7B, 0x171, 0x6F, 0x74, 0x10, 0xE,
	0x75, 0x18, 0x55, 0x54, 0x5C, 0x73, 0x67, 0x50, 0x6D, 0x78, 0x3E, 0x210, 0x6A, 0x4364, 0x6E, 0x309, 0x39, 0x30, 0xF, 0x1, 0x0, 0x63};
*/


// Fake Tables for compiling
extern char Codes7Seg[];
extern integer Codes9Seg[];

// Master Relay (No structure)
char Master_Relay(char mast, char in)
	{
	if (mast) return in;
	return 1;
	}


// Internal or External In/Out Relay
// mod= 'N' if Normal or 'I' if inverted
// typ= 'R' if internal variable or 'X' / 'Y' if external pin
void Relay_Init(Relay * r, char mod, char typ, short pin, char * bptr)
	{
	if (mod == 'N') r->output= 0;
	else r->output= 1;

	r->mode= mod;
	r->type= typ;
	r->pin= pin;
	r->bitptr= bptr;
	}

char Relay_Transfer(Relay * r, char mod, char in)		// Mode may change across usages of a same Relay
	{
	char out= r->output;
	char * bptr= r->bitptr;

	r->mode= mod;				// Last used mode
	switch(mod)
		{
		case 'N':	if (*bptr)					// Normal
						out= in;
					else
						out= 0;
					break;
		case 'I':	if (*bptr)					// Inverted
						out= 0;
					else
						out= in;
					break;
		}

	r->output= out;

	return out;
	}


// Internal or External Coil
// mod= 'N', 'I', 'S', 'R' or 'T'
// typ= 'R' if internal variable or 'Y' if external pin
void Coil_Init(Coil * c, char mod, char typ, short pin, char * bptr)
	{
	if ((mod == 'N') || (mod == 'S')) c->output= 0;
	if ((mod == 'I') || (mod == 'R')) c->output= 1;
	if (mod == 'T') c->output= 0;
	c->oldin= 0;

	c->mode= mod;
	c->type= typ;
	c->pin= pin;
	c->bitptr= bptr;
	}

char Coil_Transfer(Coil * c, char mod, char in)		// Mode can change across usages of a same Coil
	{
	char out= c->output;
	char * bptr= c->bitptr;

	c->mode= mod;				// Last used mode
	switch(mod)
		{
		case 'N':	out= in;				// Normal
					break;
		case 'I':	if (in) out= 0;			// Inverted
					else out= 1;
					break;
		case 'S':	if (in) out= 1;			// Set
					break;
		case 'R':	if (in) out= 0;			// Reset
					break;
		case 'T':	if ((in) && (!c->oldin))		// Trigger on rising edge
						{
						if (out) out= 0;
						else out= 1;
						}
					break;

		}

	c->oldin= in;
	c->output= out;
	if (c->type == 'R') *bptr=out;

	return out;
	}


#ifdef TEMPO_USED
// Ton Temporization
// vptr= pointer to current value
// lim= limit value
void Ton_Init(Ton * t, integer * vptr, integer lim)
	{
	t->output= 0;
	t->oldin= 0;

	t->limit= lim+1;
	t->valptr= vptr;
	*vptr= 0;
	}

char Ton_Transfer(Ton * t, char in)
	{
	char out= t->output;
	integer * valptr= t->valptr;

	if (in)
		{
		if (t->running)				// Don't move
			(*valptr)++;
		if (!t->oldin)				// Rising edge on input
			{
			t->running= 1;
			out= 0;
			}
		if (*valptr >= t->limit)
			{
			out= 1;					// Ton output activation
			t->running= 0;
			}
		}
	else
		{
		if (t->oldin)				// Falling edge on input
			{
			out= 0;					// Ton reset
			t->running= 0;
			t->oldin= 0;
			*valptr= 0;
			}
		}

	t->oldin= in;
	t->output= out;

	return out;
	}


// Tof Temporization
// vptr= pointer to current value
// lim= limit value
void Tof_Init(Tof * t, integer * vptr, integer lim)
	{
	t->output= 0;
	t->oldin= 0;

	t->limit= lim+1;
	t->valptr= vptr;

	*vptr= 0;
	}

char Tof_Transfer(Tof * t, char in)
	{
	char out= t->output;
	integer * valptr= t->valptr;

	if (in)
		{
		if (!t->oldin)				// Rising edge on input
		out= 1;						// Toff reset
		t->running= 0;
		t->oldin= 0;
		*valptr= 0;
		}
	else
		{
		if (t->running)				// Don't move
			(*valptr)++;
		if (t->oldin)				// Falling edge on input
			{
			t->running= 1;
			out= 1;
			}
		if (*valptr >= t->limit)
			{
			out= 0;					// Toff output activation
			t->running= 0;
			}
		}

	t->oldin= in;
	t->output= out;

	return out;
	}
#endif			// TEMPO


#ifdef OSC_USED
// OneShot Output
// typ= 'R' if rising edge
// typ= 'F' if falling edge
// typ= 'R' if falling edge inverted
void OneShot_Init(OneShot * s, char typ)
	{
	s->output= 0;
	s->oldin= 0;
	s->type= typ;
	}

char OneShot_Transfer(OneShot * s, char in)
	{
	char out= s->output;

	switch(s->type)
		{
		case 'R':	if ((in) && (!s->oldin)) out= 1;			// OSR: Rising edge => "/\"
					else out= 0;
					break;
		case 'F':	if ((!in) && (s->oldin)) out= 1;			// OSF: Falling edge => "/\"
					else out= 0;
					break;
		case 'L':	if ((!in) && (s->oldin)) out= 0;			// OSL: Falling edge => "\/"
					else out= 1;
					break;
		}

	s->oldin= in;
	s->output= out;

	return out;
	}


// Oscillator
void Oscillator_Init(Oscillator * s)
	{
	s->output= 0;
	}

char Oscillator_Transfer(Oscillator * s, char in)			// Osc: Input=1 => "/\/\/\"
	{
	char out= s->output;

	if (in) out= 1-out;
	else out= 0;

	s->output= out;

	return out;
	}
#endif


#ifdef COUNT_USED
// Counter
// bptr= ptr to begin vale
// lptr= ptr to limit value
// vptr= ptr to current value
void Count_Init(Count * c, char typ, char mod, integer * bptr, integer * lptr, integer * vptr)
	{
	c->output= 0;
	if (mod == '-') c->oldin= 1;
	else c->oldin= 0;
	c->type= typ;
	c->mode= mod;

	c->limptr= lptr;
	c->begptr= bptr;
	c->valptr= vptr;
	*vptr= *bptr;
	}

char Count_Transfer(Count * c, char in)
	{
	char out= 0;
	integer * valptr= c->valptr;
	integer * limptr= c->limptr;

	// CTU and CTD have no automatic reset (Use RES)
	switch(c->type)
		{
		// Count Up (CTU)
		case 'U':	if (c->mode == '/') if ((in) && (!c->oldin))			// Rising edge on input (/)
						(*valptr)++;
					if (c->mode == '\\') if ((!in) && (c->oldin))			// Falling edge on input (\)
						(*valptr)++;
					if (c->mode == '-') if ((in) && (c->oldin))				// Input remains 1 (-)
						(*valptr)++;
					if (c->mode == 'o') if ((!in) && (!c->oldin))			// Input remains 0 (o)
						(*valptr)++;
					if (*valptr >= *limptr) out= 1;		// Don't move
					break;
		// Count Down (CTD)
		case 'D':	if (c->mode == '/') if ((in) && (!c->oldin))			// Rising edge on input (/)
						(*valptr)--;
					if (c->mode == '\\') if ((!in) && (c->oldin))			// Falling edge on input (\)
						(*valptr)--;
					if (c->mode == '-') if ((in) && (c->oldin))				// Input remains 1 (-)
						(*valptr)--;
					if (c->mode == 'o') if ((!in) && (!c->oldin))			// Input remains 0 (o)
						(*valptr)--;
					if (*valptr <= *limptr) out= 1;		// Don't move
					break;
		// Count Cyclic (CTC)
		case 'C':	if (c->mode == '/') if ((in) && (!c->oldin))			// Rising edge on input (/)
						(*valptr)++;
					if (c->mode == '\\') if ((!in) && (c->oldin))			// Falling edge on input (\)
						(*valptr)++;
					if (c->mode == '-') if ((in) && (c->oldin))				// Input remains 1 (-)
						(*valptr)++;
					if (c->mode == 'o') if ((!in) && (!c->oldin))			// Input remains 0 (o)
						(*valptr)++;
					if (*valptr > *limptr) 			// Don't move
						{
						out= 1;
						*valptr= *(c->begptr);
						}
					break;
		// Count Cyclic Reverse (CTR)
		case 'R':	if (c->mode == '/') if ((in) && (!c->oldin))			// Rising edge on input (/)
						(*valptr)--;
					if (c->mode == '\\') if ((!in) && (c->oldin))			// Falling edge on input (\)
						(*valptr)--;
					if (c->mode == '-') if ((in) && (c->oldin))				// Input remains 1 (-)
						(*valptr)--;
					if (c->mode == 'o') if ((!in) && (!c->oldin))			// Input remains 0 (o)
						(*valptr)--;
					if (*valptr < *limptr) 			// Don't move
						{
						out= 1;
						*valptr= *(c->begptr);
						}
					break;
		}

	c->oldin= in;
	c->output= out;

	return out;
	}


char Count_Reset(Count * c, char in)
	{
	if (in)
		{
		///	c->output= 0;			// Doesn't reset output according to help
		if (c->mode == '-') c->oldin= 1;
		else c->oldin= 0;

		*(c->valptr)= 0;
		}

	return 1;
	}
#endif


#ifdef TIME_USED
// Timer
// lptr= ptr to limit value
// vptr= ptr to current value

void Timer_Init(Timer * c, char typ, integer * lptr, integer * vptr)
	{
	if (typ == 'L') c->output= 1;
	else c->output= 0;
	c->oldin= 0;
	c->type= typ;
	c->running= 0;

	c->limptr= lptr;
	c->valptr= vptr;
	*vptr= 0;
	}

char Timer_Transfer(Timer * c, char in)
	{
	char out= c->output;
	integer * valptr= c->valptr;
	integer * limptr= c->limptr;

	switch(c->type)
		{
		// Timer High (THI)
		case 'H':	if ((in) && (!c->oldin))					// Rising edge on input
						c->running= 1;
					if (c->running)
						{
						if (*valptr < *limptr)
							{
							(*valptr)++;
							out= 1;
							}
						else
							{
							c->running= 0;
							out= 0;
							}
						}
					if ((!in) && (*valptr >= *limptr))			// Reset
						{
						c->running= 0;
						*valptr= 0;
						out= 0;
						}
					break;

		// Timer Low (TLO)
		case 'L':	if ((!in) && (c->oldin))					// Falling edge on input
						c->running= 1;
					if (c->running)
						{
						if (*valptr < *limptr)
							{
							(*valptr)++;
							out= 0;
							}
						else
							{
							c->running= 0;
							out= 1;
							}
						}
					if ((in) && (*valptr >= *limptr))			// Reset
						{
						c->running= 0;
						*valptr= 0;
						out= 1;
						}
					break;

		// Retentive Timers high (RTO) have no automatic reset (use Res)
		case 'U':	if (in) (*valptr)++;							// Input is high

					if (*valptr >= *limptr)
						out= 1;
					break;

		// Retentive Timers low (RTL) have no automatic reset (use Res)
		case 'D':	if (!in) (*valptr)++;							// Input is low
					if (*valptr >= *limptr)
						out= 1;
					break;

		// Cyclic Timer (TCY)
		case 'C':	if (in) 						// Input is high
						{
						if (*valptr < *limptr)
							(*valptr)++;
						else
							{
							*valptr= 0;
							out= 1-out;
							}
						}
					else							// Input is low
						{
						out= 0;
						*valptr= 0;
						}

					break;
		}

	c->oldin= in;
	c->output= out;

	return out;
	}

char Timer_Reset(Timer * c, char in)
	{
	if (in)
		{
		///	if (c->type == 'L') c->output= 1;		// Doesn't reset output according to help
		///	else c->output= 0;
		c->oldin= 0;
		c->running= 0;

		*(c->valptr)= 0;
		}

	return 1;
	}
#endif


#ifdef QUADENCOD_USED
// Quadratic Encoder
// aptr= pointer to a input
// bptr= pointer to b input
// zptr= pointer to z input
void QuadEncoder_Init(QuadEncoder * q, char * aptr, char * bptr, char * zptr, char mod, integer rev, integer * vptr, Coil * cptr)
	{
	q->output= 0;
	q->mode= mod;
	q->oldB= 0;
	q->oldZ= 0;

	q->Aptr= aptr;
	q->Bptr= bptr;
	q->Zptr= zptr;
	q->revol= rev;
	q->valptr= vptr;
	q->colptr= cptr;
	}

char QuadEncoder_Transfer(QuadEncoder * q, char in)		// Integrated help is inverted !
	{
	char out= 0;
	char inpA= *q->Aptr;
	char inpB= *q->Bptr;
	char inpZ= 0;
	integer * valptr= q->valptr;
	Coil * colptr= q->colptr;
	integer revol= q->revol;
	integer tmp= 0;

	if (in)
		{
		if ((inpB) && (!q->oldB))			// Rising edge on input B
			{
			if (inpA)
				{
				(*valptr)--;									// Decrease
				if (colptr != NULL) *(colptr->bitptr)= 0;		// Direction= 0
				}
			else
				{
				(*valptr)++;									// Increase
				if (colptr != NULL) *(colptr->bitptr)= 1;		// Direction= 1
				}
			out= 1;								// Output pulse (count changed)
			}

		if ((!inpB) && (q->oldB))			// Falling edge on input B
			{
			if (inpA)
				{
				(*valptr)++;									// Increase
				if (colptr != NULL) *(colptr->bitptr)= 1;		// Direction= 1
				}
			else
				{
				(*valptr)--;									// Decrease
				if (colptr != NULL) *(colptr->bitptr)= 0;		// Direction= 0
				}
			out= 1;								// Output pulse (count changed)
			}

		if ((q->Zptr != NULL) && (revol >= 0))		// Z is not used if Zptr= NULL
			{										// Z reset / round is ignored if revol < 0
			inpZ= *q->Zptr;

			if (((q->mode == '/') && (inpZ) && (!q->oldZ)) ||			// Rising edge on input Z (/)
				((q->mode == '\\') && (!inpZ) && (q->oldZ)) ||			// Falling edge on input (\)
				((q->mode == '-') && (inpZ) && (q->oldZ)) ||			// Input Z remains 1 (-)
				((q->mode == 'o') && (!inpZ) && (!q->oldZ)))			// Input Z remains 0 (o)
				{
				if (revol == 0) *valptr= 0;				// Reset counter
				if (revol > 0)
					{
					tmp= (*valptr) / revol;				// Round by excess or default (missing signals)
					if (*valptr != (tmp *revol))		// If need be
						{
						if ((tmp > 0) && (out)) tmp++;
						if ((tmp < 0) && (!out)) tmp--;
						(*valptr)= tmp * revol;
						}
					}
				}
			}

		q->oldB= inpB;
		q->oldZ= inpZ;
		}

	q->output= out;

	return out;
	}
#endif


#ifdef PULSE_USED
// Pulser
// d0ptr= pointer to 0 duration value
// d1ptr= pointer to 1 duration value
// mptr= pointer multiplier value
// lptr= pointer to count value
// bptr= pointer to output value
void Pulser_Init(Pulser * p, integer * d1ptr, integer * d0ptr, integer * mptr, integer * lptr, char * bptr)
	{
	p->output= 0;
	p->stat= 0;
	p->repeat= 0;
	p->duration= 1;
	p->d1ptr= d1ptr;
	p->d0ptr= d0ptr;
	p->mulptr= mptr;
	p->limptr= lptr;
	p->bitptr= bptr;
	}

char Pulser_Transfer(Pulser * p, char in)
	{
	char out= 1;

	if ((in) && (p->repeat < *(p->limptr)))
		{
		if (p->duration == 1)
			{
			p->stat= 1-p->stat;
			*(p->bitptr)= p->stat;

			if (p->stat == 0) p->repeat++;
			}

		if (p->stat == 1)
			{
			if (p->duration < *(p->d1ptr) * *(p->mulptr)) p->duration++;
			else p->duration= 1;
			}
		else
			{
			if (p->duration < *(p->d0ptr) * *(p->mulptr)) p->duration++;
			else p->duration= 1;
			}
		}
	else
		{
		out= 0;			// Pulser not running (By JG)
		}

	p->output= out;

	return out;
	}
#endif


#ifdef STRING_USED
// Formatted String
// sptr= pointer to source string (printf format)
// dptr= pointer to destination string after processing
// vptr= pointer to variable to substitute in sptr
// cptr= pointer to variable receiving chars
void FormatString_Init(FormatString * s, char * sptr, char * dptr, integer * vptr, char * cptr)
	{
	s->output= 0;
	s->oldin= 0;

	s->index= 0;
	s->sptr= sptr;
	s->dptr= dptr;
	s->vptr= vptr;
	s->cptr= cptr;
	}

char FormatString_Transfer(FormatString * s, char in)
	{
	char out= 1;

	char * sptr= s->sptr;
	char * dptr= s->dptr;
	integer * vptr= s->vptr;

	if ((in) && (!s->oldin))			// Rising edge
		{
		if (s->index == 0)
			{
			if (vptr != NULL) sprintf(dptr, sptr, *vptr);
			else strcpy(dptr, sptr);								// No parameter to substitute
			}
		}

	if (in)
		{
		if (s->index < strlen(dptr))
			{
			*(s->cptr)= dptr[s->index];
			s->index++;
			}
		else
			out= 0;					// End of string
		}

	s->oldin= in;
	s->output= out;

	return out;
	}
#endif


#ifdef SHIFTREG_USED
// Shift register
// siz= number of registers
// rptr= pointer to registers table
void ShiftRegister_Init(ShiftRegister * s, integer siz, integer ** rptr)
	{
	integer i;

	s->output= 0;
	s->oldin= 0;
	s->regptr= rptr;
	s->size= siz;

	for (i= 0 ; i < siz ; i++)
		{
		*rptr[i]= 0;
		}
	}

char ShiftRegister_Transfer(ShiftRegister * s, char in)
	{
	integer i;
	char out= 0;

	if ((in) && (!s->oldin))			// Rising edge
		{
		for (i= s->size-1 ; i > 0 ; i--)
			{
			*(s->regptr[i])= *(s->regptr[i-1]);		// Shift values in register array
			}
		out= 1;
		}

	s->oldin= in;
	s->output= out;

	return out;
	}
#endif


#ifdef PLTAB_USED
// Piecewise Linear Table (Interpolation)
// siz= number of elements
// sptr= pointer to input value
// dptr= pointer to output value
// xptr= pointer to X values table
// yptr= pointer to Y values table
void PiecewiseLinear_Init(PiecewiseLinear * p, integer siz, integer * dptr, integer * sptr, integer * xptr, integer * yptr)
	{
	p->output= 0;
	p->size= siz;

	p->srceptr= sptr;
	p->destptr= dptr;
	p->txptr= xptr;
	p->typtr= yptr;
	}

char PiecewiseLinear_Transfer(PiecewiseLinear * p, char in)
	{
	int i= 0;
	integer y= 0;
	char out= 0;				// out= 1 if interpolation OK ; 0 if not (No matter because Right-most only)

	integer srce= *p->srceptr;
	integer * dptr= p->destptr;
	integer * tabx= p->txptr;		// X values must be in strict increasing order
	integer * taby= p->typtr;

	if (in)				// Perform action
		{
		if (srce <= tabx[0])					// Pb
			{
			*dptr= taby[0];
			}
		else if (srce >= tabx[p->size-1])		// Pb
			{
			*dptr= taby[p->size-1];
			}
		else
			{
			while(srce > tabx[i]) i++;			// srce is between tab[i-1] and tab[i]

			// Linear interpolation (may overflow)
			y= taby[i-1]+((taby[i]-taby[i-1])*(srce-tabx[i-1]))/(tabx[i]-tabx[i-1]);
			*dptr= y;
			out= 1;
			}
		}

	p->output= out;

	return out;
	}
#endif


#ifdef LUTAB_USED
// Look Up Table (Array)
// typ= 'L' for integer values table, typ= 'C' for string table
// siz= number of values in table
// dptr= pointer to destination variable
// iptr= pointer to index in table
// vptr= pointer to look up table
void LookUp_Init(LookUp * l, char typ, int siz, void * dptr, integer * iptr, void * vptr)
	{
	l->output= 0;
	l->size= siz;
	l->type= typ;

	l->indptr= iptr;
	l->destptr= dptr;
	l->tvptr= vptr;
	}

char LookUp_Transfer(LookUp * l, char in)
	{
	char out= 0;				// out= 1 if access OK ; 0 if not (No matter because Right-most only)

	integer index= *l->indptr;
	void * dptr= l->destptr;
	void * tabv= l->tvptr;

	if (in)				// Perform action
		{
		if ((index < 0) || (index >= l->size))			// Pb => gives 0
			{
			if (l->type == 'L') *((integer *) dptr)= 0;
			else *((char *) dptr)= 0;
			}
		else
			{
			if (l->type == 'L') *((integer *) dptr)= ((integer *) tabv)[index];
			else *((char *) dptr)=  ((char *) tabv)[index];
			out= 1;
			}
		}

	l->output= out;

	return out;
	}
#endif


#ifdef PERSIST_USED
// Persistant (EEprom) variable
// vptr= pointer to persistent variable
// addr= address in EEprom
void Persist_Init(Persist * p, integer * vptr, integer addr)
	{
	p->output= 0;

	p->varptr= vptr;
	p->address= addr;
	p->oldvar= 0;

	*vptr= EEPROM_read4(addr);
	}

char Persist_Transfer(Persist * p, char in)
	{
	char out= 0;

	if (in)				// Perform action
		{
		p->oldvar= EEPROM_read4(p->address);				// Read last stored value in EEPROM
		if (p->oldvar != *p->varptr)						// Value has changed ?
			EEPROM_write4(p->address, *p->varptr);			// Store new value in EEPROM
		out= 1;
		}

	p->output= out;

	return out;
	}
#endif


#ifdef MODBUS_USED
// Modbus configuration
// uart= uart# (1 ...)
// speed= uart speed (9600 ...)
// timout= 0 to use default value
void Modbus_Init(Modbus * m, int uart, long speed, int timout)
	{
	if (m->init) return ;

	m->output= 0;
	m->oldin= 0;
	m->running= 0;

	LibModbus_Init(uart, speed, timout);

	m->init= 1;
	}

// Modbus comunication with PLC
// mod= 'S' to send data, 'R' to receive, 'E' to enable transfers, 'D' to disable transfers
// dptr= ptr to FormatString variable or LUT string variable to use  to send / receive
// sizptr= ptr to size variable (initialize at 0 in receive mode, and > 0 in send mode)
char Modbus_Transfer(Modbus * m, LookUp * l, char mode, unsigned char * dataptr, integer * sizeptr, char in)
	{
	char out= 0;
	integer nb= 0;
	int i= 0;

	if ((in) && (!m->oldin))			// Rising edge
		{
		if (mode == 'E') LibModbus_Enable(1);
		if (mode == 'D') LibModbus_Enable(0);

		if (!m->running)
			{
			if ((mode == 'S') && (*sizeptr > 0))
				{
				m->running= 1;

				for (i= 0 ; i < l->size ; i++)						// copy chars from integers
					dataptr[i]=  (char)((integer *) l->tvptr)[i];

				LibModbus_IntSend(dataptr, *sizeptr);		// Call only once
				}

			if ((mode == 'R') && (*sizeptr == 0))
				m->running= 1;
			}
		}

	if (m->running)
		{
		if ((mode == 'S') && (*sizeptr > 0))
			{
			if (LibModbus_SendDone())
				*sizeptr= 0;		// Send is done => Reset size variable => out= 1
			m->running= 0;
			out= 1;
			}
		if ((mode == 'R') && (*sizeptr == 0))
			{
			nb= LibModbus_IntReceive(dataptr);			// Call until receive is done
			if (nb > 0)
				{
				for (i= 0 ; i < l->size ; i++)						// copy integers from chars
					((integer *) l->tvptr)[i]=	(integer) dataptr[i];

				*sizeptr= nb;					// Receive is done => Set size variable => out= 1
				m->running= 0;
				out= 1;
				}
			}
		}

	m->oldin= in;
	m->output= out;

	return out;
	}
#endif


#ifdef BITOPS_USED
// Rotate left of k bits for n-bit variable (cast result)
integer Rol(integer op1, int k, int n)
	{
	char i;

	for (i= 0 ; i < k ; i++)
		{
		if (op1 & (1 << (n-1)))
			op1= (op1 << 1) | 1;
		else
			op1= (op1 << 1);
		}

	return op1;
	}


// Rotate right of k bits for n-bit variable (cast result)
integer Ror(integer op1, int k, int n)
	{
	char i;

	for (i= 0 ; i < k ; i++)
		{
		if (op1 & 1)
			op1= (op1 >> 1) | (1 << (n-1));
		else
			op1= (op1 >> 1) & ~(1 << (n-1));
		}

	return op1;
	}


// Signed shift right of k bits for n-bit variable (cast result)
// High bit is reinjected instead of 0
integer Ssr(integer op1, int k, int n)
	{
	char i;

	for (i= 0 ; i < k ; i++)
		{
		if (op1 & (1 << (n-1)))
			op1= (op1 >> 1) | (1 << (n-1));
		else
			op1= (op1 >> 1) & ~(1 << (n-1));
		}

	return op1;
	}


// Reverse all bits for n-bit variable (cast result)
integer RevBits(integer op1, int n)
	{
	int i;
	integer tmp= 0;

	for (i= 0 ; i < n ; i++)
		{
		if (op1 & (1 << i)) tmp |= (1 << (n-i-1));
		}

	return tmp;
	}


// Swap high/low for n-bit variable (cast result)
integer SwapBits(integer op1, int n)
	{
	integer tmp= 0;

	switch(n)
		{
		case 8:		// swap nibbles
					tmp= ((op1 & 0x0F) << 4) | ((op1 & 0xF0) >> 4);
					break;
		case 16:	// swap bytes
					tmp= ((op1 & 0x00FF) << 8) | ((op1 & 0xFF00) >> 8);
					break;
		case 24:	// swap halfs
					tmp= ((op1 & 0x000FFF) << 12) | ((op1 & 0xFFF000) >> 12);
					break;
		case 32:	// swap words
					tmp= ((op1 & 0x0000FFFF) << 16) | ((op1 & 0xFFFF0000) >> 16);
					break;
		}

	return tmp;
	}


// Choose and reorder 8 bits among 16
integer BusTracer(integer op1, integer swap)
	{
	integer tmp= 0;
	char i, b;

	for (i= 0 ; i < 8 ; i++)
		{
		b= swap & 0x0F;
		if (op1 & (1 << i)) tmp |= (1 << b);
		swap= swap >> 4;
		}

	return tmp;
	}
#endif


#ifdef BCDOPS_USED
// Convert decimal values into packed BCD values (2 digits -> 1 byte)
integer Bin2Bcd(integer op1)
	{
	integer tmp= 0;

	tmp += op1 % 10;
	op1 = op1 / 10;
	tmp += (op1 % 10) << 4;
	op1 = op1 / 10;
	tmp += (op1 % 10) << 8;
	op1 = op1 / 10;
	tmp += (op1 % 10) << 12;
	op1 = op1 / 10;
#ifdef USE_LONGS
	tmp += (op1 % 10) << 16;
	op1 = op1 / 10;
	tmp += (op1 % 10) << 20;
	op1 = op1 / 10;
	tmp += (op1 % 10) << 24;
	op1 = op1 / 10;
	tmp += (op1 % 10) << 28;
#endif

	return tmp;
	}


// Convert packed BCD values into decimal values (1 byte -> 2 digits)
integer Bcd2Bin(integer op1)
	{
	integer tmp= 0;

	tmp += op1 & 0x0F;
	op1 = op1 >> 4;
	tmp += (op1 & 0x0F) * 10;
	op1 = op1 >> 8;
	tmp += (op1 & 0x0F) * 100;
	op1 = op1 >> 12;
	tmp += (op1 & 0x0F) * 1000;
#ifdef USE_LONGS
	op1 = op1 >> 16;
	tmp += (op1 & 0x0F) * 10000;
	op1 = op1 >> 20;
	tmp += (op1 & 0x0F) * 100000;
	op1 = op1 >> 24;
	tmp += (op1 & 0x0F) * 1000000;
	op1 = op1 >> 28;
	tmp += (op1 & 0x0F) * 10000000;
#endif

	return tmp;
	}
#endif


#ifdef DISPLAY_USED
// Get Code for 7 segment display at index position in Table
// Return 1 if OK and 0 if index error											// By JG (usually always returns 1)
char Seg7_Convert(char * ptab, integer * pdest, integer index, char type, char out)
	{
	if ((index < 0) || (index >= 129))			// Pb
		{
		*pdest= 0;
		out= 0;
		}
	else
		{
		if (type == 'C')					// Common K
			*pdest= (integer) ptab[index];
		else								// Common A
			*pdest= (integer) ~ptab[index];
		out= 1;
		}

	return out;
	}

// Get Code for 9 or 14 segment display at index position in Table
// Return 1 if OK and 0 if index error											// By JG (usually always returns 1)
char Seg9_Convert(short * ptab, integer * pdest, integer index, char type, char out)
	{
	if ((index < 0) || (index >= 129))			// Pb
		{
		*pdest= 0;
		out= 0;
		}
	else
		{
		if (type == 'C')					// Common K
			*pdest= (integer) ptab[index];
		else								// Common A
			*pdest= (integer) ~ptab[index];
		out= 1;
		}

	return out;
	}

// Get Code for 14 segment display at index position in Table
char Seg14_Convert(short * ptab, integer * pdest, integer index, char type, char out)
	{
	return Seg9_Convert(ptab, pdest, index, type, out);
	}

// Get Code for 16 segment display at index position in Table
// Return 1 if OK and 0 if index error											// By JG (usually always returns 1)
char Seg16_Convert(integer * ptab, integer * pdest, integer index, char type, char out)
	{
	if ((index < 0) || (index >= 129))			// Pb
		{
		*pdest= 0;
		out= 0;
		}
	else
		{
		if (type == 'C')					// Common K
			*pdest= ptab[index];
		else								// Common A
			*pdest= ~ptab[index];
		out= 1;
		}

	return out;
	}
#endif


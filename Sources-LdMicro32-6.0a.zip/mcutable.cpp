//-----------------------------------------------------------------------------
// Copyright 2007 Jonathan Westhues
//
// This file is part of LDmicro.
//
// LDmicro is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// LDmicro is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with LDmicro.  If not, see <http://www.gnu.org/licenses/>.
//------
//
// The table of supported MCUs, used to determine where the IOs are, what
// instruction set, what init code, etc.
// Jonathan Westhues, Oct 2004
//-----------------------------------------------------------------------------
#include "stdio.h"
#include "stdafx.h"

#include "ldmicro.h"

#include "mcutable.hpp"
#include "mcutable.h"


extern char ExePath[];

std::vector<McuIoInfo> &supportedMcus()
	{
	return SupportedMcus;
	}

/* JG6
void FillPcPinInfo(McuIoPinInfo *pinInfo);
bool fillPcPinInfos()
{
	for(uint32_t i = 0; i < arraylen(PcCfg); i++)
		FillPcPinInfo(&PcCfg[i]);
	return true;
}
*/

// ADDED by JG6 to externalize MCU definitions

// Search for Information in mcu descriptor
// Returns 1 if found (in response) or 0 if not found
int getInfofromMcuName(char * McuName, char * info, char * response)
	{
	FILE * fmcu= NULL;
	char fname[MAX_PATH]="";
	char line[MAX_STRING_LEN]= "";
	
	sprintf(fname, "%sMcus\\%s.txt", ExePath, McuName);

	fmcu= fopen(fname, "rt");
	if (fmcu == NULL) 
		{
		Error(_("Error opening mcu file."));
		return 0;
		}

	while (fgets(line, sizeof(line)-1, fmcu) != NULL)
		{
		int len= strlen(line);
		if (len == 0) continue;

		// remove useless chars at end
		while ((line[len-1] == '\r') || (line[len-1] == '\n') || (line[len-1] == '\t') || (line[len-1] == ' '))
			{
			line[len-1]= 0;
			len--;
			}

		len= strlen(line);
		if (len == 0) continue;				// Empty line
		if (line[0] == '/') continue;		// Comment

		if (strncmp(line, info, strlen(info)) == 0)
			{
			strcpy(response, line+strlen(info)+1);

			fclose(fmcu);
			return 1;
			}
		}

	fclose(fmcu);
	return 0;
	}


// Read MCU description file to restore MCU table as before
int FillMcuTable(McuIoInfo *mcu)
{
	FILE * fptr= NULL;
	char portlist[MAX_STRING_LEN]= "";
	char portpin[MAX_STRING_LEN]= "";
	char resp[MAX_STRING_LEN]= "";
	char portsize[4]= "";
	int size= 0, pin= 0, val= 0, n= 0, a= 0, b= 0;
	long x, y= 0;
	char c= 0;

	// General config
	if (getInfofromMcuName(mcu->packName, "mcu.port.prefix", resp))
		mcu->portPrefix= resp[0];

	if (getInfofromMcuName(mcu->packName, "mcu.desc.flash", resp))
		{
		sscanf(resp, "%ld%c", &x, &c);
		if (c == 'K') x *= 1024;
		if (c == 'M') x *= 1024 * 1024;
		mcu->flashWords= x / 2;				// Flash size in words
		}

	if (getInfofromMcuName(mcu->packName, "mcu.desc.ram", resp))
		{
		sscanf(resp, "%ld%c", &x, &c);
		if (c == 'K') x *= 1024;
		if (c == 'M') x *= 1024 * 1024;

		/*
		for (int k= 0 ; k < MAX_RAM_SECTIONS ; k++)		// If several banks of RAM
			{
			sprintf(portpin, "mcu.desc.ram%d.start", k);
			if (getInfofromMcuName(mcu->packName, portpin, resp)) mcu->ram[k].start= strtoul(resp, NULL, 16);
			else break;
			sprintf(portpin, "mcu.desc.ram%d.size", k);
			if (getInfofromMcuName(mcu->packName, portpin, resp)) mcu->ram[k].len= strtol(resp, NULL, 10);	
			else break;
			}
		*/
		}

	if (getInfofromMcuName(mcu->packName, "mcu.desc.family", resp))
		{
		if (str_equal(resp, "ARM32")) mcu->whichIsa= ISA_ARM;
		else if (str_equal(resp, "AVR8")) mcu->whichIsa= ISA_AVR;
		else if (str_equal(resp, "PIC16")) mcu->whichIsa= ISA_PIC16;
		else if (str_equal(resp, "PIC18")) mcu->whichIsa= ISA_PIC18;
		else mcu->whichIsa= 0;
		}

	if (getInfofromMcuName(mcu->packName, "mcu.desc.core", resp))
		{
		if (str_equal(resp, "Cortex-M4")) mcu->core= CortexF4;
		else if (str_equal(resp, "Cortex-M3")) mcu->core= CortexF1;
		else if (str_equal(resp, "AVR-8")) mcu->core= EnhancedCore128K;
		else if (str_equal(resp, "PIC16")) mcu->core= EnhancedMidrangeCore14bit;
		else if (str_equal(resp, "PIC18")) mcu->core=PIC18HighEndCore16bit;
		else mcu->core= NOTHING;
		}

	if (getInfofromMcuName(mcu->packName, "mcu.desc.pins", resp))
		mcu->pins= atoi(resp);

	if (getInfofromMcuName(mcu->packName, "mcu.desc.defaultcfg", resp)) 
		{
		sscanf(resp, "%lx", &x);
		mcu->configurationWord= x;
		}
	else mcu->configurationWord= 0;

	// Ports config
	McuIoPinInfo * McuPinTable= mcu->pinInfo;
	if (getInfofromMcuName(mcu->packName, "mcu.port.list", portlist))
	if (getInfofromMcuName(mcu->packName, "mcu.port.bits", portsize))
		{
		size= atoi(portsize);

		for (unsigned i= 0 ; i < strlen(portlist) ; i++)
			{
			if (portlist[i] != ',')
				{
				mcu->inputRegs[portlist[i]-'A']= 1;		// must be != 0
				mcu->outputRegs[portlist[i]-'A']= 1;	// must be != 0
				mcu->dirRegs[portlist[i]-'A']= 1;		// must be != 0

				for (int j= 0 ; j < size ; j++)
					{
					sprintf(portpin, "mcu.port%c.pin%d", portlist[i], j);
					if (getInfofromMcuName(mcu->packName, portpin, resp)) 
						{
						int pos= str_find(resp, "/");
						if (pos != -1)
							{
							pin= atoi(resp+pos+1);		// pin #
							resp[pos]= 0;				// pin description in resp

							McuPinTable[n].port= portlist[i];
							McuPinTable[n].bit= j;
							McuPinTable[n].pin= pin;
							strcpy(McuPinTable[n].pinName, resp);
							McuPinTable[n].ArduinoPin= 0;
							strcpy(McuPinTable[n].ArduinoName, "");
							McuPinTable[n].portN= 0;
							McuPinTable[n].dbPin= 0;
							McuPinTable[n].ioType= 0;
							McuPinTable[n].addr= 0;

							n++;
							}
						}
					}

				}
			}

		// ADC config
		McuAdcPinInfo * adcPinInfo= mcu->adcInfo;
		if (getInfofromMcuName(mcu->packName, "mcu.adc.nb", resp))
		if (getInfofromMcuName(mcu->packName, "mcu.adc.list", portlist))		
			{
			val= atoi(resp);
			mcu->adcCount= val;

			if (getInfofromMcuName(mcu->packName, "mcu.adc.bits", resp))
				{
				size= atoi(resp);
				mcu->adcMax= size;
				}
			else
				mcu->adcMax= 0;

			strcat(portlist, "/");
			int p= 0;
			int q= 0;
			for (int i= 0 ; i < val ; i++)
				{					
				sscanf(portlist + p, "%d.%d/", &a, &b);
				sprintf(portpin, "mcu.adc%d.chan%d", a, b);
				if (getInfofromMcuName(mcu->packName, portpin, resp))
					{
					int pos= str_find(resp, "/");
					if (pos != -1)
						{
						pin= atoi(resp+pos+1);		// pin #
						adcPinInfo[i].pin= pin;
						adcPinInfo[i].channel= b;
						}
					}
				else
					{
					adcPinInfo[i].pin= 0;
					adcPinInfo[i].channel= 0;
					}

				q= str_find(portlist + p, "/");
				if (q != -1) p+= q+1;
				else break;
				}
			}

		// UART config
		if (getInfofromMcuName(mcu->packName, "mcu.uart.list", resp))
			{
			resp[1]= 0;
			val= atoi(resp);								// First UART in list= default
			sprintf(portpin, "mcu.uart%d.rx", val);
			if (getInfofromMcuName(mcu->packName, portpin, resp))
				{
				int pos= str_find(resp, "/");
				if (pos != -1) pin= atoi(resp+pos+1);		// RX pin #
				else pin= 0;
				mcu->uartNeeds.rxPin= pin;
				}
			sprintf(portpin, "mcu.uart%d.tx", val);
			if (getInfofromMcuName(mcu->packName, portpin, resp))
				{
				int pos= str_find(resp, "/");
				if (pos != -1) pin= atoi(resp+pos+1);		// TX pin #
				else pin= 0;
				mcu->uartNeeds.txPin= pin;
				}
			}
		else	// No UART
			{
			mcu->uartNeeds.rxPin= 0;
			mcu->uartNeeds.txPin= 0;
			}

		// PWM config
		McuPwmPinInfo * pwmPinInfo= mcu->pwmInfo;
		if (getInfofromMcuName(mcu->packName, "mcu.pwm.nb", resp))
		if (getInfofromMcuName(mcu->packName, "mcu.pwm.list", portlist))		
			{
			val= atoi(resp);
			mcu->pwmCount= val;

			if (getInfofromMcuName(mcu->packName, "mcu.pwm.bits", resp))
				{
				size= atoi(resp);
				mcu->pwmMax= size;
				}
			else
				mcu->pwmMax= 0;

			strcat(portlist, "/");
			int p= 0;
			int q= 0;
			for (int i= 0 ; i < val ; i++)
				{					
				sscanf(portlist + p, "%d.%c/", &a, &c);				// can be PWM 1.0, PWM 2.A, ...
				sprintf(pwmPinInfo[i].name, "PWM%d.%c", a, c);

				sprintf(portpin, "mcu.pwm%d.out%c", a, c);
				if (getInfofromMcuName(mcu->packName, portpin, resp))
					{
					int pos= str_find(resp, "/");
					if (pos != -1)
						{
						pin= atoi(resp+pos+1);		// Pin #
						pwmPinInfo[i].pin= pin;					
						}
					}
				else
					{
					pwmPinInfo[i].pin= 0;
					}

				sprintf(portpin, "mcu.pwm%d.tim", a);
				if (getInfofromMcuName(mcu->packName, portpin, resp))
					{
					size= atoi(resp);
					pwmPinInfo[i].timer= size;		// Timer #
					}
				else
					pwmPinInfo[i].timer= 0;

				sprintf(portpin, "mcu.pwm%d.bits", a);
				if (getInfofromMcuName(mcu->packName, portpin, resp))
					{
					size= atoi(resp);
					pwmPinInfo[i].resolution= size;
					}
				else
					pwmPinInfo[i].resolution= 0;	// Resolution in bits

				sprintf(portpin, "mcu.pwm%d.divs", a);
				if (getInfofromMcuName(mcu->packName, portpin, resp))
					{
					size= atoi(resp);
					pwmPinInfo[i].maxcs= size;		// Predivison # (for AVRs)
					}
				else
					pwmPinInfo[i].maxcs= 0;

				q= str_find(portlist + p, "/");
				if (q != -1) p+= q+1;
				else break;
				}
			}

		// SPI config
		McuSpiInfo * spiInfo= mcu->spiInfo;
		if (getInfofromMcuName(mcu->packName, "mcu.spi.nb", resp))
		if (getInfofromMcuName(mcu->packName, "mcu.spi.list", portlist))		
			{
			val= atoi(resp);
			mcu->spiCount= val;

			strcat(portlist, "/");
			int p= 0;
			int q= 0;
			for (int i= 0 ; i < val ; i++)
				{					
				sscanf(portlist + p, "%d/", &a);
				sprintf(spiInfo[i].name, "SPI%d", a);

				sprintf(portpin, "mcu.spi%d.miso", a);
				if (getInfofromMcuName(mcu->packName, portpin, resp))
					{
					int pos= str_find(resp, "/");
					if (pos != -1)
						{
						pin= atoi(resp+pos+1);		// pin #
						spiInfo[i].MISO= pin;
						}
					}
				else
					{
					spiInfo[i].MISO= 0;
					}

				sprintf(portpin, "mcu.spi%d.mosi", a);
				if (getInfofromMcuName(mcu->packName, portpin, resp))
					{
					int pos= str_find(resp, "/");
					if (pos != -1)
						{
						pin= atoi(resp+pos+1);		// pin #
						spiInfo[i].MOSI= pin;
						}
					}
				else
					{
					spiInfo[i].MOSI= 0;
					}

				sprintf(portpin, "mcu.spi%d.sck", a);
				if (getInfofromMcuName(mcu->packName, portpin, resp))
					{
					int pos= str_find(resp, "/");
					if (pos != -1)
						{
						pin= atoi(resp+pos+1);		// pin #
						spiInfo[i].SCK= pin;
						}
					}
				else
					{
					spiInfo[i].SCK= 0;
					}

				sprintf(portpin, "mcu.spi%d.ss", a);
				if (getInfofromMcuName(mcu->packName, portpin, resp))
					{
					int pos= str_find(resp, "/");
					if (pos != -1)
						{
						pin= atoi(resp+pos+1);		// pin #
						spiInfo[i]._SS= pin;
						}
					}
				else
					{
					spiInfo[i]._SS= 0;
					}

				q= str_find(portlist + p, "/");
				if (q != -1) p+= q+1;
				else break;
				}
			}

		// I2C config
		McuI2cInfo * i2cInfo= mcu->i2cInfo;
		if (getInfofromMcuName(mcu->packName, "mcu.i2c.nb", resp))
		if (getInfofromMcuName(mcu->packName, "mcu.i2c.list", portlist))		
			{
			val= atoi(resp);
			mcu->i2cCount= val;

			strcat(portlist, "/");
			int p= 0;
			int q= 0;
			for (int i= 0 ; i < val ; i++)
				{					
				sscanf(portlist + p, "%d/", &a);
				sprintf(i2cInfo[i].name, "I2C%d", a);

				sprintf(portpin, "mcu.i2c%d.scl", a);
				if (getInfofromMcuName(mcu->packName, portpin, resp))
					{
					int pos= str_find(resp, "/");
					if (pos != -1)
						{
						pin= atoi(resp+pos+1);		// pin #
						i2cInfo[i].SCL= pin;
						}
					}
				else
					{
					i2cInfo[i].SCL= 0;
					}

				sprintf(portpin, "mcu.i2c%d.sda", a);
				if (getInfofromMcuName(mcu->packName, portpin, resp))
					{
					int pos= str_find(resp, "/");
					if (pos != -1)
						{
						pin= atoi(resp+pos+1);		// pin #
						i2cInfo[i].SDA= pin;
						}
					}
				else
					{
					i2cInfo[i].SDA= 0;
					}

				q= str_find(portlist + p, "/");
				if (q != -1) p+= q+1;
				else break;
				}
			}

		return 1;
		}
	
	return 0;		// Error
	}
//-----------------------------------------------------------------------------
// Copyright 2007 Jonathan Westhues
//
// This file is part of LDmicro.
//
// LDmicro is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// LDmicro is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with LDmicro.  If not, see <http://www.gnu.org/licenses/>.
//------
//
// The table of supported MCUs, used to determine where the IOs are, what
// instruction set, what init code, etc.
// Jonathan Westhues, Oct 2004
//-----------------------------------------------------------------------------
#ifndef __MCUTABLE_H__
#define __MCUTABLE_H__

#include "stdafx.h"

#include "ldconfig.h"
#include "mcutable.hpp"

// clang-format off

//=======================================================================================================
	// PINs
//=======================================================================================================
	// ATMEL
//=======================================================================================================

// ATtiny10 6-Pin packages
McuIoPinInfo AvrATtiny10IoPinInfo6[1*4];

// ATtiny85 8-Pin packages
McuIoPinInfo AvrATtiny85IoPinInfo8[1*6];

// ATtiny85 20-Pin packages
McuIoPinInfo AvrATtiny85IoPinInfo20[1*6];

// AT90Usb647 64-Pin packages
McuIoPinInfo AvrAT90USB647IoPinInfo64[6*8];

// ATmega48, ATmega88, ATmega168 28-Pin packages
McuIoPinInfo AvrAtmega48IoPinInfo28[3*8];

// ATmega8 28-Pin packages
McuIoPinInfo AvrAtmega8IoPinInfo28[3*8];

// ATmega8 32-Pin packages
McuIoPinInfo AvrAtmega8IoPinInfo32[3*8];

// ATmega328 28-Pin packages
McuIoPinInfo AvrAtmega328IoPinInfo28[3*8];

// ATmega328 32-Pin packages
// A VOIR: Arduino Pins	Voir aussi '\0' pour broches sp�ciales ADC 6+7
McuIoPinInfo AvrAtmega328IoPinInfo32[3*8];
/*
= {
//   port bit pin  pinName			 ArduinoPin  ArduinoName
//											  X  Nano
	{ 'D',  0, 30, "PD0 (PCINT16/RXD)"	   , 30, "0"  , 0, 0, 0, 0}, // {char port;  int bit;  int pin; char name[]}
	{ 'D',  1, 31, "PD1 (PCINT17/TXD)"	   , 31, "1"  , 0, 0, 0, 0},
	{ 'D',  2, 32, "PD2 (PCINT18/INT0)"	  , 32, "2"  , 0, 0, 0, 0},
	{ 'D',  3,  1, "PD3 (PCINT19/OC2B/INT1)" ,  1, "3"  , 0, 0, 0, 0},
	{ 'D',  4,  2, "PD4 (PCINT20/XCK/T0)"	,  2, "4"  , 0, 0, 0, 0},
	{ 'D',  5,  9, "PD5 (PCINT21/OC0B/T1)"   ,  9, "5"  , 0, 0, 0, 0},
	{ 'D',  6, 10, "PD6 (PCINT22/OC0A/AIN0)" , 10, "6"  , 0, 0, 0, 0},
	{ 'D',  7, 11, "PD7 (PCINT23/AIN1)"	  , 11, "7"  , 0, 0, 0, 0},
	{ 'B',  0, 12, "PB0 (PCINT0/ICP1/CLKO)"  , 12, "8"  , 0, 0, 0, 0},
	{ 'B',  1, 13, "PB1 (PCINT1/OC1A)"	   , 13, "9"  , 0, 0, 0, 0},
	{ 'B',  2, 14, "PB2 (PCINT2/OC1B/SS)"	, 14, "10" , 0, 0, 0, 0},
	{ 'B',  3, 15, "PB3 (PCINT3/OC2A/MOSI)"  , 15, "11" , 0, 0, 0, 0},
	{ 'B',  4, 16, "PB4 (PCINT4/MISO)"	   , 16, "12" , 0, 0, 0, 0},
	{ 'B',  5, 17, "PB5 (PCINT5/SCK)"		, 17, "13" , 0, 0, 0, 0},
	{ 'B',  6,  7, "PB6 (PCINT6/XTAL1/TOSC1)",  7, ""   , 0, 0, 0, 0},
	{ 'B',  7,  8, "PB7 (PCINT7/XTAL2/TOSC2)",  8, ""   , 0, 0, 0, 0},
	{ 'C',  0, 23, "PC0 (PCINT8/ADC0)"	   , 23, "A0" , 0, 0, 0, 0},
	{ 'C',  1, 24, "PC1 (PCINT9/ADC1)"	   , 24, "A1" , 0, 0, 0, 0},
	{ 'C',  2, 25, "PC2 (PCINT10/ADC2)"	  , 25, "A2" , 0, 0, 0, 0},
	{ 'C',  3, 26, "PC3 (PCINT11/ADC3)"	  , 26, "A3" , 0, 0, 0, 0},
	{ 'C',  4, 27, "PC4 (PCINT12/ADC4/SDA)"  , 27, "A4" , 0, 0, 0, 0},
	{ 'C',  5, 28, "PC5 (PCINT13/ADC5/SCL)"  , 28, "A5" , 0, 0, 0, 0},
	{ 'C',  6, 29, "PC6 (PCINT14/RESET)"	 , 29, "RST", 0, 0, 0, 0},
	{ '\0', 6, 19, "(ADC6)"				  , 19, "A6" , 0, 0, 0, 0},
	{ '\0', 7, 22, "(ADC7)"				  , 22, "A7" , 0, 0, 0, 0}
};
*/

// ATmega16, ATmega32 40-Pin packages
McuIoPinInfo AvrAtmega16IoPinInfo40[4*8];

// ATmega16, ATmega32 44-Pin packages
McuIoPinInfo AvrAtmega16IoPinInfo44[4*8];

// ATmega16U4, ATmega32U4 44-Pin packages
McuIoPinInfo AvrAtmega16u4IoPinInfo44[5*8];

// ATmega162 40-Pin packages
McuIoPinInfo AvrAtmega162IoPinInfo40[5*8];

// ATmega164, ATmega324, ATmega644, ATmega1264 40-Pin packages
McuIoPinInfo AvrAtmega164IoPinInfo40[4*8];

// ATmega64, ATmega128 64-Pin packages
McuIoPinInfo AvrAtmega64IoPinInfo64[7*8];

// ATmega640, ATmega1280, ATmega2560 100-Pin packages
McuIoPinInfo AvrAtmega640IoPinInfo100[8*11];


//=======================================================================================================
	// ADCs
//=======================================================================================================
	// ATMEL
//=======================================================================================================

McuAdcPinInfo AvrAdcPinInfo_6[6];
McuAdcPinInfo AvrAdcPinInfo_8[8];
McuAdcPinInfo AvrAdcPinInfo_12[12];
McuAdcPinInfo AvrAdcPinInfo_16[16];


//=======================================================================================================
	// EXTINTs
//=======================================================================================================
	// ATMEL
//=======================================================================================================
McuExtIntPinInfo AvrExtIntPinInfo6[] = {
	{ 1 }, // PCINT0
	{ 3 },
	{ 4 },
	{ 6 },
};

McuExtIntPinInfo AvrExtIntPinInfo8[] = {
	{ 5 }, // PCINT0
	{ 6 },
	{ 7 },
	{ 2 },
	{ 3 },
	{ 1 }
};

McuExtIntPinInfo AvrExtIntPinInfo32[] = {
	{ 32 }, // PD2/INT0
	{  1 }, // PD3/INT1
};

//=======================================================================================================
	// I2Cs
//=======================================================================================================
	// ATMEL
//=======================================================================================================

McuI2cInfo McuAvrI2cInfo_1[1];

//=======================================================================================================
	// SPIs
//=======================================================================================================
	// ATMEL
//=======================================================================================================

McuSpiInfo McuAvrSpiInfo_1[1];

//=======================================================================================================
	// PWMs
//=======================================================================================================
	// ATMEL
//=======================================================================================================

McuPwmPinInfo AvrPwmPinInfo_2[2];
McuPwmPinInfo AvrPwmPinInfo_3[3];
McuPwmPinInfo AvrPwmPinInfo_4[4];
McuPwmPinInfo AvrPwmPinInfo_6[6];
McuPwmPinInfo AvrPwmPinInfo_7[7];
McuPwmPinInfo AvrPwmPinInfo_8[8];
McuPwmPinInfo AvrPwmPinInfo_9[9];
McuPwmPinInfo AvrPwmPinInfo_16[16];


//=======================================================================================================
	// PINs
//=======================================================================================================
	// PIC
//=======================================================================================================

// A variety of 14-Pin PICs that share the same digital IO assignment.
McuIoPinInfo Pic16IoPinInfo14[2*8];

// A variety of 18-Pin PICs that share the same digital IO assignment.
McuIoPinInfo Pic16IoPinInfo18[2*8];

// PIC16F88
McuIoPinInfo Pic16F88IoPinInfo18[2*8];

// PIC16F1826, PIC16F1827
McuIoPinInfo Pic16f1827IoPinInfo[2*8];

// PIC16F877, PIC16F874
McuIoPinInfo Pic16F877IoPinInfo40[5*8];

// PIC16F72 28-Pin PDIP, SOIC, SSOP
McuIoPinInfo Pic16F72IoPinInfo28[3*8];

// PIC16F876, PIC16F873 28-Pin PDIP, SOIC
McuIoPinInfo Pic16F876IoPinInfo28[3*8];

// PIC16F884, PIC16F887 44-TQFP
McuIoPinInfo Pic16F887IoPinInfo44[5*8];

// PIC16F887, PIC16F884
McuIoPinInfo Pic16F887IoPinInfo40[5*8];

// PIC16F886,  PIC16F883, PIC16F882
// 28-Pin PDIP, SOIC, SSOP
McuIoPinInfo Pic16F886IoPinInfo28[3*8];

// PIC16F1512, PIC16F1513, PIC16F1516, PIC16F1518
// 28-Pin PDIP, SOIC, SSOP
McuIoPinInfo Pic16F151xIoPinInfo28[3*8];

// PIC16F1526, PIC16F1527
McuIoPinInfo Pic16F1527IoPinInfo[7*8];

//-----------------------------------------------------------------------------
// PIC18F458
//-----------------------------------------------------------------------------
McuIoPinInfo Pic18F458IoPinInfo40[5*8];

//-----------------------------------------------------------------------------
// PIC18F4520
//-----------------------------------------------------------------------------
McuIoPinInfo Pic18F4520IoPinInfo40[5*8];

//-----------------------------------------------------------------------------
// PIC18F4550
//-----------------------------------------------------------------------------
McuIoPinInfo Pic18F4550IoPinInfo40[5*8];


//=======================================================================================================
	// ADCs
//=======================================================================================================
	// PIC
//=======================================================================================================

McuAdcPinInfo Pic16FAdcPinInfo_4[4];
McuAdcPinInfo Pic16FAdcPinInfo_5[5];
McuAdcPinInfo Pic16FAdcPinInfo_7[7];
McuAdcPinInfo Pic16FAdcPinInfo_8[8];
McuAdcPinInfo Pic16FAdcPinInfo_11[11];
McuAdcPinInfo Pic16FAdcPinInfo_12[12];
McuAdcPinInfo Pic16FAdcPinInfo_14[14];
McuAdcPinInfo Pic16FAdcPinInfo_16[16];

/*
= {
//   PINx  ANx
	{ 24,   0 },
	{ 23,   1 },
	{ 22,   2 },
	{ 21,   3 },
	{ 27,   4 },
	{ 11,   5 },
	{ 17,   6 },
	{ 16,   7 },
	{ 15,   8 },
	{ 14,   9 },
	{ 13,  10 },
	{ 12,  11 },
	{  8,  12 },
	{  6,  13 },
	{  5,  14 },
	{  4,  15 },
	{ 18,  16 },
	{ 48,  17 },
	{ 47,  18 },
	{ 46,  19 },
	{ 45,  20 },
	{ 44,  21 },
	{ 43,  22 },
	{ 58,  23 },
	{ 55,  24 },
	{ 54,  25 },
	{ 53,  26 },
	{  2,  27 },
	{  1,  28 },
	{ 64,  29 },
};
*/

McuAdcPinInfo Pic18FAdcPinInfo_8[8];
McuAdcPinInfo Pic18FAdcPinInfo_12[12];

//=======================================================================================================
	// EXTINTs
//=======================================================================================================
	// PIC
//=======================================================================================================

McuExtIntPinInfo PicExtIntPinInfo6[] = {
	{	}, //
};

McuExtIntPinInfo PicExtIntPinInfo14[] = {
	{ 11 }, // INT
};

McuExtIntPinInfo PicExtIntPinInfo18[] = {
	{  6 }, // RB0/INT
};

McuExtIntPinInfo PicExtIntPinInfo28[] = {
	{ 21 }, // RB0/INT
};

McuExtIntPinInfo PicExtIntPinInfo40[] = {
	{ 33 }, // RB0/INT
};

McuExtIntPinInfo PicExtIntPinInfo44[] = {
	{ 8 }, // RB0/INT
};

McuExtIntPinInfo PicExtIntPinInfo64[] = {
	{ 48 }, // RB0/INT
};

//=======================================================================================================
	// PWMs
//=======================================================================================================
	// PIC
//=======================================================================================================

McuPwmPinInfo Pic16FPwmPinInfo_1[1];
McuPwmPinInfo Pic16FPwmPinInfo_2[2];
McuPwmPinInfo Pic16FPwmPinInfo_4[4];
McuPwmPinInfo Pic16FPwmPinInfo_10[10];

McuPwmPinInfo Pic18FPwmPinInfo_1[1];
McuPwmPinInfo Pic18FPwmPinInfo_2[2];


//=======================================================================================================
	// I2Cs
//=======================================================================================================
	// PIC
//=======================================================================================================

McuI2cInfo McuPic16FI2cInfo_1[1];
McuI2cInfo McuPic16FI2cInfo_2[2];

McuI2cInfo McuPic18FI2cInfo_1[1];
McuI2cInfo McuPic18FI2cInfo_2[2];

//=======================================================================================================
	// SPIs
//=======================================================================================================
	// PIC
//=======================================================================================================

McuSpiInfo McuPic16FSpiInfo_1[1];
McuSpiInfo McuPic16FSpiInfo_2[1];

McuSpiInfo McuPic18FSpiInfo_1[1];
McuSpiInfo McuPic18FSpiInfo_2[2];

//=======================================================================================================
	// PINs
//=======================================================================================================
	// ARM
//=======================================================================================================

McuIoPinInfo ArmSTM32F40XIoPinInfo144[7*16];

McuIoPinInfo ArmSTM32F10XIoPinInfo48[3*16];

McuAdcPinInfo ArmSTM32AdcPinInfo_8[8];
McuAdcPinInfo ArmSTM32AdcPinInfo_9[9];

McuPwmPinInfo ArmSTM32PwmPinInfo_12[12];

McuSpiInfo ArmSTM32SpiInfo_2[2];
McuSpiInfo ArmSTM32SpiInfo_3[3];

McuI2cInfo ArmSTM32I2cInfo_2[2];
McuI2cInfo ArmSTM32I2cInfo_3[3];


//=======================================================================================================
	// MCUs
//=======================================================================================================
	// ATMEL
//=======================================================================================================
McuIoInfo SupportedMcus_[] = {
/*
	{
		"Atmel AVR ATtiny10 6-Pin packages",
		"ATtiny10",
		"",
		"",
		"ATtiny10-SOT-6",
		'P',
		{ 0, 0 }, // PINx
		{ 0, 0 }, // PORTx
		{ 0, 0 }, // DDRx
0,
{ { 0, 0 } },
		AvrATtiny10IoPinInfo6,			   //McuIoPinInfo	*pinInfo;
		arraylen(AvrATtiny10IoPinInfo6),	 //int			  pinCount;
		AvrATtiny10AdcPinInfo6,			  //McuAdcPinInfo   *adcInfo;
		arraylen(AvrATtiny10AdcPinInfo6),	//int			  adcCount;
0,
		{ 0, 0 },
//		0, // OC2
		ISA_AVR,
		ReducedCore,
		0,
0,
		AvrPwmPinInfo_2,
		arraylen(AvrPwmPinInfo_2),
		0,
		AvrExtIntPinInfo6,
		arraylen(AvrExtIntPinInfo6),
		nullptr,
		0,
		nullptr,
		0,
		{{0,0}}
	},
//=======================================================================================================
	{
		"Atmel AVR ATtiny85 8-Pin packages",
		"ATtiny85",
		"",
		"",
		"ATtiny85-PDIP-8",
		'P',
		{ 0, 0 },
		{ 0, 0 },
		{ 0, 0 },
0,
{ { 0, 0 } },
		AvrATtiny85IoPinInfo8,			  //McuIoPinInfo	*pinInfo;
		arraylen(AvrATtiny85IoPinInfo8),	//int			  pinCount;
		AvrATtiny85AdcPinInfo,			  //McuAdcPinInfo   *adcInfo;
		arraylen(AvrATtiny85AdcPinInfo),	//int			  adcCount;
0,
		{ 0, 0 },
//		0, // OC2
		ISA_AVR,
		EnhancedCore128K,
		0,
0,
		AvrPwmPinInfo_4,
		arraylen(AvrPwmPinInfo_4),
		0,
		AvrExtIntPinInfo8,
		arraylen(AvrExtIntPinInfo8),
		nullptr,
		0,
		nullptr,
		0,
		{{0,0}}
	},
//=======================================================================================================
	{
		"Atmel AVR ATtiny85 20-Pin packages",
		"ATtiny85",
		"",
		"",
		"ATtiny85-QFN-20",
		'P',
		{ 0, 0 },
		{ 0, 0 },
		{ 0, 0 },
0,
{ { 0, 0 } },
		AvrATtiny85IoPinInfo20,			 //McuIoPinInfo	*pinInfo;
		arraylen(AvrATtiny85IoPinInfo20),   //int			  pinCount;
		AvrATtiny85AdcPinInfo,			  //McuAdcPinInfo   *adcInfo;
		arraylen(AvrATtiny85AdcPinInfo),	//int			  adcCount;
0,
		{ 0, 0 },
//		0, // OC2
		ISA_AVR,
		EnhancedCore128K,
		0,
0,
		AvrPwmPinInfo_4,
		arraylen(AvrPwmPinInfo_4),
		0,
		AvrExtIntPinInfo8,
		arraylen(AvrExtIntPinInfo8),
		nullptr,
		0,
		nullptr,
		0,
		{{0,0}}
	},
*/
//=======================================================================================================
	{
		"Atmel AVR AT90USB647 64-TQFP",
		"AT90USB647",
		"",
		"",
		"AT90Usb647-TQFP-64",
		'P',
		{ 0, 0, 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0, 00 }, // DDRx
0,
{ { 0, 0 } },
		AvrAT90USB647IoPinInfo64,
		arraylen(AvrAT90USB647IoPinInfo64),
		AvrAdcPinInfo_8,
		arraylen(AvrAdcPinInfo_8),
0,
{ 0, 0 },
//		17,
		ISA_AVR,
		EnhancedCore128K, //???
0,
		0,
		AvrPwmPinInfo_7,
		arraylen(AvrPwmPinInfo_7),
		0,
		nullptr,
		0,
		nullptr,
		0,
		nullptr,
		0,
		{{0,0}}
	},

//=======================================================================================================
	{
		"Atmel AVR ATmega8 28-PDIP",
		"ATmega8",
		"",
		"",
		"ATmega8-PDIP-28",
		'P',
		{ 0, 0, 0, 0 }, 
		{ 0, 0, 0, 0 }, 
		{ 0, 0, 0, 0 }, 
0,
{ { 0, 0 } },
		AvrAtmega8IoPinInfo28,
		arraylen(AvrAtmega8IoPinInfo28),
		AvrAdcPinInfo_6,
		arraylen(AvrAdcPinInfo_6),
0,
{ 0, 0 },
//		17,
		ISA_AVR,
		EnhancedCore8K,
0,
		0,
		AvrPwmPinInfo_3,
		arraylen(AvrPwmPinInfo_3),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Atmel AVR ATmega8 32-Pin packages", //char			*mcuName;
		"ATmega8",
		"",
		"",
		"ATmega8-TQFP-32", 
		'P',								
		{ 0, 0, 0, 0 }, 
		{ 0, 0, 0, 0 }, 
		{ 0, 0, 0, 0 }, 
0,							
{ { 0, 0 } },	   
		AvrAtmega8IoPinInfo32,   
		arraylen(AvrAtmega8IoPinInfo32), 
		AvrAdcPinInfo_8,	   
		arraylen(AvrAdcPinInfo_8), 
0,		 
{ 3, 0 },   
//		15,// OC2  
		ISA_AVR,		   
		EnhancedCore8K,		  
		0,					
0,
//	  { 32, 1 }, 
//	  AvrAtmega8ExtIntPinInfo32,
//	  arraylen(AvrAtmega8ExtIntPinInfo32),
		AvrPwmPinInfo_3,
		arraylen(AvrPwmPinInfo_3),
		0,
		AvrExtIntPinInfo32,
		arraylen(AvrExtIntPinInfo32),
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Atmel AVR ATmega48 28-PDIP",
		"ATmega48",
		"",
		"",
		"ATmega48-PDIP-28",
		'P',
		{ 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0 }, // DDRx
0,
{ { 0, 0 } },
		AvrAtmega48IoPinInfo28,
		arraylen(AvrAtmega48IoPinInfo28),
		AvrAdcPinInfo_6,
		arraylen(AvrAdcPinInfo_6),
0,
{ 0, 0 },
//		17,
		ISA_AVR,
		EnhancedCore128K,
0,
		0,
		AvrPwmPinInfo_6,
		arraylen(AvrPwmPinInfo_6),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Atmel AVR ATmega88 28-PDIP",
		"ATmega88",
		"",
		"",
		"ATmega88-PDIP-28",
		'P',
		{ 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0 }, // DDRx
0,
{ { 0, 0 } },
		AvrAtmega48IoPinInfo28,
		arraylen(AvrAtmega48IoPinInfo28),
		AvrAdcPinInfo_6,
		arraylen(AvrAdcPinInfo_6),
		1023,
		{ 2, 3 },
//		17,
		ISA_AVR,
		EnhancedCore128K,
		28,
		0,
		AvrPwmPinInfo_6,
		arraylen(AvrPwmPinInfo_6),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Atmel AVR ATmega168 28-PDIP",
		"ATmega168",
		"",
		"",
		"ATmega168-PDIP-28", 
		'P',
		{ 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0 }, // DDRx
0,
 { { 0, 0 } },
		AvrAtmega48IoPinInfo28,
		arraylen(AvrAtmega48IoPinInfo28),
		AvrAdcPinInfo_6,
		arraylen(AvrAdcPinInfo_6),
0,
{ 0, 0 },
//		17,
		ISA_AVR,
		EnhancedCore128K,
0,
		0,
		AvrPwmPinInfo_6,
		arraylen(AvrPwmPinInfo_6),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Atmel AVR ATmega328 28-PDIP",
		"ATmega328",
		"",
		"",
		"ATmega328-PDIP-28",
		'P',
		{ 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0 }, // DDRx
0,
{ { 0, 0 } },
		AvrAtmega328IoPinInfo28,
		arraylen(AvrAtmega328IoPinInfo28),
		AvrAdcPinInfo_6,
		arraylen(AvrAdcPinInfo_6),
0,
{ 0, 0 },
//		17,
		ISA_AVR,
		EnhancedCore128K,
0,
		0,
		AvrPwmPinInfo_6,
		arraylen(AvrPwmPinInfo_6),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Atmel AVR ATmega328 32-Pin packages",
		"ATmega328",
		"", 
		"",
		"ATmega328-TQFP-32",
		'P',								 
		{ 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0 }, // DDRx
0,						   
{ { 0, 0 } },				 
		AvrAtmega328IoPinInfo32,		 
		arraylen(AvrAtmega328IoPinInfo32), 
		AvrAdcPinInfo_8, 
		arraylen(AvrAdcPinInfo_8),
0,				 
{ 0, 0 },						
//		15,								 
		ISA_AVR,						  
		EnhancedCore128K,				
0,
		0,								 
		AvrPwmPinInfo_6,			
		arraylen(AvrPwmPinInfo_6),
		0,
		AvrExtIntPinInfo32,
		arraylen(AvrExtIntPinInfo32),
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	}, 
//=======================================================================================================
	{
		"Atmel AVR ATmega16 40-PDIP",
		"ATmega16",
		"",
		"",
		"ATmega16-PDIP-40", 
		'P',
		{ 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0 }, // DDRx
 0,
 { { 0, 0 } },
		AvrAtmega16IoPinInfo40,
		arraylen(AvrAtmega16IoPinInfo40),
		AvrAdcPinInfo_8,
		arraylen(AvrAdcPinInfo_8),
0,
{ 0, 0 },
//		21, // OC2
		ISA_AVR,
		EnhancedCore128K,
0,
		0,
		AvrPwmPinInfo_4,
		arraylen(AvrPwmPinInfo_4),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Atmel AVR ATmega16U4 44-Pin packages",
		"ATmega16U4",
		"",
		"",
		"ATmega16u4-TQFP-44",
		'P',
//		A	 B	 C	 D	 E	 F	 G	 H	  I   J	  K	  L
		{ 0, 0, 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0, 0 }, // DDRx
  0,
{ { 0, 0 } },
		AvrAtmega16u4IoPinInfo44,
		arraylen(AvrAtmega16u4IoPinInfo44),
		AvrAdcPinInfo_12,
		arraylen(AvrAdcPinInfo_12),
0,
{ 0, 0 },
//		0, // OC2
		ISA_AVR,
		EnhancedCore128K,
0,
		0,
		AvrPwmPinInfo_9,
		arraylen(AvrPwmPinInfo_9),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Atmel AVR ATmega162 40-PDIP",
		"ATmega162",
		"",
		"",
		"ATmega162-PDIP-40",
		'P',
		{ 0, 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0 }, // DDRx
0,
{ { 0, 0 } },
		AvrAtmega162IoPinInfo40,
		arraylen(AvrAtmega162IoPinInfo40),
		AvrAdcPinInfo_8,
		arraylen(AvrAdcPinInfo_8),
		0,
		{ 0, 0 },
//		2, // OC2
		ISA_AVR,
		EnhancedCore128K,
0,
		0,
		AvrPwmPinInfo_6,
		arraylen(AvrPwmPinInfo_6),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		nullptr,
		0,
		{{0,0}}
	},
//=======================================================================================================
	{
		"Atmel AVR ATmega164 40-PDIP",
		"ATmega164",
		"",
		"",
		"ATmega162-PDIP-40",
		'P',
		{ 0, 0, 0, 0, }, // PINx
		{ 0, 0, 0, 0, }, // PORTx
		{ 0, 0, 0, 0, }, // DDRx
0,
{ { 0, 0 } },
		AvrAtmega164IoPinInfo40,
		arraylen(AvrAtmega164IoPinInfo40),
		AvrAdcPinInfo_8,
		arraylen(AvrAdcPinInfo_8),
0,
{ 0, 0 },
//		21,
		ISA_AVR,
		EnhancedCore128K,
0,
		0,
		AvrPwmPinInfo_6,
		arraylen(AvrPwmPinInfo_6),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},

//=======================================================================================================
	{
		"Atmel AVR ATmega32 40-PDIP",
		"ATmega32",
		"",
		"",
		"ATmega32-PDIP-40",
		'P',
		{ 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0 }, // DDRx
0,
{ { 0, 0 } },
		AvrAtmega16IoPinInfo40,
		arraylen(AvrAtmega16IoPinInfo40),
		AvrAdcPinInfo_8,
		arraylen(AvrAdcPinInfo_8),
0,
{ 0, 0 },
//		21, // OC2
		ISA_AVR,
		EnhancedCore128K,
0,
		0,
		AvrPwmPinInfo_4,
		arraylen(AvrPwmPinInfo_4),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Atmel AVR ATmega32U4 44-Pin packages",
		"ATmega32U4",
		"",
		"",
		"ATmega32u4-TQFP-44",
		'P',
//		A	 B	 C	 D	 E	 F	 G	 H	  I   J	  K	  L
		{ 0, 0, 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0, 0 }, // DDRx
  0,
{ { 0, 0 } },
		AvrAtmega16u4IoPinInfo44,
		arraylen(AvrAtmega16u4IoPinInfo44),
		AvrAdcPinInfo_12,
		arraylen(AvrAdcPinInfo_12),
0,
{ 0, 0 },
//		0, // OC2
		ISA_AVR,
		EnhancedCore128K,
0,
		0,
		AvrPwmPinInfo_9,
		arraylen(AvrPwmPinInfo_9),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Atmel AVR ATmega32 44-Pin packages",
		"ATmega32",
		"",
		"",
		"ATmega32-TQFP-44",
		'P',
		{ 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0 }, // DDRx
0,
{ { 0, 0 } },
		AvrAtmega16IoPinInfo44,
		arraylen(AvrAtmega16IoPinInfo44),
		AvrAdcPinInfo_8,
		arraylen(AvrAdcPinInfo_8),
0,
{ 0, 0 },
//		16, // OC2
		ISA_AVR,
		EnhancedCore128K,
0,
		0,
		AvrPwmPinInfo_4,
		arraylen(AvrPwmPinInfo_4),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Atmel AVR ATmega324 40-PDIP",
		"ATmega324",
		"",
		"",
		"ATmega324-PDIP-40",
		'P',
		{ 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0 }, // DDRx
0,
{ { 0, 0 } },
		AvrAtmega164IoPinInfo40,
		arraylen(AvrAtmega164IoPinInfo40),
		AvrAdcPinInfo_8,
		arraylen(AvrAdcPinInfo_8),
0,
{ 0, 0 },
//		21,
		ISA_AVR,
		EnhancedCore128K,
0,
		0,
		AvrPwmPinInfo_6,
		arraylen(AvrPwmPinInfo_6),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},

//=======================================================================================================
	{
		"Atmel AVR ATmega64 64-TQFP",
		"ATmega64",
		"",
		"",
		"ATmega64-TQFP-64",
		'P',
		{ 0, 0, 0, 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0, 0, 0 },
0,
{ { 0, 0 } },
		AvrAtmega64IoPinInfo64,
		arraylen(AvrAtmega64IoPinInfo64),
		AvrAdcPinInfo_8,
		arraylen(AvrAdcPinInfo_8),
0,
{ 0, 0 },
//		17,
		ISA_AVR,
		EnhancedCore128K,
0,
		0,
		AvrPwmPinInfo_8,
		arraylen(AvrPwmPinInfo_8),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Atmel AVR ATmega644 40-PDIP",
		"ATmega644",
		"",
		"",
		"ATmega644-PDIP-40",
		'P',
		{ 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0 }, // DDRx
0,
{ { 0, 0 } },
		AvrAtmega164IoPinInfo40,
		arraylen(AvrAtmega164IoPinInfo40),
		AvrAdcPinInfo_8,
		arraylen(AvrAdcPinInfo_8),
0,
{ 0, 0 },
//		21,
		ISA_AVR,
		EnhancedCore128K,
0,
		0,
		AvrPwmPinInfo_6,
		arraylen(AvrPwmPinInfo_6),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},

//=======================================================================================================
	{
		"Atmel AVR ATmega128 64-TQFP",
		"ATmega128",
		"",
		"",
		"ATmega128-TQFP-64",
		'P',
//		A	 B	 C	 D	 E	 F	 G	 H	  I   J	  K	  L
		{ 0, 0, 0, 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0, 0, 0 }, // DDRx
0,
{ { 0, 0 } },
		AvrAtmega64IoPinInfo64,
		arraylen(AvrAtmega64IoPinInfo64),
		AvrAdcPinInfo_8,
		arraylen(AvrAdcPinInfo_8),
0,
{ 0, 0 },
//		17,
		ISA_AVR,
		EnhancedCore128K,
0,
		0,
		AvrPwmPinInfo_8,
		arraylen(AvrPwmPinInfo_8),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},

//=======================================================================================================
	{
		"Atmel AVR ATmega1284 40-PDIP",
		"ATmega1284",
		"",
		"",
		"ATmega1284-PDIP-40",
		'P',
		{ 0, 0, 0, 0 }, // PINx
		{ 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0 }, // DDRx
0,
 { { 0, 0 } },
		AvrAtmega164IoPinInfo40,
		arraylen(AvrAtmega164IoPinInfo40),
		AvrAdcPinInfo_8,
		arraylen(AvrAdcPinInfo_8),
0,
{ 0, 0 },
//		21,
		ISA_AVR,
		EnhancedCore128K,
0,
		0,
		AvrPwmPinInfo_6,
		arraylen(AvrPwmPinInfo_6),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},
	
//=======================================================================================================
	{
		"Atmel AVR ATmega640 100-TQFP",
		"ATmega640",
		"",
		"",
		"ATmega640-TQFP-100",
		'P',
//		A	 B	 C	 D	 E	 F	 G	 H	  I   J	  K	  L
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, // PINx  input
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, // PORTx output
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, // DDRx  dir
0,
{ { 0, 0 } },
		AvrAtmega640IoPinInfo100,
		arraylen(AvrAtmega640IoPinInfo100),
		AvrAdcPinInfo_16,
		arraylen(AvrAdcPinInfo_16),
0,
{ 0 , 0 },
//		23,
		ISA_AVR,
		EnhancedCore4M,
0,
		0,
		AvrPwmPinInfo_16,
		arraylen(AvrPwmPinInfo_16),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},

//=======================================================================================================
	{
		"Atmel AVR ATmega1280 100-TQFP",
		"ATmega1280",
		"",
		"",
		"ATmega1280-TQFP-100",
		'P',
//		A	 B	 C	 D	 E	 F	 G	 H	  I   J	  K	  L
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, // PINx  input
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, // PORTx output
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, // DDRx  dir
0,
{ { 0, 0 } },
		AvrAtmega640IoPinInfo100,
		arraylen(AvrAtmega640IoPinInfo100),
		AvrAdcPinInfo_16,
		arraylen(AvrAdcPinInfo_16),
0,
{ 0 , 0 },
//		23,
		ISA_AVR,
		EnhancedCore4M,
0,
		0,
		AvrPwmPinInfo_16,
		arraylen(AvrPwmPinInfo_16),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},
	
//=======================================================================================================
	{
		"Atmel AVR ATmega2560 100-TQFP",
		"ATmega2560",
		"",
		"",
		"ATmega2560-TQFP-100",
		'P',
//		A	 B	 C	 D	 E	 F	 G	 H	  I   J	  K	  L
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, // PINx  input
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, // PORTx output
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, // DDRx  dir
0,
{ { 0, 0 } },
		AvrAtmega640IoPinInfo100,
		arraylen(AvrAtmega640IoPinInfo100),
		AvrAdcPinInfo_16,
		arraylen(AvrAdcPinInfo_16),
0,
{ 0 , 0 },
//		23,
		ISA_AVR,
		EnhancedCore4M,
0,
		0,
		AvrPwmPinInfo_16,
		arraylen(AvrPwmPinInfo_16),
		0,
		nullptr,
		0,
		McuAvrSpiInfo_1,
		arraylen(McuAvrSpiInfo_1),
		McuAvrI2cInfo_1,
		arraylen(McuAvrI2cInfo_1),
		{{0,0}}
	},

/*
//=======================================================================================================
	// PIC10
//=======================================================================================================
	{
		"Microchip PIC10F200 6-SOT",
		"PIC10F200",
		"",
		"",
		"",
		'G',
//		A  B  C  D  E  F  G  H  I  J  K  L  M  N  O  P
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x06 }, // PORTx = GPIO
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x06 }, // PORTx
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x06 }, // TRISx
		256-1, //Location 00FFh contains the internal clock oscillator
			   //calibration value. This value should never be overwritten.
		{ { 0x10, 16 } },
		Pic6Pin_SOT23,
		arraylen(Pic6Pin_SOT23),
		nullptr,
		0,
		0,
		{ },
//		0,
		ISA_PIC16,
		BaselineCore12bit,
		6,
			(0 <<  4) |	 // nMCLR disabled
			(1 <<  3) |	 // Code protection disabled
			(0 <<  2) |	 // WDTE disabled
			(0 <<  1) |	 //
			(0 <<  0),	  //
		nullptr,
		0,
		nullptr,
		0,
		nullptr,
		0,
		nullptr,
		0,
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC10F202 6-SOT",
		"PIC10F202",
		"",
		"",
		"",
		'G',
//		A  B  C  D  E  F  G  H  I  J  K  L  M  N  O  P
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x06}, // PORTx = GPIO
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x06}, // PORTx
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x06}, // TRISx
		512-1, //Location 001FFh contains the internal clock oscillator
			   //calibration value. This value should never be overwritten.
		{ { 0x08, 24 } },
		Pic6Pin_SOT23,
		arraylen(Pic6Pin_SOT23),
		nullptr,
		0,
		0,
		{ },
//		0,
		ISA_PIC16,
		BaselineCore12bit,
		6,
			(0 <<  4) |	 // nMCLR disabled
			(1 <<  3) |	 // Code protection disabled
			(0 <<  2) |	 // WDTE disabled
			(0 <<  1) |	 //
			(0 <<  0),	  //
		nullptr,
		0,
		nullptr,
		0,
		nullptr,
		0,
		nullptr,
		0,
		{{0,0}}
	},

//=======================================================================================================
	// PIC12
//=======================================================================================================
	{
		"Microchip PIC12F675 8-pin packages", // or PIC12F629
		"PIC12F675",
		"",
		"",
		"",
		'G',
//		A  B  C  D  E  F  G  H  I  J  K  L  M  N  O  P
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x05}, // PORTx = GPIO
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x05}, // PORTx
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x85}, // TRISx
		1024,
		{ { 0x20, 64 } },
		Pic8Pin,
		arraylen(Pic8Pin),
		Pic8PinAdcPinInfo,
		arraylen(Pic8PinAdcPinInfo),
		1024,
		{ },
//		0,
		ISA_PIC16,
		MidrangeCore14bit,
		8,
		0x3FC4,
		/*
		  ($3f <<  7) |
			(1 <<  6) |	 // BOD enabled, Brown-out Detect Enable
			(0 <<  5) |	 // _MCLR disabled, GP3/MCLR pin function is digital I/O, MCLR internally tied to VDD
			(0 <<  4) |	 // PWRT enabled, Power-up Timer Enable
			(0 <<  3) |	 // WDTE disabled, Watchdog Timer disable
			(4 <<  0),	  // 100 = INTOSC oscillator: I/O function on GP4/OSC2/CLKOUT pin, I/O function on GP5/OSC1/CLKIN
		*
		nullptr,
		0,
		nullptr,
		0,
		nullptr,
		0,
		nullptr,
		0,
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC12F683 8-pin packages",
		"PIC12F683",
		"",
		"",
		"",
		'G',
//		A  B  C  D  E  F  G  H  I  J  K  L  M  N  O  P
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x05}, // PORTx = GPIO
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x05}, // PORTx
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x85}, // TRISx
		2*1024,
		{ { 0x20, 96 }, { 0xA0, 32 } },
		Pic8Pin,
		arraylen(Pic8Pin),
		Pic8PinAdcPinInfo,
		arraylen(Pic8PinAdcPinInfo),
		1024,
		{ },
//		0,
		ISA_PIC16,
		MidrangeCore14bit,
		8,
		0x3FC4,
		/*
			($7f <<7) |
			(1 <<  6) |	 // BOD enabled
			(0 <<  5) |	 // _MCLR disabled
			(0 <<  4) |	 // PWRT enabled
			(0 <<  3) |	 // WDTE disabled
			(4 <<  0),	  // 100 = INTOSC oscillator: I/O function on GP4/OSC2/CLKOUT pin, I/O function on GP5/OSC1/CLKIN
		*
		nullptr,
		0,
		nullptr,
		0,
		nullptr,
		0,
		nullptr,
		0,
		{{0,0}}
	},
*/

//=======================================================================================================
	// PIC16
//=======================================================================================================
	{
		"Microchip PIC16F72 28-Pin PDIP, SOIC, SSOP",
		"PIC16F72",
		"",
		"",
		"Pic16F72-PDIP-28",
		'R',
		{ 0, 0, 0 }, // PORTx = A B C
		{ 0, 0, 0 }, // PORTx
		{ 0, 0, 0 }, // TRISx
0,
{ { 0, 0 } },
		Pic16F72IoPinInfo28,
		arraylen(Pic16F72IoPinInfo28),
		Pic16FAdcPinInfo_5,
		arraylen(Pic16FAdcPinInfo_5),
0,
 { 0, 0 },
//		13,
		ISA_PIC16,
		MidrangeCore14bit,
 0,
 0,		/* 0XD2
			(3 <<  6) |	 // brown-out detect enabled
			(1 <<  4) |	 // code protection disabled
			(0 <<  3) |	 // PWRTE enabled
			(0 <<  2) |	 // WDTE disabled
			(2 <<  0),	  // HS oscillator
*/
		Pic16FPwmPinInfo_1,
		arraylen(Pic16FPwmPinInfo_1),
		0,
		PicExtIntPinInfo28,
		arraylen(PicExtIntPinInfo28),
		McuPic18FSpiInfo_1,
		arraylen(McuPic18FSpiInfo_1),
		McuPic16FI2cInfo_1,
		arraylen(McuPic16FI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC16F88 18-PDIP or 18-SOIC",
		"PIC16F88",
		"",
		"",
		"Pic16F88-PDIP-18",
		'R',
		{ 0, 0 }, // PORTx
		{ 0, 0 }, // PORTx
		{ 0, 0 }, // TRISx
0,
{ { 0, 0 } },
		Pic16F88IoPinInfo18,
		arraylen(Pic16F88IoPinInfo18),
		Pic16FAdcPinInfo_7,
		arraylen(Pic16FAdcPinInfo_7),
0,
{ 0, 0 },
//		0,
		ISA_PIC16,
		MidrangeCore14bit,
0,
0,		/* 0X2F42
//		  (1 << 17) | // IESO: Internal External Switchover mode enabled
//		  (1 << 16) | // FCMEN: Fail-Safe Clock Monitor enabled
			(1 << 13) | // Flash Program Memory Code Protection off
			(0 << 12) | // CCP1 function on RB3 (doesn't matter)
			(1 << 11) | // DEBUG: ICD disabled
			(3 <<  9) | // Flash Program Memory write protection off
			(1 <<  8) | // Data EE Memory Code protection off
			(0 <<  7) | // LVP disabled
			(1 <<  6) | // BOR enabled
			(0 <<  5) | // RA5/nMCLR is RA5
			(0 <<  4) | // FOSC2=0 for osc sel, HS oscillator
			(0 <<  3) | // PWRT enabled
			(0 <<  2) | // WDT disabled
			(2 <<  0),  // HS oscillator
*/
		Pic16FPwmPinInfo_1,
		arraylen(Pic16FPwmPinInfo_1),
		0,
		PicExtIntPinInfo18,
		arraylen(PicExtIntPinInfo18),
		McuPic18FSpiInfo_1,
		arraylen(McuPic18FSpiInfo_1),
		McuPic16FI2cInfo_1,
		arraylen(McuPic16FI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC16F628 18-PDIP or 18-SOIC",
		"PIC16F628",
		"",
		"",
		"Pic16F628-PDIP-18",
		'R',
		{ 0, 0 }, // PORTx
		{ 0, 0 }, // PORTx
		{ 0, 0 }, // TRISx
0,
{ { 0, 0 } },
		Pic16IoPinInfo18,
		arraylen(Pic16IoPinInfo18),
		Pic16FAdcPinInfo_4,
		arraylen(Pic16FAdcPinInfo_4),0,
{ 0, 0 },
//		0,
		ISA_PIC16,
		MidrangeCore14bit,
0,
		// code protection off, data code protection off, LVP disabled,
		// BOD reset enabled, RA5/nMCLR is _MCLR, PWRT enabled, WDT disabled,
0, // HS oscillator, _MCLR		0x3F62
//	  0x3f42, // HS oscillator, RA5 pin function is digital Input
//	  0x3F70, // INTOSC oscillator, _MCLR
//	  0x3F50, // INTOSC oscillator, RA5 pin function is digital Input
			/*
			(1 << 13) | // Code protection off,
			(1 <<  8) | // Data memory code protection off,
			(0 <<  7) | // LVP disabled, RB4/PGM is digital I/O,
			(1 <<  6) | // BOR reset enabled,
//		  (0 <<  5) | // RA5/_MCLR is RA5, RA5 pin function is digital Input,
			(1 <<  5) | // RA5/_MCLR/Vpp pin function is _MCLR
			(0 <<  3) | // PWRT enabled,
			(0 <<  2) | // WDT disabled,
//		  (1 <<  2) | // WDT enabled,
			(2 <<  0),  // HS oscillator: High-speed crystal/resonator on RA6/OSC2/CLKOUT and RA7/OSC1/CLKIN
//	   (0x10 <<  0),  // INTOSC oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN
			*/
		Pic16FPwmPinInfo_1,
		arraylen(Pic16FPwmPinInfo_1),
		0,
		PicExtIntPinInfo18,
		arraylen(PicExtIntPinInfo18),
		nullptr ,
		0,
		nullptr,
		0,
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC16F819 18-PDIP or 18-SOIC",
		"PIC16F819",
		"",
		"",
		"Pic16F819-PDIP-18",
		'R',
		{ 0, 0 }, // PORTx
		{ 0, 0 }, // PORTx
		{ 0, 0 }, // TRISx
0,
{ { 0, 0 } },
		Pic16IoPinInfo18,
		arraylen(Pic16IoPinInfo18),
		Pic16FAdcPinInfo_5,
		arraylen(Pic16FAdcPinInfo_5),
0,
		{ 0, 0 },
//		0,
		ISA_PIC16,
		MidrangeCore14bit,
0,
0,
/* 0x3F42
			(1 << 13) | // code protect off
			(1 << 12) | // CCP1 on RB2 (doesn't matter, can't use)
			(1 << 11) | // disable debugger
			(3 <<  9) | // flash protection off
			(1 <<  8) | // data protect off
			(0 <<  7) | // LVP disabled
			(1 <<  6) | // BOR enabled
			(0 <<  5) | // nMCLR/RA5 is RA5
			(0 <<  3) | // PWRTE enabled
			(0 <<  2) | // WDT disabled
//		  (1 <<  4) | // 100 = INTRC oscillator; port I/O function on both RA6/OSC2/CLKO pin and RA7/OSC1/CLKI pin
			(2 <<  0),  // 010 = HS oscillator
*/
		Pic16FPwmPinInfo_1,
		arraylen(Pic16FPwmPinInfo_1),
		0,
		PicExtIntPinInfo18,
		arraylen(PicExtIntPinInfo18),
		McuPic18FSpiInfo_1,
		arraylen(McuPic18FSpiInfo_1),
		McuPic16FI2cInfo_1,
		arraylen(McuPic16FI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC16F876 28-PDIP or 28-SOIC",
		"PIC16F876",
		"",
		"",
		"Pic16F876-PDIP-28",
		'R',
		{ 0, 0, 0 }, // PORTx
		{ 0, 0, 0 }, // PORTx
		{ 0, 0, 0 }, // TRISx
0,
{ { 0, 0 } },
		Pic16F876IoPinInfo28,
		arraylen(Pic16F876IoPinInfo28),
		Pic16FAdcPinInfo_5,
		arraylen(Pic16FAdcPinInfo_5),
0,
{ 0, 0 },
//		12,
		ISA_PIC16,
		MidrangeCore14bit,
0,
		// code protection off, debug off, flash write off, EE code protection
		// off, LVP disabled, BOD enabled, CP off, PWRT enabled, WDT disabled,
		// HS oscillator
0,
		Pic16FPwmPinInfo_2,
		arraylen(Pic16FPwmPinInfo_2),
		0,
		PicExtIntPinInfo28,
		arraylen(PicExtIntPinInfo28),
		McuPic18FSpiInfo_1,
		arraylen(McuPic18FSpiInfo_1),
		McuPic16FI2cInfo_1,
		arraylen(McuPic16FI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC16F877 40-PDIP",
		"PIC16F877",
		"",
		"",
		"Pic16F877-PDIP-40",
		'R',
		{ 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0 }, // TRISx
0,
 { { 0, 0} },
		Pic16F877IoPinInfo40,
		arraylen(Pic16F877IoPinInfo40),
		Pic16FAdcPinInfo_8,
		arraylen(Pic16FAdcPinInfo_8),
0,
{ 0, 0 },
//		16,
		ISA_PIC16,
		MidrangeCore14bit,
0,
		// code protection off, debug off, flash write off, EE code protection
		// off, LVP disabled, BOD enabled, CP off, PWRT enabled, WDT disabled,
		// HS oscillator
0,
		Pic16FPwmPinInfo_2,
		arraylen(Pic16FPwmPinInfo_2),
		0,
		PicExtIntPinInfo40,
		arraylen(PicExtIntPinInfo40),
		McuPic18FSpiInfo_1,
		arraylen(McuPic18FSpiInfo_1),
		McuPic16FI2cInfo_1,
		arraylen(McuPic16FI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC16F886 28-PDIP or 28-SOIC",
		"PIC16F886",
		"",
		"",
		"Pic16F886-PDIP-28",
		'R',
		{ 0, 0, 0, 0, 0 }, // PORTx = A B C E
		{ 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0 }, // TRISx
0,
{ { 0, 0 } },
		Pic16F886IoPinInfo28,
		arraylen(Pic16F886IoPinInfo28),
		Pic16FAdcPinInfo_11,
		arraylen(Pic16FAdcPinInfo_11),
0,
{0, 0},
//		12,
		ISA_PIC16,
		MidrangeCore14bit,
0,
0,
/*
		 (0x38 << (8+16)) | // Unimplemented: Read as 1
			(3 << (9+16)) | // flash write protection off
			(0 << (8+16)) | // BOR at 2.1 V
		 (0xff << 16) |	 // Unimplemented: Read as 1
			(1 << 13) |	 // ICD disabled
			(0 << 12) |	 // LVP disabled
			(0 << 11) |	 // fail-safe clock monitor disabled
			(0 << 10) |	 // internal/external switchover disabled
			(3 <<  8) |	 // brown-out detect enabled
			(1 <<  7) |	 // data code protection disabled
			(1 <<  6) |	 // code protection disabled
			(1 <<  5) |	 // nMCLR enabled
			(0 <<  4) |	 // PWRTE enabled
			(0 <<  3) |	 // WDTE disabled
			(2 <<  0),	  // HS oscillator
*/
		Pic16FPwmPinInfo_2,
		arraylen(Pic16FPwmPinInfo_2),
0,
		PicExtIntPinInfo28,
		arraylen(PicExtIntPinInfo28),
		McuPic18FSpiInfo_1,
		arraylen(McuPic18FSpiInfo_1),
		McuPic16FI2cInfo_1,
		arraylen(McuPic16FI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC16F887 40-PDIP",
		"PIC16F887",
		"",
		"",
		"Pic16F887-PDIP-40",
		'R',
		{ 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0 }, // TRISx
0,
{ { 0, 0 } },
		Pic16F887IoPinInfo40,
		arraylen(Pic16F887IoPinInfo40),
		Pic16FAdcPinInfo_14,
		arraylen(Pic16FAdcPinInfo_14),
0,
{ 0, 0 },
//		16,
		ISA_PIC16,
		MidrangeCore14bit,
0,
0,
/*
			(3 << (9+16)) | // flash write protection off
			(0 << (8+16)) | // BOR at 2.1 V
			(1 << 13) |	 // ICD disabled
			(0 << 12) |	 // LVP disabled
			(0 << 11) |	 // fail-safe clock monitor disabled
			(0 << 10) |	 // internal/external switchover disabled
			(3 <<  8) |	 // brown-out detect enabled
			(1 <<  7) |	 // data code protection disabled
			(1 <<  6) |	 // code protection disabled
			(1 <<  5) |	 // nMCLR enabled
			(0 <<  4) |	 // PWRTE enabled
			(0 <<  3) |	 // WDTE disabled
			(2 <<  0),	  // HS oscillator
*/
		Pic16FPwmPinInfo_2,
		arraylen(Pic16FPwmPinInfo_2),
		0,
		PicExtIntPinInfo40,
		arraylen(PicExtIntPinInfo40),
		McuPic18FSpiInfo_1,
		arraylen(McuPic18FSpiInfo_1),
		McuPic16FI2cInfo_1,
		arraylen(McuPic16FI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC16F887 44-TQFP",
		"PIC16F887",
		"",
		"",
		"PIC16F887-TQFP-44",
		'R',
		{ 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0 }, // TRISx
0,
{ { 0, 0 } },
		Pic16F887IoPinInfo44,
		arraylen(Pic16F887IoPinInfo44),
		Pic16FAdcPinInfo_14,
		arraylen(Pic16FAdcPinInfo_14),
0,
{ 0, 0 }, // rxPin; txPin;
//		16,
		ISA_PIC16,
		MidrangeCore14bit,
0,
0,
/*
			(3 << (9+16)) | // flash write protection off
			(0 << (8+16)) | // BOR at 2.1 V
			(1 << 13) |	 // ICD disabled
			(0 << 12) |	 // LVP disabled
			(0 << 11) |	 // fail-safe clock monitor disabled
			(0 << 10) |	 // internal/external switchover disabled
			(3 <<  8) |	 // brown-out detect enabled
			(1 <<  7) |	 // data code protection disabled
			(1 <<  6) |	 // code protection disabled
			(1 <<  5) |	 // nMCLR enabled
			(0 <<  4) |	 // PWRTE enabled
			(0 <<  3) |	 // WDTE disabled
			(2 <<  0),	  // HS oscillator
*/
		Pic16FPwmPinInfo_2,
		arraylen(Pic16FPwmPinInfo_2),
		0,
		PicExtIntPinInfo44,
		arraylen(PicExtIntPinInfo44),
		McuPic18FSpiInfo_1,
		arraylen(McuPic18FSpiInfo_1),
		McuPic16FI2cInfo_1,
		arraylen(McuPic16FI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC16F1512 28-Pin SPDIP, SOIC, SSOP",
		"PIC16F1512",
		"",
		"",
		"Pic16F1512-PDIP-28",
		'R',
		{ 0, 0, 0, 0, 0 }, // PORTx = A B C E
		{ 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0 }, // TRISx
0,
 { { 0, 0 } },
		Pic16F151xIoPinInfo28,
		arraylen(Pic16F151xIoPinInfo28),
		Pic16FAdcPinInfo_14,
		arraylen(Pic16FAdcPinInfo_14),
0,
{ 0, 0 },
//		12,
		ISA_PIC16,
		EnhancedMidrangeCore14bit,
0,
0,
/*
			(0 << (13+16)) | // High-voltage on MCLR must be used for programming
			(1 << (12+16)) | // In-Circuit Debugger disabled, ICSPCLK and ICSPDAT are general purpose I/O pins
			(0 << (11+16)) | // Low-Power BOR is enabled
			(1 << (10+16)) | // Brown-out Reset voltage (VBOR), low trip point selected
			(0 << ( 9+16)) | // Stack Overflow or Underflow will not cause a Reset
			(3 << ( 0+16)) | // flash write protection off
			(0 << 13) |	  // fail-safe clock monitor disabled
			(0 << 12) |	  // internal/external switchover disabled
			(3 <<  9) |	  // brown-out detect enabled
			(1 <<  7) |	  // code protection disabled
			(1 <<  6) |	  // nMCLR enabled
			(0 <<  5) |	  // PWRT enabled
			(0 <<  4) |	  // WDT disabled
			(0 <<  3) |	  // WDT disabled
			(2 <<  0),	   // HS oscillator
*/
		Pic16FPwmPinInfo_2,
		arraylen(Pic16FPwmPinInfo_2),
		0,
		PicExtIntPinInfo28,
		arraylen(PicExtIntPinInfo28),
		McuPic16FSpiInfo_1,
		arraylen(McuPic16FSpiInfo_1),
		McuPic16FI2cInfo_1,
		arraylen(McuPic16FI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC16F1516 28-Pin SPDIP, SOIC, SSOP",
		"PIC16F1516",
		"",
		"",
		"Pic16F1516-PDIP-28",
		'R',
		{ 0, 0, 0, 0, 0 }, // PORTx = A B C E
		{ 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0 }, // TRISx
0,
{ { 0, 0 } },
		Pic16F151xIoPinInfo28,
		arraylen(Pic16F151xIoPinInfo28),
		Pic16FAdcPinInfo_14,
		arraylen(Pic16FAdcPinInfo_14),
0,
{ 0, 0 },
//		12,
		ISA_PIC16,
		EnhancedMidrangeCore14bit,
0,
0,
/*
			(0 << (13+16)) | // High-voltage on MCLR must be used for programming
			(1 << (12+16)) | // In-Circuit Debugger disabled, ICSPCLK and ICSPDAT are general purpose I/O pins
			(0 << (11+16)) | // Low-Power BOR is enabled
			(1 << (10+16)) | // Brown-out Reset voltage (VBOR), low trip point selected
			(0 << ( 9+16)) | // Stack Overflow or Underflow will not cause a Reset
			(3 << ( 0+16)) | // flash write protection off
			(0 << 13) |	  // fail-safe clock monitor disabled
			(0 << 12) |	  // internal/external switchover disabled
			(3 <<  9) |	  // brown-out detect enabled
			(1 <<  7) |	  // code protection disabled
			(1 <<  6) |	  // nMCLR enabled
			(0 <<  5) |	  // PWRT enabled
			(0 <<  4) |	  // WDT disabled
			(0 <<  3) |	  // WDT disabled
			(2 <<  0),	   // HS oscillator
*/
		Pic16FPwmPinInfo_2,
		arraylen(Pic16FPwmPinInfo_2),
		0,
		PicExtIntPinInfo28,
		arraylen(PicExtIntPinInfo28),
		McuPic16FSpiInfo_1,
		arraylen(McuPic16FSpiInfo_1),
		McuPic16FI2cInfo_1,
		arraylen(McuPic16FI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC16F1527 64-Pin packages",
		"PIC16F1527",
		"",
		"",
		"Pic16F1527-TQFP-64",
		'R',
		{ 0, 0, 0, 0, 0, 0, 0 }, // PORTx = A B C D E F G
		{ 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x28C, 0x28D0, 0, 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0, 0, 0 }, // TRISx
0,
		{ { 0x20, 96 }, { 0xA0, 80 }, { 0x120, 80 }, { 0x1A0, 80 }, { 0x220, 80 }, { 0x2A0, 80 }, { 0x320, 80 }, { 0x3A0, 80 } },
		Pic16F1527IoPinInfo,
		arraylen(Pic16F1527IoPinInfo),
		Pic16FAdcPinInfo_16,
		arraylen(Pic16FAdcPinInfo_16),
0,
{ 0, 0 }, //, 5, 4 },
//		29,
		ISA_PIC16,
		EnhancedMidrangeCore14bit,
0,
0,
/*
			(0 << (13+16)) | // High-voltage on MCLR must be used for programming
			(1 << (12+16)) | // In-Circuit Debugger disabled, ICSPCLK and ICSPDAT are general purpose I/O pins
			(0 << (11+16)) | // Low-Power BOR is enabled
			(1 << (10+16)) | // Brown-out Reset voltage (VBOR), low trip point selected
			(0 << ( 9+16)) | // Stack Overflow or Underflow will not cause a Reset
			(3 << ( 0+16)) | // flash write protection off
			(0 << 13) |	  // fail-safe clock monitor disabled
			(0 << 12) |	  // internal/external switchover disabled
			(3 <<  9) |	  // brown-out detect enabled
			(1 <<  7) |	  // code protection disabled
			(1 <<  6) |	  // nMCLR enabled
			(0 <<  5) |	  // PWRT enabled
			(0 <<  4) |	  // WDT disabled
			(0 <<  3) |	  // WDT disabled
			(2 <<  0),	   // HS oscillator
*/
		Pic16FPwmPinInfo_10,
		arraylen(Pic16FPwmPinInfo_10),
		0,
		PicExtIntPinInfo64,
		arraylen(PicExtIntPinInfo64),
		McuPic16FSpiInfo_2,
		arraylen(McuPic16FSpiInfo_2),
		McuPic16FI2cInfo_2,
		arraylen(McuPic16FI2cInfo_2),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC16F1824 14-Pin PDIP, SOIC, TSSOP",
		"PIC16F1824",
		"",
		"",
		"Pic16F1824-PDIP-14",
		'R',
		{ 0, 0, 0}, // PORTx
		{ 0, 0, 0 }, // PORTx
		{ 0, 0, 0 }, // TRISx
0,
{ { 0, 0 }, { 0, 0 }, { 0, 8 } },
		Pic16IoPinInfo14,
		arraylen(Pic16IoPinInfo14),
		Pic16FAdcPinInfo_8,
		arraylen(Pic16FAdcPinInfo_8),
0,
{  0, 0 },
//		0, // pwm TODO
		ISA_PIC16,
		EnhancedMidrangeCore14bit,
0,
0,
/*
	   (0 << (13+16)) | // LVP disabled
	   (1 << (12+16)) | // DEBUG disable
	   (1 << (10+16)) | // BORV: Brown-out Reset voltage (Vbor), low trip point selected
	   (1 << ( 9+16)) | // STVREN: Stack Overflow/Underflow Reset Enable bit
	   (0 << ( 8+16)) | // PLLEN: 4xPLL disabled
	 (0xff << (0+16)) | // WRT: Write protection off
			(1 << 13) | // FCMEN enabled
			(1 << 12) | // IESO enabled
			(1 << 11) | // _CLKOUTEN disabled
			(3 <<  9) | // BOR enabled
			(1 <<  8) | // data protect off
			(1 <<  7) | // code protection off
			(0 <<  6) | // nMCLR as digital input
			(0 <<  5) | // PWRTE enabled
		   (00 <<  3) | // WDT disabled
			(4 <<  0),  // 100 = INTRC oscillator 16MHz; port I/O function on both RA6/OSC2/CLKO pin and RA7/OSC1/CLKI pin
		  //(2 <<  0),  // 010 = HS oscillator
*/
		Pic16FPwmPinInfo_4,
		arraylen(Pic16FPwmPinInfo_4),
		0,
		PicExtIntPinInfo14,
		arraylen(PicExtIntPinInfo14),
		McuPic16FSpiInfo_1,
		arraylen(McuPic16FSpiInfo_1),
		McuPic16FI2cInfo_1,
		arraylen(McuPic16FI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC16F1827 18-Pin PDIP, SOIC",
		"PIC16F1827",
		"",
		"",
		"Pic16F1827-PDIP-18",
		'R',
		{ 0, 0 }, // PORTx
		{ 0, 0 }, // PORTx
		{ 0, 0 }, // TRISx
0,
{ { 0, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 } },
		Pic16f1827IoPinInfo,
		arraylen(Pic16f1827IoPinInfo),
		Pic16FAdcPinInfo_12,
		arraylen(Pic16FAdcPinInfo_12),
0,
{ 0, 0 },
//		0, // pwm TODO
		ISA_PIC16,
		EnhancedMidrangeCore14bit,
0,
0,
/*
	   (0 << (13+16)) | // LVP disabled
	   (1 << (12+16)) | // DEBUG disable
	   (1 << (10+16)) | // BORV: Brown-out Reset voltage (Vbor), low trip point selected
	   (1 << ( 9+16)) | // STVREN: Stack Overflow/Underflow Reset Enable bit
	   (0 << ( 8+16)) | // PLLEN: 4xPLL disabled
	 (0xff << (0+16)) | // WRT: Write protection off
			(1 << 13) | // FCMEN enabled
			(1 << 12) | // IESO enabled
			(1 << 11) | // _CLKOUTEN disabled
			(3 <<  9) | // BOR enabled
			(1 <<  8) | // data protect off
			(1 <<  7) | // code protection off
			(0 <<  6) | // nMCLR as digital input
			(0 <<  5) | // PWRTE enabled
		   (00 <<  3) | // WDT disabled
			(4 <<  0),  // 100 = INTRC oscillator 16MHz; port I/O function on both RA6/OSC2/CLKO pin and RA7/OSC1/CLKI pin
		  //(2 <<  0),  // 010 = HS oscillator
*/
		Pic16FPwmPinInfo_4,
		arraylen(Pic16FPwmPinInfo_4),
		0,
		PicExtIntPinInfo18,
		arraylen(PicExtIntPinInfo18),
		McuPic16FSpiInfo_2,
		arraylen(McuPic16FSpiInfo_2),
		McuPic16FI2cInfo_2,
		arraylen(McuPic16FI2cInfo_2),
		{{0,0}}
	},

//=======================================================================================================
	// PIC18
//=======================================================================================================
	{
		"Microchip PIC18F458 40-PDIP",
		"PIC18F458",
		"",
		"",
		"Pic18F458-PDIP-40",
		'R',
		{ 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0 }, // TRISx
  0,
 { { 0, 0 } },
		Pic18F458IoPinInfo40,
		arraylen(Pic18F458IoPinInfo40),
		Pic18FAdcPinInfo_8,
		arraylen(Pic18FAdcPinInfo_8),
0,
{ 0, 0 },
//		16,
		ISA_PIC18,
		PIC18HighEndCore16bit,
0,
		// code protection off, debug off, flash write off, EE code protection
		// off, LVP disabled, BOD enabled, CP off, PWRT enabled, WDT disabled,
		// HS oscillator
0,
		Pic18FPwmPinInfo_1,
		arraylen(Pic18FPwmPinInfo_1),
		0,
		PicExtIntPinInfo40,
		arraylen(PicExtIntPinInfo40),
		McuPic18FSpiInfo_1,
		arraylen(McuPic18FSpiInfo_1),
		McuPic18FI2cInfo_1,
		arraylen(McuPic18FI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC18F4520 40-PDIP",
		"PIC18F4520",
		"",
		"",
		"Pic18F4520-PDIP-40",
		'R',
		{ 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0 }, // TRISx
  0,
 { { 0, 0 } },
		Pic18F4520IoPinInfo40,
		arraylen(Pic18F4520IoPinInfo40),
		Pic18FAdcPinInfo_8,
		arraylen(Pic18FAdcPinInfo_8),
0,
{ 0, 0 },
//		16,
		ISA_PIC18,
		PIC18HighEndCore16bit,
0,
		// code protection off, debug off, flash write off, EE code protection
		// off, LVP disabled, BOD enabled, CP off, PWRT enabled, WDT disabled,
		// HS oscillator
0,
		Pic18FPwmPinInfo_2,
		arraylen(Pic18FPwmPinInfo_2),
		0,
		PicExtIntPinInfo40,
		arraylen(PicExtIntPinInfo40),
		McuPic18FSpiInfo_1,
		arraylen(McuPic18FSpiInfo_1),
		McuPic18FI2cInfo_1,
		arraylen(McuPic18FI2cInfo_1),
		{{0,0}}
	},
//=======================================================================================================
	{
		"Microchip PIC18F4550 40-PDIP",
		"PIC18F4550",
		"",
		"",
		"Pic18F4550-PDIP-40",
		'R',
		{ 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0 }, // PORTx
		{ 0, 0, 0, 0, 0 }, // TRISx
  0,
 { { 0, 0 } },
		Pic18F4550IoPinInfo40,
		arraylen(Pic18F4550IoPinInfo40),
		Pic18FAdcPinInfo_12,
		arraylen(Pic18FAdcPinInfo_12),
0,
{ 0, 0 },
//		16,
		ISA_PIC18,
		PIC18HighEndCore16bit,
0,
		// code protection off, debug off, flash write off, EE code protection
		// off, LVP disabled, BOD enabled, CP off, PWRT enabled, WDT disabled,
		// HS oscillator
0,
		Pic18FPwmPinInfo_2,
		arraylen(Pic18FPwmPinInfo_2),
		0,
		PicExtIntPinInfo40,
		arraylen(PicExtIntPinInfo40),
		McuPic18FSpiInfo_1,
		arraylen(McuPic18FSpiInfo_1),
		McuPic18FI2cInfo_1,
		arraylen(McuPic18FI2cInfo_1),
		{{0,0}}
	},


//=======================================================================================================
	// ARM
//===========================================================================
	{
		"St ARM STM32F40X 144-LQFP",					// Nom
		"STM32F40X",									// Liste d'alias
		"",
		"",
		"Stm32F40X-LQFP-144",
		'P',										// Prefixe ports
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},   // Adresses registres In
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},   // Adresses registres Out
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},   // Adresses registres Dir
0,								 // 1 MO Flash
{ { 0, 0 } },						// RAM debut + taille
		ArmSTM32F40XIoPinInfo144,			  // Pin info
		arraylen(ArmSTM32F40XIoPinInfo144),	// Nb broches (declarees)
		ArmSTM32AdcPinInfo_9,			 // Adc info
		arraylen(ArmSTM32AdcPinInfo_9),										  // Nb Adc
0,									   // Adc valeur Maxi						  // 12 bits
{0, 0},								   // UART RX + TX (UART 6)					// RXn + TXn in I/O definition
//		0,										  // PWM default Pin
		ISA_ARM,									// Type
		CortexF4,								   // Core
0,										// Nb de broches
		0,										  // For PIC but may be used for ARM
		ArmSTM32PwmPinInfo_12,			 // Pwm info
		arraylen(ArmSTM32PwmPinInfo_12),   // Pwm info size
		0,
		nullptr,									// ExtInt info
		0,										  // ExtInt info size
		ArmSTM32SpiInfo_3,			 // SPI info
		arraylen(ArmSTM32SpiInfo_3),   // SPI info size
		ArmSTM32I2cInfo_3,			 // I2C info
		arraylen(ArmSTM32I2cInfo_3),   // I2C info size
		{{0,0}}
	},
//=======================================================================================================
	{	
		"St ARM STM32F10X 48-LQFP / Bluepill",		// Nom
		"STM32F10X",								// Liste d'alias
		"BLUEPILL",
		"",
		"Stm32F10X-LQFP-48",
		'P',										// Prefixe ports
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},	 // Adresses registres In
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},	 // Adresses registres Out
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},			  // Adresses registres Dir
0,								  // 128 KO Flash
{ { 0, 0} },				 // debut + taille
		ArmSTM32F10XIoPinInfo48,			   // Pin info
		arraylen(ArmSTM32F10XIoPinInfo48),	 // Nb broches (declarees)
		ArmSTM32AdcPinInfo_8,			  // Adc info
		arraylen(ArmSTM32AdcPinInfo_8),										  // Nb Adc
0,									   // Adc valeur Maxi						  // 12 bits
{ 0, 0},								   // UART RX + TX (UART 3)					// RXn + TXn in I/O definition
//		0,										  // PWM default Pin
		ISA_ARM,									// Type
		CortexF1,								   // Core
0,										 // Nb de broches
		0,										  // For PIC but may be used for ARM
		ArmSTM32PwmPinInfo_12,			  // Pwm info
		arraylen(ArmSTM32PwmPinInfo_12),	// Pwm info size
		0,
		nullptr,									// ExtInt info
		0,										  // ExtInt info size
		ArmSTM32SpiInfo_2,			  // SPI info
		arraylen(ArmSTM32SpiInfo_2),	// SPI info size
		ArmSTM32I2cInfo_2,			  // I2C info
		arraylen(ArmSTM32I2cInfo_2),	// I2C info size
		{{0,0}}
	},

//===========================================================================

/* JG6
	{
		"Controllino Maxi / Ext bytecode",
		"ControllinoMaxi",
		"",
		"",
		"",
		'P',
		{ 0x20, 0x23, 0x26, 0x29, 0x2C, 0x2F, 0x32, 0x100, 0x103, 0x106, 0x109 }, // PINx
		{ 0x22, 0x25, 0x28, 0x2B, 0x2E, 0x32, 0x34, 0x102, 0x105, 0x108, 0x10B }, // PORTx
		{ 0x21, 0x24, 0x27, 0x2A, 0x2D, 0x30, 0x33, 0x101, 0x104, 0x107, 0x10A }, // DDRx
		128 * 1024,
		{ { 0x200, 8192 } },
		ControllinoMaxiIoPinInfo,
		arraylen(ControllinoMaxiIoPinInfo),
		ControllinoMaxiAdcPinInfo,
		arraylen(ControllinoMaxiAdcPinInfo),
		1023,
		{ 2 , 3 },
//		23,
		ISA_XINTERPRETED,
		EnhancedCore4M,
		100,
		0,
		ControllinoMaxiPwmPinInfo,
		arraylen(ControllinoMaxiPwmPinInfo),
		nullptr,
		0,
		nullptr,
		0,
		nullptr,
		0,
		{{0,0}}
	},

	{
		"PC LPT COM",
		"PcLptCom",
		"",
		"",
		"",
		'L', // PC LPT & COM support
		{ 0x00 },
		{ 0x00 },
		{ 0x00 },
		0,
		{ { 0x00, int(0xffffff) } },
		PcCfg,
		arraylen(PcCfg),
		nullptr,
		0,
		0,
		{ 0, 0 },
//		0,
		ISA_PC,
		PC_LPT_COM,
		0,
		0,
		nullptr,
		0,
		nullptr,
		0,
		nullptr,
		0,
		nullptr,
		0,
		{{0,0}}
	},
*/
};

// clang-format on

std::vector<McuIoInfo> SupportedMcus(SupportedMcus_, SupportedMcus_ + arraylen(SupportedMcus_));

#endif //__MCUTABLE_H__

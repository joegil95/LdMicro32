#ifndef __LDMICRO_VER_H__
#define __LDMICRO_VER_H__

#define LDMICRO_VER_STR		   "32-6.0.a"

/* JG6
//   |	 |
#define LDMICRO_VER_MAJOR (32) // <-+	 |
#define LDMICRO_VER_MINOR (6) //		 |
#define LDMICRO_VER_PATCH (0) //		 |
#define LDMICRO_VER_TWEAK (4) // <-------+
*/
#endif

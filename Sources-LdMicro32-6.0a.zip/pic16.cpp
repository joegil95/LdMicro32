//-----------------------------------------------------------------------------
// Copyright 2007 Jonathan Westhues
// Copyright 2015 Nehrutsa Ihor
//
// This file is part of LDmicro.
//
// LDmicro is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// LDmicro is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with LDmicro.  If not, see <http://www.gnu.org/licenses/>.
//------
//
// A PIC16... assembler, for our own internal use, plus routines to generate
// code from the ladder logic structure, plus routines to generate the
// runtime needed to schedule the cycles.
// Jonathan Westhues, Oct 2004
//-----------------------------------------------------------------------------
#include "stdafx.h"

#include "ldmicro.h"
#include "intcode.h"


int32_t PicProgLdLen = 0;

PlcTimerData plcTmr;


bool McuAs(const char *str)
	{
	if(!Prog.mcu())
		return 0;

	return strstr(Prog.mcu()->mcuName, str) != nullptr;
	}


//-----------------------------------------------------------------------------
static void SetPrescaler(int tmr)
	{
	if(tmr == 0) 
		{
		// set up prescaler
		if(plcTmr.prescaler == 1)
			plcTmr.ps = 0x07; // wdt 2.3s
		else if(plcTmr.prescaler == 2)
			plcTmr.ps = 0x00;
		else if(plcTmr.prescaler == 4)
			plcTmr.ps = 0x01;
		else if(plcTmr.prescaler == 8)
			plcTmr.ps = 0x02;
		else if(plcTmr.prescaler == 16)
			plcTmr.ps = 0x03;
		else if(plcTmr.prescaler == 32)
			plcTmr.ps = 0x04;
		else if(plcTmr.prescaler == 64)
			plcTmr.ps = 0x05;
		else if(plcTmr.prescaler == 128)
			plcTmr.ps = 0x06;
		else if(plcTmr.prescaler == 256)
			plcTmr.ps = 0x07;
		else
			THROW_INTERNAL_EXCEPTION_FMT("%ld", plcTmr.prescaler);
		} 
	else if(tmr == 1) 
		{
		plcTmr.ps = 0x00;
		// set up prescaler
		if(plcTmr.prescaler == 1)
			plcTmr.ps |= 0x00;
		else if(plcTmr.prescaler == 2)
			plcTmr.ps |= 0x10;
		else if(plcTmr.prescaler == 4)
			plcTmr.ps |= 0x20;
		else if(plcTmr.prescaler == 8)
			plcTmr.ps |= 0x30;
		else
			THROW_INTERNAL_EXCEPTION_FMT("%ld", plcTmr.prescaler);
		// enable clock, internal source
		plcTmr.ps |= 0x01; // TMR1ON
		} 
	else
		oops();
	}

//-----------------------------------------------------------------------------
// Calc PIC 16-bit Timer1 or 8-bit Timer0  to do the timing of PLC cycle.
bool CalcPicPlcCycle(long long int cycleTimeMicroseconds, int32_t PicProgLdLen)
	{
	//memset(plcTmr, 0, sizeof(plcTmr));
	plcTmr.ticksPerCycle = (long long int)floor(1.0 * Prog.mcuClock / 4 * cycleTimeMicroseconds / 1000000 + 0.5);
	plcTmr.softDivisor = 1;
	plcTmr.prescaler = 1;
	plcTmr.ps = 0;
	plcTmr.cycleTimeMin = (int)floor(1e6 * (PLC_CLOCK_MIN * 2) * 1 * 4 / Prog.mcuClock + 0.5);
	//									  ^min_divider		 ^min_prescaler
	long int max_tmr, max_prescaler, max_softDivisor;
	if(Prog.cycleTimer == 0) 
		{
		max_tmr = 0x100;
		max_prescaler = 256;
		max_softDivisor = 0xFF; // 1..0xFFFF
		} 
	else 
		{
		max_tmr = 0x10000;
		max_prescaler = 8;
		max_softDivisor = 0xFF; // 1..0xFF
		}
	plcTmr.cycleTimeMax = (long long int)floor(1.0e6 * max_tmr * max_prescaler * max_softDivisor * 4 / Prog.mcuClock + 0.5);

	long int	  bestTmr = LONG_MIN / 4;
	long int	  bestPrescaler = LONG_MAX / 4;
	long int	  bestSoftDivisor = 1;
	long long int bestErr = LLONG_MAX / 4;
	long long int err;

	while(plcTmr.softDivisor <= max_softDivisor) 
		{
		plcTmr.prescaler = max_prescaler;
		while(plcTmr.prescaler >= 1) 
			{
			for(plcTmr.tmr = 1; plcTmr.tmr <= max_tmr; plcTmr.tmr++) 
				{
				err = plcTmr.ticksPerCycle - (long long int)plcTmr.tmr * plcTmr.prescaler * plcTmr.softDivisor;
				if(err < 0)
					err = -err;

				if((PicProgLdLen <= 0) || (plcTmr.prescaler * plcTmr.tmr >= PicProgLdLen / 3))
					if((bestErr > err) || ((bestErr == err) && (bestPrescaler < plcTmr.prescaler))) 
						{
						bestErr = err;
						bestSoftDivisor = plcTmr.softDivisor;
						bestPrescaler = plcTmr.prescaler;
						bestTmr = plcTmr.tmr;
						if(err == 0)
							goto err0;
						}
				}
			plcTmr.prescaler /= 2;
			}
		if(plcTmr.softDivisor == max_softDivisor)
			break;
		plcTmr.softDivisor++;
		}
err0:
	plcTmr.softDivisor = bestSoftDivisor;
	plcTmr.prescaler = bestPrescaler;
	plcTmr.tmr = bestTmr;
	plcTmr.Fcycle = 1.0 * Prog.mcuClock / (4.0 * plcTmr.softDivisor * plcTmr.prescaler * plcTmr.tmr);
	plcTmr.TCycle = 4.0 * plcTmr.prescaler * plcTmr.softDivisor * plcTmr.tmr / (1.0 * Prog.mcuClock);
	SetPrescaler(Prog.cycleTimer);
	if(cycleTimeMicroseconds > plcTmr.cycleTimeMax) 
		{
		Error(_("PLC cycle time more than %.3f ms not valid."), 0.001 * plcTmr.cycleTimeMax);
		return false;
		} 
	else if(cycleTimeMicroseconds < plcTmr.cycleTimeMin) 
		{
		Error(_("PLC cycle time less than %.3f ms not valid."), 0.001 * plcTmr.cycleTimeMin);
		return false;
		}
	return true;
	}


//-----------------------------------------------------------------------------
void CalcPicUartBaudRate(int32_t mcuClock, int32_t baudRate, int *divisor, int *brgh)
	{
	if(baudRate == 0) 
		{
		THROW_INTERNAL_EXCEPTION(_("Zero baud rate not possible."));
		}
	// So now we should set up the UART. First let us calculate the
	// baud rate; there is so little point in the fast baud rates that
	// I won't even bother, so
	// bps = Fosc/(64*(X+1))
	// bps*64*(X + 1) = Fosc
	// X = Fosc/(bps*64)-1
	// and round, don't truncate
	/*
		BRGH = 1 --> Baud Rate = FOSC/(16(X+1))
		BRGH = 0 --> Baud Rate = FOSC/(64(X+1))
		*/
	int div1 = (mcuClock + baudRate * 8) / (baudRate * 16) - 1;
	int div0 = (mcuClock + baudRate * 32) / (baudRate * 64) - 1;

	double actual1 = 1.0 * mcuClock / (16 * (div1 + 1));
	double actual0 = 1.0 * mcuClock / (64 * (div0 + 1));

	double percentErr1 = 100.0 * (actual1 - baudRate) / baudRate;
	double percentErr0 = 100.0 * (actual0 - baudRate) / baudRate;

	double actual;
	double percentErr;

	if((fabs(percentErr1) < fabs(percentErr0)) && (div1 <= 255)) 
		{
		actual = actual1;
		percentErr = percentErr1;
		*divisor = div1;
		*brgh = 1;
		} 
	else 
		{
		actual = actual0;
		percentErr = percentErr0;
		*divisor = div0;
		*brgh = 0;
		}
	if(*divisor > 255) 
		{
		*divisor = 255;
		ComplainAboutBaudRateOverflow();
		}

	if(fabs(percentErr) > 2)
		ComplainAboutBaudRateError(*divisor, actual, percentErr);
	}

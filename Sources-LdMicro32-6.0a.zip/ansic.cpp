//-----------------------------------------------------------------------------
// Copyright 2021 Jos� GILLES
//
// This file is part of LDmicro32.
//
// LDmicro32 is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// LDmicro32 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

#include "stdafx.h"

#include "ldmicro.h"

#include "lad2c/lad2c.h"
#include "lad2c/common.h"

extern GlobalIO * IOList;

extern int RST_USED;

extern int ADC_USED;
extern int ADC_Used[];

extern int PWM_USED;
extern int PWM_Used[];

extern int UART_USED;
extern int I2C_USED;
extern int SPI_USED;

extern int TEMPO_USED;
extern int OSC_USED;
extern int COUNT_USED;
extern int TIME_USED;
extern int QUADENCOD_USED;
extern int PULSE_USED;
extern int STEP_USED;
extern int STRING_USED;
extern int SHIFTREG_USED;
extern int PLTAB_USED;
extern int LUTAB_USED;
extern int PERSIST_USED;
extern int MODBUS_USED;
extern int BITOPS_USED;
extern int BCDOPS_USED;
extern int DISPLAY_USED;


// Select Contacts to compile and link
// Don't forget to reset variables XXX_USED !
int EnableContacts(char * contype)
	{
	FILE * flad;
	Name lname= "";

	strcpy(lname, CurrentCompilePath);
	strcat(lname, "\\ladder.h");
	flad= fopen(lname, "a+t");
	if (flad == NULL) return 0;

	if ((str_equal(contype, "TEMPO")) && (!TEMPO_USED))
		{
		fputs("#define TEMPO_USED\n", flad);
		TEMPO_USED= 1;
		}
	if ((str_equal(contype, "OSC")) && (!OSC_USED))
		{
		fputs("#define OSC_USED\n", flad);
		OSC_USED= 1;
		}
	if ((str_equal(contype, "COUNT")) && (!COUNT_USED))
		{
		fputs("#define COUNT_USED\n", flad);
		COUNT_USED= 1;
		}
	if ((str_equal(contype, "TIME")) && (!TIME_USED))
		{
		fputs("#define TIME_USED\n", flad);
		TIME_USED= 1;
		}
	if ((str_equal(contype, "QUADENCOD")) && (!QUADENCOD_USED))
		{
		fputs("#define QUADENCOD_USED\n", flad);
		QUADENCOD_USED= 1;
		}
	if ((str_equal(contype, "PULSE")) && (!PULSE_USED))
		{
		fputs("#define PULSE_USED\n", flad);
		PULSE_USED= 1;
		}
	if ((str_equal(contype, "STRING")) && (!STRING_USED))
		{
		fputs("#define STRING_USED\n", flad);
		STRING_USED= 1;
		}
	if ((str_equal(contype, "SHIFTREG")) && (!SHIFTREG_USED))
		{
		fputs("#define SHIFTREG_USED\n", flad);
		SHIFTREG_USED= 1;
		}
	if ((str_equal(contype, "PLTAB")) && (!PLTAB_USED))
		{
		fputs("#define PLTAB_USED\n", flad);
		PLTAB_USED= 1;
		}
	if ((str_equal(contype, "LUTAB")) && (!LUTAB_USED))
		{
		fputs("#define LUTAB_USED\n", flad);
		LUTAB_USED= 1;
		}
	if ((str_equal(contype, "PERSIST")) && (!PERSIST_USED))
		{
		fputs("#define PERSIST_USED\n", flad);
		PERSIST_USED= 1;
		}
	if ((str_equal(contype, "MODBUS")) && (!MODBUS_USED))
		{
		fputs("#define MODBUS_USED\n", flad);
		MODBUS_USED= 1;
		}
	if ((str_equal(contype, "BITOPS")) && (!BITOPS_USED))
		{
		fputs("#define BITOPS_USED\n", flad);
		BITOPS_USED= 1;
		}
	if ((str_equal(contype, "BCDOPS")) && (!BCDOPS_USED))
		{
		fputs("#define BCDOPS_USED\n", flad);
		BCDOPS_USED= 1;
		}
	if ((str_equal(contype, "DISPLAY")) && (!DISPLAY_USED))
		{
		fputs("#define DISPLAY_USED\n", flad);
		DISPLAY_USED= 1;
		}

/*
if ((str_equal(contype, "XXX")) && (!XXX_USED))
		{
		fputs("#define XXX_USED\n", flad);
		XXX_USED= 1;
		}
*/

	fclose(flad);
	}

// RESET management
int Configure_Reset(int mcuisa, FILE * ffuncdef)
	{
	if (!Prog.mcu()) return 0;
	if (RST_USED) return 1;

	if (mcuisa == ISA_ARM)
		{	
		fprintf(ffuncdef, "void Reset_Mcu(void)\n");
		fprintf(ffuncdef, "\t{\n");
		fprintf(ffuncdef, "\tReset_Handler();\n");
		fprintf(ffuncdef, "\t}\n\n");	
		}

	if (mcuisa == ISA_AVR)
		{	
		fprintf(ffuncdef, "void Reset_Mcu(void)\n");
		fprintf(ffuncdef, "\t{\n");
		fprintf(ffuncdef, "\tasm(\"JMP 0\");\n");
		fprintf(ffuncdef, "\t}\n\n");	
		}

	if (mcuisa == ISA_PIC16)
		{
		fprintf(ffuncdef, "void Reset_Mcu(void)\n");
		fprintf(ffuncdef, "\t{\n");
		fprintf(ffuncdef, "\t#asm\n");
		fprintf(ffuncdef, "\tljmp 0\n");
		fprintf(ffuncdef, "\t#endasm\n");
		fprintf(ffuncdef, "\t}\n\n");	
		}

	if (mcuisa == ISA_PIC18)
		{
		fprintf(ffuncdef, "void Reset_Mcu(void)\n");
		fprintf(ffuncdef, "\t{\n");
		fprintf(ffuncdef, "\t#asm\n");
		fprintf(ffuncdef, "\treset\n");
		fprintf(ffuncdef, "\t#endasm\n");
		fprintf(ffuncdef, "\t}\n\n");	
		}

	RST_USED= 1;
	return 1;
	}

// ADC initialization
int Configure_Adc(int mcuisa, char * ioname, char * refs, FILE * fhead, FILE * ffuncdef, FILE * fdev, char * lptr)
	{
	int adc = 0;
	int chan = 0;
	long resol= 0;

	if (Prog.mcu()) resol= Prog.mcu()->adcMax;
	else return 0;

	McuIoPinInfo *iop = PinInfoForName(ioname);		// infos on pin used by this ADC
	if(!iop)
		{
		THROW_INTERNAL_EXCEPTION(_("ADC pin error"));	// Error in pin layout
		return 0;
		}

	const char *s = iop->pinName;	// full pin name supposed to be in format (ADCn.c) n= ADC#, c= Channel#
	if(strlen(s))					// or in format (ANn) for PICs
		{   
		const char *pos = strstr(s, "ADC");
		if(pos) 
			{
			adc = atoi(pos + 3);				// ADC # from pin description
			chan = MuxForAdcVariable(ioname);	// channel # from McuAdcPinInfo (could also be retrieved from s)
			} 
		else	// PICs
			{
			pos = strstr(s, "AN");
			if(pos) 
				{
				adc = atoi(pos + 2);		// AN # from pin description
				chan = 1;
				} 		
			else 
				{
				THROW_INTERNAL_EXCEPTION(_("ADC pin error"));	// Error in pin layout
				return 0;
				}
			}
		}
	else
		{
		THROW_INTERNAL_EXCEPTION(_("ADC Internal error"));	// Error in ADC layout
		return 0;
		}

	if (mcuisa == ISA_ARM)
		{
		if (!ADC_USED)
			{
			fprintf(fhead, "#include \"Lib_adc.h\"\n\n");
			ADC_USED= 1;
			}

		if (!ADC_Used[16*adc+chan])
			{
			// one function for each ADC in use
			fprintf(ffuncdef, "integer Read_%s(void)\n", ioname);
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tinteger v= 0;\n");
			fprintf(ffuncdef, "\tv = LibADC_Read(ADC%d, ADC_Channel_%d);\n", adc, chan);
			fprintf(ffuncdef, "\treturn v;\n");
			fprintf(ffuncdef, "\t}\n\n");

			// Warning: only 12 bit resolution is available on Bluepill !
			fprintf(fdev, "LibADC_Init(ADC%d, ADC_Channel_%d, ADC_Resolution_%ldb);\n\n", adc, chan, resol);

			ADC_Used[16*adc+chan]= 1;
			}
		}

	if (mcuisa == ISA_AVR)
		{
		if (!ADC_USED)
			{
			fprintf(fhead, "#include \"AdcLib.h\"\n\n");

			fprintf(fdev, "ADC_Init(1, %ld);\n\n", resol);			// Predivision= 2^1
			ADC_USED= 1;
			}

		chan= adc;		// Only one ADC for AVRs
		adc= 0;

		if (!ADC_Used[chan])
			{
			// One function for each ADC in use
			fprintf(ffuncdef, "integer Read_%s(void)\n", ioname);
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tinteger v= 0;\n");
			fprintf(ffuncdef, "\tv = ADC_Read(%d);\n", chan);
			fprintf(ffuncdef, "\treturn v;\n");
			fprintf(ffuncdef, "\t}\n\n");

			ADC_Used[chan]= 1;
			}
		}

	if ((mcuisa == ISA_PIC16) || (mcuisa == ISA_PIC18))
		{
		if (!ADC_USED)
			{
			fprintf(fhead, "#include \"AdcLib.h\"\n\n");

			fprintf(fdev, "ADC_Init();\n\n");
			ADC_USED= 1;
			}

		chan= adc;		// Only one ADC for PICs
		adc= 0;

		if (!ADC_Used[chan])
			{
			// One function for each ADC in use
			fprintf(ffuncdef, "integer Read_%s(void)\n", ioname);
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tinteger v= 0;\n");
			fprintf(ffuncdef, "\tv = ADC_Read(%d, %s);\n", chan, refs);
			fprintf(ffuncdef, "\treturn v;\n");
			fprintf(ffuncdef, "\t}\n\n");

			ADC_Used[chan]= 1;
			}
		}

	return 1;
	}


// PWM initialization
int Configure_Pwm(int mcuisa, char * ioname, long freq, FILE * fhead, FILE * ffuncdef, FILE * fdev, char * lptr)
	{
	int pwm= 0;
	int chan= 0;
	long resol= 0;
	int tim= 0;
	int maxcs= 0;
	String info= "", resp= "";

	if (Prog.mcu()) resol= Prog.mcu()->pwmMax;
	else return 0;

	McuIoPinInfo *iop = PinInfoForName(ioname);		// Infos on pin used by this PWM
	if(!iop)
		{
		THROW_INTERNAL_EXCEPTION(_("PWM pin error"));	// Error in pin layout
		return 0;
		}

	const char *s = iop->pinName;	// Full pin name supposed to be in format (PWMn.c) n= PWM#, c= Channel#
	if(strlen(s))					// or in format (PWMnx) n=PWM#, x= Channel A,B,C...
		{   
		const char *pos = strstr(s, "PWM");
		if(pos) 
			{
			pwm = atoi(pos + 3);		// PWM#
			tim= pwm;					// For ARMs, AVRs timer# = PWM#

			const char *p = strchr(pos, '.');
			if(p) 
				{
				chan= atoi(p + 1);		// Channel# for ARMs
				} 
			else
				{
				pwm= strtol(pos + 3, nullptr, 16);		// PWM# for AVRs (0x01, 0x02, 0x3A, 0x3B...)
				chan= 0;								// No channel for AVRs
				}
			} 
		else
			{
			THROW_INTERNAL_EXCEPTION(_("PWM pin error"));	// Error in pin layout
			return 0;
			}
		}
	else 
		{
		THROW_INTERNAL_EXCEPTION(_("PWM Internal error"));	// Error in PWM layout
		return 0;
		}

	if (mcuisa == ISA_ARM)
		{
		if (!PWM_USED)
			{
			fprintf(fhead, "#include \"Lib_pwm.h\"\n\n");
			PWM_USED= 1;
			}

		if (!PWM_Used[16*pwm+chan])
			{
			// One function for each PWM in use
			fprintf(ffuncdef, "LibPWM_TIM_t TIM%d_Chan%d;\n\n", pwm, chan);

			fprintf(ffuncdef, "void Pwm_%s(long freq, long percent)\n", ioname);
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tstatic long oldfreq= 0;\n");
			fprintf(ffuncdef, "\tif (freq != oldfreq)\n");
			fprintf(ffuncdef, "\t\tLibPWM_InitTimer(TIM%d, &TIM%d_Chan%d, (double) freq);\n", tim, tim, chan);
			fprintf(ffuncdef, "\tLibPWM_SetChannelPercent(&TIM%d_Chan%d, LibPWM_Channel_%d, percent);\n", tim, chan, chan);
			fprintf(ffuncdef, "\toldfreq= freq;\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "void Pwm_%s_Stop(void)\n", ioname);
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tPwm_%s(0, 0);\n", ioname);				// Set freq to 0 so that PWM can be restarted
			fprintf(ffuncdef, "\tLibPWM_StopTimer(TIM%d);\n", tim);
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(fdev, "LibPWM_InitTimer(TIM%d, &TIM%d_Chan%d, %ld);\n", tim, tim, chan, freq);
			if((Prog.mcu()) && (Prog.mcu()->core == CortexF1))
				fprintf(fdev, "LibPWM_InitChannel(&TIM%d_Chan%d, LibPWM_Channel_%d);\n\n", tim, chan, chan);
			else if((Prog.mcu()) && (Prog.mcu()->core == CortexF4))
				fprintf(fdev, "LibPWM_InitChannel(&TIM%d_Chan%d, LibPWM_Channel_%d, LibPWM_PinsPack_2);\n\n", tim, chan, chan);

			PWM_Used[16*pwm+chan] = 1;		// Marked as used PWM 4.1 -> 0x41
			}
		}

	if (mcuisa == ISA_AVR)	
		{
		if (!PWM_USED)
			{
			fprintf(fhead, "#include \"PwmLib.h\"\n\n");
			PWM_USED= 1;
			}

		McuPwmPinInfo *ioq = PwmMaxInfoForName(ioname, Prog.cycleTimer);
		if (ioq)
			{
			maxcs= ioq->maxcs;			// Number of possible prediv (5 or 7)
			resol= ioq->resolution;		// Number of bits (8 or 10)
			}
		else
			{
			THROW_INTERNAL_EXCEPTION(_("PWM Internal error"));	// Error in PWM layout
			return 0;
			}

		if (!PWM_Used[pwm])
			{
			// one function for each PWM in use
			fprintf(ffuncdef, "void Pwm_%s(long freq, long percent)\n", ioname);
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tstatic long oldfreq= 0;\n");
			fprintf(ffuncdef, "\tif (freq != oldfreq)\n");
			fprintf(ffuncdef, "\t\tPWM_Init(0x%2.2X, %d, %ld, %ld, %d);\n", pwm, Prog.mcuClock, freq, resol, maxcs);
			fprintf(ffuncdef, "\tPWM_Set(0x%2.2X, percent, %ld);\n", pwm, resol);
			fprintf(ffuncdef, "\toldfreq= freq;\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "void Pwm_%s_Stop(void)\n", ioname);
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tPwm_%s(0, 0);\n", ioname);				// Set freq to 0 so that PWM can be restarted
			fprintf(ffuncdef, "\tPWM_Stop(%d);\n", pwm);
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(fdev, "PWM_Init(0x%2.2X, %d, %ld, %ld, %d);\n\n", pwm, Prog.mcuClock, freq, resol, maxcs);

			PWM_Used[pwm] = 1;		// Marked as used PWM 1 -> 0x01 ; PWM 2A -> 0x2A
			}
		}

	if ((mcuisa == ISA_PIC16) || (mcuisa == ISA_PIC18))
		{
		if (!PWM_USED)
			{
			fprintf(fhead, "#include \"PwmLib.h\"\n\n");
			PWM_USED= 1;
			}

		McuPwmPinInfo *pop = PwmPinInfo(iop->pin);
		if(pop) 
			{
			tim = pop->timer;				// PWM Timer
			resol= pop->resolution;
			}
		else
			{
			THROW_INTERNAL_EXCEPTION(_("PWM Internal error"));	// Error in PWM layout
			return 0;
			}

		if (!PWM_Used[pwm])
			{
			// one function for each PWM in use
			fprintf(ffuncdef, "void Pwm_%s(long freq, long percent)\n", ioname);
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tstatic long oldfreq= 0;\n");
			fprintf(ffuncdef, "\tif (freq != oldfreq)\n");
			fprintf(ffuncdef, "\t\tPWM_Init(0x%2.2X, %d, %ld, %ld);\n", pwm, Prog.mcuClock, freq, resol);
			fprintf(ffuncdef, "\tPWM_Set(0x%2.2X, percent, %ld);\n", pwm, resol);
			fprintf(ffuncdef, "\toldfreq= freq;\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "void Pwm_%s_Stop(void)\n", ioname);
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tPwm_%s(0, 0);\n", ioname);				// Set freq to 0 so that PWM can be restarted
			fprintf(ffuncdef, "\tPWM_Stop(%d);\n", pwm);
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(fdev, "PWM_Init(0x%2.2X, %d, %ld, %ld);\n\n", pwm, Prog.mcuClock, freq, resol);

			PWM_Used[pwm] = 1;		// Marked as used
			}
		}

	return 1;
	}


// UART initialization
// Only 1 UART can be used in a same ladder
int Configure_Uart(int mcuisa, long bauds, FILE * fhead, FILE * ffuncdef, FILE * fdev, char * lptr)
	{
	int uart= 0;

	if (!Prog.mcu()) return 0;

	char pinName[MAX_NAME_LEN] = "";
	GetPinName(Prog.mcu()->uartNeeds.rxPin, pinName); // search for RXn / TXn pins in MCU definnition
	if(strlen(pinName)) 
		{
		const char *pos = strstr(pinName, "RX");
		if(pos)
			uart= atoi(pos + 2); // UART#
		else 
			{
			THROW_INTERNAL_EXCEPTION(_("<no UART!>"));		// No UART found in Mcu desciptor
			return 0;
			}
		}
	 else 
		{
		THROW_INTERNAL_EXCEPTION(_("<no UART!>"));		// No UART found in Mcu desciptor
		return 0;
		}

	if (mcuisa == ISA_ARM)
		{
		if (!UART_USED)
			{
			fprintf(fhead, "#include \"Lib_uart.h\"\n");
			fprintf(fhead, "\n");

			fprintf(ffuncdef, "void Uart_Transmit(unsigned char data)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tLibUart_Putc(USART%d, data);\n", uart);
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "unsigned char Uart_Receive(void)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tuint8_t c= 0;\n");
			fprintf(ffuncdef, "\tc = LibUart_Getc(USART%d);\n", uart);
			fprintf(ffuncdef, "\treturn c;\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "int Uart_Transmit_Ready(void)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tif (LibUart_Transmit_Ready(USART%d)) return 1;\n", uart);
			fprintf(ffuncdef, "\telse return 0;\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "int Uart_Receive_Avail(void)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tif (LibUart_Received_Data(USART%d)) return 1;\n", uart);
			fprintf(ffuncdef, "\telse return 0;\n");
			fprintf(ffuncdef, "\t}\n\n");
			  
			if((uart == 4) || (uart == 5))			// UART != USART
				fprintf(fdev, "LibUart_Init(UART%d, %d, USART_WordLength_8b, USART_Parity_No, USART_StopBits_1);\n", uart, bauds);
			else
				fprintf(fdev, "LibUart_Init(USART%d, %d, USART_WordLength_8b, USART_Parity_No, USART_StopBits_1);\n", uart, bauds);
			fprintf(fdev, "\n");

			UART_USED= 1;
			}
		}

	if (mcuisa == ISA_AVR)
		{
		int divisor= 0;
		double actual= 0;
		double error= 0;
		calcAvrUsart(&divisor, &actual, &error);
		testAvrUsart(divisor, actual, error);

		if (!UART_USED)
			{
			fprintf(fhead, "#include \"UartLib.h\"\n\n");

			fprintf(ffuncdef, "void Uart_Transmit(unsigned char data)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tUART_Transmit(data);\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "unsigned char Uart_Receive(void)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tuint8_t c= 0;\n");
			fprintf(ffuncdef, "\tc = UART_Receive();\n");
			fprintf(ffuncdef, "\treturn c;\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "int Uart_Transmit_Ready(void)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tif (UART_Transmit_Ready()) return 1;\n");
			fprintf(ffuncdef, "\telse return 0;\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "int Uart_Receive_Avail(void)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tif (UART_Receive_Avail()) return 1;\n");
			fprintf(ffuncdef, "\telse return 0;\n");
			fprintf(ffuncdef, "\t}\n\n");
			  
			fprintf(fdev, "UART_Init(%d);\n\n", divisor);

			UART_USED= 1;
			}
		}

	if ((mcuisa == ISA_PIC16) || (mcuisa == ISA_PIC18))		
		{
		if (!UART_USED)
			{
			fprintf(fhead, "#include \"UartLib.h\"\n\n");

			fprintf(ffuncdef, "void Uart_Transmit(unsigned char data)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tUART_Transmit(data);\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "unsigned char Uart_Receive(void)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tunsigned char c= 0;\n");
			fprintf(ffuncdef, "\tc = UART_Receive();\n");
			fprintf(ffuncdef, "\treturn c;\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "int Uart_Transmit_Ready(void)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tif (UART_Transmit_Ready()) return 1;\n");
			fprintf(ffuncdef, "\telse return 0;\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "int Uart_Receive_Avail(void)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tif (UART_Receive_Avail()) return 1;\n");
			fprintf(ffuncdef, "\telse return 0;\n");
			fprintf(ffuncdef, "\t}\n\n");
			  
			fprintf(fdev, "UART_Init(%d);\n\n", bauds);

			UART_USED= 1;
			}
		}

	return 1;
	}


// I2C initialization
// Only 1 I2C bus can be used in a same ladder
int Configure_I2c(int mcuisa, char * i2cname, long speed, FILE * fhead, FILE * ffuncdef, FILE * fdev, char * lptr)
	{
	int i2c= 0;

	if (!Prog.mcu()) return 0;

	i2c = atoi(i2cname + 3);						// I2C# or 0 if no #
	if (i2c == 0) i2c= 1;							// I2C -> I2C1
	if((I2C_USED != 0) && (I2C_USED != i2c))
		{
		THROW_INTERNAL_EXCEPTION(_("Only one I2C can be used"));
		return 0;
		}

	int  devpins[2];			// To receive SCL and SDA pins on returned port
	int i2cPort= PinsForI2cVariable(i2cname, 2, devpins);		// To force pin assignment on I2C
	if (i2cPort == 0)
		{
		THROW_INTERNAL_EXCEPTION(_("I2C functions used but not supported for this micro."));
		return 0;
		}

	if (mcuisa == ISA_ARM)
		{
		if (!I2C_USED)
			{
			fprintf(fhead, "#include \"Lib_i2c.h\"\n\n");

			fprintf(ffuncdef, "void I2C_Send(uint8_t address, long registr, uint8_t send)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tLibI2C_SetReg(I2C%d, address, registr, send);\n", i2c);
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "uint16_t I2C_Recv(uint8_t address, long registr)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tuint16_t recv= 0;\n");
			fprintf(ffuncdef, "\trecv= LibI2C_GetReg(I2C%d, address, registr);\n", i2c);
			fprintf(ffuncdef, "\treturn recv;\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(fdev, "LibI2C_MasterInit(I2C%d, %d);\n\n", i2c, Prog.i2cRate);

			I2C_USED= i2c;
			}
		}

	if (mcuisa == ISA_AVR)
		{
		if (!I2C_USED)
			{
			fprintf(fhead, "#include \"I2cLib.h\"\n\n");

			fprintf(ffuncdef, "void I2C_Send(uint8_t address, long registr, uint8_t send)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tI2C_MasterSetReg(address, registr, send);\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "char I2C_Recv(uint8_t address, long registr)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tchar recv= 0;\n");
			fprintf(ffuncdef, "\trecv= I2C_MasterGetReg(address, registr);\n");
			fprintf(ffuncdef, "\treturn recv;\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(fdev, "I2C_Init(%d, %d);\n\n", Prog.mcuClock, Prog.i2cRate);

			I2C_USED= i2c;
			}
		}

	if ((mcuisa == ISA_PIC16) || (mcuisa == ISA_PIC18))
		{
		if (SPI_USED)
			{
			THROW_INTERNAL_EXCEPTION(_("SPI & I2C can't be used together on PICs"));
			return 0;
			}

		if (!I2C_USED)
			{
			fprintf(fhead, "#include \"I2cLib.h\"\n\n");

			fprintf(ffuncdef, "void I2C_Send(char address, long registr, char send)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tI2C_MasterSetReg(address, (char) registr, send);\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "char I2C_Recv(char address, long registr)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tchar recv= 0;\n");
			fprintf(ffuncdef, "\trecv= I2C_MasterGetReg(address, (char) registr);\n");
			fprintf(ffuncdef, "\treturn recv;\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(fdev, "I2C_Init(%d, %d);\n\n", Prog.mcuClock, Prog.i2cRate);

			I2C_USED= i2c;
			}
		}

	return 1;
	}


// SPI initialization
// Only 1 SPI bus can be used in a same ladder

int Configure_Spi(int mcuisa, char * spiname, long rate, FILE * fhead, FILE * ffuncdef, FILE * fdev, char * lptr)
	{
	int spi= 0;
	char misoPin, mosiPin, sckPin, ssPin;

	if (!Prog.mcu()) return 0;

	spi = atoi(spiname + 3);						// SPI# or 0 if no #
	if (spi == 0) spi= 1;							// SPI -> SPI1
	if((SPI_USED != 0) && (SPI_USED != spi))
		{
		THROW_INTERNAL_EXCEPTION(_("Only one SPI can be used"));
		return 0;
		}

	int  devpins[4];			// To receive SPI pins on returned port
	int spiPort= PinsForSpiVariable(spiname, 4, devpins);		// To force pin assignment on SPI
	if (spiPort == 0)
		{
		THROW_INTERNAL_EXCEPTION(_("SPI functions used but not supported for this micro."));
		return 0;
		}
	else
		{
		mosiPin= devpins[0];
		misoPin= devpins[1];
		sckPin= devpins[2];
		ssPin= devpins[3];
		}

	if (mcuisa == ISA_ARM)
		{
		if (!SPI_USED)
			{
			fprintf(fhead, "#include \"Lib_spi.h\"\n\n");

			fprintf(ffuncdef, "uint8_t SPI_SendRecv(uint8_t send)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\treturn LibSPI_Send(SPI%d, send);\n", spi);
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "void SPI_Write(char * str)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tLibSPI_WriteMulti(SPI%d, str, strlen(str));\n", spi);
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(fdev, "#define SPI_RatePrescaler LibSPI_GetPrescaler(SPI%d, %d)\n", spi, Prog.spiRate);
			fprintf(fdev, "LibSPI_Init(SPI%d, LibSPI_DataSize_%db, SPI_RatePrescaler);\n\n", spi, 8);

			SPI_USED= spi;
			}
		}

	if (mcuisa == ISA_AVR)
		{
		if (!SPI_USED)
			{
			fprintf(fhead, "#include \"SpiLib.h\"\n\n");

			fprintf(fhead, "#define SPIPORT PORT%c\n", spiPort);
			fprintf(fhead, "#define SPIDDR DDR%c\n", spiPort);
			fprintf(fhead, "#define MOSI %d\n", mosiPin);
			fprintf(fhead, "#define MISO %d\n", misoPin);
			fprintf(fhead, "#define SCK %d\n", sckPin);
			fprintf(fhead, "#define SS %d\n\n", ssPin);

			fprintf(ffuncdef, "uint8_t SPI_SendRecv(uint8_t send)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\treturn SPI_Send(send);\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "void SPI_Write(char * str)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tint i= 0;\n");
			fprintf(ffuncdef, "\twhile(str[i] != 0)\n");
			fprintf(ffuncdef, "\t\t{\n");
			fprintf(ffuncdef, "\t\tSPI_Send(str[i]);\n");
			fprintf(ffuncdef, "\t\ti++;\n");
			fprintf(ffuncdef, "\t\t}\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(fdev, "SPI_Init(SPI_GetPrescaler(%d, %d));\n", Prog.mcuClock, Prog.spiRate);

			SPI_USED= spi;
			}
		}

	if ((mcuisa == ISA_PIC16) || (mcuisa == ISA_PIC18))
		{
		if (I2C_USED)
			{
			THROW_INTERNAL_EXCEPTION(_("SPI & I2C can't be used together on PICs"));
			return 0;
			}

		if (!SPI_USED)
			{
			fprintf(fhead, "#include \"SpiLib.h\"\n\n");

			fprintf(ffuncdef, "char SPI_SendRecv(char send)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\treturn SPI_Send(send);\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(ffuncdef, "void SPI_Write(char * str)\n");
			fprintf(ffuncdef, "\t{\n");
			fprintf(ffuncdef, "\tint i= 0;\n");
			fprintf(ffuncdef, "\twhile(str[i] != 0)\n");
			fprintf(ffuncdef, "\t\t{\n");
			fprintf(ffuncdef, "\t\tSPI_Send(str[i]);\n");
			fprintf(ffuncdef, "\t\ti++;\n");
			fprintf(ffuncdef, "\t\t}\n");
			fprintf(ffuncdef, "\t}\n\n");

			fprintf(fdev, "SPI_Init(SPI_GetPrescaler(%d, %d));\n", Prog.mcuClock, Prog.spiRate);

			SPI_USED= spi;
			}
		}

	return 1;
	}

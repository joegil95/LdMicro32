//-----------------------------------------------------------------------------
// Copyright 2007 Jonathan Westhues
// Copyright 2015 Nehrutsa Ihor
//
// This file is part of LDmicro.
//
// LDmicro is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// LDmicro is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with LDmicro.  If not, see <http://www.gnu.org/licenses/>.
//------
//
// An AVR assembler, for our own internal use, plus routines to generate
// code from the ladder logic structure, plus routines to generate the
// runtime needed to schedule the cycles.
// Jonathan Westhues, Oct 2004
//-----------------------------------------------------------------------------
#include "stdafx.h"

#include "ldmicro.h"



uint32_t AvrProgLdLen = 0;


//-----------------------------------------------------------------------------
// Calc AVR 8-bit Timer0
// or   AVR 16-bit Timer1 to do the timing for NPulse generator.
static bool CalcAvrTimerNPulse(double target, int *bestPrescaler, BYTE *cs, int *bestDivider, int *bestError, double *bestTarget)
	{
	int max_tmr;
	if(Prog.cycleTimer == 0)
		max_tmr = 0x10000; // used Timer1 for NPulse
	else
		max_tmr = 0x100; // used Timer0 for NPulse
	// frequency (HZ) is
	// target = mcuClock / (divider * prescaler)
	// divider = mcuClock / (target * prescaler)
	//dbp("target=%.3f", target);
	*bestDivider = -INT_MAX;
	*bestError = INT_MAX;
	double freq;
	int	err;
	int	divider;
	int	prescaler;
	for(prescaler = 1;;) 
		{
		divider = int(round((double)Prog.mcuClock / (target * prescaler)));
		freq = (double)Prog.mcuClock / (prescaler * divider);

		//dbp("prescaler=%d divider=%d freq=%f Hz",prescaler, divider, freq);

		err = (int)fabs(freq - target);
		if((err <= *bestError) && (*bestDivider < divider)) 
			{
			if(divider <= max_tmr) 
				{
				*bestError = err;
				*bestPrescaler = prescaler;
				*bestDivider = divider;
				*bestTarget = freq;
				}
			}
		if(prescaler == 1)
			prescaler = 8;
		else if(prescaler == 8)
			prescaler = 64;
		else if(prescaler == 64)
			prescaler = 256;
		else if(prescaler == 256)
			prescaler = 1024;
		else
			break;
		}
	switch(*bestPrescaler) 
		{
		case 1:
			*cs = 1;
			break;
		case 8:
			*cs = 2;
			break;
		case 64:
			*cs = 3;
			break;
		case 256:
			*cs = 4;
			break;
		case 1024:
			*cs = 5;
			break;
		default:
			oops();
			break;
		}

	//dbp("bestPrescaler=%d bestDivider=%d bestTarget=%d Hz", *bestPrescaler, *bestDivider, *bestTarget);

	return true;
	}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// Calc AVR 16-bit Timer1 or 8-bit Timer0 to do the timing of PLC cycle.
bool CalcAvrPlcCycle(long long int cycleTimeMicroseconds, uint32_t AvrProgLdLen)
	{
	//memset(plcTmr, 0, sizeof(plcTmr));
	plcTmr.softDivisor = 1;
	plcTmr.prescaler = 1;
	plcTmr.cs = 0;
	plcTmr.cycleTimeMin = (int)floor(1e6 * PLC_CLOCK_MIN * 1 / Prog.mcuClock + 0.5);
	//									 ^min_divider	^min_prescaler
	long int max_tmr, max_prescaler, max_softDivisor;
	if(Prog.cycleTimer == 0) 
		{
		max_tmr = 0xFF;		 //+1;
		max_prescaler = 1024;   // 1,8,64,256,1024
		max_softDivisor = 0xFF; // 1..0xFFFF
		} 
	else 
		{
		max_tmr = 0xFFFF;	   //+1;
		max_prescaler = 1024;   // 1,8,64,256,1024
		max_softDivisor = 0xFF; // 1..0xFF
		}
	plcTmr.cycleTimeMax = (long long int)floor(1e6 * max_tmr * max_prescaler * max_softDivisor / Prog.mcuClock + 0.5);
	if(cycleTimeMicroseconds <= 0)
		return false;
	plcTmr.ticksPerCycle = (long long int)floor(1.0 * Prog.mcuClock * cycleTimeMicroseconds / 1000000 + 0.5);
	long int	  bestTmr = LONG_MIN;
	long int	  bestPrescaler = LONG_MAX;
	long int	  bestSoftDivisor = 0;
	long long int bestErr = LLONG_MAX;
	long long int err;

	while(plcTmr.softDivisor <= max_softDivisor) 
		{
		plcTmr.prescaler = max_prescaler;
		while(plcTmr.prescaler >= 1) {
			for(plcTmr.tmr = 1; plcTmr.tmr <= max_tmr; plcTmr.tmr++) 
				{
				err = plcTmr.ticksPerCycle - (long long int)plcTmr.tmr * plcTmr.prescaler * plcTmr.softDivisor;
				if(err < 0)
					err = -err;

				if((bestErr > err) || ((bestErr == err) && (bestPrescaler < plcTmr.prescaler))) 
					{
					bestErr = err;
					bestSoftDivisor = plcTmr.softDivisor;
					bestPrescaler = plcTmr.prescaler;
					bestTmr = plcTmr.tmr;
					if(err == 0)
						goto err0;
					}
				}
			if(plcTmr.prescaler == 1)
				break;
			else if(plcTmr.prescaler == 8)
				plcTmr.prescaler = 1;
			else if(plcTmr.prescaler == 64)
				plcTmr.prescaler = 8;
			else if(plcTmr.prescaler == 256)
				plcTmr.prescaler = 64;
			else if(plcTmr.prescaler == 1024)
				plcTmr.prescaler = 256;
			else
				oops();
			}
		if(plcTmr.softDivisor == max_softDivisor)
			break;
		plcTmr.softDivisor++;
		}

err0:
	plcTmr.softDivisor = bestSoftDivisor;
	plcTmr.prescaler = bestPrescaler;
	plcTmr.tmr = bestTmr;

	plcTmr.Fcycle = 1.0 * Prog.mcuClock / (1.0 * plcTmr.softDivisor * plcTmr.prescaler * plcTmr.tmr);
	plcTmr.TCycle = 1.0 * plcTmr.prescaler * plcTmr.softDivisor * plcTmr.tmr / (1.0 * Prog.mcuClock);
	switch(plcTmr.prescaler) 
		{
		case 1:
			plcTmr.cs = 1;
			break;
		case 8:
			plcTmr.cs = 2;
			break;
		case 64:
			plcTmr.cs = 3;
			break;
		case 256:
			plcTmr.cs = 4;
			break;
		case 1024:
			plcTmr.cs = 5;
			break;
		default:
			THROW_INTERNAL_EXCEPTION_FMT("plcTmr.prescaler=%ld", plcTmr.prescaler);
		}

	if(plcTmr.tmr > max_tmr) 
		{
		Error(_("PLC cycle time more than %lld ms not valid."), plcTmr.cycleTimeMax / 1000);
		return false;
		} 
	else if((plcTmr.prescaler * plcTmr.tmr) < PLC_CLOCK_MIN) 
		{
		Error(_("PLC cycle time less than %d us not valid."), plcTmr.cycleTimeMin);
		return false;
		}
	return true;
	}

//-----------------------------------------------------------------------------
int calcAvrUsart(int *divisor, double *actual, double *error)
	{
	// bps = Fosc/(16*(X+1))
	// bps*16*(X + 1) = Fosc
	// X = Fosc/(bps*16)-1
	// and round, don't truncate
	*divisor = (Prog.mcuClock + Prog.baudRate * 8) / (Prog.baudRate * 16) - 1;

	*actual = 1.0 * Prog.mcuClock / (16.0 * (*divisor + 1));
	*error = 100.0 * (*actual - Prog.baudRate) / Prog.baudRate;

	return *divisor;
	}

//-----------------------------------------------------------------------------
int testAvrUsart(int divisor, double actual, double error)
	{
	if(fabs(error) > 2)
		ComplainAboutBaudRateError(divisor, actual, error);
	if(divisor > 4095)
		ComplainAboutBaudRateOverflow();

	return divisor;
	}

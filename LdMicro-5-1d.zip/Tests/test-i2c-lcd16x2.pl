   0:# INIT TABLES
   1:INIT TABLE signed 1 byte name[7] := {72, 101, 108, 108, 111, 32, 33}
   7:# 
   8:# ======= START RUNG 1 =======
  10:LabelRung1: // 
  11:set bit '$rung_top'
  13:# start series [
  14:# ELEM_CONTACTS
  15:if 'Ronce' {
  16:    clear bit '$rung_top'
  17:}
  19:# ELEM_LOOK_UP_TABLE name
  20:if '$rung_top' {
  21:    let var 'tab' := 'name[i]'
  22:}
  24:# ] finish series
  25:# 
  26:# ======= START RUNG 2 =======
  28:LabelRung2: // 
  29:set bit '$rung_top'
  31:# start series [
  32:# ELEM_CONTACTS
  33:if 'Ronce' {
  34:    clear bit '$rung_top'
  35:}
  37:# ELEM_I2C_WR
  38:if '$rung_top' {
  39:    I2C_WRITE 'I2C' send 'tab', done? into 'I2C'
  40:    set bit '$rung_top'
  41:}
  43:# ELEM_ADD
  44:if '$rung_top' {
  45:    increment 'i'; copy overlap(-1 to 0) flag to '$overlap'; copy overflow flag to 'ROverflowFlagV'
  46:}
  48:# ] finish series
  49:# 
  50:# ======= START RUNG 3 =======
  52:LabelRung3: // 
  53:set bit '$rung_top'
  55:# start series [
  56:# ELEM_GRT
  57:if '$rung_top' {
  58:    if 'i' <= '6' {
  59:        clear bit '$rung_top'
  60:    }
  61:}
  63:# ELEM_COIL
  64:if '$rung_top' {
  65:    set bit 'Ronce'
  66:}
  68:# ] finish series
  69:# 
  70:# ======= START RUNG 4 =======
  72:LabelRung4: // 
  73:set bit '$rung_top'
  75:# start series [
  76:# ELEM_CONTACTS
  77:if not 'Ronce' {
  78:    clear bit '$rung_top'
  79:}
  81:# ELEM_I2C_WR
  82:if '$rung_top' {
  83:    I2C_WRITE 'I2C' send '0xA0', done? into 'I2C'
  84:    set bit '$rung_top'
  85:}
  87:# ELEM_I2C_WR
  88:if '$rung_top' {
  89:    I2C_WRITE 'I2C' send ''0'', done? into 'I2C'
  90:    set bit '$rung_top'
  91:}
  93:# ELEM_COIL
  94:if '$rung_top' {
  95:    clear bit 'Rshow'
  96:} else {
  97:    set bit 'Rshow'
  98:}
 100:# ] finish series
 102:LabelRung5: // 

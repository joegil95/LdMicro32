#ifndef __LDMICRO_VER_H__
#define __LDMICRO_VER_H__

#define LDMICRO_VER_STR           "5.4.0.0"
                              //   |     |
#define LDMICRO_VER_MAJOR (5) // <-+     |
#define LDMICRO_VER_MINOR (3) //         |
#define LDMICRO_VER_PATCH (1) //         |
#define LDMICRO_VER_TWEAK (0) // <-------+

#endif

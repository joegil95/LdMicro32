/*******************************************************************************
*  file    : resource.h
*  created : 16.08.2018
*  author  : Slyshyk Oleksiy (alexslyshyk@gmail.com)
*******************************************************************************/
#ifndef RESOURCE_H
#define RESOURCE_H

#include "default_resource.h"

#ifndef RT_MANIFEST
  #define RT_MANIFEST 24
#endif

#endif // RESOURCE_H

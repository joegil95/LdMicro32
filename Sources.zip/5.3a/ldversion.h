#ifndef __LDMICRO_VER_H__
#define __LDMICRO_VER_H__

#define LDMICRO_VER_STR           "LdMicro32 5.3a"
                              //   |     |
#define LDMICRO_VER_MAJOR (5) // <-+     |
#define LDMICRO_VER_MINOR (3) //         |
#define LDMICRO_VER_PATCH (0) //         |
#define LDMICRO_VER_TWEAK (4) // <-------+

#endif
